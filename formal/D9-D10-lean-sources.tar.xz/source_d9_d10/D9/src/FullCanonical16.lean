import FullCanonical16Rows04
namespace IsolationGame.FullCanonical.T16
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
theorem full_values : Marked.gameValue original ∅ .dominator ∅=4 ∧ Marked.gameValue original ∅ .staller ∅=5 := by
  constructor
  · exact (Marked.value_eq_of_white_eq original ∅ marks_16 ∅ ∅ .dominator (by decide +kernel)).trans row_16.1
  · exact (Marked.value_eq_of_white_eq original ∅ marks_16 ∅ ∅ .staller (by decide +kernel)).trans row_16.2
theorem strict_full : MarkedSum.StrictCapacity original ∅ ∅ 5 := by
  constructor
  · rw [full_values.1] <;> decide +kernel
  · intro v hv
    fin_cases v
    · change Marked.gameValue original marks_16 .staller {0}+1≤5
      rw [after_16_0.2] <;> decide +kernel
    · change Marked.gameValue original marks_16 .staller {1}+1≤5
      rw [after_16_1.2] <;> decide +kernel
    · change Marked.gameValue original marks_16 .staller {2}+1≤5
      rw [after_16_2.2] <;> decide +kernel
    · change Marked.gameValue original marks_16 .staller {3}+1≤5
      rw [after_16_3.2] <;> decide +kernel
    · change Marked.gameValue original marks_16 .staller {4}+1≤5
      rw [after_16_4.2] <;> decide +kernel
    · change Marked.gameValue original marks_16 .staller {5}+1≤5
      rw [after_16_5.2] <;> decide +kernel
    · change Marked.gameValue original marks_16 .staller {6}+1≤5
      rw [after_16_6.2] <;> decide +kernel
    · change Marked.gameValue original marks_16 .staller {7}+1≤5
      rw [after_16_7.2] <;> decide +kernel
    · change Marked.gameValue original marks_16 .staller {8}+1≤5
      rw [after_16_8.2] <;> decide +kernel
    · change Marked.gameValue original marks_16 .staller {9}+1≤5
      rw [after_16_9.2] <;> decide +kernel
    · change Marked.gameValue original marks_16 .staller {10}+1≤5
      rw [after_16_10.2] <;> decide +kernel
#print axioms full_values
#print axioms strict_full
end IsolationGame.FullCanonical.T16
