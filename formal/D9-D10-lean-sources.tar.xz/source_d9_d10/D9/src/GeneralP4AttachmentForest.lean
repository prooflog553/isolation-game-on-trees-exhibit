import P4Attachment
import P7GraftForest

/-! Source preparation only. This file has not yet been elaborated.
The embedding retains the complete attachment carrier; it is used only to
transfer acyclicity, never to replace game states by a reduced graph. -/
namespace IsolationGame.GeneralP4Receiver
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

private def armEmbed (a : Fin 4) : Fin 7 := ⟨a.val, by omega⟩

private theorem armEmbed_injective : Function.Injective armEmbed := by
  intro a b h
  apply Fin.ext
  exact congrArg (fun x : Fin 7 => x.val) h

private theorem armEmbed_zero (a : Fin 4) : armEmbed a = 0 ↔ a = 0 := by
  revert a
  decide +kernel

private theorem armEmbed_adj : ∀ a b : Fin 4,
    CentreOrdinary.graph.Adj (armEmbed a) (armEmbed b) ↔ P4Receiver.T.Adj a b := by
  decide +kernel

/-- Attaching a genuine endpoint-rooted P4 preserves arbitrary base forests. -/
theorem attachment_acyclic {V : Type} [Fintype V] [DecidableEq V]
    (G : SimpleGraph V) (z : V) (hG : G.IsAcyclic) :
    (P4Receiver.A G z).IsAcyclic := by
  let f : P4Receiver.A G z →g P7Graft.graph G z := {
    toFun := Sum.map id armEmbed
    map_rel' := by
      intro u v h
      cases u with
      | inl u =>
        cases v with
        | inl v => exact h
        | inr v => exact ⟨h.1, (armEmbed_zero v).mpr h.2⟩
      | inr u =>
        cases v with
        | inl v => exact ⟨(armEmbed_zero u).mpr h.1, h.2⟩
        | inr v => exact (armEmbed_adj u v).mpr h }
  have hf : Function.Injective f := by
    intro u v h
    cases u with
    | inl u =>
      cases v with
      | inl v => exact congrArg Sum.inl (Sum.inl.inj h)
      | inr v => exact False.elim (Sum.noConfusion h)
    | inr u =>
      cases v with
      | inl v => exact False.elim (Sum.noConfusion h)
      | inr v => exact congrArg Sum.inr (armEmbed_injective (Sum.inr.inj h))
  intro v c hc
  exact P7Graft.graph_acyclic G z hG (c.map f) (hc.map hf)

#print axioms attachment_acyclic
end IsolationGame.GeneralP4Receiver
