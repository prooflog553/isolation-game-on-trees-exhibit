import FullCanonicalDAG
namespace IsolationGame.FullCanonical.T10
abbrev original : SimpleGraph (Fin 3) := CanonicalLocal.graph CanonicalLocal.Index.t10
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
noncomputable def perm_0 : Fin 3 ≃ Fin 3 :=
  Equiv.ofBijective (fun v => ![0,1,2] v) (by decide +kernel)
theorem adjacency_0 : ∀u v,original.Adj (perm_0 u) (perm_0 v) ↔ original.Adj u v := by decide +kernel
end IsolationGame.FullCanonical.T10
