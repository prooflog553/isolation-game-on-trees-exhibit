import BWCenterFollowers
namespace IsolationGame.BWBridge
open Isolation.Graph
open MarkedModule

/-- A nonwhite left centre prevents the bridge from creating any white
adjacency. This is normalization only, not deletion of blue moves. -/
 theorem normalize_split (p q : Nat) (L : Side p→Prop) (R : Side q→Prop)
    (hL : ¬L (root p)) :
    (view p q).noniso (whiteSum p q L R)=
      whiteSum p q (MarkedModule.graph.noniso L) (MarkedModule.graph.noniso R) := by
  funext v; apply propext
  cases v with
  | inl v =>
    constructor
    · rintro ⟨hv,w,hw,ha⟩
      cases w with
      | inl w => exact ⟨hv,w,hw,ha⟩
      | inr w =>
        have he : v=root p := ha.1
        exact False.elim (hL (he ▸ hv))
    · rintro ⟨hv,w,hw,ha⟩; exact ⟨hv,.inl w,hw,ha⟩
  | inr v =>
    constructor
    · rintro ⟨hv,w,hw,ha⟩
      cases w with
      | inr w => exact ⟨hv,w,hw,ha⟩
      | inl w =>
        have he : w=root p := ha.2
        exact False.elim (hL (he ▸ hw))
    · rintro ⟨hv,w,hw,ha⟩; exact ⟨hv,.inr w,hw,ha⟩

 theorem right_local_remove (p q : Nat) (L : Side p→Prop) (R : Side q→Prop)
    (v : Side q) (hv : v≠root q) :
    (view p q).remove (whiteSum p q L R) (.inr v)=
      whiteSum p q L (MarkedModule.graph.remove R v) := by
  funext w; apply propext; cases w with
  | inl w => simp [Isolation.Graph.remove,Isolation.Graph.closed,whiteSum,Isolation.Graph.whiteSum,
      view,original,Attachment.original,GuardedEdge.view,hv]
  | inr w => simp [Isolation.Graph.remove,Isolation.Graph.closed,whiteSum,Isolation.Graph.whiteSum,
      view,original,Attachment.original,GuardedEdge.view,MarkedModule.graph]

 theorem right_local_step (p q : Nat) (L : Side p→Prop) (R : Side q→Prop)
    (hL : ¬L (root p)) (hLn : MarkedModule.graph.noniso L=L)
    (v : Side q) (hv : v≠root q) :
    (view p q).step (whiteSum p q L R) (.inr v)=
      whiteSum p q L (MarkedModule.step R v) := by
  unfold Isolation.Graph.step
  rw [right_local_remove p q L R v hv,normalize_split p q _ _ hL,hLn]

 theorem right_middle_step (p q : Nat) (σ : State (Fin p)) (τ : State (Fin q)) (i : Fin q) :
    (view p q).step (whiteSum p q (white σ) (WhiteReserve.whiteRoot τ)) (.inr (.gate (some i)))=
      whiteSum p q (white σ) (white (set τ i (afterGate (τ i)))) := by
  rw [right_local_step p q _ _ (by simp [root,white]) (module_normalized σ) _ (by simp [root])]
  rw [WhiteReserve.middle_step]

 theorem right_middle_value (p q : Nat) (hq : 1≤q) (i : Fin q) (t : Player) :
    Marked.gameValue (original p q) (marks p q) t {.inr (.gate (some i))}=
      Marked.gameValue (MarkedSum.original MarkedModule.original MarkedModule.original)
        (MarkedSum.combine (MarkedModule.initialMarks (B:=Fin p))
          (MarkedModule.stateMarks (set (whole q) i (.opened true true)))) t ∅ := by
  apply split_value p q _ _ _ _ (white (whole p)) (white (set (whole q) i (.opened true true)))
  · have h := ForestFoundation.marked_white_step (original p q) (marks p q) ∅ (.inr (.gate (some i)))
    rw [initial_white p q hq] at h
    simp only [Finset.insert_empty] at h
    exact h.symm.trans (right_middle_step p q (whole p) (whole q) i)
  · exact pure_white p
  · exact MarkedModule.stateMarks_white _
  · simp [root,white]
  · simp [root,white]

#print axioms right_middle_value
end IsolationGame.BWBridge
