import CenterT08ReceiverModel
import CoreFamilyAdjacency
import MarkedRelabel
import AttachmentGraph
import Profile_08
import Mathlib.Tactic.FinCases

namespace IsolationGame.CenterT08Receiver
open CoreFamily CanonicalLocal

abbrev PureV (p : Nat) := CoreFamily.Vertex [] p
abbrev SplitV (p : Nat) := Sum (PureV p) (Fin 11)

def toSplit (p : Nat) : Vertex p → SplitV p
  | .inl v => Fin.cases (.inl none) (fun j => .inr j) v
  | .inr (.inl (i,r)) => .inl (some ⟨Fin.cast (Nat.zero_add p).symm i,r⟩)
  | .inr (.inr (i,_)) => Fin.elim0 i

def fromSplit (p : Nat) : SplitV p → Vertex p
  | .inl none => fixed p 0
  | .inl (some ⟨i,r⟩) => ordinary p (Fin.cast (Nat.zero_add p) i) r
  | .inr j => fixed p j.succ

def splitEquiv (p : Nat) : Vertex p ≃ SplitV p where
  toFun := toSplit p
  invFun := fromSplit p
  left_inv := by
    intro v
    cases v with
    | inl v => refine Fin.cases ?_ ?_ v
               · simp [toSplit,fromSplit,fixed,TwoPool.fixed]
               · intro j; simp [toSplit,fromSplit,fixed,TwoPool.fixed]
    | inr v => cases v with
      | inl v => rcases v with ⟨i,r⟩; simp [toSplit,fromSplit,ordinary,TwoPool.ordinaryLeft,Fin.cast,Fin.cast]
      | inr v => exact Fin.elim0 v.1
  right_inv := by
    intro v
    cases v with
    | inl v => cases v with
      | none => simp [toSplit,fromSplit,fixed,TwoPool.fixed]
      | some v => rcases v with ⟨i,r⟩; simp [toSplit,fromSplit,ordinary,TwoPool.ordinaryLeft,Fin.cast,Fin.cast]
    | inr v => simp [toSplit,fromSplit,fixed,TwoPool.fixed]

abbrev splitGraph (p : Nat) := Attachment.original
  (CoreFamily.graph [] p) LocalProfile.e0E0D1L2.original none 0

theorem shifted_adj : ∀j k : Fin 11,
    fixedGraph.Adj j.succ k.succ ↔ LocalProfile.e0E0D1L2.original.Adj j k := by
  decide +kernel

theorem root_shifted_adj : ∀j : Fin 11,
    fixedGraph.Adj 0 j.succ ↔ j=0 := by
  decide +kernel

theorem root_ordinary_adj (p : Nat) (i : Fin p) (r : Fin 7) :
    (CoreFamily.graph [] p).Adj none (some ⟨Fin.cast (Nat.zero_add p).symm i,r⟩) ↔ r=0 := by
  rw [CoreFamily.family_root_adj]
  simp [CoreFamily.label,CanonicalLocal.root]

theorem ordinary_ordinary_adj (p : Nat) (i j : Fin p) (r s : Fin 7) :
    (CoreFamily.graph [] p).Adj
      (some ⟨Fin.cast (Nat.zero_add p).symm i,r⟩)
      (some ⟨Fin.cast (Nat.zero_add p).symm j,s⟩) ↔
        i=j ∧ CentreOrdinary.graph.Adj r s := by
  by_cases hij : i=j
  · subst j
    rw [CoreFamily.family_same_adj]
    simp only [eq_self_iff_true,true_and]
    simp [CoreFamily.label] at *
    fin_cases r <;> fin_cases s <;> decide +kernel
  · have hj : Fin.cast (Nat.zero_add p).symm i ≠ Fin.cast (Nat.zero_add p).symm j := by
      simpa using hij
    have hh := CoreFamily.family_distinct_no_adj [] p _ _ hj r s
    simp [hij,hh]

theorem splitEquiv_adj (p : Nat) (u v : Vertex p) :
    (splitGraph p).Adj (splitEquiv p u) (splitEquiv p v) ↔ (graph p).Adj u v := by
  cases u with
  | inl u =>
    induction u using Fin.cases with
    | zero =>
      cases v with
      | inl v =>
        induction v using Fin.cases with
        | zero => simp [splitEquiv,toSplit,splitGraph,graph,fixedGraph,
                        Attachment.original,TwoPool.graph]
        | succ j =>
          simpa [splitEquiv,toSplit,splitGraph,graph,Attachment.original,
                 TwoPool.graph] using (root_shifted_adj j).symm
      | inr v =>
        cases v with
        | inl a =>
          rcases a with ⟨i,r⟩
          simpa [splitEquiv,toSplit,splitGraph,graph,Attachment.original,
                 TwoPool.graph] using (root_ordinary_adj p i r)
        | inr a => exact Fin.elim0 a.1
    | succ j =>
      cases v with
      | inl v =>
        induction v using Fin.cases with
        | zero =>
          have h := root_shifted_adj j
          rw [fixedGraph.adj_comm] at h
          simpa [splitEquiv,toSplit,splitGraph,graph,Attachment.original,
                 TwoPool.graph] using h.symm
        | succ k =>
          simpa [splitEquiv,toSplit,splitGraph,graph,Attachment.original,
                 TwoPool.graph] using (shifted_adj j k).symm
      | inr v =>
        cases v with
        | inl a =>
          rcases a with ⟨i,r⟩
          simp [splitEquiv,toSplit,splitGraph,graph,Attachment.original,
                TwoPool.graph,Fin.succ_ne_zero]
        | inr a => exact Fin.elim0 a.1
  | inr u =>
    cases u with
    | inl a =>
      rcases a with ⟨i,r⟩
      cases v with
      | inl v =>
        induction v using Fin.cases with
        | zero =>
          have h := root_ordinary_adj p i r
          rw [(CoreFamily.graph [] p).adj_comm] at h
          simpa [splitEquiv,toSplit,splitGraph,graph,Attachment.original,
                 TwoPool.graph] using h
        | succ j =>
          simp [splitEquiv,toSplit,splitGraph,graph,Attachment.original,
                TwoPool.graph,Fin.succ_ne_zero]
      | inr v =>
        cases v with
        | inl b =>
          rcases b with ⟨j,s⟩
          simpa [splitEquiv,toSplit,splitGraph,graph,Attachment.original,
                 TwoPool.graph] using (ordinary_ordinary_adj p i j r s)
        | inr b => exact Fin.elim0 b.1
    | inr a => exact Fin.elim0 a.1

theorem marks_image (p : Nat) :
    (marks p).image (splitEquiv p) =
      MarkedSum.combine ({none} : Finset (PureV p)) (∅ : Finset (Fin 11)) := by
  classical
  ext v
  cases v with
  | inl v =>
    cases v with
    | none =>
      simp [marks,TwoPool.marks,splitEquiv,toSplit,MarkedSum.combine,
            MarkedSum.liftLeft,MarkedSum.liftRight]
    | some v =>
      rcases v with ⟨i,r⟩
      simp [marks,TwoPool.marks,splitEquiv,toSplit,MarkedSum.combine,
            MarkedSum.liftLeft,MarkedSum.liftRight]
  | inr j =>
    simp [marks,TwoPool.marks,splitEquiv,toSplit,MarkedSum.combine,
          MarkedSum.liftLeft,MarkedSum.liftRight]

theorem value_split (p : Nat) (t : Player) (X : Finset (Vertex p)) :
    Marked.gameValue (graph p) (marks p) t X =
      Marked.gameValue (splitGraph p)
        (MarkedSum.combine ({none} : Finset (PureV p)) ∅) t (X.image (splitEquiv p)) := by
  rw [←marks_image]
  exact (Marked.gameValue_relabel (graph p) (splitGraph p) (splitEquiv p)
    (splitEquiv_adj p) (marks p) X t).symm

#print axioms splitEquiv_adj
#print axioms value_split
end IsolationGame.CenterT08Receiver
