import CoreFamilyReindex

/-! SOURCE-ONLY candidate. Stable nonordinary sublist, exact ordinary pool.
No canonical-code validity assumption: in particular all invalid codes, whose
decode is t00, stay in the nonordinary list verbatim and with multiplicity.
-/
namespace IsolationGame.CoreFamily
open CanonicalLocal NecessaryCore

/-- Stable filter; raw nonordinary codes are neither canonicalized nor removed. -/
def nonordinaryCodes (xs : List Nat) : List Nat :=
  xs.filter (fun n => decide (decode n ≠ .t02))

/-- Literal number of positions decoding to the ordinary profile. -/
def ordinaryCount : List Nat → Nat
  | [] => 0
  | n::xs => if decode n = .t02 then ordinaryCount xs+1 else ordinaryCount xs

@[simp] theorem ordinaryCount_nil : ordinaryCount [] = 0 := rfl
@[simp] theorem ordinaryCount_cons (n : Nat) (xs : List Nat) :
    ordinaryCount (n::xs) =
      if decode n = .t02 then ordinaryCount xs+1 else ordinaryCount xs := rfl

/-- The count agrees with the standard boolean list count. -/
theorem ordinaryCount_eq_countP (xs : List Nat) :
    ordinaryCount xs = xs.countP (fun n => decide (decode n = .t02)) := by
  induction xs with
  | nil => rfl
  | cons n xs ih =>
    by_cases h : decode n = .t02 <;>
      simp [ordinaryCount,List.countP_cons,h,ih,Nat.add_comm]

@[simp] theorem mem_nonordinaryCodes (xs : List Nat) (n : Nat) :
    n ∈ nonordinaryCodes xs ↔ n∈xs ∧ decode n ≠ .t02 := by
  simp [nonordinaryCodes]

theorem nonordinaryCodes_length_add_count (xs : List Nat) :
    (nonordinaryCodes xs).length + ordinaryCount xs = xs.length := by
  induction xs with
  | nil => rfl
  | cons n xs ih =>
    by_cases h : decode n = .t02 <;>
      simp [nonordinaryCodes,ordinaryCount,h] at * <;> omega

/-- The head and shifted-tail index maps. -/
def headIndex (n : Nat) (xs : List Nat) (q : Nat) :
    Fin ((n::xs).length+q) := ⟨0,by simp⟩

def tailIndex (n : Nat) (xs : List Nat) (q : Nat)
    (i : Fin (xs.length+q)) : Fin ((n::xs).length+q) :=
  ⟨i.val+1,by
    have hi := i.isLt
    change i.val+1 < xs.length+1+q
    omega⟩

@[simp] theorem label_headIndex (n : Nat) (xs : List Nat) (q : Nat) :
    label (n::xs) q (headIndex n xs q) = decode n := by
  simp [label,headIndex]

@[simp] theorem label_tailIndex (n : Nat) (xs : List Nat) (q : Nat)
    (i : Fin (xs.length+q)) :
    label (n::xs) q (tailIndex n xs q i) = label xs q i := by
  by_cases h : i.val < xs.length
  · have h' : i.val+1 < (n::xs).length := by simpa using Nat.succ_lt_succ h
    simp [label,tailIndex,h,h']
  · have h' : ¬i.val+1 < (n::xs).length := by simpa using h
    simp [label,tailIndex,h,h']

/-- Exact decomposition into the first position and all remaining positions. -/
def headTailEquiv (n : Nat) (xs : List Nat) (q : Nat) :
    Option (Fin (xs.length+q)) ≃ Fin ((n::xs).length+q) where
  toFun
    | none => headIndex n xs q
    | some i => tailIndex n xs q i
  invFun i := if h : i.val=0 then none else
    some ⟨i.val-1,by
      have hi : i.val < xs.length+1+q := by
        simpa only [List.length_cons] using i.isLt
      change i.val-1 < xs.length+q
      omega⟩
  left_inv := by
    intro i
    cases i with
    | none => simp [headIndex]
    | some i => simp [tailIndex]
  right_inv := by
    intro i
    dsimp
    split_ifs with h
    · apply Fin.ext
      simpa [headIndex] using h.symm
    · apply Fin.ext
      have := i.isLt
      simp [tailIndex]
      omega

@[simp] theorem headTailEquiv_none (n : Nat) (xs : List Nat) (q : Nat) :
    headTailEquiv n xs q none = headIndex n xs q := rfl
@[simp] theorem headTailEquiv_some (n : Nat) (xs : List Nat) (q : Nat)
    (i : Fin (xs.length+q)) :
    headTailEquiv n xs q (some i) = tailIndex n xs q i := rfl

/-- Append one new pool position after all existing list and pool positions. -/
def poolLastEquiv (xs : List Nat) (q : Nat) :
    Option (Fin (xs.length+q)) ≃ Fin (xs.length+(q+1)) where
  toFun
    | none => ⟨xs.length+q,by omega⟩
    | some i => ⟨i.val,by have := i.isLt; omega⟩
  invFun i := if h : i.val<xs.length+q then some ⟨i.val,h⟩ else none
  left_inv := by
    intro i
    cases i with
    | none => simp
    | some i => simp [i.isLt]
  right_inv := by
    intro i
    dsimp
    split_ifs with h
    · rfl
    · apply Fin.ext
      have := i.isLt
      dsimp
      omega

@[simp] theorem label_poolLast_none (xs : List Nat) (q : Nat) :
    label xs (q+1) (poolLastEquiv xs q none) = .t02 := by
  have h : ¬xs.length+q < xs.length := by omega
  simp [label,poolLastEquiv,h]

@[simp] theorem label_poolLast_some (xs : List Nat) (q : Nat)
    (i : Fin (xs.length+q)) :
    label xs (q+1) (poolLastEquiv xs q (some i)) = label xs q i := by
  exact label_eq_of_val_eq xs _ _ rfl

namespace LabelReindex

/-- Retain one identical raw head and lift a tail's exact label reindexing. -/
def cons {xs ys : List Nat} {q r : Nat} (e : LabelReindex xs q ys r) (n : Nat) :
    LabelReindex (n::xs) q (n::ys) r where
  indexEquiv := (headTailEquiv n xs q).symm.trans
    ((Equiv.optionCongr e.indexEquiv).trans (headTailEquiv n ys r))
  label_eq := by
    intro i
    obtain ⟨a,rfl⟩ := (headTailEquiv n xs q).surjective i
    simp only [Equiv.trans_apply,Equiv.symm_apply_apply]
    cases a with
    | none =>
      change label (n::xs) q (headIndex n xs q) =
        label (n::ys) r (headIndex n ys r)
      rw [label_headIndex,label_headIndex]
    | some a =>
      change label (n::xs) q (tailIndex n xs q a) =
        label (n::ys) r (tailIndex n ys r (e.indexEquiv a))
      rw [label_tailIndex,label_tailIndex]
      exact e.label_eq a

end LabelReindex

/-- Move an ordinary head into the last pool position. Every other branch
retains its relative order and every local coordinate is retained. -/
def ordinaryHeadReindex (n : Nat) (xs : List Nat) (q : Nat)
    (hn : decode n = .t02) : LabelReindex (n::xs) q xs (q+1) where
  indexEquiv := (headTailEquiv n xs q).symm.trans (poolLastEquiv xs q)
  label_eq := by
    intro i
    obtain ⟨a,rfl⟩ := (headTailEquiv n xs q).surjective i
    simp only [Equiv.trans_apply,Equiv.symm_apply_apply]
    cases a with
    | none =>
      change label (n::xs) q (headIndex n xs q) = label xs (q+1) (poolLastEquiv xs q none)
      rw [label_headIndex,label_poolLast_none]
      exact hn
    | some a =>
      change label (n::xs) q (tailIndex n xs q a) =
        label xs (q+1) (poolLastEquiv xs q (some a))
      rw [label_tailIndex,label_poolLast_some]

/-- Exact normalization index bijection, by induction on the actual list.
The stable nonordinary filter is used without sorting or re-encoding. -/
theorem exists_ordinaryNormalizationReindex (xs : List Nat) (q : Nat) :
    Nonempty (LabelReindex xs q (nonordinaryCodes xs) (q+ordinaryCount xs)) := by
  induction xs generalizing q with
  | nil =>
    simpa [nonordinaryCodes,ordinaryCount] using
      (show Nonempty (LabelReindex [] q [] q) from ⟨LabelReindex.refl [] q⟩)
  | cons n xs ih =>
    by_cases hn : decode n = .t02
    · obtain ⟨e⟩ := ih (q+1)
      have f := (ordinaryHeadReindex n xs q hn).trans e
      exact ⟨by simpa [nonordinaryCodes,ordinaryCount,hn,
        Nat.add_assoc,Nat.add_left_comm,Nat.add_comm] using f⟩
    · obtain ⟨e⟩ := ih q
      exact ⟨by simpa [nonordinaryCodes,ordinaryCount,hn] using e.cons n⟩

noncomputable def ordinaryNormalizationReindex (xs : List Nat) (q : Nat) :
    LabelReindex xs q (nonordinaryCodes xs) (q+ordinaryCount xs) :=
  Classical.choice (exists_ordinaryNormalizationReindex xs q)

/-- Requested complete rooted graph normalization. -/
noncomputable def ordinaryNormalizationIso (xs : List Nat) (q : Nat) :
    graph xs q ≃g graph (nonordinaryCodes xs) (q+ordinaryCount xs) :=
  (ordinaryNormalizationReindex xs q).graphIso

@[simp] theorem ordinaryNormalizationIso_root (xs : List Nat) (q : Nat) :
    ordinaryNormalizationIso xs q none = none := rfl

theorem ordinaryNormalization_rootedIso (xs : List Nat) (q : Nat) :
    RootedAssembly.RootedIso (graph xs q) none
      (graph (nonordinaryCodes xs) (q+ordinaryCount xs)) none :=
  (ordinaryNormalizationReindex xs q).rootedIso

/-- Arbitrary marks/history transport through ordinary normalization. -/
theorem ordinaryNormalization_white (xs : List Nat) (q : Nat)
    (M X : Finset (Vertex xs q)) (v : Vertex xs q) :
    Marked.White (graph (nonordinaryCodes xs) (q+ordinaryCount xs))
      (M.image (ordinaryNormalizationIso xs q)) (X.image (ordinaryNormalizationIso xs q))
      (ordinaryNormalizationIso xs q v) ↔ Marked.White (graph xs q) M X v :=
  (ordinaryNormalizationReindex xs q).white M X v

theorem ordinaryNormalization_legal (xs : List Nat) (q : Nat)
    (M X : Finset (Vertex xs q)) (v : Vertex xs q) :
    Marked.Legal (graph (nonordinaryCodes xs) (q+ordinaryCount xs))
      (M.image (ordinaryNormalizationIso xs q)) (X.image (ordinaryNormalizationIso xs q))
      (ordinaryNormalizationIso xs q v) ↔ Marked.Legal (graph xs q) M X v :=
  (ordinaryNormalizationReindex xs q).legal M X v

theorem ordinaryNormalization_value (xs : List Nat) (q : Nat)
    (M X : Finset (Vertex xs q)) (t : Player) :
    Marked.gameValue (graph (nonordinaryCodes xs) (q+ordinaryCount xs))
      (M.image (ordinaryNormalizationIso xs q)) t (X.image (ordinaryNormalizationIso xs q)) =
      Marked.gameValue (graph xs q) M t X :=
  (ordinaryNormalizationReindex xs q).gameValue M X t

#print axioms exists_ordinaryNormalizationReindex
#print axioms ordinaryNormalizationIso
#print axioms ordinaryNormalization_rootedIso
end IsolationGame.CoreFamily
