import ExceptionalCoreReceiver
import ReceiverBudgetExceptionBridge

namespace IsolationGame.CompletePositiveReceiver
open CanonicalLocal AllProfileCore PairableProfileCore UniversalProfileBudget
  ReceiverBudgetExceptions

abbrev Vertex (xs : List Nat) (q k p : Nat) := UniversalReceiverThresholds.Vertex xs q k p
abbrev graph (xs : List Nat) (q k p : Nat) := UniversalReceiverThresholds.graph xs q k p

/-- On the exact exception class, the improved scalar is exactly 3n/7. -/
theorem exceptional_scalar_eq_floor (xs : List Nat) (q p : Nat)
    (hp : pairCount xs=1) (hs : slackSum xs=0) :
    3*(p+q)+cost xs+4 = 3*Fintype.card (Vertex xs q 2 p)/7 := by
  have hw := listSlack_exact xs
  rw [UniversalReceiverThresholds.order,coreOrder_eq_sizeSum]
  omega

/-- Restricted floor conclusion for precisely the single-special class.
This is not an unrestricted k=2 floor assertion. -/
theorem ordinary_exceptional_floor (xs : List Nat) (q p : Nat)
    (hx : SingleSpecial xs) :
    isolationNumber (graph xs q 2 p) ≤ 3*Fintype.card (Vertex xs q 2 p)/7 := by
  obtain ⟨hp,hs⟩ := (singleSpecial_iff_pair_one_slack_zero xs).mp hx
  have hshape := (slackSum_zero_iff xs).mp hs
  have hu := ExceptionalCoreReceiver.ordinary_scalar_upper xs q p hshape (by omega)
  have he := exceptional_scalar_eq_floor xs q p hp hs
  exact hu.trans_eq he

/-- The missing k=2 ceiling case is completed on this exact receiver family,
including every finite natural-number list and all p,q. -/
theorem ordinary_k2_ceil (xs : List Nat) (q p : Nat) :
    isolationNumber (graph xs q 2 p) ≤
      (3*Fintype.card (Vertex xs q 2 p)+6)/7 := by
  classical
  by_cases hx : SingleSpecial xs
  · have h := ordinary_exceptional_floor xs q p hx
    exact h.trans (by omega)
  · exact ReceiverBudgetExceptionBridge.ordinary_k2_ceil_outside_exceptions xs q p hx

/-- Unconditional in the core profile list; the receiver parameter is
positive. No assertion about all diameter-nine trees follows from this. -/
theorem ordinary_ceil_of_positive_k (xs : List Nat) (q k p : Nat) (hk : 1≤k) :
    isolationNumber (graph xs q k p) ≤
      (3*Fintype.card (Vertex xs q k p)+6)/7 := by
  by_cases he : k=2
  · subst k
    exact ordinary_k2_ceil xs q p
  · exact UniversalReceiverThresholds.ordinary_ceil_of_k xs q k p (by omega)

/-- Same literal full graph for geometry, carrier order, and ordinary game. -/
theorem family_tree_diameter_order_ceil (xs : List Nat) (q k p : Nat) (hk : 1≤k) :
    (graph xs q k p).IsTree ∧ (graph xs q k p).diam ≤ 9 ∧
    Fintype.card (Vertex xs q k p)=coreOrder xs+1+4*k+7*(p+q) ∧
    isolationNumber (graph xs q k p) ≤
      (3*Fintype.card (Vertex xs q k p)+6)/7 :=
  ⟨UniversalReceiverThresholds.graph_tree xs q k p,
    UniversalReceiverThresholds.diam_le_nine xs q k p,
    UniversalReceiverThresholds.order xs q k p,
    ordinary_ceil_of_positive_k xs q k p hk⟩

#print axioms exceptional_scalar_eq_floor
#print axioms ordinary_exceptional_floor
#print axioms ordinary_k2_ceil
#print axioms ordinary_ceil_of_positive_k
#print axioms family_tree_diameter_order_ceil
end IsolationGame.CompletePositiveReceiver
