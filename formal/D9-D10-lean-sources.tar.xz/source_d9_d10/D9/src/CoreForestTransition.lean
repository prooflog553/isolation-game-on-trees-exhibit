import CoreRootOpening

namespace IsolationGame.CoreForest
open CanonicalLocal CoreFamily CoreFamilySemantics IsolatedRestriction
variable (xs : List Nat) (p : Nat)

def moveVertex (i : Fin (xs.length+p)) (u : Fin (size (label xs p i))) : DeletedVertex xs p :=
  ⟨some ⟨i,u⟩,by simp [MarkedBoundary.retained]⟩

/-- Deleting the genuinely marked, unselected centre preserves the current
white set, while still removing its POSSIBLE move. This is a white identity,
not a free value-deletion claim. -/
theorem deleted_white (W : LocalWhite xs p) (X : Finset (Vertex xs p)) (hz : none∉X)
    (u : DeletedVertex xs p) :
    Marked.White (forest xs p) (forestMarks xs p W) (restrict (MarkedBoundary.retained none) X) u ↔
      Marked.White (CoreFamily.graph xs p) (marks xs p W) X u.val := by
  have hi := IsolatedRestriction.white_iff
    (MarkedBoundary.isolateVertex (CoreFamily.graph xs p) none)
    (MarkedBoundary.retained none) (MarkedBoundary.edges_inside (CoreFamily.graph xs p) none)
    (marks xs p W) X u
  rw [MarkedBoundary.induced_isolated_eq] at hi
  have hw := MarkedBoundary.white_eq_unspent (CoreFamily.graph xs p) none (marks xs p W) X
    (root_marked xs p W) hz
  exact hi.symm.trans (congrFun hw u.val).symm.to_iff

theorem deleted_legal (W : LocalWhite xs p) (X : Finset (Vertex xs p)) (hz : none∉X)
    (u : DeletedVertex xs p) :
    Marked.Legal (forest xs p) (forestMarks xs p W) (restrict (MarkedBoundary.retained none) X) u ↔
      Marked.Legal (CoreFamily.graph xs p) (marks xs p W) X u.val := by
  have hi := IsolatedRestriction.legal_iff
    (MarkedBoundary.isolateVertex (CoreFamily.graph xs p) none)
    (MarkedBoundary.retained none) (MarkedBoundary.edges_inside (CoreFamily.graph xs p) none)
    (marks xs p W) X u
  rw [MarkedBoundary.induced_isolated_eq] at hi
  have hu : u.val≠none := (Finset.mem_erase.mp u.property).1
  exact hi.symm.trans (MarkedBoundary.legal_iff_unspent (CoreFamily.graph xs p) none
    (marks xs p W) X (root_marked xs p W) hz u.val hu).symm

theorem restrict_empty : restrict (MarkedBoundary.retained (none : Vertex xs p)) ∅=∅ := by
  ext v
  simp

theorem restrict_move (i : Fin (xs.length+p)) (u : Fin (size (label xs p i))) :
    restrict (MarkedBoundary.retained (none : Vertex xs p)) {some ⟨i,u⟩}={moveVertex xs p i u} := by
  have h := IsolatedRestriction.restrict_insert (MarkedBoundary.retained (none : Vertex xs p)) ∅
    (moveVertex xs p i u)
  simpa only [restrict_empty,Finset.insert_empty] using h

theorem legal_local (W : LocalWhite xs p) (hn : Normalized xs p W)
    (i : Fin (xs.length+p)) (u : Fin (size (label xs p i))) :
    Marked.Legal (forest xs p) (forestMarks xs p W) ∅ (moveVertex xs p i u) ↔
      (GuardedEdge.view (CanonicalLocal.graph (label xs p i))).legal (W i) u := by
  have h := deleted_legal xs p W ∅ (by simp) (moveVertex xs p i u)
  rw [restrict_empty] at h
  exact h.trans (actual_legal_local xs p W hn i u)

theorem local_next_white (W : LocalWhite xs p) (hn : Normalized xs p W)
    (i : Fin (xs.length+p)) (u : Fin (size (label xs p i))) (v : DeletedVertex xs p) :
    Marked.White (forest xs p) (forestMarks xs p W) {moveVertex xs p i u} v ↔
      Marked.White (forest xs p) (forestMarks xs p (playLocal xs p W i u)) ∅ v := by
  have h1 := deleted_white xs p W {some ⟨i,u⟩} (by simp) v
  rw [restrict_move] at h1
  have h2 := deleted_white xs p (playLocal xs p W i u) ∅ (by simp) v
  rw [restrict_empty] at h2
  exact h1.trans ((original_next_white xs p W hn (some ⟨i,u⟩) v.val).trans h2.symm)

theorem local_next_value (W : LocalWhite xs p) (hn : Normalized xs p W)
    (i : Fin (xs.length+p)) (u : Fin (size (label xs p i))) (turn : Player) :
    Marked.gameValue (forest xs p) (forestMarks xs p W) turn {moveVertex xs p i u}=
      Marked.gameValue (forest xs p) (forestMarks xs p (playLocal xs p W i u)) turn ∅ :=
  Marked.value_eq_of_white_eq _ _ _ _ _ turn (local_next_white xs p W hn i u)

theorem d_move_upper (W : LocalWhite xs p) (hn : Normalized xs p W)
    (i : Fin (xs.length+p)) (u : Fin (size (label xs p i)))
    (hu : (GuardedEdge.view (CanonicalLocal.graph (label xs p i))).legal (W i) u)
    (k : Nat) (hk : Marked.gameValue (forest xs p) (forestMarks xs p (playLocal xs p W i u)) .staller ∅≤k) :
    Marked.gameValue (forest xs p) (forestMarks xs p W) .dominator ∅≤1+k := by
  have h := Marked.d_move_upper (forest xs p) (forestMarks xs p W) ∅
    (moveVertex xs p i u) ((legal_local xs p W hn i u).mpr hu)
  simp only [Finset.insert_empty] at h
  rw [local_next_value xs p W hn] at h
  omega

theorem s_responses_upper (W : LocalWhite xs p) (hn : Normalized xs p W) (k : Nat)
    (hall : ∀i u,(GuardedEdge.view (CanonicalLocal.graph (label xs p i))).legal (W i) u →
      1+Marked.gameValue (forest xs p) (forestMarks xs p (playLocal xs p W i u)) .dominator ∅≤k) :
    Marked.gameValue (forest xs p) (forestMarks xs p W) .staller ∅≤k := by
  by_cases ht : Marked.Terminal (forest xs p) (forestMarks xs p W) ∅
  · rw [(Marked.value_zero_iff_terminal _ _ _ _).mpr ht]
    exact Nat.zero_le _
  · obtain ⟨v,hv,he⟩ := Marked.exists_optimal_s_move (forest xs p) (forestMarks xs p W) ∅ ht
    rcases v with ⟨v,hvret⟩
    cases v with
    | none => simp [MarkedBoundary.retained] at hvret
    | some v =>
      obtain ⟨i,u⟩ := v
      change Marked.Legal (forest xs p) (forestMarks xs p W) ∅ (moveVertex xs p i u) at hv
      have h := hall i u ((legal_local xs p W hn i u).mp hv)
      simp only [Finset.insert_empty] at he
      change Marked.gameValue (forest xs p) (forestMarks xs p W) .staller ∅=
        1+Marked.gameValue (forest xs p) (forestMarks xs p W) .dominator {moveVertex xs p i u} at he
      rw [local_next_value xs p W hn] at he
      omega

#print axioms local_next_value
#print axioms d_move_upper
#print axioms s_responses_upper
end IsolationGame.CoreForest
