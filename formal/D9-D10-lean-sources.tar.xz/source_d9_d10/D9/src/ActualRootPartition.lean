import ActualRootBranches
import NestedBranches

/-!
Candidate generated 2026-10-19. Verification status is recorded in native receipts.
This module exposes the exact full-carrier tree partition already proved in
RootedAssemblyGeometry. Every vertex appears once: the root or exactly one
actual root-neighbor descendant component. No cardinality-only replacement
for this bijection is used.
-/
namespace IsolationGame.ActualRootPartition
open ActualRootBranches IsolatedRestriction SmallPiece
variable {V : Type} [Fintype V] [DecidableEq V]

abbrev Code (G : SimpleGraph V) (r : V) :=
  Option (Σ a : Child G r, Active (piece G r a))

def realize (G : SimpleGraph V) (r : V) : Code G r → V
  | none => r
  | some ⟨_,v⟩ => v.val

theorem realize_bijective (G : SimpleGraph V) (hG : G.IsTree) (r : V) :
    Function.Bijective (realize G r) := by
  constructor
  · intro x y he
    cases x with
    | none =>
      cases y with
      | none => rfl
      | some y =>
        obtain ⟨a,v⟩ := y
        change r = v.val at he
        exact False.elim (root_not_piece G r a ((congrArg (fun z => z ∈ piece G r a) he).mpr v.property))
    | some x =>
      obtain ⟨a,u⟩ := x
      cases y with
      | none =>
        change u.val = r at he
        exact False.elim (root_not_piece G r a ((congrArg (fun z => z ∈ piece G r a) he).mp u.property))
      | some y =>
        obtain ⟨b,v⟩ := y
        have hv : u.val = v.val := he
        have hab := unique_piece G hG r a b u.val u.property (hv.symm ▸ v.property)
        subst b
        have huv : u = v := Subtype.ext hv
        subst v
        rfl
  · intro v
    by_cases hv : v = r
    · exact ⟨none,hv.symm⟩
    · obtain ⟨a,ha⟩ := covered_by_piece G hG r v hv
      exact ⟨some ⟨a,⟨v,ha⟩⟩,rfl⟩

noncomputable def realizeEquiv (G : SimpleGraph V) (hG : G.IsTree) (r : V) :
    Code G r ≃ V := Equiv.ofBijective (realize G r) (realize_bijective G hG r)

theorem root_adj (G : SimpleGraph V) (hG : G.IsTree) (r : V)
    (a : Child G r) (u : Active (piece G r a)) : G.Adj r u.val ↔ u.val = a.val := by
  classical
  constructor
  · intro h
    let b : Child G r := ⟨u.val, by simp [children,h]⟩
    have hab := unique_piece G hG r a b u.val u.property (self_mem_piece G r b)
    exact (congrArg Subtype.val hab).symm
  · intro h
    rw [h]
    exact child_edge G r a

theorem no_cross (G : SimpleGraph V) (hG : G.IsTree) (r : V)
    (a b : Child G r) (hab : a ≠ b) (u : Active (piece G r a)) (v : Active (piece G r b)) :
    ¬G.Adj u.val v.val := by
  classical
  have hun : u.val ≠ r := fun h => root_not_piece G r a ((congrArg (fun z => z ∈ piece G r a) h).mp u.property)
  have hvn : v.val ≠ r := fun h => root_not_piece G r b ((congrArg (fun z => z ∈ piece G r b) h).mp v.property)
  let u' : Active (MarkedBoundary.retained r) := ⟨u.val, Finset.mem_erase.mpr ⟨hun,Finset.mem_univ _⟩⟩
  let v' : Active (MarkedBoundary.retained r) := ⟨v.val, Finset.mem_erase.mpr ⟨hvn,Finset.mem_univ _⟩⟩
  have hu : u' ∈ component G r a := (mem_restrict _ _ u').mpr u.property
  have hv : v' ∈ component G r b := (mem_restrict _ _ v').mpr v.property
  exact components_noCross G hG r a b hab u' hu v' hv

@[simp] theorem realizeEquiv_none (G : SimpleGraph V) (hG : G.IsTree) (r : V) :
    realizeEquiv G hG r none = r := rfl

@[simp] theorem realizeEquiv_some (G : SimpleGraph V) (hG : G.IsTree) (r : V)
    (a : Child G r) (u : Active (piece G r a)) :
    realizeEquiv G hG r (some ⟨a,u⟩) = u.val := rfl

#print axioms realize_bijective
#print axioms root_adj
#print axioms no_cross
end IsolationGame.ActualRootPartition
