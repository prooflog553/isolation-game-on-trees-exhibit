import GeneralP4StarModel
import OneP4Transport
import MarkedRelabel

/-! Full-carrier, full-history and arbitrary-turn transport.
No vertex is deleted and no numerical cardinality cast stands in for a graph map.
The ordinary P7 pool is fixed pointwise by every P4 branch permutation.
Source preparation only; pending explicit permission to run Lean. -/
namespace IsolationGame.GeneralP4Receiver
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

section FixedRelabel
variable {F U : Type} [Fintype F] [DecidableEq F] [Fintype U] [DecidableEq U]

def liftFixedEquiv (e : F ≃ U) (p q : Nat) :
    TwoPool.Vertex F p q ≃ TwoPool.Vertex U p q :=
  Equiv.sumCongr e (Equiv.refl _)

theorem liftFixed_adj (G : SimpleGraph F) (H : SimpleGraph U) (e : F ≃ U)
    (he : ∀ u v, H.Adj (e u) (e v) ↔ G.Adj u v)
    (z : F) (w : U) (hr : e z=w) (p q : Nat)
    (u v : TwoPool.Vertex F p q) :
    (TwoPool.graph H w w p q).Adj (liftFixedEquiv e p q u) (liftFixedEquiv e p q v) ↔
      (TwoPool.graph G z z p q).Adj u v := by
  have hroot (x : F) : e x=w ↔ x=z := by
    rw [←hr]
    exact e.injective.eq_iff
  rcases u with u | (⟨i,r⟩|⟨i,r⟩)
  all_goals rcases v with v | (⟨j,s⟩|⟨j,s⟩)
  all_goals simp [liftFixedEquiv,TwoPool.graph,he,hroot]

/-- Only reassociation of tagged sums; even the unused Fin0 summand is preserved. -/
def reassocTo (p q : Nat) : TwoPool.Vertex (F ⊕ Fin 4) p q →
    TwoPool.Vertex F p q ⊕ Fin 4
  | .inl (.inl v) => .inl (.inl v)
  | .inl (.inr r) => .inr r
  | .inr v => .inl (.inr v)

def reassocFrom (p q : Nat) : TwoPool.Vertex F p q ⊕ Fin 4 →
    TwoPool.Vertex (F ⊕ Fin 4) p q
  | .inl (.inl v) => .inl (.inl v)
  | .inl (.inr v) => .inr v
  | .inr r => .inl (.inr r)

def reassocEquiv (p q : Nat) : TwoPool.Vertex (F ⊕ Fin 4) p q ≃
    TwoPool.Vertex F p q ⊕ Fin 4 where
  toFun := reassocTo p q
  invFun := reassocFrom p q
  left_inv := by intro v; rcases v with (v|r) | v <;> rfl
  right_inv := by intro v; rcases v with (v|v) | r <;> rfl

theorem reassoc_adj (G : SimpleGraph F) (z : F) (p q : Nat)
    (u v : TwoPool.Vertex (F ⊕ Fin 4) p q) :
    (Attachment.original (TwoPool.graph G z z p q) P4Receiver.T
      (TwoPool.fixed p q z) 0).Adj (reassocEquiv p q u) (reassocEquiv p q v) ↔
    (TwoPool.graph (Attachment.original G P4Receiver.T z 0)
      (Sum.inl z) (Sum.inl z) p q).Adj u v := by
  rcases u with (u|r) | (⟨i,a⟩|⟨i,a⟩)
  all_goals rcases v with (v|s) | (⟨j,b⟩|⟨j,b⟩)
  all_goals simp [reassocEquiv,reassocTo,Attachment.original,TwoPool.graph,TwoPool.fixed]
end FixedRelabel

abbrev SplitV (k p : Nat) := Vertex k p ⊕ Fin 4
abbrev splitGraph (k p : Nat) :=
  Attachment.original (graph k p) P4Receiver.T (centre k p) 0

def splitEquiv (k p : Nat) : Vertex (k+1) p ≃ SplitV k p :=
  (liftFixedEquiv (splitFixed k) p 0).trans (reassocEquiv p 0)

@[simp] theorem split_centre (k p : Nat) :
    splitEquiv k p (centre (k+1) p) = .inl (centre k p) := rfl
@[simp] theorem split_new_branch (k p : Nat) (r : Fin 4) :
    splitEquiv k p (branch (k+1) p 0 r) = .inr r := rfl
@[simp] theorem split_old_branch (k p : Nat) (i : Fin k) (r : Fin 4) :
    splitEquiv k p (branch (k+1) p i.succ r) = .inl (branch k p i r) := rfl
@[simp] theorem split_ordinary (k p : Nat) (i : Fin p) (r : Fin 7) :
    splitEquiv k p (ordinary (k+1) p i r) = .inl (ordinary k p i r) := rfl

theorem splitEquiv_adj (k p : Nat) (u v : Vertex (k+1) p) :
    (splitGraph k p).Adj (splitEquiv k p u) (splitEquiv k p v) ↔
      (graph (k+1) p).Adj u v := by
  have h1 := liftFixed_adj (fixedGraph (k+1))
    (Attachment.original (fixedGraph k) P4Receiver.T (root k) 0)
    (splitFixed k) (splitFixed_adj k) (root (k+1)) (.inl (root k)) rfl p 0 u v
  have h2 := reassoc_adj (fixedGraph k) (root k) p 0
    (liftFixedEquiv (splitFixed k) p 0 u) (liftFixedEquiv (splitFixed k) p 0 v)
  exact h2.trans h1

theorem split_marks (k p : Nat) :
    (marks (k+1) p).image (splitEquiv k p) = MarkedSum.combine (marks k p) ∅ := by
  simp [marks,TwoPool.marks,centre,fixed,root,splitEquiv,liftFixedEquiv,
    splitFixed,splitFixedTo,reassocEquiv,reassocTo,MarkedSum.combine,
    MarkedSum.liftLeft,MarkedSum.liftRight]

/-- All histories and both turns, with the actual initial marks. -/
theorem value_split (k p : Nat) (t : Player) (X : Finset (Vertex (k+1) p)) :
    Marked.gameValue (graph (k+1) p) (marks (k+1) p) t X =
      Marked.gameValue (splitGraph k p) (MarkedSum.combine (marks k p) ∅)
        t (X.image (splitEquiv k p)) := by
  rw [←split_marks]
  exact (Marked.gameValue_relabel (graph (k+1) p) (splitGraph k p) (splitEquiv k p)
    (splitEquiv_adj k p) (marks (k+1) p) X t).symm

theorem legal_split (k p : Nat) (X : Finset (Vertex (k+1) p)) (v : Vertex (k+1) p) :
    Marked.Legal (splitGraph k p) (MarkedSum.combine (marks k p) ∅)
      (X.image (splitEquiv k p)) (splitEquiv k p v) ↔
    Marked.Legal (graph (k+1) p) (marks (k+1) p) X v := by
  rw [←split_marks]
  exact Marked.legal_relabel _ _ _ (splitEquiv_adj k p) _ _ _

/-- Arbitrary branch permutations, with no finite-k matrix certification. -/
def fixedPerm (k : Nat) (e : Equiv.Perm (Fin k)) : Fixed k ≃ Fixed k :=
  Equiv.optionCongr (Equiv.prodCongr e (Equiv.refl _))

theorem fixedPerm_adj (k : Nat) (e : Equiv.Perm (Fin k)) (u v : Fixed k) :
    (fixedGraph k).Adj (fixedPerm k e u) (fixedPerm k e v) ↔ (fixedGraph k).Adj u v := by
  rcases u with _ | ⟨i,r⟩
  all_goals rcases v with _ | ⟨j,s⟩
  all_goals simp [fixedPerm,fixedGraph,e.injective.eq_iff]

def permuteEquiv (k p : Nat) (e : Equiv.Perm (Fin k)) : Vertex k p ≃ Vertex k p :=
  liftFixedEquiv (fixedPerm k e) p 0

@[simp] theorem permute_centre (k p : Nat) (e : Equiv.Perm (Fin k)) :
    permuteEquiv k p e (centre k p) = centre k p := rfl
@[simp] theorem permute_branch (k p : Nat) (e : Equiv.Perm (Fin k))
    (i : Fin k) (r : Fin 4) :
    permuteEquiv k p e (branch k p i r) = branch k p (e i) r := rfl
@[simp] theorem permute_ordinary (k p : Nat) (e : Equiv.Perm (Fin k))
    (i : Fin p) (r : Fin 7) :
    permuteEquiv k p e (ordinary k p i r) = ordinary k p i r := rfl

theorem permuteEquiv_adj (k p : Nat) (e : Equiv.Perm (Fin k)) (u v : Vertex k p) :
    (graph k p).Adj (permuteEquiv k p e u) (permuteEquiv k p e v) ↔
      (graph k p).Adj u v :=
  liftFixed_adj (fixedGraph k) (fixedGraph k) (fixedPerm k e) (fixedPerm_adj k e)
    (root k) (root k) rfl p 0 u v

theorem permute_marks (k p : Nat) (e : Equiv.Perm (Fin k)) :
    (marks k p).image (permuteEquiv k p e) = marks k p := by
  simp [marks,TwoPool.marks,root,permuteEquiv,liftFixedEquiv,fixedPerm]

theorem value_permute (k p : Nat) (e : Equiv.Perm (Fin k)) (t : Player)
    (X : Finset (Vertex k p)) :
    Marked.gameValue (graph k p) (marks k p) t X =
      Marked.gameValue (graph k p) (marks k p) t (X.image (permuteEquiv k p e)) := by
  have h := Marked.gameValue_relabel (graph k p) (graph k p) (permuteEquiv k p e)
    (permuteEquiv_adj k p e) (marks k p) X t
  rw [permute_marks] at h
  exact h.symm

theorem legal_permute (k p : Nat) (e : Equiv.Perm (Fin k))
    (X : Finset (Vertex k p)) (v : Vertex k p) :
    Marked.Legal (graph k p) (marks k p) (X.image (permuteEquiv k p e))
      (permuteEquiv k p e v) ↔ Marked.Legal (graph k p) (marks k p) X v := by
  have h := Marked.legal_relabel (graph k p) (graph k p) (permuteEquiv k p e)
    (permuteEquiv_adj k p e) (marks k p) X v
  rw [permute_marks] at h
  exact h

#print axioms splitEquiv_adj
#print axioms value_split
#print axioms legal_split
#print axioms fixedPerm_adj
#print axioms value_permute
#print axioms legal_permute
end IsolationGame.GeneralP4Receiver
