import FloorLocalBase
import FloorLocalRow001
import FloorLocalRow018
import FloorLocalRow019
import FloorLocalRow066
set_option maxRecDepth 4096
set_option maxHeartbeats 1000000
namespace IsolationGame.FloorLocal
def marks_109 : Finset (Fin 7) := {1,2,3}
theorem normalized_109 : ∀v : Fin 7, Marked.White original_02 marks_109 ∅ v ↔ v∈({0,4,5,6} : Finset (Fin 7)) := by decide +kernel
theorem after_109_0 : Marked.gameValue original_02 marks_109 .dominator {0}=1 ∧ Marked.gameValue original_02 marks_109 .staller {0}=1 :=
  LocalProfile.DAG.transport original_02 marks_109 marks_019 0 1 1 (by decide +kernel) row_019
theorem after_109_1 : Marked.gameValue original_02 marks_109 .dominator {1}=1 ∧ Marked.gameValue original_02 marks_109 .staller {1}=2 :=
  LocalProfile.DAG.transport original_02 marks_109 marks_066 1 1 2 (by decide +kernel) row_066
theorem after_109_4 : Marked.gameValue original_02 marks_109 .dominator {4}=0 ∧ Marked.gameValue original_02 marks_109 .staller {4}=0 :=
  LocalProfile.DAG.transport original_02 marks_109 marks_001 4 0 0 (by decide +kernel) row_001
theorem after_109_5 : Marked.gameValue original_02 marks_109 .dominator {5}=0 ∧ Marked.gameValue original_02 marks_109 .staller {5}=0 :=
  LocalProfile.DAG.transport original_02 marks_109 marks_001 5 0 0 (by decide +kernel) row_001
theorem after_109_6 : Marked.gameValue original_02 marks_109 .dominator {6}=1 ∧ Marked.gameValue original_02 marks_109 .staller {6}=1 :=
  LocalProfile.DAG.transport original_02 marks_109 marks_018 6 1 1 (by decide +kernel) row_018
theorem row_109 : Marked.gameValue original_02 marks_109 .dominator ∅=1 ∧ Marked.gameValue original_02 marks_109 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original_02 marks_109 1 2 4 0 (by decide +kernel) (by decide +kernel)
  · rw [after_109_4.2]
  · rw [after_109_0.1]
  · intro v hv
    fin_cases v
    · have h := after_109_0
      change 1≤1+Marked.gameValue original_02 marks_109 .staller {0} ∧ 1+Marked.gameValue original_02 marks_109 .dominator {0}≤2
      omega
    · have h := after_109_1
      change 1≤1+Marked.gameValue original_02 marks_109 .staller {1} ∧ 1+Marked.gameValue original_02 marks_109 .dominator {1}≤2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_109 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_109 ∅ 3) hv)
    · have h := after_109_4
      change 1≤1+Marked.gameValue original_02 marks_109 .staller {4} ∧ 1+Marked.gameValue original_02 marks_109 .dominator {4}≤2
      omega
    · have h := after_109_5
      change 1≤1+Marked.gameValue original_02 marks_109 .staller {5} ∧ 1+Marked.gameValue original_02 marks_109 .dominator {5}≤2
      omega
    · have h := after_109_6
      change 1≤1+Marked.gameValue original_02 marks_109 .staller {6} ∧ 1+Marked.gameValue original_02 marks_109 .dominator {6}≤2
      omega
#print axioms row_109
end IsolationGame.FloorLocal
