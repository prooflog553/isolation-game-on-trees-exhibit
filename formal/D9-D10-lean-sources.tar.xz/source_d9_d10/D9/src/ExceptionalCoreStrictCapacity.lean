import PairableProfileSelectedBudget
import PureModuleStrict
import GenericSelectedRoot

/-! SOURCE-ONLY until separately compiled. Strict capacity for selected-root
cores whose labels are t01, t02, t08, with at least one pairable copy.
All values and all legal followers stay on the original full carrier. -/
namespace IsolationGame.ExceptionalCoreStrict
open CanonicalLocal CoreFamily CoreFamilySemantics CoreForest
  AllProfileCore PairableProfileCore

set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

def localClosed (t : Index) : Fin (size t) → Prop :=
  (GuardedEdge.view (CanonicalLocal.graph t)).noniso
    (fun v => True ∧ v ≠ root t)

abbrev closed (xs : List Nat) (q : Nat) : LocalWhite xs q :=
  closeCentre xs q (initialLocal xs q)

theorem closed_local (xs : List Nat) (q : Nat) (i : Fin (xs.length+q)) :
    closed xs q i = localClosed (label xs q i) :=
  AllProfileCore.initial_closed_local xs q i

theorem closed_normalized (xs : List Nat) (q : Nat) :
    Normalized xs q (closed xs q) :=
  next_normalized xs q (initialLocal xs q) (initial_normalized xs q) none

theorem local_closed_legal (t : Index) (u : Fin (size t)) :
    Marked.Legal (CanonicalLocal.graph t) {root t} ∅ u ↔
      (GuardedEdge.view (CanonicalLocal.graph t)).legal (localClosed t) u := by
  constructor
  · rintro ⟨v, hc, hw⟩
    rw [AllProfileCore.root_only_white] at hw
    exact ⟨v, hw, (GuardedEdge.closed_agree _ _ _).mpr hc⟩
  · rintro ⟨v, hw, hc⟩
    refine ⟨v, (GuardedEdge.closed_agree _ _ _).mp hc, ?_⟩
    rw [AllProfileCore.root_only_white]
    exact hw

/-- Every original action is preserved by this follower identity. -/
theorem local_closed_follow_value (t : Index) (u : Fin (size t)) (turn : Player) :
    Marked.gameValue (CanonicalLocal.graph t)
      (ForestFoundation.canonicalMarks
        ((GuardedEdge.view (CanonicalLocal.graph t)).step (localClosed t) u)) turn ∅ =
      Marked.gameValue (CanonicalLocal.graph t) {root t} turn {u} := by
  have hs := ForestFoundation.marked_white_step (CanonicalLocal.graph t) {root t} ∅ u
  rw [AllProfileCore.root_only_white] at hs
  change (GuardedEdge.view (CanonicalLocal.graph t)).step (localClosed t) u = _ at hs
  simp only [Finset.insert_empty] at hs
  have hv := Marked.canonical_mark_value (CanonicalLocal.graph t) {root t} {u} turn
  rw [←hs] at hv
  exact hv.symm

/-- The ordinary copy has the same one-move reduction after its root is
closed. This uses white inclusion in the accepted all-white certificate. -/
theorem ordinary_closed_follow (u : Fin (size .t02)) :
    Marked.gameValue (CanonicalLocal.graph .t02)
      (ForestFoundation.canonicalMarks
        ((GuardedEdge.view (CanonicalLocal.graph .t02)).step (localClosed .t02) u))
      .staller ∅ + 1 ≤ expectedS .t02 := by
  let G := CanonicalLocal.graph .t02
  let P := (GuardedEdge.view G).step (localClosed .t02) u
  let Q := (GuardedEdge.view G).step (fun _ => True) u
  have hnP : (GuardedEdge.view G).noniso P = P := by
    exact funext (fun v => propext ((GuardedEdge.view G).normalize_idempotent _ v))
  have hnQ : (GuardedEdge.view G).noniso Q = Q := by
    exact funext (fun v => propext ((GuardedEdge.view G).normalize_idempotent _ v))
  have hsub : ∀v, Marked.White G (ForestFoundation.canonicalMarks P) ∅ v →
      Marked.White G (ForestFoundation.canonicalMarks Q) ∅ v := by
    intro v hv
    apply (ForestFoundation.canonical_white G Q hnQ v).mpr
    apply (GuardedEdge.view G).step_mono (localClosed .t02) (fun _ => True)
      (fun _ _ => trivial) u v
    exact (ForestFoundation.canonical_white G P hnP v).mp hv
  have hm := Marked.value_of_white_subset G
    (ForestFoundation.canonicalMarks P) (ForestFoundation.canonicalMarks Q) ∅ ∅ .staller hsub
  have hq := PureModuleStrict.local_follow_S u
  change Marked.gameValue G (ForestFoundation.canonicalMarks Q) .staller ∅ ≤ 2 at hq
  change Marked.gameValue G (ForestFoundation.canonicalMarks P) .staller ∅ + 1 ≤ 3
  omega

/-- The local follower property is established for each legal original
vertex. It is not inferred from the initial D/S gap. -/
theorem local_closed_follow (t : Index)
    (ht : t=.t01 ∨ t=.t02 ∨ t=.t08) (u : Fin (size t))
    (hu : (GuardedEdge.view (CanonicalLocal.graph t)).legal (localClosed t) u) :
    Marked.gameValue (CanonicalLocal.graph t)
      (ForestFoundation.canonicalMarks
        ((GuardedEdge.view (CanonicalLocal.graph t)).step (localClosed t) u))
      .staller ∅ + 1 ≤ expectedS t := by
  rcases ht with rfl | rfl | rfl
  · rw [local_closed_follow_value]
    have h := (CanonicalLocal.strict_exact .t01).mpr rfl
    simpa only [Finset.insert_empty] using h.2 u ((local_closed_legal _ _).mpr hu)
  · exact ordinary_closed_follow u
  · rw [local_closed_follow_value]
    have h := (CanonicalLocal.strict_exact .t08).mpr rfl
    simpa only [Finset.insert_empty] using h.2 u ((local_closed_legal _ _).mpr hu)

/-- A strict local copy supplies a legal D move whose follower saves two
units of its S capacity. The extra unit pays the actual move. -/
theorem local_d_witness (t : Index) (hp : pairable t=true) :
    ∃u : Fin (size t),
      (GuardedEdge.view (CanonicalLocal.graph t)).legal (localClosed t) u ∧
      Marked.gameValue (CanonicalLocal.graph t)
        (ForestFoundation.canonicalMarks
          ((GuardedEdge.view (CanonicalLocal.graph t)).step (localClosed t) u))
        .staller ∅ + 2 ≤ expectedS t := by
  have hpos : 0 < expectedS t := by cases t <;> simp_all [pairable,expectedS]
  have hnt : ¬Marked.Terminal (CanonicalLocal.graph t) {root t} ∅ := by
    apply (Marked.value_pos_iff_nonterminal _ _ _ .staller).mp
    rw [CanonicalLocal.S_value]
    exact hpos
  obtain ⟨u,hu,he⟩ := Marked.exists_optimal_d_move (CanonicalLocal.graph t) {root t} ∅ hnt
  refine ⟨u, (local_closed_legal t u).mp hu, ?_⟩
  rw [local_closed_follow_value]
  have hd := ((CanonicalLocal.strict_exact t).mpr hp).1
  simp only [Finset.insert_empty] at he
  omega

/-- One specified summand loses k, without truncated-subtraction mistakes. -/
theorem reduced_sum {n : Nat} (c : Fin n → Nat) (i : Fin n) (k : Nat) (hk : k ≤ c i) :
    (∑j : Fin n, if j=i then c j-k else c j) + k = ∑j : Fin n, c j := by
  classical
  let d : Fin n → Nat := fun j => if j=i then c j-k else c j
  have h1 := Finset.add_sum_erase Finset.univ c (Finset.mem_univ i)
  have h2 := Finset.add_sum_erase Finset.univ d (Finset.mem_univ i)
  have hi : d i = c i-k := by simp [d]
  have hr : (∑j ∈ (Finset.univ : Finset (Fin n)).erase i, d j) =
      ∑j ∈ (Finset.univ : Finset (Fin n)).erase i, c j := by
    apply Finset.sum_congr rfl
    intro j hj
    exact if_neg (Finset.mem_erase.mp hj).1
  rw [hi,hr] at h2
  change (∑j, d j)+k = _
  omega

/-- Genuine separated-forest bound after one move, with its exact local
saving. All unplayed components retain their full accepted S capacity. -/
theorem forest_after_bound (xs : List Nat) (q : Nat)
    (i : Fin (xs.length+q)) (u : Fin (size (label xs q i))) (k : Nat)
    (hb : Marked.gameValue (CanonicalLocal.graph (label xs q i))
      (ForestFoundation.canonicalMarks
        ((GuardedEdge.view (CanonicalLocal.graph (label xs q i))).step (closed xs q i) u))
      .staller ∅ + k ≤ expectedS (label xs q i)) :
    Marked.gameValue (forest xs q)
      (forestMarks xs q (playLocal xs q (closed xs q) i u)) .staller ∅ + k ≤
      ∑j : Fin (xs.length+q), expectedS (label xs q j) := by
  classical
  let c : Fin (xs.length+q) → Nat := fun j => expectedS (label xs q j)
  let d : Fin (xs.length+q) → Nat := fun j => if j=i then c j-k else c j
  have hc : ∀j, Marked.gameValue (CanonicalLocal.graph (label xs q j))
      (ForestFoundation.canonicalMarks (playLocal xs q (closed xs q) i u j)) .staller ∅ ≤ d j := by
    intro j
    by_cases hj : j=i
    · subst j
      simp only [playLocal,Function.update_self,d,if_pos rfl]
      change _ ≤ expectedS (label xs q i)-k
      omega
    · simp only [playLocal,Function.update_of_ne hj,d,if_neg hj]
      rw [closed_local]
      exact (AllProfileCore.closed_profile_S _).le
  have hf := mixed_s_upper xs q (CoreFamily.family_tree xs q).IsAcyclic
    (playLocal xs q (closed xs q) i u) d ∅ hc (by simp)
  simp only [Finset.card_empty,Nat.zero_div,Nat.sub_zero] at hf
  have hk : k ≤ c i := by change k ≤ expectedS (label xs q i); omega
  have hs := reduced_sum c i k hk
  change (∑j, d j)+k=∑j,c j at hs
  change _ ≤ ∑j,c j
  omega

theorem label_shape (xs : List Nat) (q : Nat)
    (hshape : ∀n ∈ xs, NecessaryCore.decode n=.t01 ∨
      NecessaryCore.decode n=.t02 ∨ NecessaryCore.decode n=.t08)
    (i : Fin (xs.length+q)) :
    label xs q i=.t01 ∨ label xs q i=.t02 ∨ label xs q i=.t08 := by
  unfold CoreFamily.label
  split
  · exact hshape _ (List.get_mem xs _)
  · exact Or.inr (Or.inl rfl)

/-- Complete strict capacity of the actually separated closed forest. -/
theorem closed_forest_strict (xs : List Nat) (q : Nat)
    (hshape : ∀n ∈ xs, NecessaryCore.decode n=.t01 ∨
      NecessaryCore.decode n=.t02 ∨ NecessaryCore.decode n=.t08)
    (hp : 0 < pairCount xs) :
    MarkedSum.StrictCapacity (forest xs q) (forestMarks xs q (closed xs q)) ∅
      (∑j : Fin (xs.length+q), expectedS (label xs q j)) := by
  classical
  constructor
  · have hicard : 0 < (pairIndices xs q).card := by rw [pairIndices_card]; exact hp
    obtain ⟨i,hi⟩ := Finset.card_pos.mp hicard
    have hip := (Finset.mem_filter.mp hi).2
    obtain ⟨u,hu,hb⟩ := local_d_witness (label xs q i) hip
    rw [←closed_local xs q i] at hu hb
    have hf := forest_after_bound xs q i u 2 hb
    have hd := CoreForest.d_move_upper xs q (closed xs q) (closed_normalized xs q)
      i u hu _ (Nat.le_refl _)
    omega
  · intro v hv
    rcases v with ⟨v,hret⟩
    cases v with
    | none => simp [MarkedBoundary.retained] at hret
    | some v =>
      obtain ⟨i,u⟩ := v
      change Marked.Legal (forest xs q) (forestMarks xs q (closed xs q)) ∅
        (moveVertex xs q i u) at hv
      have hu := (CoreForest.legal_local xs q (closed xs q) (closed_normalized xs q) i u).mp hv
      rw [closed_local] at hu
      have hb := local_closed_follow (label xs q i) (label_shape xs q hshape i) u hu
      rw [←closed_local xs q i] at hb
      have hf := forest_after_bound xs q i u 1 hb
      simp only [Finset.insert_empty]
      change Marked.gameValue (forest xs q) (forestMarks xs q (closed xs q))
        .staller {moveVertex xs q i u} + 1 ≤ _
      rw [local_next_value xs q (closed xs q) (closed_normalized xs q)]
      exact hf

theorem played_closed_roots_nonwhite (xs : List Nat) (q : Nat)
    (i : Fin (xs.length+q)) (u : Fin (size (label xs q i))) :
    ∀j, ¬playLocal xs q (closed xs q) i u j (root (label xs q j)) := by
  intro j
  by_cases hj : j=i
  · subst j
    simp only [playLocal,Function.update_self]
    intro hw
    exact closed_roots_nonwhite xs q (initialLocal xs q) i
      ((GuardedEdge.view (CanonicalLocal.graph (label xs q i))).step_subset _ _ _ hw)
  · simp only [playLocal,Function.update_of_ne hj]
    exact closed_roots_nonwhite xs q (initialLocal xs q) j

/-- Return to the full original carrier: its centre remains an original
vertex, but it is genuinely illegal in this state and in each follower. -/
theorem closed_full_strict (xs : List Nat) (q : Nat)
    (hshape : ∀n ∈ xs, NecessaryCore.decode n=.t01 ∨
      NecessaryCore.decode n=.t02 ∨ NecessaryCore.decode n=.t08)
    (hp : 0 < pairCount xs) :
    MarkedSum.StrictCapacity (CoreFamily.graph xs q) (marks xs q (closed xs q)) ∅
      (∑j : Fin (xs.length+q), expectedS (label xs q j)) := by
  have hf := closed_forest_strict xs q hshape hp
  constructor
  · rw [free_root_value xs q (closed xs q) (closed_normalized xs q)
      (closed_roots_nonwhite xs q (initialLocal xs q))]
    exact hf.1
  · intro v hv
    cases v with
    | none =>
      obtain ⟨i,hi⟩ := (actual_legal_root xs q (closed xs q) (closed_normalized xs q)).mp hv
      exact False.elim (closed_roots_nonwhite xs q (initialLocal xs q) i hi)
    | some v =>
      obtain ⟨i,u⟩ := v
      have hu := (actual_legal_local xs q (closed xs q) (closed_normalized xs q) i u).mp hv
      have hl := (CoreForest.legal_local xs q (closed xs q) (closed_normalized xs q) i u).mpr hu
      have hs := hf.2 (moveVertex xs q i u) hl
      simp only [Finset.insert_empty] at hs ⊢
      rw [local_next_value xs q (closed xs q) (closed_normalized xs q)] at hs
      rw [original_next_value xs q (closed xs q) (closed_normalized xs q)]
      change Marked.gameValue (CoreFamily.graph xs q)
        (marks xs q (playLocal xs q (closed xs q) i u)) .staller ∅ + 1 ≤ _
      rw [free_root_value xs q (playLocal xs q (closed xs q) i u)
        (next_normalized xs q (closed xs q) (closed_normalized xs q) (some ⟨i,u⟩))
        (played_closed_roots_nonwhite xs q i u)]
      exact hs

/-- Full white equivalence, sufficient for both initial D and every legal
follower, rather than just equality of a current value. -/
theorem selected_closed_white (xs : List Nat) (q : Nat) (v : Vertex xs q) :
    Marked.White (CoreFamily.graph xs q) {none} {none} v ↔
      Marked.White (CoreFamily.graph xs q) (marks xs q (closed xs q)) ∅ v := by
  have hi : Marked.White (CoreFamily.graph xs q) {none} ∅ = white xs q (initialLocal xs q) := by
    funext w
    exact propext (initial_original_white xs q w)
  have hs := ForestFoundation.marked_white_step (CoreFamily.graph xs q) {none} ∅ none
  rw [hi] at hs
  change (GuardedEdge.view (CoreFamily.graph xs q)).step (white xs q (initialLocal xs q)) none = _ at hs
  rw [step_eq_next xs q (initialLocal xs q) (initial_normalized xs q)] at hs
  simp only [Finset.insert_empty] at hs
  rw [←hs]
  exact (original_white xs q (closed xs q) (closed_normalized xs q) v).symm

/-- Actual selected-root strictness on the unchanged full core graph. -/
theorem root_selected_strict (xs : List Nat) (q : Nat)
    (hshape : ∀n ∈ xs, NecessaryCore.decode n=.t01 ∨
      NecessaryCore.decode n=.t02 ∨ NecessaryCore.decode n=.t08)
    (hp : 0 < pairCount xs) :
    MarkedSum.StrictCapacity (CoreFamily.graph xs q) {none} {none} (3*q+cost xs) := by
  have hf := closed_full_strict xs q hshape hp
  have he : (∑j : Fin (xs.length+q), expectedS (label xs q j)) = 3*q+cost xs := by
    rw [AllProfileCore.sum_label]
    simp [cost,expectedS,Nat.mul_comm,Nat.add_comm]
  rw [he] at hf
  exact (MarkedSum.strictCapacity_iff_of_white_iff (CoreFamily.graph xs q)
    {none} (marks xs q (closed xs q)) {none} ∅ (3*q+cost xs)
    (selected_closed_white xs q)).mpr hf

theorem root_selected_strict_pair_one (xs : List Nat) (q : Nat)
    (hshape : ∀n ∈ xs, NecessaryCore.decode n=.t01 ∨
      NecessaryCore.decode n=.t02 ∨ NecessaryCore.decode n=.t08)
    (hp : pairCount xs=1) :
    MarkedSum.StrictCapacity (CoreFamily.graph xs q) {none} {none} (3*q+cost xs) :=
  root_selected_strict xs q hshape (by omega)

/-- Exactly the empty-history playedMarks state produced by the actual
first-root Attachment.after_left_root_value split. -/
theorem root_playedMarks_strict (xs : List Nat) (q : Nat)
    (hshape : ∀n ∈ xs, NecessaryCore.decode n=.t01 ∨
      NecessaryCore.decode n=.t02 ∨ NecessaryCore.decode n=.t08)
    (hp : 0 < pairCount xs) :
    MarkedSum.StrictCapacity (CoreFamily.graph xs q)
      (SelectedVertex.playedMarks (CoreFamily.graph xs q) ∅ none) ∅ (3*q+cost xs) := by
  apply (MarkedSum.strictCapacity_iff_of_white_iff (CoreFamily.graph xs q)
    (SelectedVertex.playedMarks (CoreFamily.graph xs q) ∅ none) {none}
    ∅ {none} (3*q+cost xs) ?_).mpr (root_selected_strict xs q hshape hp)
  intro v
  rw [GenericCoreReceiver.played_self_marks_eq]
  have h1 := congrFun (SelectedVertex.absorb_white (CoreFamily.graph xs q) {none} ∅ none) v
  exact (Iff.of_eq h1).symm

#print axioms ordinary_closed_follow
#print axioms local_closed_follow
#print axioms local_d_witness
#print axioms closed_forest_strict
#print axioms closed_full_strict
#print axioms root_selected_strict
#print axioms root_playedMarks_strict
end IsolationGame.ExceptionalCoreStrict
