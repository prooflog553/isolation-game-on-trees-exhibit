import GeneralP4StrongBounds
import OriginalBridge

/-! Every bound here retains every original action. The guarded comparison
uses the actual after-3 mark set and its exact initial white predicate. -/
namespace IsolationGame.GeneralP4Receiver
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

section LocalAttachment
variable {V : Type} [Fintype V] [DecidableEq V]

theorem p4_after3_D : Marked.gameValue P4Receiver.T (P4Receiver.after 3) .dominator ∅=1 := by
  apply LocalProfile.value_of_horizons _ _ .dominator 1
  · decide +kernel
  · exact Or.inr (by decide +kernel)

theorem p4_after3_S : Marked.gameValue P4Receiver.T (P4Receiver.after 3) .staller ∅=1 := by
  apply LocalProfile.value_of_horizons _ _ .staller 1
  · decide +kernel
  · exact Or.inr (by decide +kernel)

theorem p4_after3_private : ∀w : Fin 4,
    Marked.White P4Receiver.T (P4Receiver.after 3) ∅ w → P4Receiver.T.Adj 1 w → w=0 := by
  decide +kernel

theorem p4_bridge_eq_add (G : SimpleGraph V) (z : V) :
    P4Receiver.A G z=GuardedEdge.addEdge (MarkedSum.original G P4Receiver.T)
      (.inl z) (.inr (0 : Fin 4)) (by simp) := by
  ext u v
  cases u <;> cases v
  all_goals simp [P4Receiver.A,Attachment.original,GuardedEdge.addEdge,
    Isolation.Graph.withEdge,GuardedEdge.view,MarkedSum.original,MarkedSum.graph,
    Isolation.Graph.disjointSum]
  all_goals tauto

/-- The only delicate P4 endpoint follower is controlled by a genuine private
switch. Vertex 2 is actually marked in after 3; no history-generic leaf claim
is used. -/
theorem p4_after3_S_bound (G : SimpleGraph V) (z : V) (M : Finset V)
    (hG : G.IsAcyclic) (hz : z∈M) :
    Marked.gameValue (P4Receiver.A G z) (P4Receiver.AM M) .staller {.inr (3 : Fin 4)} ≤
      Marked.gameValue G M .staller ∅+1 := by
  rw [P4Receiver.absorb_one,P4Receiver.right_played G z M hz,P4Receiver.played_after]
  rw [p4_bridge_eq_add]
  have hx : Sum.inl z∈MarkedSum.combine M (P4Receiver.after 3) := by simp [hz]
  have hedge : (MarkedSum.original G P4Receiver.T).Adj
      (.inr (1 : Fin 4)) (.inr 0) := by
    change P4Receiver.T.Adj 1 0
    decide +kernel
  have hp : ∀w,Marked.White (MarkedSum.original G P4Receiver.T)
      (MarkedSum.combine M (P4Receiver.after 3)) ∅ w →
      (MarkedSum.original G P4Receiver.T).Adj (.inr (1 : Fin 4)) w → w=.inr 0 := by
    intro w hw ha
    cases w with
    | inl w => exact False.elim ha
    | inr w =>
      apply congrArg Sum.inr
      apply p4_after3_private w ?_ ha
      have hw' := (MarkedSum.original_white G P4Receiver.T M ∅ (P4Receiver.after 3) ∅ (.inr w))
      simpa only [P4Receiver.empty_combine] using hw'.mp hw
  have hb := GuardedEdge.marked_value_bound (MarkedSum.original G P4Receiver.T)
    (MarkedSum.combine M (P4Receiver.after 3)) (.inl z) (.inr (0 : Fin 4)) (.inr 1)
    (by simp) hx hedge hp .staller
  rw [P4Receiver.balanced_after G M hG (P4Receiver.after 3) 1 p4_after3_D p4_after3_S] at hb
  exact hb

/-- All four original prescribed P4 actions, for a genuinely marked base port. -/
theorem p4_right_follower_S (G : SimpleGraph V) (z : V) (M : Finset V)
    (hG : G.IsAcyclic) (hz : z∈M) (a : Fin 4) :
    Marked.gameValue (P4Receiver.A G z) (P4Receiver.AM M) .staller {.inr a} ≤
      Marked.gameValue G M .staller ∅+1 := by
  fin_cases a
  · change Marked.gameValue (P4Receiver.A G z) (P4Receiver.AM M) .staller {Sum.inr (0 : Fin 4)} ≤ _
    rw [P4Receiver.after_right_sum G z M hz 0 (P4Receiver.after_root_mem 0 (Or.inl rfl)),
      P4Receiver.balanced_after G M hG (P4Receiver.after 0) 1 P4Receiver.after0_D P4Receiver.after0_S]
  · change Marked.gameValue (P4Receiver.A G z) (P4Receiver.AM M) .staller {Sum.inr (1 : Fin 4)} ≤ _
    rw [P4Receiver.after_right_sum G z M hz 1 (P4Receiver.after_root_mem 1 (Or.inr rfl)),
      P4Receiver.terminal_after G M hG (P4Receiver.after 1) P4Receiver.after1_terminal]
    omega
  · change Marked.gameValue (P4Receiver.A G z) (P4Receiver.AM M) .staller {Sum.inr (2 : Fin 4)} ≤ _
    rw [P4Receiver.absorb_one,P4Receiver.right_played G z M hz,P4Receiver.played_after,
      P4Receiver.normalize_after2 G z M hz,
      Attachment.marked_endpoints_value G P4Receiver.T z 0 M (insert 0 (P4Receiver.after 2)) hz
        (Finset.mem_insert_self _ _) ∅ .staller,
      P4Receiver.terminal_after G M hG (insert 0 (P4Receiver.after 2)) P4Receiver.after2_normal_terminal]
    omega
  · exact p4_after3_S_bound G z M hG hz
end LocalAttachment

#print axioms p4_after3_S_bound
#print axioms p4_right_follower_S
end IsolationGame.GeneralP4Receiver
