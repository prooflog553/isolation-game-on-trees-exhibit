import FourteenResidualData

/-! Finite kernel arithmetic only: first profile fixed to t12.
All arithmetic is checked by kernel reduction; no graph or history search. -/
namespace IsolationGame.FourteenResidual
open CanonicalLocal
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

theorem check11_t12 (b : Index) :
    NumericResidual [.t12] [b] → MatchesFourteen [.t12] [b] := by
  cases b <;> decide +kernel

theorem check12_t12 (b c : Index) :
    NumericResidual [.t12] [b, c] → MatchesFourteen [.t12] [b, c] := by
  cases b <;> cases c <;> decide +kernel

#print axioms check11_t12
#print axioms check12_t12
end IsolationGame.FourteenResidual
