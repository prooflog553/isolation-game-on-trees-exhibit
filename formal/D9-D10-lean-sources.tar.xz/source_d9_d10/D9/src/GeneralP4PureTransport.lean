import GeneralP4Transport
import PureModuleStrict

/-! The k=0 bridge is to the actual pure family. Only its D=3p and its
centre-played S<=3p are used. No initial pure S<=3p assertion occurs. -/
namespace IsolationGame.GeneralP4Receiver
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

abbrev PureV (p : Nat) := CoreFamily.Vertex [] p

def pureTo (p : Nat) : Vertex 0 p → PureV p
  | .inl none => none
  | .inl (some (i,_)) => Fin.elim0 i
  | .inr (.inl (i,r)) => some ⟨Fin.cast (Nat.zero_add p).symm i,r⟩
  | .inr (.inr (i,_)) => Fin.elim0 i

def pureFrom (p : Nat) : PureV p → Vertex 0 p
  | none => centre 0 p
  | some ⟨i,r⟩ => ordinary 0 p (Fin.cast (Nat.zero_add p) i) r

def pureEquiv (p : Nat) : Vertex 0 p ≃ PureV p where
  toFun := pureTo p
  invFun := pureFrom p
  left_inv := by
    intro v
    rcases v with (_ | ⟨i,r⟩) | (⟨i,r⟩|⟨i,r⟩)
    · rfl
    · exact Fin.elim0 i
    · simp [pureTo,pureFrom,ordinary,TwoPool.ordinaryLeft,Fin.cast]
    · exact Fin.elim0 i
  right_inv := by
    intro v
    cases v with
    | none => rfl
    | some v =>
      rcases v with ⟨i,r⟩
      simp [pureTo,pureFrom,ordinary,TwoPool.ordinaryLeft,Fin.cast]

@[simp] theorem pure_centre (p : Nat) : pureEquiv p (centre 0 p) = none := rfl
@[simp] theorem pure_ordinary (p : Nat) (i : Fin p) (r : Fin 7) :
    pureEquiv p (ordinary 0 p i r) = some ⟨Fin.cast (Nat.zero_add p).symm i,r⟩ := rfl

theorem pureEquiv_adj (p : Nat) (u v : Vertex 0 p) :
    (CoreFamily.graph [] p).Adj (pureEquiv p u) (pureEquiv p v) ↔
      (graph 0 p).Adj u v := by
  rcases u with (_ | ⟨i,r⟩) | (⟨i,r⟩|⟨i,r⟩)
  all_goals rcases v with (_ | ⟨j,s⟩) | (⟨j,s⟩|⟨j,s⟩)
  all_goals first | exact Fin.elim0 i | exact Fin.elim0 j | skip
  · simp [pureEquiv,pureTo,graph,fixedGraph,TwoPool.graph]
  · simpa [pureEquiv,pureTo,graph,TwoPool.graph,root] using
      (OneP4Receiver.root_ordinary_adj p j s)
  · have h := OneP4Receiver.root_ordinary_adj p i r
    rw [(CoreFamily.graph [] p).adj_comm] at h
    simpa [pureEquiv,pureTo,graph,TwoPool.graph,root] using h
  · simpa [pureEquiv,pureTo,graph,TwoPool.graph] using
      (OneP4Receiver.ordinary_ordinary_adj p i j r s)

theorem pure_marks (p : Nat) : (marks 0 p).image (pureEquiv p) = {none} := by
  simp [marks,TwoPool.marks,root,pureEquiv,pureTo]

theorem value_pure (p : Nat) (t : Player) (X : Finset (Vertex 0 p)) :
    Marked.gameValue (graph 0 p) (marks 0 p) t X =
      Marked.gameValue (CoreFamily.graph [] p) {none} t (X.image (pureEquiv p)) := by
  rw [←pure_marks]
  exact (Marked.gameValue_relabel (graph 0 p) (CoreFamily.graph [] p) (pureEquiv p)
    (pureEquiv_adj p) (marks 0 p) X t).symm

theorem pure_D (p : Nat) :
    Marked.gameValue (graph 0 p) (marks 0 p) .dominator ∅ = 3*p := by
  rw [value_pure]
  simpa using PureModuleStrict.D_value p

theorem pure_root_follower_S (p : Nat) :
    Marked.gameValue (graph 0 p) (marks 0 p) .staller {centre 0 p} ≤ 3*p := by
  rw [value_pure]
  simpa using PureModuleStrict.follower_S p none

/-- Actual played marks, on the same carrier, absorb precisely the singleton history. -/
theorem root_absorb (k p : Nat) (t : Player) :
    Marked.gameValue (graph k p) (marks k p) t {centre k p} =
      Marked.gameValue (graph k p)
        (SelectedVertex.playedMarks (graph k p) (marks k p) (centre k p)) t ∅ := by
  apply Marked.value_eq_of_white_eq
  intro v
  change Marked.White _ _ (insert (centre k p) ∅) v ↔ _
  rw [SelectedVertex.absorb_white]

#print axioms pureEquiv_adj
#print axioms value_pure
#print axioms pure_D
#print axioms pure_root_follower_S
#print axioms root_absorb
end IsolationGame.GeneralP4Receiver
