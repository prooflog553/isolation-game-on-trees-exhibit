import CoreFamilyAdjacency
import RootedAssemblyContract
import MarkedRelabel

/-!
SOURCE-ONLY candidate, 2026-10-19. No native elaboration claimed.
Complete original-carrier reindexing. Local vertex coordinates are cast only
along equality of the canonical labels, never along cardinality alone.
-/
namespace IsolationGame.CoreFamily
open CanonicalLocal NecessaryCore

/-- An exact index bijection together with equality of every canonical label. -/
structure LabelReindex (xs : List Nat) (p : Nat) (ys : List Nat) (q : Nat) where
  indexEquiv : Fin (xs.length+p) ≃ Fin (ys.length+q)
  label_eq : ∀i, label xs p i = label ys q (indexEquiv i)

namespace LabelReindex

def refl (xs : List Nat) (p : Nat) : LabelReindex xs p xs p :=
  ⟨Equiv.refl _, fun _ => rfl⟩

def trans {xs ys zs : List Nat} {p q r : Nat}
    (e : LabelReindex xs p ys q) (f : LabelReindex ys q zs r) :
    LabelReindex xs p zs r :=
  ⟨e.indexEquiv.trans f.indexEquiv, fun i => (e.label_eq i).trans (f.label_eq _)⟩

def symm {xs ys : List Nat} {p q : Nat} (e : LabelReindex xs p ys q) :
    LabelReindex ys q xs p := by
  refine ⟨e.indexEquiv.symm, ?_⟩
  intro i
  simpa using (e.label_eq (e.indexEquiv.symm i)).symm

end LabelReindex

/-- Proof-irrelevant cast retaining the literal local vertex number. -/
def coordinateEquiv {a b : Index} (h : a=b) : Fin (size a) ≃ Fin (size b) where
  toFun := Fin.cast (congrArg size h)
  invFun := Fin.cast (congrArg size h.symm)
  left_inv := by intro i; cases h; rfl
  right_inv := by intro i; cases h; rfl

@[simp] theorem coordinateEquiv_val {a b : Index} (h : a=b) (v : Fin (size a)) :
    (coordinateEquiv h v).val = v.val := rfl

@[simp] theorem coordinateEquiv_root {a b : Index} (h : a=b) :
    coordinateEquiv h (root a) = root b := by cases h; rfl

@[simp] theorem coordinateEquiv_adj {a b : Index} (h : a=b)
    (u v : Fin (size a)) :
    (CanonicalLocal.graph b).Adj (coordinateEquiv h u) (coordinateEquiv h v) ↔
      (CanonicalLocal.graph a).Adj u v := by cases h; rfl

/-- The same raw list position has the same label for any pool parameter. -/
theorem label_eq_of_val_eq (xs : List Nat) {p q : Nat}
    (i : Fin (xs.length+p)) (j : Fin (xs.length+q)) (h : i.val=j.val) :
    label xs p i = label xs q j := by
  rcases i with ⟨i,hi⟩
  rcases j with ⟨j,hj⟩
  dsimp at h
  subst j
  rfl

namespace LabelReindex
variable {xs ys : List Nat} {p q : Nat}

/-- Complete vertex bijection: root and every local vertex, including blue
or otherwise currently unhelpful actions, remain in the carrier. -/
def vertexEquiv (e : LabelReindex xs p ys q) : Vertex xs p ≃ Vertex ys q :=
  Equiv.optionCongr (Equiv.sigmaCongr e.indexEquiv
    (fun i => coordinateEquiv (e.label_eq i)))

@[simp] theorem vertexEquiv_none (e : LabelReindex xs p ys q) :
    e.vertexEquiv none = none := rfl

@[simp] theorem vertexEquiv_some (e : LabelReindex xs p ys q)
    (i : Fin (xs.length+p)) (v : Fin (size (label xs p i))) :
    e.vertexEquiv (some ⟨i,v⟩) =
      some ⟨e.indexEquiv i,coordinateEquiv (e.label_eq i) v⟩ := rfl

/-- A standard rooted full original-graph isomorphism. No tree, game,
mark, sorting, allowed-code, or multiplicity assumption is required. -/
def graphIso (e : LabelReindex xs p ys q) : graph xs p ≃g graph ys q where
  toEquiv := e.vertexEquiv
  map_rel_iff' := by
    intro u v
    have hr (i : Fin (xs.length+p)) (a : Fin (size (label xs p i))) :
        (graph ys q).Adj none
            (some ⟨e.indexEquiv i,coordinateEquiv (e.label_eq i) a⟩) ↔
          (graph xs p).Adj none (some ⟨i,a⟩) := by
      rw [CoreFamilySemantics.root_adj,CoreFamilySemantics.root_adj]
      rw [←coordinateEquiv_root (e.label_eq i)]
      exact (coordinateEquiv (e.label_eq i)).injective.eq_iff
    cases u with
    | none =>
      cases v with
      | none => exact iff_of_false (graph ys q).irrefl (graph xs p).irrefl
      | some v => obtain ⟨i,a⟩ := v; exact hr i a
    | some u =>
      obtain ⟨i,a⟩ := u
      cases v with
      | none =>
        change (graph ys q).Adj
            (some ⟨e.indexEquiv i,coordinateEquiv (e.label_eq i) a⟩) none ↔
          (graph xs p).Adj (some ⟨i,a⟩) none
        rw [(graph ys q).adj_comm,(graph xs p).adj_comm]
        exact hr i a
      | some v =>
        obtain ⟨j,b⟩ := v
        change (graph ys q).Adj
            (some ⟨e.indexEquiv i,coordinateEquiv (e.label_eq i) a⟩)
            (some ⟨e.indexEquiv j,coordinateEquiv (e.label_eq j) b⟩) ↔
          (graph xs p).Adj (some ⟨i,a⟩) (some ⟨j,b⟩)
        by_cases hij : i=j
        · subst j
          rw [CoreFamilySemantics.same_adj,CoreFamilySemantics.same_adj]
          exact coordinateEquiv_adj (e.label_eq i) a b
        · exact iff_of_false
            (CoreFamilySemantics.distinct_no_adj ys q _ _
              (fun h => hij (e.indexEquiv.injective h)) _ _)
            (CoreFamilySemantics.distinct_no_adj xs p i j hij a b)

@[simp] theorem graphIso_root (e : LabelReindex xs p ys q) :
    e.graphIso none = none := rfl

theorem rootedIso (e : LabelReindex xs p ys q) :
    RootedAssembly.RootedIso (graph xs p) none (graph ys q) none :=
  ⟨e.graphIso.toEquiv,rfl,fun _ _ => e.graphIso.map_adj_iff⟩

/-- Arbitrary genuine marks, selected histories, vertex and player's turn. -/
theorem white (e : LabelReindex xs p ys q) (M X : Finset (Vertex xs p))
    (v : Vertex xs p) :
    Marked.White (graph ys q) (M.image e.graphIso) (X.image e.graphIso) (e.graphIso v) ↔
      Marked.White (graph xs p) M X v :=
  Marked.white_relabel _ _ e.graphIso.toEquiv (fun _ _ => e.graphIso.map_adj_iff) M X v

theorem legal (e : LabelReindex xs p ys q) (M X : Finset (Vertex xs p))
    (v : Vertex xs p) :
    Marked.Legal (graph ys q) (M.image e.graphIso) (X.image e.graphIso) (e.graphIso v) ↔
      Marked.Legal (graph xs p) M X v :=
  Marked.legal_relabel _ _ e.graphIso.toEquiv (fun _ _ => e.graphIso.map_adj_iff) M X v

theorem gameValue (e : LabelReindex xs p ys q) (M X : Finset (Vertex xs p))
    (t : Player) :
    Marked.gameValue (graph ys q) (M.image e.graphIso) t (X.image e.graphIso) =
      Marked.gameValue (graph xs p) M t X :=
  Marked.gameValue_relabel _ _ e.graphIso.toEquiv (fun _ _ => e.graphIso.map_adj_iff) M X t

end LabelReindex

/-- Minimal external API when an exact index permutation is already given. -/
def reindexIso (xs ys : List Nat) (p q : Nat)
    (e : Fin (xs.length+p) ≃ Fin (ys.length+q))
    (he : ∀i,label xs p i = label ys q (e i)) : graph xs p ≃g graph ys q :=
  (LabelReindex.mk e he).graphIso

#print axioms LabelReindex.graphIso
#print axioms LabelReindex.rootedIso
#print axioms LabelReindex.white
#print axioms LabelReindex.legal
#print axioms LabelReindex.gameValue
end IsolationGame.CoreFamily
