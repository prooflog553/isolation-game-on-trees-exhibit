import CoreFamilyContract

namespace IsolationGame.CoreFamilySemantics
open CanonicalLocal CoreFamily

 theorem root_adj (xs : List Nat) (p : Nat) (i : Fin (xs.length+p)) (v : Fin (size (label xs p i))) :
    (CoreFamily.graph xs p).Adj none (some ⟨i,v⟩) ↔ v=root (label xs p i) := by
  simp [CoreFamily.graph,SimpleGraph.fromRel,eq_comm]

 theorem same_adj (xs : List Nat) (p : Nat) (i : Fin (xs.length+p)) (u v : Fin (size (label xs p i))) :
    (CoreFamily.graph xs p).Adj (some ⟨i,u⟩) (some ⟨i,v⟩) ↔ (CanonicalLocal.graph (label xs p i)).Adj u v := by
  simp [CoreFamily.graph,SimpleGraph.fromRel]
  constructor
  · rintro ⟨_,h|h⟩
    · obtain ⟨j,a,b,hab,⟨hij,hu⟩,_,hv⟩ := h
      subst j
      cases hu
      cases hv
      exact hab
    · obtain ⟨j,a,b,hab,⟨hij,hv⟩,_,hu⟩ := h
      subst j
      cases hu
      cases hv
      exact hab.symm
  · intro h
    exact ⟨h.ne,Or.inl ⟨i,u,v,h,⟨rfl,HEq.rfl⟩,rfl,HEq.rfl⟩⟩

 theorem distinct_no_adj (xs : List Nat) (p : Nat) (i j : Fin (xs.length+p)) (hij : i≠j)
    (u : Fin (size (label xs p i))) (v : Fin (size (label xs p j))) :
    ¬(CoreFamily.graph xs p).Adj (some ⟨i,u⟩) (some ⟨j,v⟩) := by
  simp [CoreFamily.graph,SimpleGraph.fromRel,hij,hij.symm]
  constructor
  · intro k a b _ hi _ hj _
    exact hij (hi.trans hj.symm)
  · intro k a b _ hj _ hi _
    exact hij (hi.trans hj.symm)

end IsolationGame.CoreFamilySemantics
