import FullCanonical05Rows05
namespace IsolationGame.FullCanonical.T05
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_24 : Finset (Fin 16) := {1,2,3,5,6}
theorem after_24_0 : Marked.gameValue original marks_24 .dominator {0}=3 ∧ Marked.gameValue original marks_24 .staller {0}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_24 marks_11 0 3 3 (by decide +kernel) row_11
theorem after_24_1 : Marked.gameValue original marks_24 .dominator {1}=4 ∧ Marked.gameValue original marks_24 .staller {1}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_24 marks_20 1 4 4 (by decide +kernel) row_20
theorem after_24_4 : Marked.gameValue original marks_24 .dominator {4}=4 ∧ Marked.gameValue original marks_24 .staller {4}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_24 marks_20 4 4 4 (by decide +kernel) row_20
theorem after_24_5 : Marked.gameValue original marks_24 .dominator {5}=4 ∧ Marked.gameValue original marks_24 .staller {5}=5 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_24 marks_23 5 4 5 (by decide +kernel) row_23
theorem after_24_7 : Marked.gameValue original marks_24 .dominator {7}=3 ∧ Marked.gameValue original marks_24 .staller {7}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_24 marks_13 7 3 3 (by decide +kernel) row_13
theorem after_24_8 : Marked.gameValue original marks_24 .dominator {8}=3 ∧ Marked.gameValue original marks_24 .staller {8}=4 :=
  FullCanonicalDAG.transport_perm original perm_4 adjacency_4 marks_24 marks_18 8 3 4 (by decide +kernel) row_18
theorem after_24_9 : Marked.gameValue original marks_24 .dominator {9}=3 ∧ Marked.gameValue original marks_24 .staller {9}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_24 marks_19 9 3 4 (by decide +kernel) row_19
theorem after_24_10 : Marked.gameValue original marks_24 .dominator {10}=3 ∧ Marked.gameValue original marks_24 .staller {10}=3 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_24 marks_13 10 3 3 (by decide +kernel) row_13
theorem after_24_11 : Marked.gameValue original marks_24 .dominator {11}=3 ∧ Marked.gameValue original marks_24 .staller {11}=4 :=
  FullCanonicalDAG.transport_perm original perm_5 adjacency_5 marks_24 marks_18 11 3 4 (by decide +kernel) row_18
theorem after_24_12 : Marked.gameValue original marks_24 .dominator {12}=3 ∧ Marked.gameValue original marks_24 .staller {12}=4 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_24 marks_19 12 3 4 (by decide +kernel) row_19
theorem after_24_13 : Marked.gameValue original marks_24 .dominator {13}=3 ∧ Marked.gameValue original marks_24 .staller {13}=3 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_24 marks_13 13 3 3 (by decide +kernel) row_13
theorem after_24_14 : Marked.gameValue original marks_24 .dominator {14}=3 ∧ Marked.gameValue original marks_24 .staller {14}=4 :=
  FullCanonicalDAG.transport_perm original perm_6 adjacency_6 marks_24 marks_18 14 3 4 (by decide +kernel) row_18
theorem after_24_15 : Marked.gameValue original marks_24 .dominator {15}=3 ∧ Marked.gameValue original marks_24 .staller {15}=4 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_24 marks_19 15 3 4 (by decide +kernel) row_19
theorem row_24 : Marked.gameValue original marks_24 .dominator ∅=4 ∧ Marked.gameValue original marks_24 .staller ∅=5 := by
  apply LocalProfile.DAG.bellman original marks_24 4 5 0 1 (by decide +kernel) (by decide +kernel)
  · rw [after_24_0.2]
  · rw [after_24_1.1]
  · intro v hv
    fin_cases v
    · have h := after_24_0
      change 4 ≤ 1+Marked.gameValue original marks_24 .staller {0} ∧ 1+Marked.gameValue original marks_24 .dominator {0} ≤ 5
      omega
    · have h := after_24_1
      change 4 ≤ 1+Marked.gameValue original marks_24 .staller {1} ∧ 1+Marked.gameValue original marks_24 .dominator {1} ≤ 5
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_24 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_24 ∅ 3) hv)
    · have h := after_24_4
      change 4 ≤ 1+Marked.gameValue original marks_24 .staller {4} ∧ 1+Marked.gameValue original marks_24 .dominator {4} ≤ 5
      omega
    · have h := after_24_5
      change 4 ≤ 1+Marked.gameValue original marks_24 .staller {5} ∧ 1+Marked.gameValue original marks_24 .dominator {5} ≤ 5
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_24 ∅ 6) hv)
    · have h := after_24_7
      change 4 ≤ 1+Marked.gameValue original marks_24 .staller {7} ∧ 1+Marked.gameValue original marks_24 .dominator {7} ≤ 5
      omega
    · have h := after_24_8
      change 4 ≤ 1+Marked.gameValue original marks_24 .staller {8} ∧ 1+Marked.gameValue original marks_24 .dominator {8} ≤ 5
      omega
    · have h := after_24_9
      change 4 ≤ 1+Marked.gameValue original marks_24 .staller {9} ∧ 1+Marked.gameValue original marks_24 .dominator {9} ≤ 5
      omega
    · have h := after_24_10
      change 4 ≤ 1+Marked.gameValue original marks_24 .staller {10} ∧ 1+Marked.gameValue original marks_24 .dominator {10} ≤ 5
      omega
    · have h := after_24_11
      change 4 ≤ 1+Marked.gameValue original marks_24 .staller {11} ∧ 1+Marked.gameValue original marks_24 .dominator {11} ≤ 5
      omega
    · have h := after_24_12
      change 4 ≤ 1+Marked.gameValue original marks_24 .staller {12} ∧ 1+Marked.gameValue original marks_24 .dominator {12} ≤ 5
      omega
    · have h := after_24_13
      change 4 ≤ 1+Marked.gameValue original marks_24 .staller {13} ∧ 1+Marked.gameValue original marks_24 .dominator {13} ≤ 5
      omega
    · have h := after_24_14
      change 4 ≤ 1+Marked.gameValue original marks_24 .staller {14} ∧ 1+Marked.gameValue original marks_24 .dominator {14} ≤ 5
      omega
    · have h := after_24_15
      change 4 ≤ 1+Marked.gameValue original marks_24 .staller {15} ∧ 1+Marked.gameValue original marks_24 .dominator {15} ≤ 5
      omega
def marks_25 : Finset (Fin 16) := {2,3,5,6}
theorem after_25_0 : Marked.gameValue original marks_25 .dominator {0}=3 ∧ Marked.gameValue original marks_25 .staller {0}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_25 marks_11 0 3 3 (by decide +kernel) row_11
theorem after_25_1 : Marked.gameValue original marks_25 .dominator {1}=4 ∧ Marked.gameValue original marks_25 .staller {1}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_25 marks_20 1 4 4 (by decide +kernel) row_20
theorem after_25_2 : Marked.gameValue original marks_25 .dominator {2}=4 ∧ Marked.gameValue original marks_25 .staller {2}=5 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_25 marks_24 2 4 5 (by decide +kernel) row_24
theorem after_25_4 : Marked.gameValue original marks_25 .dominator {4}=4 ∧ Marked.gameValue original marks_25 .staller {4}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_25 marks_20 4 4 4 (by decide +kernel) row_20
theorem after_25_5 : Marked.gameValue original marks_25 .dominator {5}=4 ∧ Marked.gameValue original marks_25 .staller {5}=5 :=
  FullCanonicalDAG.transport_perm original perm_7 adjacency_7 marks_25 marks_24 5 4 5 (by decide +kernel) row_24
theorem after_25_7 : Marked.gameValue original marks_25 .dominator {7}=3 ∧ Marked.gameValue original marks_25 .staller {7}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_25 marks_13 7 3 3 (by decide +kernel) row_13
theorem after_25_8 : Marked.gameValue original marks_25 .dominator {8}=3 ∧ Marked.gameValue original marks_25 .staller {8}=4 :=
  FullCanonicalDAG.transport_perm original perm_8 adjacency_8 marks_25 marks_19 8 3 4 (by decide +kernel) row_19
theorem after_25_9 : Marked.gameValue original marks_25 .dominator {9}=3 ∧ Marked.gameValue original marks_25 .staller {9}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_25 marks_22 9 3 4 (by decide +kernel) row_22
theorem after_25_10 : Marked.gameValue original marks_25 .dominator {10}=3 ∧ Marked.gameValue original marks_25 .staller {10}=3 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_25 marks_13 10 3 3 (by decide +kernel) row_13
theorem after_25_11 : Marked.gameValue original marks_25 .dominator {11}=3 ∧ Marked.gameValue original marks_25 .staller {11}=4 :=
  FullCanonicalDAG.transport_perm original perm_9 adjacency_9 marks_25 marks_19 11 3 4 (by decide +kernel) row_19
theorem after_25_12 : Marked.gameValue original marks_25 .dominator {12}=3 ∧ Marked.gameValue original marks_25 .staller {12}=4 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_25 marks_22 12 3 4 (by decide +kernel) row_22
theorem after_25_13 : Marked.gameValue original marks_25 .dominator {13}=3 ∧ Marked.gameValue original marks_25 .staller {13}=3 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_25 marks_13 13 3 3 (by decide +kernel) row_13
theorem after_25_14 : Marked.gameValue original marks_25 .dominator {14}=3 ∧ Marked.gameValue original marks_25 .staller {14}=4 :=
  FullCanonicalDAG.transport_perm original perm_10 adjacency_10 marks_25 marks_19 14 3 4 (by decide +kernel) row_19
theorem after_25_15 : Marked.gameValue original marks_25 .dominator {15}=3 ∧ Marked.gameValue original marks_25 .staller {15}=4 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_25 marks_22 15 3 4 (by decide +kernel) row_22
theorem row_25 : Marked.gameValue original marks_25 .dominator ∅=4 ∧ Marked.gameValue original marks_25 .staller ∅=5 := by
  apply LocalProfile.DAG.bellman original marks_25 4 5 0 1 (by decide +kernel) (by decide +kernel)
  · rw [after_25_0.2]
  · rw [after_25_1.1]
  · intro v hv
    fin_cases v
    · have h := after_25_0
      change 4 ≤ 1+Marked.gameValue original marks_25 .staller {0} ∧ 1+Marked.gameValue original marks_25 .dominator {0} ≤ 5
      omega
    · have h := after_25_1
      change 4 ≤ 1+Marked.gameValue original marks_25 .staller {1} ∧ 1+Marked.gameValue original marks_25 .dominator {1} ≤ 5
      omega
    · have h := after_25_2
      change 4 ≤ 1+Marked.gameValue original marks_25 .staller {2} ∧ 1+Marked.gameValue original marks_25 .dominator {2} ≤ 5
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_25 ∅ 3) hv)
    · have h := after_25_4
      change 4 ≤ 1+Marked.gameValue original marks_25 .staller {4} ∧ 1+Marked.gameValue original marks_25 .dominator {4} ≤ 5
      omega
    · have h := after_25_5
      change 4 ≤ 1+Marked.gameValue original marks_25 .staller {5} ∧ 1+Marked.gameValue original marks_25 .dominator {5} ≤ 5
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_25 ∅ 6) hv)
    · have h := after_25_7
      change 4 ≤ 1+Marked.gameValue original marks_25 .staller {7} ∧ 1+Marked.gameValue original marks_25 .dominator {7} ≤ 5
      omega
    · have h := after_25_8
      change 4 ≤ 1+Marked.gameValue original marks_25 .staller {8} ∧ 1+Marked.gameValue original marks_25 .dominator {8} ≤ 5
      omega
    · have h := after_25_9
      change 4 ≤ 1+Marked.gameValue original marks_25 .staller {9} ∧ 1+Marked.gameValue original marks_25 .dominator {9} ≤ 5
      omega
    · have h := after_25_10
      change 4 ≤ 1+Marked.gameValue original marks_25 .staller {10} ∧ 1+Marked.gameValue original marks_25 .dominator {10} ≤ 5
      omega
    · have h := after_25_11
      change 4 ≤ 1+Marked.gameValue original marks_25 .staller {11} ∧ 1+Marked.gameValue original marks_25 .dominator {11} ≤ 5
      omega
    · have h := after_25_12
      change 4 ≤ 1+Marked.gameValue original marks_25 .staller {12} ∧ 1+Marked.gameValue original marks_25 .dominator {12} ≤ 5
      omega
    · have h := after_25_13
      change 4 ≤ 1+Marked.gameValue original marks_25 .staller {13} ∧ 1+Marked.gameValue original marks_25 .dominator {13} ≤ 5
      omega
    · have h := after_25_14
      change 4 ≤ 1+Marked.gameValue original marks_25 .staller {14} ∧ 1+Marked.gameValue original marks_25 .dominator {14} ≤ 5
      omega
    · have h := after_25_15
      change 4 ≤ 1+Marked.gameValue original marks_25 .staller {15} ∧ 1+Marked.gameValue original marks_25 .dominator {15} ≤ 5
      omega
def marks_26 : Finset (Fin 16) := {0,1,2,3}
theorem after_26_0 : Marked.gameValue original marks_26 .dominator {0}=4 ∧ Marked.gameValue original marks_26 .staller {0}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_26 marks_16 0 4 4 (by decide +kernel) row_16
theorem after_26_4 : Marked.gameValue original marks_26 .dominator {4}=4 ∧ Marked.gameValue original marks_26 .staller {4}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_26 marks_20 4 4 4 (by decide +kernel) row_20
theorem after_26_5 : Marked.gameValue original marks_26 .dominator {5}=4 ∧ Marked.gameValue original marks_26 .staller {5}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_26 marks_20 5 4 4 (by decide +kernel) row_20
theorem after_26_6 : Marked.gameValue original marks_26 .dominator {6}=4 ∧ Marked.gameValue original marks_26 .staller {6}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_26 marks_20 6 4 4 (by decide +kernel) row_20
theorem after_26_7 : Marked.gameValue original marks_26 .dominator {7}=4 ∧ Marked.gameValue original marks_26 .staller {7}=4 :=
  FullCanonicalDAG.transport_perm original perm_4 adjacency_4 marks_26 marks_20 7 4 4 (by decide +kernel) row_20
theorem after_26_8 : Marked.gameValue original marks_26 .dominator {8}=4 ∧ Marked.gameValue original marks_26 .staller {8}=4 :=
  FullCanonicalDAG.transport_perm original perm_4 adjacency_4 marks_26 marks_20 8 4 4 (by decide +kernel) row_20
theorem after_26_9 : Marked.gameValue original marks_26 .dominator {9}=4 ∧ Marked.gameValue original marks_26 .staller {9}=4 :=
  FullCanonicalDAG.transport_perm original perm_4 adjacency_4 marks_26 marks_20 9 4 4 (by decide +kernel) row_20
theorem after_26_10 : Marked.gameValue original marks_26 .dominator {10}=4 ∧ Marked.gameValue original marks_26 .staller {10}=4 :=
  FullCanonicalDAG.transport_perm original perm_5 adjacency_5 marks_26 marks_20 10 4 4 (by decide +kernel) row_20
theorem after_26_11 : Marked.gameValue original marks_26 .dominator {11}=4 ∧ Marked.gameValue original marks_26 .staller {11}=4 :=
  FullCanonicalDAG.transport_perm original perm_5 adjacency_5 marks_26 marks_20 11 4 4 (by decide +kernel) row_20
theorem after_26_12 : Marked.gameValue original marks_26 .dominator {12}=4 ∧ Marked.gameValue original marks_26 .staller {12}=4 :=
  FullCanonicalDAG.transport_perm original perm_5 adjacency_5 marks_26 marks_20 12 4 4 (by decide +kernel) row_20
theorem after_26_13 : Marked.gameValue original marks_26 .dominator {13}=4 ∧ Marked.gameValue original marks_26 .staller {13}=4 :=
  FullCanonicalDAG.transport_perm original perm_6 adjacency_6 marks_26 marks_20 13 4 4 (by decide +kernel) row_20
theorem after_26_14 : Marked.gameValue original marks_26 .dominator {14}=4 ∧ Marked.gameValue original marks_26 .staller {14}=4 :=
  FullCanonicalDAG.transport_perm original perm_6 adjacency_6 marks_26 marks_20 14 4 4 (by decide +kernel) row_20
theorem after_26_15 : Marked.gameValue original marks_26 .dominator {15}=4 ∧ Marked.gameValue original marks_26 .staller {15}=4 :=
  FullCanonicalDAG.transport_perm original perm_6 adjacency_6 marks_26 marks_20 15 4 4 (by decide +kernel) row_20
theorem row_26 : Marked.gameValue original marks_26 .dominator ∅=5 ∧ Marked.gameValue original marks_26 .staller ∅=5 := by
  apply LocalProfile.DAG.bellman original marks_26 5 5 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_26_0.2]
  · rw [after_26_0.1]
  · intro v hv
    fin_cases v
    · have h := after_26_0
      change 5 ≤ 1+Marked.gameValue original marks_26 .staller {0} ∧ 1+Marked.gameValue original marks_26 .dominator {0} ≤ 5
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_26 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_26 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_26 ∅ 3) hv)
    · have h := after_26_4
      change 5 ≤ 1+Marked.gameValue original marks_26 .staller {4} ∧ 1+Marked.gameValue original marks_26 .dominator {4} ≤ 5
      omega
    · have h := after_26_5
      change 5 ≤ 1+Marked.gameValue original marks_26 .staller {5} ∧ 1+Marked.gameValue original marks_26 .dominator {5} ≤ 5
      omega
    · have h := after_26_6
      change 5 ≤ 1+Marked.gameValue original marks_26 .staller {6} ∧ 1+Marked.gameValue original marks_26 .dominator {6} ≤ 5
      omega
    · have h := after_26_7
      change 5 ≤ 1+Marked.gameValue original marks_26 .staller {7} ∧ 1+Marked.gameValue original marks_26 .dominator {7} ≤ 5
      omega
    · have h := after_26_8
      change 5 ≤ 1+Marked.gameValue original marks_26 .staller {8} ∧ 1+Marked.gameValue original marks_26 .dominator {8} ≤ 5
      omega
    · have h := after_26_9
      change 5 ≤ 1+Marked.gameValue original marks_26 .staller {9} ∧ 1+Marked.gameValue original marks_26 .dominator {9} ≤ 5
      omega
    · have h := after_26_10
      change 5 ≤ 1+Marked.gameValue original marks_26 .staller {10} ∧ 1+Marked.gameValue original marks_26 .dominator {10} ≤ 5
      omega
    · have h := after_26_11
      change 5 ≤ 1+Marked.gameValue original marks_26 .staller {11} ∧ 1+Marked.gameValue original marks_26 .dominator {11} ≤ 5
      omega
    · have h := after_26_12
      change 5 ≤ 1+Marked.gameValue original marks_26 .staller {12} ∧ 1+Marked.gameValue original marks_26 .dominator {12} ≤ 5
      omega
    · have h := after_26_13
      change 5 ≤ 1+Marked.gameValue original marks_26 .staller {13} ∧ 1+Marked.gameValue original marks_26 .dominator {13} ≤ 5
      omega
    · have h := after_26_14
      change 5 ≤ 1+Marked.gameValue original marks_26 .staller {14} ∧ 1+Marked.gameValue original marks_26 .dominator {14} ≤ 5
      omega
    · have h := after_26_15
      change 5 ≤ 1+Marked.gameValue original marks_26 .staller {15} ∧ 1+Marked.gameValue original marks_26 .dominator {15} ≤ 5
      omega
def marks_27 : Finset (Fin 16) := {1,2,3}
theorem after_27_0 : Marked.gameValue original marks_27 .dominator {0}=4 ∧ Marked.gameValue original marks_27 .staller {0}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_27 marks_16 0 4 4 (by decide +kernel) row_16
theorem after_27_1 : Marked.gameValue original marks_27 .dominator {1}=5 ∧ Marked.gameValue original marks_27 .staller {1}=5 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_27 marks_26 1 5 5 (by decide +kernel) row_26
theorem after_27_4 : Marked.gameValue original marks_27 .dominator {4}=4 ∧ Marked.gameValue original marks_27 .staller {4}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_27 marks_20 4 4 4 (by decide +kernel) row_20
theorem after_27_5 : Marked.gameValue original marks_27 .dominator {5}=4 ∧ Marked.gameValue original marks_27 .staller {5}=5 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_27 marks_23 5 4 5 (by decide +kernel) row_23
theorem after_27_6 : Marked.gameValue original marks_27 .dominator {6}=4 ∧ Marked.gameValue original marks_27 .staller {6}=5 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_27 marks_24 6 4 5 (by decide +kernel) row_24
theorem after_27_7 : Marked.gameValue original marks_27 .dominator {7}=4 ∧ Marked.gameValue original marks_27 .staller {7}=4 :=
  FullCanonicalDAG.transport_perm original perm_4 adjacency_4 marks_27 marks_20 7 4 4 (by decide +kernel) row_20
theorem after_27_8 : Marked.gameValue original marks_27 .dominator {8}=4 ∧ Marked.gameValue original marks_27 .staller {8}=5 :=
  FullCanonicalDAG.transport_perm original perm_4 adjacency_4 marks_27 marks_23 8 4 5 (by decide +kernel) row_23
theorem after_27_9 : Marked.gameValue original marks_27 .dominator {9}=4 ∧ Marked.gameValue original marks_27 .staller {9}=5 :=
  FullCanonicalDAG.transport_perm original perm_4 adjacency_4 marks_27 marks_24 9 4 5 (by decide +kernel) row_24
theorem after_27_10 : Marked.gameValue original marks_27 .dominator {10}=4 ∧ Marked.gameValue original marks_27 .staller {10}=4 :=
  FullCanonicalDAG.transport_perm original perm_5 adjacency_5 marks_27 marks_20 10 4 4 (by decide +kernel) row_20
theorem after_27_11 : Marked.gameValue original marks_27 .dominator {11}=4 ∧ Marked.gameValue original marks_27 .staller {11}=5 :=
  FullCanonicalDAG.transport_perm original perm_5 adjacency_5 marks_27 marks_23 11 4 5 (by decide +kernel) row_23
theorem after_27_12 : Marked.gameValue original marks_27 .dominator {12}=4 ∧ Marked.gameValue original marks_27 .staller {12}=5 :=
  FullCanonicalDAG.transport_perm original perm_5 adjacency_5 marks_27 marks_24 12 4 5 (by decide +kernel) row_24
theorem after_27_13 : Marked.gameValue original marks_27 .dominator {13}=4 ∧ Marked.gameValue original marks_27 .staller {13}=4 :=
  FullCanonicalDAG.transport_perm original perm_6 adjacency_6 marks_27 marks_20 13 4 4 (by decide +kernel) row_20
theorem after_27_14 : Marked.gameValue original marks_27 .dominator {14}=4 ∧ Marked.gameValue original marks_27 .staller {14}=5 :=
  FullCanonicalDAG.transport_perm original perm_6 adjacency_6 marks_27 marks_23 14 4 5 (by decide +kernel) row_23
theorem after_27_15 : Marked.gameValue original marks_27 .dominator {15}=4 ∧ Marked.gameValue original marks_27 .staller {15}=5 :=
  FullCanonicalDAG.transport_perm original perm_6 adjacency_6 marks_27 marks_24 15 4 5 (by decide +kernel) row_24
theorem row_27 : Marked.gameValue original marks_27 .dominator ∅=5 ∧ Marked.gameValue original marks_27 .staller ∅=6 := by
  apply LocalProfile.DAG.bellman original marks_27 5 6 0 1 (by decide +kernel) (by decide +kernel)
  · rw [after_27_0.2]
  · rw [after_27_1.1]
  · intro v hv
    fin_cases v
    · have h := after_27_0
      change 5 ≤ 1+Marked.gameValue original marks_27 .staller {0} ∧ 1+Marked.gameValue original marks_27 .dominator {0} ≤ 6
      omega
    · have h := after_27_1
      change 5 ≤ 1+Marked.gameValue original marks_27 .staller {1} ∧ 1+Marked.gameValue original marks_27 .dominator {1} ≤ 6
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_27 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_27 ∅ 3) hv)
    · have h := after_27_4
      change 5 ≤ 1+Marked.gameValue original marks_27 .staller {4} ∧ 1+Marked.gameValue original marks_27 .dominator {4} ≤ 6
      omega
    · have h := after_27_5
      change 5 ≤ 1+Marked.gameValue original marks_27 .staller {5} ∧ 1+Marked.gameValue original marks_27 .dominator {5} ≤ 6
      omega
    · have h := after_27_6
      change 5 ≤ 1+Marked.gameValue original marks_27 .staller {6} ∧ 1+Marked.gameValue original marks_27 .dominator {6} ≤ 6
      omega
    · have h := after_27_7
      change 5 ≤ 1+Marked.gameValue original marks_27 .staller {7} ∧ 1+Marked.gameValue original marks_27 .dominator {7} ≤ 6
      omega
    · have h := after_27_8
      change 5 ≤ 1+Marked.gameValue original marks_27 .staller {8} ∧ 1+Marked.gameValue original marks_27 .dominator {8} ≤ 6
      omega
    · have h := after_27_9
      change 5 ≤ 1+Marked.gameValue original marks_27 .staller {9} ∧ 1+Marked.gameValue original marks_27 .dominator {9} ≤ 6
      omega
    · have h := after_27_10
      change 5 ≤ 1+Marked.gameValue original marks_27 .staller {10} ∧ 1+Marked.gameValue original marks_27 .dominator {10} ≤ 6
      omega
    · have h := after_27_11
      change 5 ≤ 1+Marked.gameValue original marks_27 .staller {11} ∧ 1+Marked.gameValue original marks_27 .dominator {11} ≤ 6
      omega
    · have h := after_27_12
      change 5 ≤ 1+Marked.gameValue original marks_27 .staller {12} ∧ 1+Marked.gameValue original marks_27 .dominator {12} ≤ 6
      omega
    · have h := after_27_13
      change 5 ≤ 1+Marked.gameValue original marks_27 .staller {13} ∧ 1+Marked.gameValue original marks_27 .dominator {13} ≤ 6
      omega
    · have h := after_27_14
      change 5 ≤ 1+Marked.gameValue original marks_27 .staller {14} ∧ 1+Marked.gameValue original marks_27 .dominator {14} ≤ 6
      omega
    · have h := after_27_15
      change 5 ≤ 1+Marked.gameValue original marks_27 .staller {15} ∧ 1+Marked.gameValue original marks_27 .dominator {15} ≤ 6
      omega
end IsolationGame.FullCanonical.T05
