import FullCanonical09Base
namespace IsolationGame.FullCanonical.T09
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_0 : Finset (Fin 9) := {0,1,2,3,4,5,6,7,8}
theorem row_0 : Marked.gameValue original marks_0 .dominator ∅=0 ∧ Marked.gameValue original marks_0 .staller ∅=0 := by
  constructor <;> apply (Marked.value_zero_iff_terminal _ _ _ _).mpr <;> decide +kernel
def marks_1 : Finset (Fin 9) := {0,1,2,3,4,5,8}
theorem after_1_5 : Marked.gameValue original marks_1 .dominator {5}=0 ∧ Marked.gameValue original marks_1 .staller {5}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_1 marks_0 5 0 0 (by decide +kernel) row_0
theorem after_1_6 : Marked.gameValue original marks_1 .dominator {6}=0 ∧ Marked.gameValue original marks_1 .staller {6}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_1 marks_0 6 0 0 (by decide +kernel) row_0
theorem after_1_7 : Marked.gameValue original marks_1 .dominator {7}=0 ∧ Marked.gameValue original marks_1 .staller {7}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_1 marks_0 7 0 0 (by decide +kernel) row_0
theorem row_1 : Marked.gameValue original marks_1 .dominator ∅=1 ∧ Marked.gameValue original marks_1 .staller ∅=1 := by
  apply LocalProfile.DAG.bellman original marks_1 1 1 5 5 (by decide +kernel) (by decide +kernel)
  · rw [after_1_5.2]
  · rw [after_1_5.1]
  · intro v hv
    fin_cases v
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_1 ∅ 0) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_1 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_1 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_1 ∅ 3) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_1 ∅ 4) hv)
    · have h := after_1_5
      change 1 ≤ 1+Marked.gameValue original marks_1 .staller {5} ∧ 1+Marked.gameValue original marks_1 .dominator {5} ≤ 1
      omega
    · have h := after_1_6
      change 1 ≤ 1+Marked.gameValue original marks_1 .staller {6} ∧ 1+Marked.gameValue original marks_1 .dominator {6} ≤ 1
      omega
    · have h := after_1_7
      change 1 ≤ 1+Marked.gameValue original marks_1 .staller {7} ∧ 1+Marked.gameValue original marks_1 .dominator {7} ≤ 1
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_1 ∅ 8) hv)
def marks_2 : Finset (Fin 9) := {0,1,2,3,4,6,7}
theorem after_2_0 : Marked.gameValue original marks_2 .dominator {0}=0 ∧ Marked.gameValue original marks_2 .staller {0}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_2 marks_0 0 0 0 (by decide +kernel) row_0
theorem after_2_5 : Marked.gameValue original marks_2 .dominator {5}=0 ∧ Marked.gameValue original marks_2 .staller {5}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_2 marks_0 5 0 0 (by decide +kernel) row_0
theorem after_2_6 : Marked.gameValue original marks_2 .dominator {6}=0 ∧ Marked.gameValue original marks_2 .staller {6}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_2 marks_0 6 0 0 (by decide +kernel) row_0
theorem after_2_8 : Marked.gameValue original marks_2 .dominator {8}=0 ∧ Marked.gameValue original marks_2 .staller {8}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_2 marks_0 8 0 0 (by decide +kernel) row_0
theorem row_2 : Marked.gameValue original marks_2 .dominator ∅=1 ∧ Marked.gameValue original marks_2 .staller ∅=1 := by
  apply LocalProfile.DAG.bellman original marks_2 1 1 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_2_0.2]
  · rw [after_2_0.1]
  · intro v hv
    fin_cases v
    · have h := after_2_0
      change 1 ≤ 1+Marked.gameValue original marks_2 .staller {0} ∧ 1+Marked.gameValue original marks_2 .dominator {0} ≤ 1
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_2 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_2 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_2 ∅ 3) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_2 ∅ 4) hv)
    · have h := after_2_5
      change 1 ≤ 1+Marked.gameValue original marks_2 .staller {5} ∧ 1+Marked.gameValue original marks_2 .dominator {5} ≤ 1
      omega
    · have h := after_2_6
      change 1 ≤ 1+Marked.gameValue original marks_2 .staller {6} ∧ 1+Marked.gameValue original marks_2 .dominator {6} ≤ 1
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_2 ∅ 7) hv)
    · have h := after_2_8
      change 1 ≤ 1+Marked.gameValue original marks_2 .staller {8} ∧ 1+Marked.gameValue original marks_2 .dominator {8} ≤ 1
      omega
def marks_3 : Finset (Fin 9) := {1,2,3,4,6,7}
theorem after_3_0 : Marked.gameValue original marks_3 .dominator {0}=0 ∧ Marked.gameValue original marks_3 .staller {0}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_3 marks_0 0 0 0 (by decide +kernel) row_0
theorem after_3_1 : Marked.gameValue original marks_3 .dominator {1}=1 ∧ Marked.gameValue original marks_3 .staller {1}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_3 marks_2 1 1 1 (by decide +kernel) row_2
theorem after_3_5 : Marked.gameValue original marks_3 .dominator {5}=0 ∧ Marked.gameValue original marks_3 .staller {5}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_3 marks_0 5 0 0 (by decide +kernel) row_0
theorem after_3_6 : Marked.gameValue original marks_3 .dominator {6}=0 ∧ Marked.gameValue original marks_3 .staller {6}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_3 marks_0 6 0 0 (by decide +kernel) row_0
theorem after_3_8 : Marked.gameValue original marks_3 .dominator {8}=0 ∧ Marked.gameValue original marks_3 .staller {8}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_3 marks_0 8 0 0 (by decide +kernel) row_0
theorem row_3 : Marked.gameValue original marks_3 .dominator ∅=1 ∧ Marked.gameValue original marks_3 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_3 1 2 0 1 (by decide +kernel) (by decide +kernel)
  · rw [after_3_0.2]
  · rw [after_3_1.1]
  · intro v hv
    fin_cases v
    · have h := after_3_0
      change 1 ≤ 1+Marked.gameValue original marks_3 .staller {0} ∧ 1+Marked.gameValue original marks_3 .dominator {0} ≤ 2
      omega
    · have h := after_3_1
      change 1 ≤ 1+Marked.gameValue original marks_3 .staller {1} ∧ 1+Marked.gameValue original marks_3 .dominator {1} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_3 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_3 ∅ 3) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_3 ∅ 4) hv)
    · have h := after_3_5
      change 1 ≤ 1+Marked.gameValue original marks_3 .staller {5} ∧ 1+Marked.gameValue original marks_3 .dominator {5} ≤ 2
      omega
    · have h := after_3_6
      change 1 ≤ 1+Marked.gameValue original marks_3 .staller {6} ∧ 1+Marked.gameValue original marks_3 .dominator {6} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_3 ∅ 7) hv)
    · have h := after_3_8
      change 1 ≤ 1+Marked.gameValue original marks_3 .staller {8} ∧ 1+Marked.gameValue original marks_3 .dominator {8} ≤ 2
      omega
end IsolationGame.FullCanonical.T09
