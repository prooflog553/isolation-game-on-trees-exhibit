import ProtectedEdgeOriginal

namespace IsolationGame.Marked
variable {V : Type} [Fintype V] [DecidableEq V] (G : SimpleGraph V)

/-- Equality of normalized white predicates in the same original graph
preserves both values for arbitrary initial marks and selected histories. -/
theorem value_eq_of_white_eq (M N X Y : Finset V) (p : Player)
    (hW : ∀v,White G M X v ↔ White G N Y v) : gameValue G M p X=gameValue G N p Y :=
  Nat.le_antisymm
    (value_of_white_subset G M N X Y p (fun v=>(hW v).mp))
    (value_of_white_subset G N M Y X p (fun v=>(hW v).mpr))

/-- Canonical complement-white marks preserve the complete original game's
value; blue move vertices and original adjacency remain unchanged. -/
theorem canonical_mark_value (M X : Finset V) (p : Player) :
    gameValue G M p X=
      gameValue G (ForestFoundation.canonicalMarks (White G M X)) p ∅ := by
  apply value_eq_of_white_eq G M _ X ∅ p
  intro v
  exact (ForestFoundation.canonical_white G _ (ForestFoundation.marked_white_normalized G M X) v).symm

#print axioms value_eq_of_white_eq
#print axioms canonical_mark_value
end IsolationGame.Marked
