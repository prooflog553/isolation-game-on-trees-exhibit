import FamilyTree
import CanonicalProfiles

namespace IsolationGame.AllProfileCore
open CanonicalLocal CoreFamily

/-- The accepted decoder maps every natural number outside 0..19 to t00. -/
def cost (xs : List Nat) : Nat := (xs.map (fun n => expectedS (NecessaryCore.decode n))).sum
abbrev coreOrder (xs : List Nat) : Nat := NecessaryCore.coreOrder xs

private theorem sum_fin_succ (n : Nat) (f : Fin (n+1) → Nat) :
    (∑ i, f i) = f 0 + ∑ i : Fin n, f i.succ := by
  calc
    _ = ∑ o : Option (Fin n), f ((finSuccEquiv n).symm o) :=
      (Fintype.sum_equiv (finSuccEquiv n).symm _ _ (fun _ => rfl)).symm
    _ = _ := by simp [Fintype.sum_option]

private theorem sum_fin_add (m n : Nat) (f : Fin (m+n) → Nat) :
    (∑ i, f i) = (∑ i : Fin m, f (Fin.castAdd n i)) +
      ∑ i : Fin n, f (Fin.natAdd m i) := by
  calc
    _ = ∑ s : Fin m ⊕ Fin n, f (finSumFinEquiv s) :=
      (Fintype.sum_equiv finSumFinEquiv _ _ (fun _ => rfl)).symm
    _ = _ := by rw [Fintype.sum_sum_type]; rfl

private theorem sum_get_map (xs : List Nat) (f : Nat → Nat) :
    (∑ i : Fin xs.length, f (xs.get i)) = (xs.map f).sum := by
  induction xs with
  | nil => simp
  | cons a xs ih => simpa [sum_fin_succ] using congrArg (fun n => f a+n) ih

/-- Split the actual labelled copies; no code-validity assumption is used. -/
theorem sum_label (xs : List Nat) (q : Nat) (f : Index → Nat) :
    (∑ i : Fin (xs.length+q), f (CoreFamily.label xs q i)) =
      (xs.map (fun n => f (NecessaryCore.decode n))).sum + q*f .t02 := by
  rw [sum_fin_add]
  have hleft : (∑ i : Fin xs.length, f (CoreFamily.label xs q (Fin.castAdd q i))) =
      (xs.map (fun n => f (NecessaryCore.decode n))).sum := by
    simpa [CoreFamily.label] using sum_get_map xs (fun n => f (NecessaryCore.decode n))
  have hright : (∑ i : Fin q, f (CoreFamily.label xs q (Fin.natAdd xs.length i))) = q*f .t02 := by
    simp [CoreFamily.label,Nat.not_lt.mpr (Nat.le_add_right xs.length _)]
  rw [hleft,hright]

theorem core_order (xs : List Nat) (q : Nat) :
    Fintype.card (CoreFamily.Vertex xs q) = coreOrder xs+7*q := by
  classical
  change Fintype.card (Option (Σ i : Fin (xs.length+q),
    Fin (size (CoreFamily.label xs q i)))) = _
  simp only [Fintype.card_option,Fintype.card_sigma,Fintype.card_fin]
  rw [sum_label]
  simp [coreOrder,NecessaryCore.coreOrder,size]
  omega

theorem core_tree (xs : List Nat) (q : Nat) : (CoreFamily.graph xs q).IsTree :=
  CoreFamily.family_tree xs q

#print axioms sum_label
#print axioms core_order
#print axioms core_tree
end IsolationGame.AllProfileCore
