import CanonicalData
import ProfileDAG

namespace IsolationGame.FloorLocal
def original_01 : SimpleGraph (Fin 4) := CanonicalLocal.graph .t01
instance : DecidableRel original_01.Adj := inferInstanceAs (DecidableRel (LocalProfile.graph _).Adj)
def original_02 : SimpleGraph (Fin 7) := CanonicalLocal.graph .t02
instance : DecidableRel original_02.Adj := inferInstanceAs (DecidableRel (LocalProfile.graph _).Adj)
def original_03 : SimpleGraph (Fin 10) := CanonicalLocal.graph .t03
instance : DecidableRel original_03.Adj := inferInstanceAs (DecidableRel (LocalProfile.graph _).Adj)
def original_04 : SimpleGraph (Fin 13) := CanonicalLocal.graph .t04
instance : DecidableRel original_04.Adj := inferInstanceAs (DecidableRel (LocalProfile.graph _).Adj)
def original_06 : SimpleGraph (Fin 5) := CanonicalLocal.graph .t06
instance : DecidableRel original_06.Adj := inferInstanceAs (DecidableRel (LocalProfile.graph _).Adj)
def original_07 : SimpleGraph (Fin 8) := CanonicalLocal.graph .t07
instance : DecidableRel original_07.Adj := inferInstanceAs (DecidableRel (LocalProfile.graph _).Adj)
def original_08 : SimpleGraph (Fin 11) := CanonicalLocal.graph .t08
instance : DecidableRel original_08.Adj := inferInstanceAs (DecidableRel (LocalProfile.graph _).Adj)
def original_10 : SimpleGraph (Fin 3) := CanonicalLocal.graph .t10
instance : DecidableRel original_10.Adj := inferInstanceAs (DecidableRel (LocalProfile.graph _).Adj)
def original_11 : SimpleGraph (Fin 6) := CanonicalLocal.graph .t11
instance : DecidableRel original_11.Adj := inferInstanceAs (DecidableRel (LocalProfile.graph _).Adj)
def original_12 : SimpleGraph (Fin 9) := CanonicalLocal.graph .t12
instance : DecidableRel original_12.Adj := inferInstanceAs (DecidableRel (LocalProfile.graph _).Adj)
def original_14 : SimpleGraph (Fin 5) := CanonicalLocal.graph .t14
instance : DecidableRel original_14.Adj := inferInstanceAs (DecidableRel (LocalProfile.graph _).Adj)
def original_15 : SimpleGraph (Fin 8) := CanonicalLocal.graph .t15
instance : DecidableRel original_15.Adj := inferInstanceAs (DecidableRel (LocalProfile.graph _).Adj)
def original_16 : SimpleGraph (Fin 11) := CanonicalLocal.graph .t16
instance : DecidableRel original_16.Adj := inferInstanceAs (DecidableRel (LocalProfile.graph _).Adj)
def original_19 : SimpleGraph (Fin 4) := CanonicalLocal.graph .t19
instance : DecidableRel original_19.Adj := inferInstanceAs (DecidableRel (LocalProfile.graph _).Adj)
end IsolationGame.FloorLocal
