import CompanionFinitePairing
import StrictCapacityRelabel
import ForestSumAlgebra

namespace IsolationGame.DisjointCompanion
open IsolatedRestriction FiniteForestComponents
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
variable {V U I : Type} [Fintype V] [DecidableEq V] [Fintype U] [DecidableEq U]
  [Fintype I] [DecidableEq I]

abbrev left (A : Finset V) : Finset (V ⊕ U) := MarkedSum.liftLeft A
abbrev right : Finset (V ⊕ U) := MarkedSum.liftRight Finset.univ

def leftEquiv (A : Finset V) : Active A ≃ Active (left (U:=U) A) where
  toFun v := ⟨.inl v.val,by simpa [left,MarkedSum.liftLeft] using v.property⟩
  invFun v := match v with
    | ⟨.inl v,hv⟩ => ⟨v,by simpa [left,MarkedSum.liftLeft] using hv⟩
    | ⟨.inr v,hv⟩ => False.elim (by simpa [left,MarkedSum.liftLeft] using hv)
  left_inv v := rfl
  right_inv v := by
    rcases v with ⟨v,hv⟩
    cases v with
    | inl v => rfl
    | inr v => simp [left,MarkedSum.liftLeft] at hv

def rightEquiv : U ≃ Active (right (V:=V) (U:=U)) where
  toFun v := ⟨.inr v,by simp [right,MarkedSum.liftRight]⟩
  invFun v := match v with
    | ⟨.inr v,_⟩ => v
    | ⟨.inl v,hv⟩ => False.elim (by simpa [right,MarkedSum.liftRight] using hv)
  left_inv v := rfl
  right_inv v := by
    rcases v with ⟨v,hv⟩
    cases v with
    | inr v => rfl
    | inl v => simp [right,MarkedSum.liftRight] at hv

theorem left_marks (A M : Finset V) (N : Finset U) :
    (restrict A M).image (leftEquiv (U:=U) A) =
      restrict (left A) (MarkedSum.combine M N) := by
  ext v
  obtain ⟨u,rfl⟩ := (leftEquiv (U:=U) A).surjective v
  simp [leftEquiv,mem_restrict]

theorem right_marks (M : Finset V) (N : Finset U) :
    N.image (rightEquiv (V:=V)) = restrict right (MarkedSum.combine M N) := by
  ext v
  obtain ⟨u,rfl⟩ := (rightEquiv (V:=V) (U:=U)).surjective v
  simp [rightEquiv,mem_restrict]

theorem left_value (G : SimpleGraph V) (H : SimpleGraph U) (A M X : Finset V)
    (N Y : Finset U) (t : Player) :
    valueOn (MarkedSum.original G H) (left A) (MarkedSum.combine M N)
      (MarkedSum.combine X Y) t = valueOn G A M X t := by
  unfold valueOn
  have h := Marked.gameValue_relabel (induced G A)
    (induced (MarkedSum.original G H) (left A)) (leftEquiv A)
    (by intro u v;rfl) (restrict A M) (restrict A X) t
  rw [left_marks,left_marks] at h
  exact h

theorem left_strict (G : SimpleGraph V) (H : SimpleGraph U) (A M X : Finset V)
    (N Y : Finset U) (c : Nat)
    (hc : MarkedSum.StrictCapacity (induced G A) (restrict A M) (restrict A X) c) :
    MarkedSum.StrictCapacity (induced (MarkedSum.original G H) (left A))
      (restrict (left A) (MarkedSum.combine M N))
      (restrict (left A) (MarkedSum.combine X Y)) c := by
  have h := MarkedSum.strict_relabel (induced G A)
    (induced (MarkedSum.original G H) (left A)) (leftEquiv A)
    (by intro u v;rfl) (restrict A M) (restrict A X) c hc
  rw [left_marks,left_marks] at h
  exact h

theorem right_strict (G : SimpleGraph V) (H : SimpleGraph U) (M X : Finset V)
    (N Y : Finset U) (d : Nat) (hd : MarkedSum.StrictCapacity H N Y d) :
    MarkedSum.StrictCapacity (induced (MarkedSum.original G H) right)
      (restrict right (MarkedSum.combine M N))
      (restrict right (MarkedSum.combine X Y)) d := by
  have h := MarkedSum.strict_relabel H (induced (MarkedSum.original G H) right)
    rightEquiv (by intro u v;rfl) N Y d hd
  rw [right_marks,right_marks] at h
  exact h

/-- One external original strict forest component is included in the same
finite pairing count. This statement retains every vertex on both sides. -/
theorem S_upper (G : SimpleGraph V) (H : SimpleGraph U)
    (hSum : (MarkedSum.original G H).IsAcyclic) (C : I → Finset V)
    (hdis : ∀i j,i≠j → Disjoint (C i) (C j))
    (hcross : ∀i j,i≠j → ∀u∈C i,∀v∈C j,¬G.Adj u v)
    (hcover : Finset.univ.biUnion C=Finset.univ)
    (M X : Finset V) (N Y : Finset U) (c : I → Nat) (J : Finset I) (d : Nat)
    (hc : ∀i,valueOn G (C i) M X .staller ≤ c i)
    (hj : ∀i∈J,MarkedSum.StrictCapacity (induced G (C i))
      (restrict (C i) M) (restrict (C i) X) (c i))
    (hd : MarkedSum.StrictCapacity H N Y d) :
    Marked.gameValue (MarkedSum.original G H) (MarkedSum.combine M N) .staller
      (MarkedSum.combine X Y) ≤ (d+∑i,c i)-(J.card+1)/2 := by
  classical
  apply mixed_with_strict_companion (MarkedSum.original G H)
    hSum (fun i=>left (C i)) right
  · intro i j hij
    apply Finset.disjoint_left.mpr
    intro v hv hw
    cases v with
    | inl v =>
      have hvi : v∈C i := by simpa [left,MarkedSum.liftLeft] using hv
      have hvj : v∈C j := by simpa [left,MarkedSum.liftLeft] using hw
      exact Finset.disjoint_left.mp (hdis i j hij) hvi hvj
    | inr v => simp [left,MarkedSum.liftLeft] at hv
  · intro i j hij u hu v hv ha
    cases u with
    | inr u => simp [left,MarkedSum.liftLeft] at hu
    | inl u => cases v with
      | inr v => simp [left,MarkedSum.liftLeft] at hv
      | inl v =>
        exact hcross i j hij u (by simpa [left,MarkedSum.liftLeft] using hu)
          v (by simpa [left,MarkedSum.liftLeft] using hv) ha
  · intro i
    apply Finset.disjoint_left.mpr
    intro v hv hw
    cases v <;> simp [left,right,MarkedSum.liftLeft,MarkedSum.liftRight] at *
  · intro i u hu v hv ha
    cases u with
    | inl u => simp [right,MarkedSum.liftRight] at hu
    | inr u => cases v with
      | inl v => exact ha
      | inr v => simp [left,MarkedSum.liftLeft] at hv
  · ext v
    cases v with
    | inr v => simp [right,MarkedSum.liftRight]
    | inl v =>
      have hv : v ∈ Finset.univ.biUnion C := by rw [hcover];simp
      obtain ⟨i,hi,hvi⟩ := Finset.mem_biUnion.mp hv
      simp only [Finset.mem_union,Finset.mem_univ,iff_true]
      exact Or.inr (Finset.mem_biUnion.mpr ⟨i,by simp,by simpa [left,MarkedSum.liftLeft] using hvi⟩)
  · intro i
    rw [left_value]
    exact hc i
  · intro i hi
    exact left_strict G H (C i) M X N Y (c i) (hj i hi)
  · exact right_strict G H M X N Y d hd

#print axioms leftEquiv
#print axioms rightEquiv
#print axioms left_marks
#print axioms right_marks
#print axioms left_value
#print axioms left_strict
#print axioms right_strict
#print axioms S_upper
end IsolationGame.DisjointCompanion
