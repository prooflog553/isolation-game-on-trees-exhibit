import FullCanonical16Rows03
namespace IsolationGame.FullCanonical.T16
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_16 : Finset (Fin 11) := {}
theorem after_16_0 : Marked.gameValue original marks_16 .dominator {0}=3 ∧ Marked.gameValue original marks_16 .staller {0}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_9 0 3 3 (by decide +kernel) row_9
theorem after_16_1 : Marked.gameValue original marks_16 .dominator {1}=3 ∧ Marked.gameValue original marks_16 .staller {1}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_10 1 3 3 (by decide +kernel) row_10
theorem after_16_2 : Marked.gameValue original marks_16 .dominator {2}=3 ∧ Marked.gameValue original marks_16 .staller {2}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_13 2 3 4 (by decide +kernel) row_13
theorem after_16_3 : Marked.gameValue original marks_16 .dominator {3}=3 ∧ Marked.gameValue original marks_16 .staller {3}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_15 3 3 4 (by decide +kernel) row_15
theorem after_16_4 : Marked.gameValue original marks_16 .dominator {4}=3 ∧ Marked.gameValue original marks_16 .staller {4}=3 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_16 marks_10 4 3 3 (by decide +kernel) row_10
theorem after_16_5 : Marked.gameValue original marks_16 .dominator {5}=3 ∧ Marked.gameValue original marks_16 .staller {5}=4 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_16 marks_13 5 3 4 (by decide +kernel) row_13
theorem after_16_6 : Marked.gameValue original marks_16 .dominator {6}=3 ∧ Marked.gameValue original marks_16 .staller {6}=4 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_16 marks_15 6 3 4 (by decide +kernel) row_15
theorem after_16_7 : Marked.gameValue original marks_16 .dominator {7}=3 ∧ Marked.gameValue original marks_16 .staller {7}=3 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_16 marks_10 7 3 3 (by decide +kernel) row_10
theorem after_16_8 : Marked.gameValue original marks_16 .dominator {8}=3 ∧ Marked.gameValue original marks_16 .staller {8}=4 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_16 marks_13 8 3 4 (by decide +kernel) row_13
theorem after_16_9 : Marked.gameValue original marks_16 .dominator {9}=3 ∧ Marked.gameValue original marks_16 .staller {9}=4 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_16 marks_15 9 3 4 (by decide +kernel) row_15
theorem after_16_10 : Marked.gameValue original marks_16 .dominator {10}=4 ∧ Marked.gameValue original marks_16 .staller {10}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_14 10 4 4 (by decide +kernel) row_14
theorem row_16 : Marked.gameValue original marks_16 .dominator ∅=4 ∧ Marked.gameValue original marks_16 .staller ∅=5 := by
  apply LocalProfile.DAG.bellman original marks_16 4 5 0 10 (by decide +kernel) (by decide +kernel)
  · rw [after_16_0.2]
  · rw [after_16_10.1]
  · intro v hv
    fin_cases v
    · have h := after_16_0
      change 4 ≤ 1+Marked.gameValue original marks_16 .staller {0} ∧ 1+Marked.gameValue original marks_16 .dominator {0} ≤ 5
      omega
    · have h := after_16_1
      change 4 ≤ 1+Marked.gameValue original marks_16 .staller {1} ∧ 1+Marked.gameValue original marks_16 .dominator {1} ≤ 5
      omega
    · have h := after_16_2
      change 4 ≤ 1+Marked.gameValue original marks_16 .staller {2} ∧ 1+Marked.gameValue original marks_16 .dominator {2} ≤ 5
      omega
    · have h := after_16_3
      change 4 ≤ 1+Marked.gameValue original marks_16 .staller {3} ∧ 1+Marked.gameValue original marks_16 .dominator {3} ≤ 5
      omega
    · have h := after_16_4
      change 4 ≤ 1+Marked.gameValue original marks_16 .staller {4} ∧ 1+Marked.gameValue original marks_16 .dominator {4} ≤ 5
      omega
    · have h := after_16_5
      change 4 ≤ 1+Marked.gameValue original marks_16 .staller {5} ∧ 1+Marked.gameValue original marks_16 .dominator {5} ≤ 5
      omega
    · have h := after_16_6
      change 4 ≤ 1+Marked.gameValue original marks_16 .staller {6} ∧ 1+Marked.gameValue original marks_16 .dominator {6} ≤ 5
      omega
    · have h := after_16_7
      change 4 ≤ 1+Marked.gameValue original marks_16 .staller {7} ∧ 1+Marked.gameValue original marks_16 .dominator {7} ≤ 5
      omega
    · have h := after_16_8
      change 4 ≤ 1+Marked.gameValue original marks_16 .staller {8} ∧ 1+Marked.gameValue original marks_16 .dominator {8} ≤ 5
      omega
    · have h := after_16_9
      change 4 ≤ 1+Marked.gameValue original marks_16 .staller {9} ∧ 1+Marked.gameValue original marks_16 .dominator {9} ≤ 5
      omega
    · have h := after_16_10
      change 4 ≤ 1+Marked.gameValue original marks_16 .staller {10} ∧ 1+Marked.gameValue original marks_16 .dominator {10} ≤ 5
      omega
end IsolationGame.FullCanonical.T16
