import MixedFinitePairing

namespace IsolationGame.FiniteForestComponents
open IsolatedRestriction
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
variable {V I : Type} [Fintype V] [DecidableEq V] [Fintype I] [DecidableEq I]

/-- Add one actual strict induced component to an arbitrary finite mixed
partition. All capacities refer to the original induced carriers. -/
theorem mixed_with_strict_companion (G : SimpleGraph V) (hG : G.IsAcyclic)
    (C : I → Finset V) (A : Finset V)
    (hdis : ∀i j,i≠j → Disjoint (C i) (C j))
    (hcross : ∀i j,i≠j → ∀u∈C i,∀v∈C j,¬G.Adj u v)
    (hAdis : ∀i,Disjoint A (C i))
    (hAcross : ∀i,∀u∈A,∀v∈C i,¬G.Adj u v)
    (hcover : A ∪ Finset.univ.biUnion C = Finset.univ)
    (M X : Finset V) (c : I → Nat) (J : Finset I) (d : Nat)
    (hc : ∀i,valueOn G (C i) M X .staller ≤ c i)
    (hj : ∀i∈J,MarkedSum.StrictCapacity (induced G (C i))
      (restrict (C i) M) (restrict (C i) X) (c i))
    (hd : MarkedSum.StrictCapacity (induced G A) (restrict A M) (restrict A X) d) :
    Marked.gameValue G M .staller X ≤ (d+∑i,c i)-(J.card+1)/2 := by
  classical
  let C' : Option I → Finset V := fun i => match i with | none=>A | some i=>C i
  let c' : Option I → Nat := fun i => match i with | none=>d | some i=>c i
  let J' : Finset (Option I) := insert none (J.image some)
  have hdis' : ∀i j,i≠j → Disjoint (C' i) (C' j) := by
    intro i j hij
    cases i with
    | none => cases j with
      | none => exact False.elim (hij rfl)
      | some j => exact hAdis j
    | some i => cases j with
      | none => exact (hAdis i).symm
      | some j => exact hdis i j (by intro h;exact hij (congrArg some h))
  have hcross' : ∀i j,i≠j → ∀u∈C' i,∀v∈C' j,¬G.Adj u v := by
    intro i j hij u hu v hv
    cases i with
    | none => cases j with
      | none => exact False.elim (hij rfl)
      | some j => exact hAcross j u hu v hv
    | some i => cases j with
      | none => exact fun h=>hAcross i v hv u hu h.symm
      | some j => exact hcross i j (by intro h;exact hij (congrArg some h)) u hu v hv
  have hc' : ∀i∈(Finset.univ : Finset (Option I)),valueOn G (C' i) M X .staller≤c' i := by
    intro i _
    cases i with
    | none =>
      exact (Marked.starting_player_inequality (induced G A) (restrict A M) (restrict A X)).trans hd.1
    | some i => exact hc i
  have hj' : ∀i∈J',MarkedSum.StrictCapacity (induced G (C' i))
      (restrict (C' i) M) (restrict (C' i) X) (c' i) := by
    intro i hi
    rcases Finset.mem_insert.mp hi with rfl | hi
    · exact hd
    · obtain ⟨j,hj0,rfl⟩ := Finset.mem_image.mp hi
      exact hj j hj0
  have hcard : J'.card=J.card+1 := by simp [J',Finset.card_image_of_injective,Option.some_injective]
  have hsum : (∑i : Option I,c' i)=d+∑i,c i := by simp [c',Fintype.sum_option]
  have hfull : (Finset.univ : Finset (Option I)).biUnion C'=Finset.univ := by
    rw [←hcover]
    ext v
    simp only [Finset.mem_biUnion,Finset.mem_univ,true_and,Finset.mem_union]
    constructor
    · rintro ⟨i,hi⟩
      cases i with
      | none => exact Or.inl hi
      | some i => exact Or.inr ⟨i,hi⟩
    · rintro (h | ⟨i,hi⟩)
      · exact ⟨none,h⟩
      · exact ⟨some i,hi⟩
  have h := finite_mixed_s_upper G hG C' hdis' hcross' Finset.univ J'
    (Finset.subset_univ _) M X c' hc' hj'
  rw [hfull,univ_value,hcard,hsum] at h
  exact h

#print axioms mixed_with_strict_companion
end IsolationGame.FiniteForestComponents
