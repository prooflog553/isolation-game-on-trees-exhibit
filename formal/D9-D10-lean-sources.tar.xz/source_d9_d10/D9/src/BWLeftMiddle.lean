import BWLocalFollowers
import BWDetachedModule
import WhiteRootConversionValue
namespace IsolationGame.BWBridge
open Isolation.Graph
open MarkedModule

 theorem left_local_remove (p q : Nat) (L : Side p→Prop) (R : Side q→Prop)
    (v : Side p) (hv : v≠root p) :
    (view p q).remove (whiteSum p q L R) (.inl v)=
      whiteSum p q (MarkedModule.graph.remove L v) R := by
  funext w; apply propext; cases w with
  | inr w => simp [Isolation.Graph.remove,Isolation.Graph.closed,whiteSum,Isolation.Graph.whiteSum,
      view,original,Attachment.original,GuardedEdge.view,hv]
  | inl w => simp [Isolation.Graph.remove,Isolation.Graph.closed,whiteSum,Isolation.Graph.whiteSum,
      view,original,Attachment.original,GuardedEdge.view,MarkedModule.graph]

 theorem left_middle_step (p q : Nat) (σ : State (Fin p)) (τ : State (Fin q)) (i : Fin p) :
    (view p q).step (whiteSum p q (white σ) (WhiteReserve.whiteRoot τ)) (.inl (.gate (some i)))=
      whiteSum p q (white (set σ i (afterGate (σ i)))) (WhiteReserve.whiteRoot τ) := by
  unfold Isolation.Graph.step
  rw [left_local_remove p q _ _ _ (by simp [root])]
  rw [normalize_split p q _ _ (by simp [Isolation.Graph.remove,root,white]),white_root_normalized]
  change whiteSum p q (MarkedModule.step (white σ) (.gate (some i))) _=_
  rw [MarkedModule.middle_step]

 theorem legal_right (p q : Nat) (L : Side p→Prop) (R : Side q→Prop) (v : Side q)
    (h : MarkedModule.graph.legal R v) :
    (view p q).legal (whiteSum p q L R) (.inr v) := by
  obtain ⟨w,hw,hc⟩:=h
  refine ⟨.inr w,hw,?_⟩
  simpa [Isolation.Graph.closed,view,original,Attachment.original,GuardedEdge.view,
    MarkedModule.graph] using hc

 theorem right_b_after_left_middle_legal (p q : Nat) (hq : 1≤q) (i : Fin p) (j : Fin q) :
    Marked.Legal (original p q) (marks p q) {.inl (.gate (some i))} (.inr (.b (j,false))) := by
  have hwhite : Marked.White (original p q) (marks p q) {.inl (.gate (some i))}=
      whiteSum p q (white (set (whole p) i (.opened true true))) (WhiteReserve.whiteRoot (whole q)) := by
    have h := ForestFoundation.marked_white_step (original p q) (marks p q) ∅ (.inl (.gate (some i)))
    rw [initial_white p q hq] at h
    simp only [Finset.insert_empty] at h
    exact h.symm.trans (left_middle_step p q (whole p) (whole q) i)
  apply (ForestFoundation.marked_white_legal (original p q) (marks p q) {.inl (.gate (some i))} _).mp
  rw [hwhite]
  apply legal_right
  exact (WhiteReserve.legal_arm_root (whole q) .b j false).mpr (by simp [BWBridge.whole,Status.live])

 theorem after_left_middle_b_S_bound (p q : Nat) (hp : 1≤p) (hq : 1≤q) (i : Fin p) (j : Fin q) :
    Marked.gameValue (original p q) (marks p q) .staller
      {(.inr (.b (j,false))),(.inl (.gate (some i)))} ≤ 3*(p+q)-1 := by
  have hfee := left_boundary_fee p q {(.inr (.b (j,false))),(.inl (.gate (some i)))}
  have hm : marks p q=MarkedSum.combine (MarkedModule.initialMarks (B:=Fin p)) (∅ : Finset (Side q)) := by
    simp [marks,root,MarkedModule.initialMarks,MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight]
  have hx : ({(.inr (.b (j,false))),(.inl (.gate (some i)))} : Finset (Vertex p q))=
      MarkedSum.combine {.gate (some i)} {.b (j,false)} := by
    ext v; simp [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight,or_comm]
  rw [hm,hx] at hfee
  have hsum := (MarkedSum.forest_sum_bounds
    (MarkedBoundary.isolateVertex MarkedModule.original (root p))
    (MarkedModule.original (B:=Fin q))
    (MarkedBoundary.isolate_acyclic _ _ (module_acyclic p)) (module_acyclic q)
    MarkedModule.initialMarks {.gate (some i)} ∅ {.b (j,false)}).2.2
  have hl := BWDetachedModule.isolated_middle_bound p i
  have hr := unmarked_b_S_bound q j
  rw [hm,hx]
  omega

 theorem left_middle_D_bound (p q : Nat) (hp : 1≤p) (hq : 1≤q) (i : Fin p) :
    Marked.gameValue (original p q) (marks p q) .dominator {.inl (.gate (some i))}≤3*(p+q) := by
  let j : Fin q := ⟨0,by omega⟩
  have h := Marked.d_move_upper (original p q) (marks p q) {.inl (.gate (some i))}
    (.inr (.b (j,false))) (right_b_after_left_middle_legal p q hq i j)
  have hs := after_left_middle_b_S_bound p q hp hq i j
  omega

#print axioms after_left_middle_b_S_bound
#print axioms left_middle_D_bound
end IsolationGame.BWBridge
