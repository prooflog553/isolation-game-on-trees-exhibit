import FullCanonical02Rows01
namespace IsolationGame.FullCanonical.T02
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_8 : Finset (Fin 7) := {}
theorem after_8_0 : Marked.gameValue original marks_8 .dominator {0}=2 ∧ Marked.gameValue original marks_8 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_5 0 2 2 (by decide +kernel) row_5
theorem after_8_1 : Marked.gameValue original marks_8 .dominator {1}=1 ∧ Marked.gameValue original marks_8 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_4 1 1 2 (by decide +kernel) row_4
theorem after_8_2 : Marked.gameValue original marks_8 .dominator {2}=1 ∧ Marked.gameValue original marks_8 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_6 2 1 2 (by decide +kernel) row_6
theorem after_8_3 : Marked.gameValue original marks_8 .dominator {3}=1 ∧ Marked.gameValue original marks_8 .staller {3}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_7 3 1 2 (by decide +kernel) row_7
theorem after_8_4 : Marked.gameValue original marks_8 .dominator {4}=1 ∧ Marked.gameValue original marks_8 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_8 marks_4 4 1 2 (by decide +kernel) row_4
theorem after_8_5 : Marked.gameValue original marks_8 .dominator {5}=1 ∧ Marked.gameValue original marks_8 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_8 marks_6 5 1 2 (by decide +kernel) row_6
theorem after_8_6 : Marked.gameValue original marks_8 .dominator {6}=1 ∧ Marked.gameValue original marks_8 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_8 marks_7 6 1 2 (by decide +kernel) row_7
theorem row_8 : Marked.gameValue original marks_8 .dominator ∅=3 ∧ Marked.gameValue original marks_8 .staller ∅=3 := by
  apply LocalProfile.DAG.bellman original marks_8 3 3 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_8_0.2]
  · rw [after_8_0.1]
  · intro v hv
    fin_cases v
    · have h := after_8_0
      change 3 ≤ 1+Marked.gameValue original marks_8 .staller {0} ∧ 1+Marked.gameValue original marks_8 .dominator {0} ≤ 3
      omega
    · have h := after_8_1
      change 3 ≤ 1+Marked.gameValue original marks_8 .staller {1} ∧ 1+Marked.gameValue original marks_8 .dominator {1} ≤ 3
      omega
    · have h := after_8_2
      change 3 ≤ 1+Marked.gameValue original marks_8 .staller {2} ∧ 1+Marked.gameValue original marks_8 .dominator {2} ≤ 3
      omega
    · have h := after_8_3
      change 3 ≤ 1+Marked.gameValue original marks_8 .staller {3} ∧ 1+Marked.gameValue original marks_8 .dominator {3} ≤ 3
      omega
    · have h := after_8_4
      change 3 ≤ 1+Marked.gameValue original marks_8 .staller {4} ∧ 1+Marked.gameValue original marks_8 .dominator {4} ≤ 3
      omega
    · have h := after_8_5
      change 3 ≤ 1+Marked.gameValue original marks_8 .staller {5} ∧ 1+Marked.gameValue original marks_8 .dominator {5} ≤ 3
      omega
    · have h := after_8_6
      change 3 ≤ 1+Marked.gameValue original marks_8 .staller {6} ∧ 1+Marked.gameValue original marks_8 .dominator {6} ≤ 3
      omega
end IsolationGame.FullCanonical.T02
