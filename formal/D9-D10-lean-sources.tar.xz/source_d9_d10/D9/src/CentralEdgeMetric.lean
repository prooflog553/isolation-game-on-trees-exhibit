import DescendantGeometry

/-!
Initially authored source-only on 2026-10-19. Compilation status is recorded
in the accompanying immutable build receipts and independent review evidence.

A reverse geometry interface for arbitrary actual finite trees. The two halves
are induced graphs on an exact OneBridge partition of the original vertices.
There are no game hypotheses, marked-floor assumptions, or profile hypotheses.
-/
namespace IsolationGame.DiameterNineCentralSplit

open PartitionBridge

variable {V : Type} [Fintype V] [DecidableEq V]

/-- A literal edge cut, with the intrinsic rooted radii of both induced halves.
The membership witnesses occur before the dependent root subtypes. -/
def SplitWithin (G : SimpleGraph V) (A : Finset V) (a b : V) (L R : Nat) : Prop :=
  ∃ ha : a ∈ A, ∃ hb : b ∉ A,
    G.Adj a b ∧
    OneBridge G A a b ∧
    (IsolatedRestriction.induced G A).IsTree ∧
    (IsolatedRestriction.induced G (outside A)).IsTree ∧
    (∀ v : Side A, (IsolatedRestriction.induced G A).dist ⟨a, ha⟩ v ≤ L) ∧
    (∀ v : Side (outside A),
      (IsolatedRestriction.induced G (outside A)).dist
        ⟨b, by simp [outside, hb]⟩ v ≤ R)

/-- Cutting a simple tree path at any vertex in its support gives exact
additivity of original-graph distances. -/
theorem path_distance_add (G : SimpleGraph V) (hT : G.IsTree)
    {x y z : V} (p : G.Walk x y) (hp : p.IsPath) (hz : z ∈ p.support) :
    G.dist x y = G.dist x z + G.dist z y := by
  have hpre := tree_path_length_eq_dist hT (p.takeUntil z hz) (hp.takeUntil hz)
  have hpost := tree_path_length_eq_dist hT (p.dropUntil z hz) (hp.dropUntil hz)
  have hwhole := tree_path_length_eq_dist hT p hp
  have hsplit := congrArg SimpleGraph.Walk.length (p.take_spec hz)
  simp only [SimpleGraph.Walk.length_append] at hsplit
  omega

/-- The index of a vertex of a simple tree path is its distance from the
initial endpoint. The suffix also has its exact original-graph length. -/
theorem path_getVert_distances (G : SimpleGraph V) (hT : G.IsTree)
    {x y : V} (p : G.Walk x y) (hp : p.IsPath) (i : Nat) (hi : i ≤ p.length) :
    G.dist x (p.getVert i) = i ∧ G.dist (p.getVert i) y + i = p.length := by
  have hmem := p.getVert_mem_support i
  have hle := p.length_takeUntil_le hmem
  have hget : p.getVert (p.takeUntil (p.getVert i) hmem).length = p.getVert i := by
    symm
    simpa only [SimpleGraph.Walk.getVert_length] using
      (p.getVert_takeUntil hmem (Nat.le_refl _))
  have hindex : (p.takeUntil (p.getVert i) hmem).length = i :=
    hp.getVert_injOn hle hi hget
  have hpre := tree_path_length_eq_dist hT
    (p.takeUntil (p.getVert i) hmem) (hp.takeUntil hmem)
  have hadd := path_distance_add G hT p hp hmem
  have hwhole := tree_path_length_eq_dist hT p hp
  constructor <;> omega

/-- Reverse the exact cut without changing any original vertices. -/
theorem outside_oneBridge (G : SimpleGraph V) (A : Finset V) (a b : V)
    (hcut : OneBridge G A a b) : OneBridge G (outside A) b a := by
  intro u v hu hv
  have huA : u ∉ A := by simpa [outside] using hu
  have hvA : v ∈ A := by simpa [outside] using hv
  constructor
  · intro huv
    exact ((hcut v u hvA huA).mp huv.symm).symm
  · intro he
    exact ((hcut v u hvA huA).mpr he.symm).symm

/-- Every path from one side to the other passes the appropriate endpoint.
This is the off-diametral-path control: it quantifies over all original vertices,
not just vertices lying on a selected longest path. -/
theorem distance_through_left (G : SimpleGraph V) (hT : G.IsTree)
    (A : Finset V) (a b : V) (hcut : OneBridge G A a b)
    (u v : V) (hu : u ∈ A) (hv : v ∉ A) :
    G.dist u v = G.dist u a + G.dist a v := by
  obtain ⟨p, hp, _⟩ := hT.isConnected.exists_path_of_dist v u
  have ha := walk_crosses_endpoint G A a b hcut p hv hu
  have h := path_distance_add G hT p hp ha
  rw [G.dist_comm (u := v) (v := u),
    G.dist_comm (u := v) (v := a), G.dist_comm (u := a) (v := u)] at h
  omega

#print axioms path_distance_add
#print axioms path_getVert_distances
#print axioms outside_oneBridge
#print axioms distance_through_left
end IsolationGame.DiameterNineCentralSplit
