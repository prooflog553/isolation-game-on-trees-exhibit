import FullCanonical12Rows04
namespace IsolationGame.FullCanonical.T12
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
theorem full_values : Marked.gameValue original ∅ .dominator ∅=3 ∧ Marked.gameValue original ∅ .staller ∅=4 := by
  constructor
  · exact (Marked.value_eq_of_white_eq original ∅ marks_17 ∅ ∅ .dominator (by decide +kernel)).trans row_17.1
  · exact (Marked.value_eq_of_white_eq original ∅ marks_17 ∅ ∅ .staller (by decide +kernel)).trans row_17.2
theorem not_strict_full : ¬MarkedSum.StrictCapacity original ∅ ∅ 4 := by
  intro h
  have hf := h.2 8 (by decide +kernel)
  change Marked.gameValue original marks_17 .staller {8}+1≤4 at hf
  rw [after_17_8.2] at hf
  omega
#print axioms full_values
#print axioms not_strict_full
end IsolationGame.FullCanonical.T12
