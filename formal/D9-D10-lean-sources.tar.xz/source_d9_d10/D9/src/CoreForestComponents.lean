import CoreFamilyTransition
import MixedFinitePairing
import MarkedRelabel

namespace IsolationGame.CoreForest
open CanonicalLocal CoreFamily CoreFamilySemantics IsolatedRestriction
variable (xs : List Nat) (p : Nat)

abbrev DeletedVertex := Active (MarkedBoundary.retained (none : Vertex xs p))
abbrev forest := MarkedBoundary.deleted (CoreFamily.graph xs p) none

noncomputable def component (i : Fin (xs.length+p)) : Finset (DeletedVertex xs p) :=
  @Finset.filter _ (fun v=>∃u,v.val=some ⟨i,u⟩) (Classical.decPred _) Finset.univ

theorem mem_component (i : Fin (xs.length+p)) (v : DeletedVertex xs p) :
    v∈component xs p i ↔ ∃u,v.val=some ⟨i,u⟩ := by
  simp [component]

theorem components_cover : (Finset.univ.biUnion (component xs p))=Finset.univ := by
  classical
  ext v
  simp only [Finset.mem_biUnion,Finset.mem_univ,true_and,iff_true]
  rcases v with ⟨v,hv⟩
  cases v with
  | none => simp [MarkedBoundary.retained] at hv
  | some v =>
    obtain ⟨i,u⟩ := v
    exact ⟨i,(mem_component xs p i _).mpr ⟨u,rfl⟩⟩

theorem components_disjoint (i j : Fin (xs.length+p)) (hij : i≠j) :
    Disjoint (component xs p i) (component xs p j) := by
  apply Finset.disjoint_left.mpr
  intro v hi hj
  obtain ⟨u,hu⟩ := (mem_component xs p i v).mp hi
  obtain ⟨w,hw⟩ := (mem_component xs p j v).mp hj
  have he := congrArg (fun v : Vertex xs p=>v.map Sigma.fst) (hu.symm.trans hw)
  exact hij (Option.some.inj he)

theorem components_no_cross (i j : Fin (xs.length+p)) (hij : i≠j)
    (u : DeletedVertex xs p) (hu : u∈component xs p i)
    (v : DeletedVertex xs p) (hv : v∈component xs p j) : ¬(forest xs p).Adj u v := by
  obtain ⟨a,ha⟩ := (mem_component xs p i u).mp hu
  obtain ⟨b,hb⟩ := (mem_component xs p j v).mp hv
  change ¬(CoreFamily.graph xs p).Adj u.val v.val
  rw [ha,hb]
  exact distinct_no_adj xs p i j hij a b

def embed (i : Fin (xs.length+p)) (u : Fin (size (label xs p i))) : Active (component xs p i) :=
  ⟨⟨some ⟨i,u⟩,by simp [MarkedBoundary.retained]⟩,(mem_component xs p i _).mpr ⟨u,rfl⟩⟩

theorem embed_bijective (i : Fin (xs.length+p)) : Function.Bijective (embed xs p i) := by
  constructor
  · intro u v he
    have hh := congrArg (fun w : Active (component xs p i)=>w.val.val) he
    have hsig := Option.some.inj hh
    exact eq_of_heq (Sigma.mk.inj_iff.mp hsig).2
  · intro v
    obtain ⟨u,hu⟩ := (mem_component xs p i v.val).mp v.property
    refine ⟨u,?_⟩
    apply Subtype.ext
    apply Subtype.ext
    exact hu.symm

noncomputable def localEquiv (i : Fin (xs.length+p)) :
    Fin (size (label xs p i))≃Active (component xs p i) :=
  Equiv.ofBijective (embed xs p i) (embed_bijective xs p i)

theorem local_adjacency (i : Fin (xs.length+p)) (u v : Fin (size (label xs p i))) :
    (induced (forest xs p) (component xs p i)).Adj (localEquiv xs p i u) (localEquiv xs p i v) ↔
      (CanonicalLocal.graph (label xs p i)).Adj u v :=
  same_adj xs p i u v

noncomputable def forestMarks (W : LocalWhite xs p) : Finset (DeletedVertex xs p) :=
  restrict (MarkedBoundary.retained none) (marks xs p W)

theorem local_marks_image (W : LocalWhite xs p) (i : Fin (xs.length+p)) :
    (ForestFoundation.canonicalMarks (W i)).image (localEquiv xs p i)=
      restrict (component xs p i) (forestMarks xs p W) := by
  classical
  ext v
  obtain ⟨u,rfl⟩ := (localEquiv xs p i).surjective v
  simp only [Finset.mem_image,(localEquiv xs p i).injective.eq_iff,exists_eq_right]
  simp only [mem_restrict,forestMarks]
  change u∈ForestFoundation.canonicalMarks (W i) ↔
    some ⟨i,u⟩∈marks xs p W
  simp [ForestFoundation.canonicalMarks,marks,white]

theorem local_value (W : LocalWhite xs p) (i : Fin (xs.length+p)) (turn : Player) :
    Marked.gameValue (induced (forest xs p) (component xs p i))
      (restrict (component xs p i) (forestMarks xs p W)) turn ∅=
    Marked.gameValue (CanonicalLocal.graph (label xs p i))
      (ForestFoundation.canonicalMarks (W i)) turn ∅ := by
  have h := Marked.gameValue_relabel (CanonicalLocal.graph (label xs p i))
    (induced (forest xs p) (component xs p i)) (localEquiv xs p i)
    (local_adjacency xs p i) (ForestFoundation.canonicalMarks (W i)) ∅ turn
  simpa only [local_marks_image,Finset.image_empty] using h

theorem local_strict (W : LocalWhite xs p) (i : Fin (xs.length+p)) (c : Nat)
    (h : MarkedSum.StrictCapacity (CanonicalLocal.graph (label xs p i))
      (ForestFoundation.canonicalMarks (W i)) ∅ c) :
    MarkedSum.StrictCapacity (induced (forest xs p) (component xs p i))
      (restrict (component xs p i) (forestMarks xs p W)) ∅ c := by
  have ht := MarkedSum.strict_relabel (CanonicalLocal.graph (label xs p i))
    (induced (forest xs p) (component xs p i)) (localEquiv xs p i)
    (local_adjacency xs p i) (ForestFoundation.canonicalMarks (W i)) ∅ c h
  simpa only [local_marks_image,Finset.image_empty] using ht

#print axioms local_value
#print axioms local_strict
end IsolationGame.CoreForest
