import GeneralP4StrictLocal

namespace IsolationGame.GeneralP4Receiver
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

/-- Unmarked original P4 strict capacity, including all original followers. -/
theorem p4_unmarked_strict : MarkedSum.StrictCapacity P4Receiver.T ∅ ∅ 2 := by
  constructor
  · have h : Marked.gameValue P4Receiver.T ∅ .dominator ∅≤1 :=
      (Marked.gameValue_le_iff _ _ _ _ _).mpr (by decide +kernel)
    omega
  · intro v _
    have h : Marked.gameValue P4Receiver.T ∅ .staller {v}≤1 := by
      apply (Marked.gameValue_le_iff _ _ _ _ _).mpr
      fin_cases v <;> decide +kernel
    simpa only [Finset.insert_empty] using (by omega :
      Marked.gameValue P4Receiver.T ∅ .staller {v}+1≤2)

theorem p4_unmarked_pair_S : Marked.gameValue pairGraph ∅ .staller ∅≤3 := by
  have h := MarkedSum.forest_strict_pair P4Receiver.T P4Receiver.T
    P4Receiver.t_acyclic P4Receiver.t_acyclic ∅ ∅ ∅ ∅ 2 2
    p4_unmarked_strict p4_unmarked_strict
  simpa only [P4Receiver.empty_combine] using h

section DoubleIsolation
variable {V : Type} [Fintype V] [DecidableEq V]

/-- Exact full-carrier adjacency after isolating the shared marked centre. -/
theorem double_isolate_adj (G : SimpleGraph V) (z : V)
    (u v : (V ⊕ Fin 4) ⊕ Fin 4) :
    (MarkedSum.original (MarkedBoundary.isolateVertex G z) pairGraph).Adj
        (tripleAssoc u) (tripleAssoc v) ↔
      (MarkedBoundary.isolateVertex (doubleGraph G z) (.inl (.inl z))).Adj u v := by
  rcases u with (u|u)|u
  all_goals rcases v with (v|v)|v
  all_goals simp [doubleGraph,P4Receiver.A,Attachment.original,MarkedBoundary.isolateVertex,
    tripleAssoc,Equiv.sumAssoc,MarkedSum.original,MarkedSum.graph,
    Isolation.Graph.disjointSum,GuardedEdge.view]
  all_goals tauto

theorem double_unmarked_image (M : Finset V) :
    (doubleMarks M).image tripleAssoc=MarkedSum.combine M (∅ : Finset (Fin 4 ⊕ Fin 4)) := by
  classical
  ext v
  rw [image_mem_equiv]
  rcases v with v | (r|s)
  all_goals simp [doubleMarks,P4Receiver.AM,tripleAssoc,Equiv.sumAssoc]

theorem double_isolate_S_bound (G : SimpleGraph V) (z : V) (M : Finset V)
    (hG : G.IsAcyclic) (hz : z∈M) (v : V) :
    Marked.gameValue (doubleGraph G z) (doubleMarks M) .staller {.inl (.inl v)} ≤
      1+Marked.gameValue (MarkedBoundary.isolateVertex G z) M .staller {v}+3 := by
  have hA := attachment_acyclic (P4Receiver.A G z) (.inl z) (attachment_acyclic G z hG)
  have hm : Sum.inl (Sum.inl z)∈doubleMarks M := by simp [doubleMarks,P4Receiver.AM,hz]
  have hf := MarkedBoundary.S_fee (doubleGraph G z) (.inl (.inl z)) hA
    (doubleMarks M) {.inl (.inl v)} hm
  have he := Marked.gameValue_relabel
    (MarkedBoundary.isolateVertex (doubleGraph G z) (.inl (.inl z)))
    (MarkedSum.original (MarkedBoundary.isolateVertex G z) pairGraph)
    tripleAssoc (double_isolate_adj G z) (doubleMarks M) {.inl (.inl v)} .staller
  rw [double_unmarked_image] at he
  simp only [Finset.image_singleton] at he
  rw [←he] at hf
  have hs := MarkedSum.S_upper_value (MarkedBoundary.isolateVertex G z) pairGraph
    (MarkedSum.forest_no_minus _ (MarkedBoundary.isolate_acyclic G z hG))
    (MarkedSum.forest_no_minus pairGraph pair_acyclic) M {v} ∅ ∅
  have hx : MarkedSum.combine ({v} : Finset V) (∅ : Finset (Fin 4 ⊕ Fin 4))={.inl v} := by
    simp [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight]
  rw [hx] at hs
  have hp := p4_unmarked_pair_S
  change Marked.gameValue (doubleGraph G z) (doubleMarks M) .staller {.inl (.inl v)} ≤
    1+Marked.gameValue (MarkedSum.original (MarkedBoundary.isolateVertex G z) pairGraph)
      (MarkedSum.combine M ∅) .staller {.inl v} at hf
  omega
end DoubleIsolation

/-- One local ordinary move reduces the erased pure-forest capacity by one. -/
theorem pure_forest_ordinary_paid (p : Nat) (i : Fin p) (u : Fin 7) :
    1+Marked.gameValue (CoreForest.forest [] p)
      (CoreForest.forestMarks [] p (PureModuleStrict.W p)) .staller
      {CoreForest.moveVertex [] p (Fin.cast (Nat.zero_add p).symm i) u}≤3*p := by
  let j : Fin (0+p) := Fin.cast (Nat.zero_add p).symm i
  let c : Fin (0+p)→Nat := fun k=>if k=j then 2 else 3
  have hc : ∀k : Fin (0+p),Marked.gameValue (CanonicalLocal.graph (CoreFamily.label [] p k))
      (ForestFoundation.canonicalMarks (CoreFamilySemantics.playLocal [] p (PureModuleStrict.W p) j u k))
      .staller ∅≤c k := by
    intro k
    by_cases hk : k=j
    · subst k
      simp only [CoreFamilySemantics.playLocal,Function.update_self,c,ite_true]
      exact PureModuleStrict.local_follow_S u
    · simp only [CoreFamilySemantics.playLocal,Function.update_of_ne hk,c,if_neg hk]
      exact PureModuleStrict.local_initial_S.le
  have hf := CoreForest.mixed_s_upper [] p (CoreFamily.family_tree [] p).IsAcyclic
    (CoreFamilySemantics.playLocal [] p (PureModuleStrict.W p) j u) c ∅ hc (by simp)
  simp only [Finset.card_empty,Nat.zero_div,Nat.sub_zero] at hf
  rw [CoreForest.local_next_value [] p (PureModuleStrict.W p) (PureModuleStrict.normalized p)]
  have he := PureModuleStrict.one_cost_sum j
  change (∑k,c k)+1=3*(0+p) at he
  change 1+Marked.gameValue (CoreForest.forest [] p)
    (CoreForest.forestMarks [] p (CoreFamilySemantics.playLocal [] p (PureModuleStrict.W p) j u)) .staller ∅≤3*p
  calc
    _≤1+∑k,c k := Nat.add_le_add_left hf 1
    _=3*p := by omega

theorem pure_isolate_adj (p : Nat) (u v : Vertex 0 p) :
    (MarkedBoundary.isolateVertex (CoreFamily.graph [] p) none).Adj (pureEquiv p u) (pureEquiv p v) ↔
      (MarkedBoundary.isolateVertex (graph 0 p) (centre 0 p)).Adj u v := by
  have hr (v : Vertex 0 p) : pureEquiv p v=none ↔ v=centre 0 p := by
    rw [←pure_centre p]
    exact (pureEquiv p).injective.eq_iff
  simp only [MarkedBoundary.isolateVertex,pureEquiv_adj,ne_eq,hr]

theorem pure_isolate_ordinary_paid (p : Nat) (i : Fin p) (u : Fin 7) :
    1+Marked.gameValue (MarkedBoundary.isolateVertex (graph 0 p) (centre 0 p))
      (marks 0 p) .staller {ordinary 0 p i u}≤3*p := by
  have he := Marked.gameValue_relabel
    (MarkedBoundary.isolateVertex (graph 0 p) (centre 0 p))
    (MarkedBoundary.isolateVertex (CoreFamily.graph [] p) none)
    (pureEquiv p) (pure_isolate_adj p) (marks 0 p) {ordinary 0 p i u} .staller
  rw [pure_marks] at he
  simp only [Finset.image_singleton,pure_ordinary] at he
  rw [←he,←PureModuleStrict.initial_marks p,
    MarkedBoundary.isolated_value_eq_deleted]
  have hx := CoreForest.restrict_move [] p (Fin.cast (Nat.zero_add p).symm i) u
  rw [hx]
  exact pure_forest_ordinary_paid p i u

/-- Every original first follower on the complete two-P4 receiver carrier. -/
theorem two_follower_S (p : Nat) (v : Vertex 2 p) :
    Marked.gameValue (graph 2 p) (marks 2 p) .staller {v}≤3*p+3 := by
  rcases TwoPool.vertex_exhaustion p 0 v with ⟨a,rfl⟩ | ⟨i,r,rfl⟩ | ⟨i,r,rfl⟩
  · cases a with
    | none =>
      change Marked.gameValue (graph 2 p) (marks 2 p) .staller {centre 2 p}≤3*p+3
      rw [root_absorb]
      simpa [cBudget] using root_played_S_strong 2 p
    | some a =>
      rcases a with ⟨i,r⟩
      change Marked.gameValue (graph 2 p) (marks 2 p) .staller {branch 2 p i r}≤3*p+3
      rw [value_permute 2 p (Equiv.swap i 0)]
      simp only [Finset.image_singleton,permute_branch,Equiv.swap_apply_left]
      rw [value_split]
      change Marked.gameValue (P4Receiver.A (graph 1 p) (centre 1 p))
        (P4Receiver.AM (marks 1 p)) .staller {.inr r}≤3*p+3
      have h := p4_right_follower_S (graph 1 p) (centre 1 p) (marks 1 p)
        (graph_acyclic 1 p) (root_marked 1 p) r
      have hs := S_upper_strong 1 p
      omega
  · change Marked.gameValue (graph 2 p) (marks 2 p) .staller {ordinary 2 p i r}≤3*p+3
    rw [value_doubleSplit 0 p]
    change Marked.gameValue (doubleGraph (graph 0 p) (centre 0 p)) (doubleMarks (marks 0 p))
      .staller {.inl (.inl (ordinary 0 p i r))}≤3*p+3
    have h := double_isolate_S_bound (graph 0 p) (centre 0 p) (marks 0 p)
      (graph_acyclic 0 p) (root_marked 0 p) (ordinary 0 p i r)
    have hp := pure_isolate_ordinary_paid p i r
    have hh : 1+Marked.gameValue (MarkedBoundary.isolateVertex (graph 0 p) (centre 0 p))
        (marks 0 p) .staller {ordinary 0 p i r}+3≤3*p+3 := by omega
    convert le_trans h hh using 1
    congr 1
  · exact Fin.elim0 i

/-- Full strict capacity, all natural ordinary multiplicities and all original
legal followers. The initially marked centre remains an original action. -/
theorem two_strict_capacity (p : Nat) :
    MarkedSum.StrictCapacity (graph 2 p) (marks 2 p) ∅ (3*p+4) := by
  constructor
  · have h := D_upper_strong 2 p
    omega
  · intro v _
    simp only [Finset.insert_empty]
    have h := two_follower_S p v
    omega

#print axioms p4_unmarked_strict
#print axioms double_isolate_S_bound
#print axioms pure_forest_ordinary_paid
#print axioms pure_isolate_ordinary_paid
#print axioms two_follower_S
#print axioms two_strict_capacity
end IsolationGame.GeneralP4Receiver
