import ExceptionalCoreStrictCapacity
import GeneralP4StrictCapacity
import PairableProfileReceiverFamily

namespace IsolationGame.ExceptionalCoreReceiver
open CanonicalLocal AllProfileCore PairableProfileCore

set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

abbrev Vertex (xs : List Nat) (q p : Nat) := PairableProfileReceiver.Vertex xs q 2 p
abbrev graph (xs : List Nat) (q p : Nat) := PairableProfileReceiver.graph xs q 2 p

theorem opening_split (xs : List Nat) (q p : Nat) (turn : Player) :
    Marked.gameValue (graph xs q p) ∅ turn
      {GenericCoreReceiver.openingRoot (V:=CoreFamily.Vertex xs q) none 2 p} =
      Marked.gameValue (MarkedSum.original (CoreFamily.graph xs q) (GeneralP4Receiver.graph 2 p))
        (MarkedSum.combine (SelectedVertex.playedMarks (CoreFamily.graph xs q) ∅ none)
          (GeneralP4Receiver.marks 2 p)) turn ∅ := by
  convert GenericCoreReceiver.opening_split (CoreFamily.graph xs q) none 2 p turn using 1
    <;> congr 1 <;> apply Subsingleton.elim

/-- The core root has actually been selected; the receiver root has only
been marked by that move. Both original component carriers are retained. -/
theorem opening_S_upper (xs : List Nat) (q p : Nat)
    (hshape : ∀n ∈ xs, NecessaryCore.decode n=.t01 ∨
      NecessaryCore.decode n=.t02 ∨ NecessaryCore.decode n=.t08)
    (hp : 0 < pairCount xs) :
    Marked.gameValue (graph xs q p) ∅ .staller
      {GenericCoreReceiver.openingRoot (V:=CoreFamily.Vertex xs q) none 2 p} ≤
      3*(p+q)+cost xs+3 := by
  rw [opening_split]
  have h := MarkedSum.forest_strict_pair
    (CoreFamily.graph xs q) (GeneralP4Receiver.graph 2 p)
    (AllProfileCore.core_tree xs q).IsAcyclic (GeneralP4Receiver.graph_acyclic 2 p)
    (SelectedVertex.playedMarks (CoreFamily.graph xs q) ∅ none) ∅
    (GeneralP4Receiver.marks 2 p) ∅ (3*q+cost xs) (3*p+4)
    (ExceptionalCoreStrict.root_playedMarks_strict xs q hshape hp)
    (GeneralP4Receiver.two_strict_capacity p)
  have he : MarkedSum.combine (∅ : Finset (CoreFamily.Vertex xs q))
      (∅ : Finset (GeneralP4Receiver.Vertex 2 p)) = ∅ := by
    simp [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight]
  rw [he] at h
  have ha : (3*q+cost xs)+(3*p+4)-1 ≤ 3*(p+q)+cost xs+3 := by omega
  convert h.trans ha using 1 <;> congr 1 <;> apply Subsingleton.elim

/-- The paid first Dominator move plus the strict-pair saving. -/
theorem ordinary_scalar_upper (xs : List Nat) (q p : Nat)
    (hshape : ∀n ∈ xs, NecessaryCore.decode n=.t01 ∨
      NecessaryCore.decode n=.t02 ∨ NecessaryCore.decode n=.t08)
    (hp : 0 < pairCount xs) :
    isolationNumber (graph xs q p) ≤ 3*(p+q)+cost xs+4 := by
  have hm := Marked.d_move_upper
    (GenericCoreReceiver.graph (CoreFamily.graph xs q) none 2 p) ∅ ∅
    (GenericCoreReceiver.openingRoot none 2 p)
    (GenericCoreReceiver.opening_legal (CoreFamily.graph xs q) none 2 p)
  simp only [Finset.insert_empty] at hm
  have hs := opening_S_upper xs q p hshape hp
  change Marked.gameValue
    (GenericCoreReceiver.graph (CoreFamily.graph xs q) none 2 p) ∅ .staller
    {GenericCoreReceiver.openingRoot none 2 p} ≤ 3*(p+q)+cost xs+3 at hs
  have ht := hm.trans (Nat.add_le_add_left hs 1)
  change IsolationGame.gameValue (graph xs q p) .dominator ∅ ≤ _
  rw [←Marked.value_empty_marks]
  convert ht using 1 <;> first | omega | (congr 1 <;> apply Subsingleton.elim)

#print axioms opening_S_upper
#print axioms ordinary_scalar_upper
end IsolationGame.ExceptionalCoreReceiver
