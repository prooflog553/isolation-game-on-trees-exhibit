import FullCanonical08Rows03
namespace IsolationGame.FullCanonical.T08
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_16 : Finset (Fin 11) := {0,1,2,3,7,10}
theorem after_16_0 : Marked.gameValue original marks_16 .dominator {0}=2 ∧ Marked.gameValue original marks_16 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_11 0 2 2 (by decide +kernel) row_11
theorem after_16_4 : Marked.gameValue original marks_16 .dominator {4}=1 ∧ Marked.gameValue original marks_16 .staller {4}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_3 4 1 1 (by decide +kernel) row_3
theorem after_16_5 : Marked.gameValue original marks_16 .dominator {5}=1 ∧ Marked.gameValue original marks_16 .staller {5}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_3 5 1 1 (by decide +kernel) row_3
theorem after_16_6 : Marked.gameValue original marks_16 .dominator {6}=1 ∧ Marked.gameValue original marks_16 .staller {6}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_3 6 1 1 (by decide +kernel) row_3
theorem after_16_7 : Marked.gameValue original marks_16 .dominator {7}=1 ∧ Marked.gameValue original marks_16 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_6 7 1 2 (by decide +kernel) row_6
theorem after_16_8 : Marked.gameValue original marks_16 .dominator {8}=1 ∧ Marked.gameValue original marks_16 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_6 8 1 2 (by decide +kernel) row_6
theorem after_16_9 : Marked.gameValue original marks_16 .dominator {9}=1 ∧ Marked.gameValue original marks_16 .staller {9}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_6 9 1 2 (by decide +kernel) row_6
theorem row_16 : Marked.gameValue original marks_16 .dominator ∅=2 ∧ Marked.gameValue original marks_16 .staller ∅=3 := by
  apply LocalProfile.DAG.bellman original marks_16 2 3 4 0 (by decide +kernel) (by decide +kernel)
  · rw [after_16_4.2]
  · rw [after_16_0.1]
  · intro v hv
    fin_cases v
    · have h := after_16_0
      change 2 ≤ 1+Marked.gameValue original marks_16 .staller {0} ∧ 1+Marked.gameValue original marks_16 .dominator {0} ≤ 3
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_16 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_16 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_16 ∅ 3) hv)
    · have h := after_16_4
      change 2 ≤ 1+Marked.gameValue original marks_16 .staller {4} ∧ 1+Marked.gameValue original marks_16 .dominator {4} ≤ 3
      omega
    · have h := after_16_5
      change 2 ≤ 1+Marked.gameValue original marks_16 .staller {5} ∧ 1+Marked.gameValue original marks_16 .dominator {5} ≤ 3
      omega
    · have h := after_16_6
      change 2 ≤ 1+Marked.gameValue original marks_16 .staller {6} ∧ 1+Marked.gameValue original marks_16 .dominator {6} ≤ 3
      omega
    · have h := after_16_7
      change 2 ≤ 1+Marked.gameValue original marks_16 .staller {7} ∧ 1+Marked.gameValue original marks_16 .dominator {7} ≤ 3
      omega
    · have h := after_16_8
      change 2 ≤ 1+Marked.gameValue original marks_16 .staller {8} ∧ 1+Marked.gameValue original marks_16 .dominator {8} ≤ 3
      omega
    · have h := after_16_9
      change 2 ≤ 1+Marked.gameValue original marks_16 .staller {9} ∧ 1+Marked.gameValue original marks_16 .dominator {9} ≤ 3
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_16 ∅ 10) hv)
def marks_17 : Finset (Fin 11) := {2,3,5,6,8,9}
theorem after_17_0 : Marked.gameValue original marks_17 .dominator {0}=0 ∧ Marked.gameValue original marks_17 .staller {0}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_0 0 0 0 (by decide +kernel) row_0
theorem after_17_1 : Marked.gameValue original marks_17 .dominator {1}=1 ∧ Marked.gameValue original marks_17 .staller {1}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_4 1 1 1 (by decide +kernel) row_4
theorem after_17_2 : Marked.gameValue original marks_17 .dominator {2}=1 ∧ Marked.gameValue original marks_17 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_12 2 1 2 (by decide +kernel) row_12
theorem after_17_4 : Marked.gameValue original marks_17 .dominator {4}=1 ∧ Marked.gameValue original marks_17 .staller {4}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_4 4 1 1 (by decide +kernel) row_4
theorem after_17_5 : Marked.gameValue original marks_17 .dominator {5}=1 ∧ Marked.gameValue original marks_17 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_17 marks_12 5 1 2 (by decide +kernel) row_12
theorem after_17_7 : Marked.gameValue original marks_17 .dominator {7}=0 ∧ Marked.gameValue original marks_17 .staller {7}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_0 7 0 0 (by decide +kernel) row_0
theorem after_17_8 : Marked.gameValue original marks_17 .dominator {8}=1 ∧ Marked.gameValue original marks_17 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_5 8 1 2 (by decide +kernel) row_5
theorem after_17_10 : Marked.gameValue original marks_17 .dominator {10}=1 ∧ Marked.gameValue original marks_17 .staller {10}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_5 10 1 2 (by decide +kernel) row_5
theorem row_17 : Marked.gameValue original marks_17 .dominator ∅=1 ∧ Marked.gameValue original marks_17 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_17 1 2 0 1 (by decide +kernel) (by decide +kernel)
  · rw [after_17_0.2]
  · rw [after_17_1.1]
  · intro v hv
    fin_cases v
    · have h := after_17_0
      change 1 ≤ 1+Marked.gameValue original marks_17 .staller {0} ∧ 1+Marked.gameValue original marks_17 .dominator {0} ≤ 2
      omega
    · have h := after_17_1
      change 1 ≤ 1+Marked.gameValue original marks_17 .staller {1} ∧ 1+Marked.gameValue original marks_17 .dominator {1} ≤ 2
      omega
    · have h := after_17_2
      change 1 ≤ 1+Marked.gameValue original marks_17 .staller {2} ∧ 1+Marked.gameValue original marks_17 .dominator {2} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_17 ∅ 3) hv)
    · have h := after_17_4
      change 1 ≤ 1+Marked.gameValue original marks_17 .staller {4} ∧ 1+Marked.gameValue original marks_17 .dominator {4} ≤ 2
      omega
    · have h := after_17_5
      change 1 ≤ 1+Marked.gameValue original marks_17 .staller {5} ∧ 1+Marked.gameValue original marks_17 .dominator {5} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_17 ∅ 6) hv)
    · have h := after_17_7
      change 1 ≤ 1+Marked.gameValue original marks_17 .staller {7} ∧ 1+Marked.gameValue original marks_17 .dominator {7} ≤ 2
      omega
    · have h := after_17_8
      change 1 ≤ 1+Marked.gameValue original marks_17 .staller {8} ∧ 1+Marked.gameValue original marks_17 .dominator {8} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_17 ∅ 9) hv)
    · have h := after_17_10
      change 1 ≤ 1+Marked.gameValue original marks_17 .staller {10} ∧ 1+Marked.gameValue original marks_17 .dominator {10} ≤ 2
      omega
def marks_18 : Finset (Fin 11) := {0,1,2,3,8,9}
theorem after_18_0 : Marked.gameValue original marks_18 .dominator {0}=1 ∧ Marked.gameValue original marks_18 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_18 marks_2 0 1 1 (by decide +kernel) row_2
theorem after_18_4 : Marked.gameValue original marks_18 .dominator {4}=1 ∧ Marked.gameValue original marks_18 .staller {4}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_18 marks_4 4 1 1 (by decide +kernel) row_4
theorem after_18_5 : Marked.gameValue original marks_18 .dominator {5}=1 ∧ Marked.gameValue original marks_18 .staller {5}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_18 marks_4 5 1 1 (by decide +kernel) row_4
theorem after_18_6 : Marked.gameValue original marks_18 .dominator {6}=1 ∧ Marked.gameValue original marks_18 .staller {6}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_18 marks_4 6 1 1 (by decide +kernel) row_4
theorem after_18_7 : Marked.gameValue original marks_18 .dominator {7}=1 ∧ Marked.gameValue original marks_18 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_18 marks_6 7 1 2 (by decide +kernel) row_6
theorem after_18_8 : Marked.gameValue original marks_18 .dominator {8}=1 ∧ Marked.gameValue original marks_18 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_18 marks_6 8 1 2 (by decide +kernel) row_6
theorem after_18_10 : Marked.gameValue original marks_18 .dominator {10}=1 ∧ Marked.gameValue original marks_18 .staller {10}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_18 marks_6 10 1 2 (by decide +kernel) row_6
theorem row_18 : Marked.gameValue original marks_18 .dominator ∅=2 ∧ Marked.gameValue original marks_18 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_18 2 2 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_18_0.2]
  · rw [after_18_0.1]
  · intro v hv
    fin_cases v
    · have h := after_18_0
      change 2 ≤ 1+Marked.gameValue original marks_18 .staller {0} ∧ 1+Marked.gameValue original marks_18 .dominator {0} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_18 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_18 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_18 ∅ 3) hv)
    · have h := after_18_4
      change 2 ≤ 1+Marked.gameValue original marks_18 .staller {4} ∧ 1+Marked.gameValue original marks_18 .dominator {4} ≤ 2
      omega
    · have h := after_18_5
      change 2 ≤ 1+Marked.gameValue original marks_18 .staller {5} ∧ 1+Marked.gameValue original marks_18 .dominator {5} ≤ 2
      omega
    · have h := after_18_6
      change 2 ≤ 1+Marked.gameValue original marks_18 .staller {6} ∧ 1+Marked.gameValue original marks_18 .dominator {6} ≤ 2
      omega
    · have h := after_18_7
      change 2 ≤ 1+Marked.gameValue original marks_18 .staller {7} ∧ 1+Marked.gameValue original marks_18 .dominator {7} ≤ 2
      omega
    · have h := after_18_8
      change 2 ≤ 1+Marked.gameValue original marks_18 .staller {8} ∧ 1+Marked.gameValue original marks_18 .dominator {8} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_18 ∅ 9) hv)
    · have h := after_18_10
      change 2 ≤ 1+Marked.gameValue original marks_18 .staller {10} ∧ 1+Marked.gameValue original marks_18 .dominator {10} ≤ 2
      omega
def marks_19 : Finset (Fin 11) := {1,2,3,4,5,6}
theorem after_19_0 : Marked.gameValue original marks_19 .dominator {0}=1 ∧ Marked.gameValue original marks_19 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_19 marks_3 0 1 1 (by decide +kernel) row_3
theorem after_19_1 : Marked.gameValue original marks_19 .dominator {1}=1 ∧ Marked.gameValue original marks_19 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_19 marks_13 1 1 2 (by decide +kernel) row_13
theorem after_19_4 : Marked.gameValue original marks_19 .dominator {4}=1 ∧ Marked.gameValue original marks_19 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_19 marks_13 4 1 2 (by decide +kernel) row_13
theorem after_19_7 : Marked.gameValue original marks_19 .dominator {7}=0 ∧ Marked.gameValue original marks_19 .staller {7}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_19 marks_0 7 0 0 (by decide +kernel) row_0
theorem after_19_8 : Marked.gameValue original marks_19 .dominator {8}=0 ∧ Marked.gameValue original marks_19 .staller {8}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_19 marks_0 8 0 0 (by decide +kernel) row_0
theorem after_19_9 : Marked.gameValue original marks_19 .dominator {9}=1 ∧ Marked.gameValue original marks_19 .staller {9}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_19 marks_7 9 1 2 (by decide +kernel) row_7
theorem after_19_10 : Marked.gameValue original marks_19 .dominator {10}=1 ∧ Marked.gameValue original marks_19 .staller {10}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_19 marks_3 10 1 1 (by decide +kernel) row_3
theorem row_19 : Marked.gameValue original marks_19 .dominator ∅=1 ∧ Marked.gameValue original marks_19 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_19 1 2 7 0 (by decide +kernel) (by decide +kernel)
  · rw [after_19_7.2]
  · rw [after_19_0.1]
  · intro v hv
    fin_cases v
    · have h := after_19_0
      change 1 ≤ 1+Marked.gameValue original marks_19 .staller {0} ∧ 1+Marked.gameValue original marks_19 .dominator {0} ≤ 2
      omega
    · have h := after_19_1
      change 1 ≤ 1+Marked.gameValue original marks_19 .staller {1} ∧ 1+Marked.gameValue original marks_19 .dominator {1} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_19 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_19 ∅ 3) hv)
    · have h := after_19_4
      change 1 ≤ 1+Marked.gameValue original marks_19 .staller {4} ∧ 1+Marked.gameValue original marks_19 .dominator {4} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_19 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_19 ∅ 6) hv)
    · have h := after_19_7
      change 1 ≤ 1+Marked.gameValue original marks_19 .staller {7} ∧ 1+Marked.gameValue original marks_19 .dominator {7} ≤ 2
      omega
    · have h := after_19_8
      change 1 ≤ 1+Marked.gameValue original marks_19 .staller {8} ∧ 1+Marked.gameValue original marks_19 .dominator {8} ≤ 2
      omega
    · have h := after_19_9
      change 1 ≤ 1+Marked.gameValue original marks_19 .staller {9} ∧ 1+Marked.gameValue original marks_19 .dominator {9} ≤ 2
      omega
    · have h := after_19_10
      change 1 ≤ 1+Marked.gameValue original marks_19 .staller {10} ∧ 1+Marked.gameValue original marks_19 .dominator {10} ≤ 2
      omega
end IsolationGame.FullCanonical.T08
