import FullCanonical03
import StrictCompanionPairing
import PrivateSwitchAttachment
import PureModuleStrict

/-! SOURCE-ONLY. The middle/end distinction is deliberately explicit.
The accepted row_13 has an original BLUE first move 2 with S-follower 4;
therefore it is NOT strict at capacity 4 despite D=3,S=4. -/
namespace IsolationGame.CompositeWhiteCore03Facts
open FullCanonical.T03
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

/-- All original legal first actions of row_12, not merely its D/S gap. -/
theorem middle_strict : MarkedSum.StrictCapacity original marks_12 ∅ 4 := by
  constructor
  · rw [row_12.1] <;> omega
  · intro v hv
    fin_cases v
    · change Marked.gameValue original marks_12 .staller {0}+1≤4
      rw [after_12_0.2] <;> omega
    · change Marked.gameValue original marks_12 .staller {1}+1≤4
      rw [after_12_1.2] <;> omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_12 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_12 ∅ 3) hv)
    · change Marked.gameValue original marks_12 .staller {4}+1≤4
      rw [after_12_4.2] <;> omega
    · change Marked.gameValue original marks_12 .staller {5}+1≤4
      rw [after_12_5.2] <;> omega
    · change Marked.gameValue original marks_12 .staller {6}+1≤4
      rw [after_12_6.2] <;> omega
    · change Marked.gameValue original marks_12 .staller {7}+1≤4
      rw [after_12_7.2] <;> omega
    · change Marked.gameValue original marks_12 .staller {8}+1≤4
      rw [after_12_8.2] <;> omega
    · change Marked.gameValue original marks_12 .staller {9}+1≤4
      rw [after_12_9.2] <;> omega

/-- The end state's tempting strict-capacity-4 claim is false. -/
theorem end_not_strict : ¬MarkedSum.StrictCapacity original marks_13 ∅ 4 := by
  intro h
  have hl : Marked.Legal original marks_13 ∅ (2 : Fin 10) := by decide +kernel
  have hh := h.2 2 hl
  change Marked.gameValue original marks_13 .staller {2}+1≤4 at hh
  rw [after_13_2.2] at hh
  omega

/-- The original arm-start is the private switch. In the end state it may
itself be white; OriginalBridge explicitly handles its later isolation. -/
theorem middle_private : ∀ w : Fin 10,
    Marked.White original marks_12 ∅ w → original.Adj 1 w → w=0 := by
  decide +kernel

theorem end_private : ∀ w : Fin 10,
    Marked.White original marks_13 ∅ w → original.Adj 1 w → w=0 := by
  decide +kernel

abbrev P (p : Nat) := CoreFamily.graph [] p

/-- An active blue original global port is handled by real guarded edge
simulation. It is NOT deleted under a false two-marked-endpoint premise. -/
theorem middle_blue_port_bound (p : Nat) (turn : Player) :
    Marked.gameValue (Attachment.original (P p) original none 0)
      (MarkedSum.combine {none} marks_12) turn ∅ ≤
    Marked.gameValue (MarkedSum.original (P p) original)
      (MarkedSum.combine {none} marks_12) turn ∅ :=
  Attachment.private_switch_value_bound (P p) original none 0 1 {none} marks_12
    (Finset.mem_singleton_self _) (by decide +kernel) middle_private turn

/-- The active-port comparison is also true for the end state, but the local
strictness needed for the desired one-move saving is absent. -/
theorem end_blue_port_bound (p : Nat) (turn : Player) :
    Marked.gameValue (Attachment.original (P p) original none 0)
      (MarkedSum.combine {none} marks_13) turn ∅ ≤
    Marked.gameValue (MarkedSum.original (P p) original)
      (MarkedSum.combine {none} marks_13) turn ∅ :=
  Attachment.private_switch_value_bound (P p) original none 0 1 {none} marks_13
    (Finset.mem_singleton_self _) (by decide +kernel) end_private turn

/-- A genuine all-p MIDDLE follower bound on the actual full attachment.
This is the newly implemented safe saving. It is not asserted for the end
follower and is not an unconditional Q03 strict-capacity theorem. -/
theorem middle_follower_S_upper (p : Nat) :
    Marked.gameValue (Attachment.original (P p) original none 0)
      (MarkedSum.combine {none} marks_12) .staller ∅ ≤ 3*p+4 := by
  have hg := (CoreFamily.family_tree [] p).IsAcyclic
  have hT : original.IsAcyclic := by
    have ht : original.IsTree := CanonicalLocal.tree_of_certificate original 0
      (by unfold CanonicalLocal.ReachThree; decide +kernel) (by decide +kernel)
    exact ht.IsAcyclic
  have hp := MarkedSum.forest_strict_pair (P p) original hg hT
    {none} ∅ marks_12 ∅ (3*p+1) 4 (PureModuleStrict.family_strict p) middle_strict
  have he0 : MarkedSum.combine (∅ : Finset (CoreFamily.Vertex [] p))
      (∅ : Finset (Fin 10)) = ∅ := by
    simp [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight]
  rw [he0] at hp
  have hb := middle_blue_port_bound p .staller
  omega

#print axioms middle_strict
#print axioms end_not_strict
#print axioms middle_blue_port_bound
#print axioms end_blue_port_bound
#print axioms middle_follower_S_upper
end IsolationGame.CompositeWhiteCore03Facts
