import AttachmentSplit
import LocalStarCount

namespace IsolationGame.Attachment
open Isolation.Graph
variable {V U : Type} [Fintype V] [DecidableEq V] [Fintype U] [DecidableEq U]
  (G : SimpleGraph V) (H : SimpleGraph U) (z : V) (b : U)

theorem inactive_capacity (hG : G.IsAcyclic) (hH : H.IsAcyclic)
    (hLoc : AttachmentGeometry.LocalSpec H b)
    (M X : Finset V) (N Y : Finset U)
    (hi : ¬Marked.Legal (original G H z b) (MarkedSum.combine M N) (MarkedSum.combine X Y) (.inr b))
    (p : Player) :
    Marked.gameValue (original G H z b) (MarkedSum.combine M N) p (MarkedSum.combine X Y) ≤
      Marked.gameValue G M .staller X+(AttachmentGeometry.longStars H b).card := by
  let P := leftWhite G H z b M X N Y
  let Q := rightWhite G H z b M X N Y
  let MP := ForestFoundation.canonicalMarks P
  let MQ := ForestFoundation.canonicalMarks Q
  have hnP := left_normalized G H z b M X N Y hi
  have hnQ := right_normalized G H z b M X N Y hi
  have hbase : Marked.gameValue G MP .staller ∅≤Marked.gameValue G M .staller X := by
    apply Marked.value_of_white_subset
    intro v hv
    exact left_white_subset G H z b M X N Y hi v ((ForestFoundation.canonical_white G P hnP v).mp hv)
  have hr : ¬Marked.Legal H MQ ∅ b := by
    rintro ⟨w,hc,hw⟩
    have hq := (ForestFoundation.canonical_white H Q hnQ w).mp hw
    exact hi ⟨.inr w,(closed_right G H z b b w).mpr hc,hq⟩
  have hlocal := AttachmentGeometry.actual_local_capacity H b hLoc MQ ∅ hr .staller
  have hsum := MarkedSum.S_upper_value G H (MarkedSum.forest_no_minus G hG)
    (MarkedSum.forest_no_minus H hH) MP ∅ MQ ∅
  have hds := MarkedSum.sum_d_le_s G H (MarkedSum.forest_no_minus G hG)
    (MarkedSum.forest_no_minus H hH) MP ∅ MQ ∅
  have hempty : MarkedSum.combine (∅ : Finset V) (∅ : Finset U)=∅ := by
    simp [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight]
  rw [hempty] at hsum hds
  rw [inactive_split_value G H z b M X N Y hi p]
  change Marked.gameValue (MarkedSum.original G H) (MarkedSum.combine MP MQ) p ∅ ≤ _
  cases p with
  | dominator => exact hds.trans (hsum.trans (Nat.add_le_add hbase hlocal))
  | staller => exact hsum.trans (Nat.add_le_add hbase hlocal)

 theorem combine_insert_left (X : Finset V) (Y : Finset U) (v : V) :
    MarkedSum.combine (insert v X) Y=insert (.inl v) (MarkedSum.combine X Y) := by
  simp [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight]

 theorem combine_insert_right (X : Finset V) (Y : Finset U) (v : U) :
    MarkedSum.combine X (insert v Y)=insert (.inr v) (MarkedSum.combine X Y) := by
  simp [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight]

 theorem root_selected_illegal (M X : Finset V) (N Y : Finset U) (hb : b∈Y) :
    ¬Marked.Legal (original G H z b) (MarkedSum.combine M N) (MarkedSum.combine X Y) (.inr b) := by
  rintro ⟨w,hc,hw⟩
  exact hw.1.2 ⟨.inr b,(MarkedSum.combine_inr X Y b).mpr hb,hc⟩

#print axioms inactive_capacity
end IsolationGame.Attachment
