import FullCanonical08Rows02
namespace IsolationGame.FullCanonical.T08
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_12 : Finset (Fin 11) := {1,2,3,5,6,8,9}
theorem after_12_0 : Marked.gameValue original marks_12 .dominator {0}=0 ∧ Marked.gameValue original marks_12 .staller {0}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_0 0 0 0 (by decide +kernel) row_0
theorem after_12_1 : Marked.gameValue original marks_12 .dominator {1}=1 ∧ Marked.gameValue original marks_12 .staller {1}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_4 1 1 1 (by decide +kernel) row_4
theorem after_12_4 : Marked.gameValue original marks_12 .dominator {4}=1 ∧ Marked.gameValue original marks_12 .staller {4}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_4 4 1 1 (by decide +kernel) row_4
theorem after_12_5 : Marked.gameValue original marks_12 .dominator {5}=1 ∧ Marked.gameValue original marks_12 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_7 5 1 2 (by decide +kernel) row_7
theorem after_12_7 : Marked.gameValue original marks_12 .dominator {7}=0 ∧ Marked.gameValue original marks_12 .staller {7}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_0 7 0 0 (by decide +kernel) row_0
theorem after_12_8 : Marked.gameValue original marks_12 .dominator {8}=1 ∧ Marked.gameValue original marks_12 .staller {8}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_1 8 1 1 (by decide +kernel) row_1
theorem after_12_10 : Marked.gameValue original marks_12 .dominator {10}=1 ∧ Marked.gameValue original marks_12 .staller {10}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_1 10 1 1 (by decide +kernel) row_1
theorem row_12 : Marked.gameValue original marks_12 .dominator ∅=1 ∧ Marked.gameValue original marks_12 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_12 1 2 0 1 (by decide +kernel) (by decide +kernel)
  · rw [after_12_0.2]
  · rw [after_12_1.1]
  · intro v hv
    fin_cases v
    · have h := after_12_0
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {0} ∧ 1+Marked.gameValue original marks_12 .dominator {0} ≤ 2
      omega
    · have h := after_12_1
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {1} ∧ 1+Marked.gameValue original marks_12 .dominator {1} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_12 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_12 ∅ 3) hv)
    · have h := after_12_4
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {4} ∧ 1+Marked.gameValue original marks_12 .dominator {4} ≤ 2
      omega
    · have h := after_12_5
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {5} ∧ 1+Marked.gameValue original marks_12 .dominator {5} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_12 ∅ 6) hv)
    · have h := after_12_7
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {7} ∧ 1+Marked.gameValue original marks_12 .dominator {7} ≤ 2
      omega
    · have h := after_12_8
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {8} ∧ 1+Marked.gameValue original marks_12 .dominator {8} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_12 ∅ 9) hv)
    · have h := after_12_10
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {10} ∧ 1+Marked.gameValue original marks_12 .dominator {10} ≤ 2
      omega
def marks_13 : Finset (Fin 11) := {0,1,2,3,4,5,6}
theorem after_13_0 : Marked.gameValue original marks_13 .dominator {0}=1 ∧ Marked.gameValue original marks_13 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_3 0 1 1 (by decide +kernel) row_3
theorem after_13_7 : Marked.gameValue original marks_13 .dominator {7}=0 ∧ Marked.gameValue original marks_13 .staller {7}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_0 7 0 0 (by decide +kernel) row_0
theorem after_13_8 : Marked.gameValue original marks_13 .dominator {8}=0 ∧ Marked.gameValue original marks_13 .staller {8}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_0 8 0 0 (by decide +kernel) row_0
theorem after_13_9 : Marked.gameValue original marks_13 .dominator {9}=1 ∧ Marked.gameValue original marks_13 .staller {9}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_4 9 1 1 (by decide +kernel) row_4
theorem after_13_10 : Marked.gameValue original marks_13 .dominator {10}=1 ∧ Marked.gameValue original marks_13 .staller {10}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_3 10 1 1 (by decide +kernel) row_3
theorem row_13 : Marked.gameValue original marks_13 .dominator ∅=1 ∧ Marked.gameValue original marks_13 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_13 1 2 7 0 (by decide +kernel) (by decide +kernel)
  · rw [after_13_7.2]
  · rw [after_13_0.1]
  · intro v hv
    fin_cases v
    · have h := after_13_0
      change 1 ≤ 1+Marked.gameValue original marks_13 .staller {0} ∧ 1+Marked.gameValue original marks_13 .dominator {0} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_13 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_13 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_13 ∅ 3) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_13 ∅ 4) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_13 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_13 ∅ 6) hv)
    · have h := after_13_7
      change 1 ≤ 1+Marked.gameValue original marks_13 .staller {7} ∧ 1+Marked.gameValue original marks_13 .dominator {7} ≤ 2
      omega
    · have h := after_13_8
      change 1 ≤ 1+Marked.gameValue original marks_13 .staller {8} ∧ 1+Marked.gameValue original marks_13 .dominator {8} ≤ 2
      omega
    · have h := after_13_9
      change 1 ≤ 1+Marked.gameValue original marks_13 .staller {9} ∧ 1+Marked.gameValue original marks_13 .dominator {9} ≤ 2
      omega
    · have h := after_13_10
      change 1 ≤ 1+Marked.gameValue original marks_13 .staller {10} ∧ 1+Marked.gameValue original marks_13 .dominator {10} ≤ 2
      omega
def marks_14 : Finset (Fin 11) := {2,3,7,8,9,10}
theorem after_14_0 : Marked.gameValue original marks_14 .dominator {0}=1 ∧ Marked.gameValue original marks_14 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_2 0 1 1 (by decide +kernel) row_2
theorem after_14_1 : Marked.gameValue original marks_14 .dominator {1}=1 ∧ Marked.gameValue original marks_14 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_6 1 1 2 (by decide +kernel) row_6
theorem after_14_2 : Marked.gameValue original marks_14 .dominator {2}=1 ∧ Marked.gameValue original marks_14 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_9 2 1 2 (by decide +kernel) row_9
theorem after_14_4 : Marked.gameValue original marks_14 .dominator {4}=0 ∧ Marked.gameValue original marks_14 .staller {4}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_0 4 0 0 (by decide +kernel) row_0
theorem after_14_5 : Marked.gameValue original marks_14 .dominator {5}=1 ∧ Marked.gameValue original marks_14 .staller {5}=1 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_14 marks_1 5 1 1 (by decide +kernel) row_1
theorem after_14_6 : Marked.gameValue original marks_14 .dominator {6}=1 ∧ Marked.gameValue original marks_14 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_5 6 1 2 (by decide +kernel) row_5
theorem after_14_7 : Marked.gameValue original marks_14 .dominator {7}=1 ∧ Marked.gameValue original marks_14 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_6 7 1 2 (by decide +kernel) row_6
theorem row_14 : Marked.gameValue original marks_14 .dominator ∅=1 ∧ Marked.gameValue original marks_14 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_14 1 2 4 0 (by decide +kernel) (by decide +kernel)
  · rw [after_14_4.2]
  · rw [after_14_0.1]
  · intro v hv
    fin_cases v
    · have h := after_14_0
      change 1 ≤ 1+Marked.gameValue original marks_14 .staller {0} ∧ 1+Marked.gameValue original marks_14 .dominator {0} ≤ 2
      omega
    · have h := after_14_1
      change 1 ≤ 1+Marked.gameValue original marks_14 .staller {1} ∧ 1+Marked.gameValue original marks_14 .dominator {1} ≤ 2
      omega
    · have h := after_14_2
      change 1 ≤ 1+Marked.gameValue original marks_14 .staller {2} ∧ 1+Marked.gameValue original marks_14 .dominator {2} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_14 ∅ 3) hv)
    · have h := after_14_4
      change 1 ≤ 1+Marked.gameValue original marks_14 .staller {4} ∧ 1+Marked.gameValue original marks_14 .dominator {4} ≤ 2
      omega
    · have h := after_14_5
      change 1 ≤ 1+Marked.gameValue original marks_14 .staller {5} ∧ 1+Marked.gameValue original marks_14 .dominator {5} ≤ 2
      omega
    · have h := after_14_6
      change 1 ≤ 1+Marked.gameValue original marks_14 .staller {6} ∧ 1+Marked.gameValue original marks_14 .dominator {6} ≤ 2
      omega
    · have h := after_14_7
      change 1 ≤ 1+Marked.gameValue original marks_14 .staller {7} ∧ 1+Marked.gameValue original marks_14 .dominator {7} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_14 ∅ 8) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_14 ∅ 9) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_14 ∅ 10) hv)
def marks_15 : Finset (Fin 11) := {2,3,5,6,7,10}
theorem after_15_0 : Marked.gameValue original marks_15 .dominator {0}=1 ∧ Marked.gameValue original marks_15 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_3 0 1 1 (by decide +kernel) row_3
theorem after_15_1 : Marked.gameValue original marks_15 .dominator {1}=1 ∧ Marked.gameValue original marks_15 .staller {1}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_3 1 1 1 (by decide +kernel) row_3
theorem after_15_2 : Marked.gameValue original marks_15 .dominator {2}=1 ∧ Marked.gameValue original marks_15 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_10 2 1 2 (by decide +kernel) row_10
theorem after_15_4 : Marked.gameValue original marks_15 .dominator {4}=1 ∧ Marked.gameValue original marks_15 .staller {4}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_3 4 1 1 (by decide +kernel) row_3
theorem after_15_5 : Marked.gameValue original marks_15 .dominator {5}=1 ∧ Marked.gameValue original marks_15 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_15 marks_10 5 1 2 (by decide +kernel) row_10
theorem after_15_7 : Marked.gameValue original marks_15 .dominator {7}=0 ∧ Marked.gameValue original marks_15 .staller {7}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_0 7 0 0 (by decide +kernel) row_0
theorem after_15_8 : Marked.gameValue original marks_15 .dominator {8}=1 ∧ Marked.gameValue original marks_15 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_5 8 1 2 (by decide +kernel) row_5
theorem after_15_9 : Marked.gameValue original marks_15 .dominator {9}=1 ∧ Marked.gameValue original marks_15 .staller {9}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_5 9 1 2 (by decide +kernel) row_5
theorem row_15 : Marked.gameValue original marks_15 .dominator ∅=1 ∧ Marked.gameValue original marks_15 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_15 1 2 7 0 (by decide +kernel) (by decide +kernel)
  · rw [after_15_7.2]
  · rw [after_15_0.1]
  · intro v hv
    fin_cases v
    · have h := after_15_0
      change 1 ≤ 1+Marked.gameValue original marks_15 .staller {0} ∧ 1+Marked.gameValue original marks_15 .dominator {0} ≤ 2
      omega
    · have h := after_15_1
      change 1 ≤ 1+Marked.gameValue original marks_15 .staller {1} ∧ 1+Marked.gameValue original marks_15 .dominator {1} ≤ 2
      omega
    · have h := after_15_2
      change 1 ≤ 1+Marked.gameValue original marks_15 .staller {2} ∧ 1+Marked.gameValue original marks_15 .dominator {2} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_15 ∅ 3) hv)
    · have h := after_15_4
      change 1 ≤ 1+Marked.gameValue original marks_15 .staller {4} ∧ 1+Marked.gameValue original marks_15 .dominator {4} ≤ 2
      omega
    · have h := after_15_5
      change 1 ≤ 1+Marked.gameValue original marks_15 .staller {5} ∧ 1+Marked.gameValue original marks_15 .dominator {5} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_15 ∅ 6) hv)
    · have h := after_15_7
      change 1 ≤ 1+Marked.gameValue original marks_15 .staller {7} ∧ 1+Marked.gameValue original marks_15 .dominator {7} ≤ 2
      omega
    · have h := after_15_8
      change 1 ≤ 1+Marked.gameValue original marks_15 .staller {8} ∧ 1+Marked.gameValue original marks_15 .dominator {8} ≤ 2
      omega
    · have h := after_15_9
      change 1 ≤ 1+Marked.gameValue original marks_15 .staller {9} ∧ 1+Marked.gameValue original marks_15 .dominator {9} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_15 ∅ 10) hv)
end IsolationGame.FullCanonical.T08
