import FullCanonical07Rows04
namespace IsolationGame.FullCanonical.T07
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
theorem full_values : Marked.gameValue original ∅ .dominator ∅=3 ∧ Marked.gameValue original ∅ .staller ∅=3 := by
  constructor
  · exact (Marked.value_eq_of_white_eq original ∅ marks_16 ∅ ∅ .dominator (by decide +kernel)).trans row_16.1
  · exact (Marked.value_eq_of_white_eq original ∅ marks_16 ∅ ∅ .staller (by decide +kernel)).trans row_16.2
theorem not_strict_full : ¬MarkedSum.StrictCapacity original ∅ ∅ 3 := by
  intro h
  have hd := h.1
  rw [full_values.1] at hd
  omega
#print axioms full_values
#print axioms not_strict_full
end IsolationGame.FullCanonical.T07
