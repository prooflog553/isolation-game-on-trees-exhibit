import FourteenResidualData

/-! Finite kernel arithmetic only: first profile fixed to t13.
All arithmetic is checked by kernel reduction; no graph or history search. -/
namespace IsolationGame.FourteenResidual
open CanonicalLocal
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

theorem check11_t13 (b : Index) :
    NumericResidual [.t13] [b] → MatchesFourteen [.t13] [b] := by
  cases b <;> decide +kernel

theorem check12_t13 (b c : Index) :
    NumericResidual [.t13] [b, c] → MatchesFourteen [.t13] [b, c] := by
  cases b <;> cases c <;> decide +kernel

#print axioms check11_t13
#print axioms check12_t13
end IsolationGame.FourteenResidual
