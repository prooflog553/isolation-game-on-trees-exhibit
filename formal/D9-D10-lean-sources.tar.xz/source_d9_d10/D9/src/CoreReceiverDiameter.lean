import CoreReceiverRootRadius

/-! Geometry of the exact full original attachment. No bound on game values
or coverage of other diameter-nine trees is claimed here. -/
namespace IsolationGame.CoreReceiverGeometry
open RootedBridgeDiameter

abbrev Vertex (xs : List Nat) (q k p : Nat) :=
  CoreFamily.Vertex xs q ⊕ GeneralP4Receiver.Vertex k p

def graph (xs : List Nat) (q k p : Nat) : SimpleGraph (Vertex xs q k p) :=
  Attachment.original (CoreFamily.graph xs q) (GeneralP4Receiver.graph k p)
    none (GeneralP4Receiver.centre k p)

theorem dist_le_nine (xs : List Nat) (q k p : Nat) (v w : Vertex xs q k p) :
    (graph xs q k p).dist v w ≤ 9 :=
  original_dist_le_nine _ _ _ _ (core_rootWalkBound xs q) (receiver_rootWalkBound k p) v w

theorem diam_le_nine (xs : List Nat) (q k p : Nat) : (graph xs q k p).diam ≤ 9 :=
  original_diam_le_nine _ _ _ _ (core_rootWalkBound xs q) (receiver_rootWalkBound k p)

/-- The exact H(q)=[3,15] core / G(k,p) receiver family, for every q,k,p. -/
theorem core0315_receiver_diam_le_nine (q k p : Nat) :
    (Attachment.original (CoreFamily.graph [3,15] q) (GeneralP4Receiver.graph k p)
      none (GeneralP4Receiver.centre k p)).diam ≤ 9 :=
  diam_le_nine [3,15] q k p

#print axioms dist_le_nine
#print axioms diam_le_nine
#print axioms core0315_receiver_diam_le_nine
end IsolationGame.CoreReceiverGeometry
