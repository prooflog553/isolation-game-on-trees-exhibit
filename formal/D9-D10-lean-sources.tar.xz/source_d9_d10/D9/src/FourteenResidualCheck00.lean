import FourteenResidualData

/-! Finite kernel arithmetic only: first profile fixed to t00.
All arithmetic is checked by kernel reduction; no graph or history search. -/
namespace IsolationGame.FourteenResidual
open CanonicalLocal
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

theorem check11_t00 (b : Index) :
    NumericResidual [.t00] [b] → MatchesFourteen [.t00] [b] := by
  cases b <;> decide +kernel

theorem check12_t00 (b c : Index) :
    NumericResidual [.t00] [b, c] → MatchesFourteen [.t00] [b, c] := by
  cases b <;> cases c <;> decide +kernel

#print axioms check11_t00
#print axioms check12_t00
end IsolationGame.FourteenResidual
