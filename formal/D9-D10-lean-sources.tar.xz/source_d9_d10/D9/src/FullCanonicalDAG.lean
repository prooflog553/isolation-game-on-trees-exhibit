import ProfileDAG
import MarkedRelabel
import CanonicalProfiles

namespace IsolationGame.FullCanonicalDAG
variable {V : Type} [Fintype V] [DecidableEq V] (G : SimpleGraph V)

theorem transport_perm (e : V ≃ V) (he : ∀v w,G.Adj (e v) (e w) ↔ G.Adj v w)
    (M N : Finset V) (v : V) (d s : Nat)
    (hw : ∀w,Marked.White G M {v} w ↔ Marked.White G N ∅ (e w))
    (hc : Marked.gameValue G N .dominator ∅=d ∧ Marked.gameValue G N .staller ∅=s) :
    Marked.gameValue G M .dominator {v}=d ∧ Marked.gameValue G M .staller {v}=s := by
  have ht (turn : Player) : Marked.gameValue G M turn {v}=Marked.gameValue G N turn ∅ := by
    have heq := Marked.gameValue_relabel G G e he M {v} turn
    have hw' : ∀w,Marked.White G (M.image e) (({v} : Finset V).image e) w ↔ Marked.White G N ∅ w := by
      intro w
      obtain ⟨u,rfl⟩ := e.surjective w
      exact (Marked.white_relabel G G e he M {v} u).trans (hw u)
    exact heq.symm.trans (Marked.value_eq_of_white_eq G (M.image e) N (({v} : Finset V).image e) ∅ turn hw')
  exact ⟨(ht .dominator).trans hc.1,(ht .staller).trans hc.2⟩

#print axioms transport_perm
end IsolationGame.FullCanonicalDAG
