import FullCanonical18Rows00
namespace IsolationGame.FullCanonical.T18
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_4 : Finset (Fin 9) := {1,2,3,4,5,6,7}
theorem after_4_0 : Marked.gameValue original marks_4 .dominator {0}=0 ∧ Marked.gameValue original marks_4 .staller {0}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_4 marks_0 0 0 0 (by decide +kernel) row_0
theorem after_4_1 : Marked.gameValue original marks_4 .dominator {1}=0 ∧ Marked.gameValue original marks_4 .staller {1}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_4 marks_0 1 0 0 (by decide +kernel) row_0
theorem after_4_4 : Marked.gameValue original marks_4 .dominator {4}=0 ∧ Marked.gameValue original marks_4 .staller {4}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_4 marks_0 4 0 0 (by decide +kernel) row_0
theorem after_4_8 : Marked.gameValue original marks_4 .dominator {8}=0 ∧ Marked.gameValue original marks_4 .staller {8}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_4 marks_0 8 0 0 (by decide +kernel) row_0
theorem row_4 : Marked.gameValue original marks_4 .dominator ∅=1 ∧ Marked.gameValue original marks_4 .staller ∅=1 := by
  apply LocalProfile.DAG.bellman original marks_4 1 1 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_4_0.2]
  · rw [after_4_0.1]
  · intro v hv
    fin_cases v
    · have h := after_4_0
      change 1 ≤ 1+Marked.gameValue original marks_4 .staller {0} ∧ 1+Marked.gameValue original marks_4 .dominator {0} ≤ 1
      omega
    · have h := after_4_1
      change 1 ≤ 1+Marked.gameValue original marks_4 .staller {1} ∧ 1+Marked.gameValue original marks_4 .dominator {1} ≤ 1
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 3) hv)
    · have h := after_4_4
      change 1 ≤ 1+Marked.gameValue original marks_4 .staller {4} ∧ 1+Marked.gameValue original marks_4 .dominator {4} ≤ 1
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 6) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 7) hv)
    · have h := after_4_8
      change 1 ≤ 1+Marked.gameValue original marks_4 .staller {8} ∧ 1+Marked.gameValue original marks_4 .dominator {8} ≤ 1
      omega
def marks_5 : Finset (Fin 9) := {0,4,5,6,7,8}
theorem after_5_0 : Marked.gameValue original marks_5 .dominator {0}=1 ∧ Marked.gameValue original marks_5 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_5 marks_1 0 1 1 (by decide +kernel) row_1
theorem after_5_1 : Marked.gameValue original marks_5 .dominator {1}=0 ∧ Marked.gameValue original marks_5 .staller {1}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_5 marks_0 1 0 0 (by decide +kernel) row_0
theorem after_5_2 : Marked.gameValue original marks_5 .dominator {2}=0 ∧ Marked.gameValue original marks_5 .staller {2}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_5 marks_0 2 0 0 (by decide +kernel) row_0
theorem after_5_3 : Marked.gameValue original marks_5 .dominator {3}=0 ∧ Marked.gameValue original marks_5 .staller {3}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_5 marks_0 3 0 0 (by decide +kernel) row_0
theorem row_5 : Marked.gameValue original marks_5 .dominator ∅=1 ∧ Marked.gameValue original marks_5 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_5 1 2 1 0 (by decide +kernel) (by decide +kernel)
  · rw [after_5_1.2]
  · rw [after_5_0.1]
  · intro v hv
    fin_cases v
    · have h := after_5_0
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {0} ∧ 1+Marked.gameValue original marks_5 .dominator {0} ≤ 2
      omega
    · have h := after_5_1
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {1} ∧ 1+Marked.gameValue original marks_5 .dominator {1} ≤ 2
      omega
    · have h := after_5_2
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {2} ∧ 1+Marked.gameValue original marks_5 .dominator {2} ≤ 2
      omega
    · have h := after_5_3
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {3} ∧ 1+Marked.gameValue original marks_5 .dominator {3} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 4) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 6) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 7) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 8) hv)
def marks_6 : Finset (Fin 9) := {2,3,4,5,6,7}
theorem after_6_0 : Marked.gameValue original marks_6 .dominator {0}=0 ∧ Marked.gameValue original marks_6 .staller {0}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_6 marks_0 0 0 0 (by decide +kernel) row_0
theorem after_6_1 : Marked.gameValue original marks_6 .dominator {1}=0 ∧ Marked.gameValue original marks_6 .staller {1}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_6 marks_0 1 0 0 (by decide +kernel) row_0
theorem after_6_2 : Marked.gameValue original marks_6 .dominator {2}=1 ∧ Marked.gameValue original marks_6 .staller {2}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_6 marks_4 2 1 1 (by decide +kernel) row_4
theorem after_6_4 : Marked.gameValue original marks_6 .dominator {4}=0 ∧ Marked.gameValue original marks_6 .staller {4}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_6 marks_0 4 0 0 (by decide +kernel) row_0
theorem after_6_8 : Marked.gameValue original marks_6 .dominator {8}=0 ∧ Marked.gameValue original marks_6 .staller {8}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_6 marks_0 8 0 0 (by decide +kernel) row_0
theorem row_6 : Marked.gameValue original marks_6 .dominator ∅=1 ∧ Marked.gameValue original marks_6 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_6 1 2 0 2 (by decide +kernel) (by decide +kernel)
  · rw [after_6_0.2]
  · rw [after_6_2.1]
  · intro v hv
    fin_cases v
    · have h := after_6_0
      change 1 ≤ 1+Marked.gameValue original marks_6 .staller {0} ∧ 1+Marked.gameValue original marks_6 .dominator {0} ≤ 2
      omega
    · have h := after_6_1
      change 1 ≤ 1+Marked.gameValue original marks_6 .staller {1} ∧ 1+Marked.gameValue original marks_6 .dominator {1} ≤ 2
      omega
    · have h := after_6_2
      change 1 ≤ 1+Marked.gameValue original marks_6 .staller {2} ∧ 1+Marked.gameValue original marks_6 .dominator {2} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_6 ∅ 3) hv)
    · have h := after_6_4
      change 1 ≤ 1+Marked.gameValue original marks_6 .staller {4} ∧ 1+Marked.gameValue original marks_6 .dominator {4} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_6 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_6 ∅ 6) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_6 ∅ 7) hv)
    · have h := after_6_8
      change 1 ≤ 1+Marked.gameValue original marks_6 .staller {8} ∧ 1+Marked.gameValue original marks_6 .dominator {8} ≤ 2
      omega
def marks_7 : Finset (Fin 9) := {0,1,4,7,8}
theorem after_7_1 : Marked.gameValue original marks_7 .dominator {1}=1 ∧ Marked.gameValue original marks_7 .staller {1}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_2 1 1 1 (by decide +kernel) row_2
theorem after_7_2 : Marked.gameValue original marks_7 .dominator {2}=1 ∧ Marked.gameValue original marks_7 .staller {2}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_2 2 1 1 (by decide +kernel) row_2
theorem after_7_3 : Marked.gameValue original marks_7 .dominator {3}=1 ∧ Marked.gameValue original marks_7 .staller {3}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_2 3 1 1 (by decide +kernel) row_2
theorem after_7_4 : Marked.gameValue original marks_7 .dominator {4}=1 ∧ Marked.gameValue original marks_7 .staller {4}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_1 4 1 1 (by decide +kernel) row_1
theorem after_7_5 : Marked.gameValue original marks_7 .dominator {5}=1 ∧ Marked.gameValue original marks_7 .staller {5}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_1 5 1 1 (by decide +kernel) row_1
theorem after_7_6 : Marked.gameValue original marks_7 .dominator {6}=1 ∧ Marked.gameValue original marks_7 .staller {6}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_1 6 1 1 (by decide +kernel) row_1
theorem row_7 : Marked.gameValue original marks_7 .dominator ∅=2 ∧ Marked.gameValue original marks_7 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_7 2 2 1 1 (by decide +kernel) (by decide +kernel)
  · rw [after_7_1.2]
  · rw [after_7_1.1]
  · intro v hv
    fin_cases v
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_7 ∅ 0) hv)
    · have h := after_7_1
      change 2 ≤ 1+Marked.gameValue original marks_7 .staller {1} ∧ 1+Marked.gameValue original marks_7 .dominator {1} ≤ 2
      omega
    · have h := after_7_2
      change 2 ≤ 1+Marked.gameValue original marks_7 .staller {2} ∧ 1+Marked.gameValue original marks_7 .dominator {2} ≤ 2
      omega
    · have h := after_7_3
      change 2 ≤ 1+Marked.gameValue original marks_7 .staller {3} ∧ 1+Marked.gameValue original marks_7 .dominator {3} ≤ 2
      omega
    · have h := after_7_4
      change 2 ≤ 1+Marked.gameValue original marks_7 .staller {4} ∧ 1+Marked.gameValue original marks_7 .dominator {4} ≤ 2
      omega
    · have h := after_7_5
      change 2 ≤ 1+Marked.gameValue original marks_7 .staller {5} ∧ 1+Marked.gameValue original marks_7 .dominator {5} ≤ 2
      omega
    · have h := after_7_6
      change 2 ≤ 1+Marked.gameValue original marks_7 .staller {6} ∧ 1+Marked.gameValue original marks_7 .dominator {6} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_7 ∅ 7) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_7 ∅ 8) hv)
end IsolationGame.FullCanonical.T18
