import CoreFamilySteps

namespace IsolationGame.CoreFamilySemantics
open CanonicalLocal CoreFamily Isolation.Graph
variable (xs : List Nat) (p : Nat)

def initialLocal : LocalWhite xs p := fun i=>
  (GuardedEdge.view (CanonicalLocal.graph (label xs p i))).noniso (fun _=>True)

theorem initial_normalized : Normalized xs p (initialLocal xs p) := by
  intro i
  funext v
  exact propext ((GuardedEdge.view (CanonicalLocal.graph (label xs p i))).normalize_idempotent _ v)

/-- Exact initialization of the unchanged original graph: only the centre is
marked, and no vertex has yet been selected. -/
theorem initial_original_white (v : Vertex xs p) :
    Marked.White (CoreFamily.graph xs p) {none} ∅ v ↔ white xs p (initialLocal xs p) v := by
  rw [←GuardedEdge.white_agree]
  have hr : (GuardedEdge.view (CoreFamily.graph xs p)).raw
      (fun u=>u∈({none} : Finset (Vertex xs p))) (fun u=>u∈(∅ : Finset (Vertex xs p)))=
      white xs p (fun _ _=>True) := by
    funext u
    apply propext
    cases u <;> simp [raw,white]
  rw [hr]
  cases v with
  | none => exact iff_of_false (noniso_root xs p _) id
  | some v =>
    obtain ⟨i,u⟩ := v
    exact noniso_local xs p _ i u

theorem initial_value (turn : Player) :
    Marked.gameValue (CoreFamily.graph xs p) {none} turn ∅=
      Marked.gameValue (CoreFamily.graph xs p) (marks xs p (initialLocal xs p)) turn ∅ := by
  apply Marked.value_eq_of_white_eq
  intro v
  exact (initial_original_white xs p v).trans
    (original_white xs p (initialLocal xs p) (initial_normalized xs p) v).symm

#print axioms initial_original_white
#print axioms initial_value
end IsolationGame.CoreFamilySemantics
