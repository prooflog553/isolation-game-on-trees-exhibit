import BWLeftMiddle
import BWOddGated
namespace Isolation.Graph
variable {V : Type} (G : Graph V)

 theorem step_commute (W : V→Prop) (v w : V) : G.step (G.step W v) w=G.step (G.step W w) v := by
  funext z; apply propext
  unfold step
  rw [normalize_move,normalize_move]
  have he : G.remove (G.remove W v) w=G.remove (G.remove W w) v := by
    funext a; apply propext; simp only [remove]; tauto
  rw [he]
end Isolation.Graph

namespace IsolationGame.BWBridge
open Isolation.Graph
open MarkedModule

 theorem gated_agree {n : Nat} (σ : State (Fin n)) :
    MarkedModule.graph.AgreeOnWhite (GatedGraph.graph MarkedModule.owner) (gatedWhite σ) := by
  intro v w hw
  exact (GuardedEdge.closed_agree MarkedModule.original v w).trans
    ((GatedGraph.connected_closed MarkedModule.owner MarkedModule.star (gatedState σ) v w hw).trans
      (GuardedEdge.closed_agree (GatedGraph.original MarkedModule.owner) v w).symm)

 theorem gated_delete_whole {n : Nat} (σ : State (Fin n)) (i : Fin n) (s : Bool) (hi : σ i=.whole) :
    (gatedState σ).deleteUnit (i,s)=gatedState (set σ i (.reserve (!s))) := by
  apply congrArg₂ Gated.State.mk
  · ext j; obtain ⟨k,t⟩ := j
    by_cases hk : k=i
    · subst k; cases s <;> cases t <;>
        simp [Gated.State.deleteUnit,gatedState,MarkedModule.set,hi,Status.live]
    · cases s <;> cases t <;>
        simp [Gated.State.deleteUnit,gatedState,MarkedModule.set,hk,Ne.symm hk,Status.live]
  · ext j; cases j with
    | none => simp [Gated.State.deleteUnit,gatedState]
    | some k =>
      by_cases hk : k=i
      · subst k; cases s <;> simp [Gated.State.deleteUnit,gatedState,MarkedModule.set,hi,Status.closed]
      · simp [Gated.State.deleteUnit,gatedState,MarkedModule.set,hk]

 theorem gated_arm_step {n : Nat} (σ : State (Fin n)) (a : Arm) (i : Fin n) (s : Bool) (hi : σ i=.whole) :
    MarkedModule.step (gatedWhite σ) (arm a i s)=gatedWhite (set σ i (.reserve (!s))) := by
  have he : MarkedModule.step (gatedWhite σ) (arm a i s)=
      (GatedGraph.graph MarkedModule.owner).noniso
        ((GatedGraph.graph MarkedModule.owner).remove (gatedWhite σ) (arm a i s)) := by
    funext w; exact propext (MarkedModule.graph.move_congr _ _ (gated_agree σ) _ w)
  rw [he]
  cases a <;> simp only [arm]
  · rw [GatedGraph.state_b_step,gated_delete_whole σ i s hi]
  · rw [GatedGraph.state_c_step,gated_delete_whole σ i s hi]
  · rw [GatedGraph.state_d_step,gated_delete_whole σ i s hi]

 theorem left_local_step (p q : Nat) (L : Side p→Prop) (R : Side q→Prop)
    (hL : ¬L (root p)) (hRn : MarkedModule.graph.noniso R=R)
    (v : Side p) (hv : v≠root p) :
    (view p q).step (whiteSum p q L R) (.inl v)=
      whiteSum p q (MarkedModule.step L v) R := by
  unfold Isolation.Graph.step
  rw [left_local_remove p q L R v hv,normalize_split p q _ _]
  · rw [hRn]
  · exact fun h=>hL h.1

 theorem after_left_arm_root (p q : Nat) (i : Fin p) (a : Arm) (s : Bool) :
    (view p q).step ((view p q).step (initialWhite p q) (.inl (arm a i s))) (.inl (root p))=
      whiteSum p q (gatedWhite (set (whole p) i (.reserve (!s)))) (white (whole q)) := by
  rw [(view p q).step_commute]
  change (view p q).step ((view p q).step
    (whiteSum p q (white (whole p)) (WhiteReserve.whiteRoot (whole q))) (.inl (root p))) _=_
  rw [root_left_step,left_local_step p q _ _ (by simp [root,gatedWhite,GatedGraph.stateWhite,GatedGraph.white])
    (module_normalized _) _ (by cases a <;> simp [arm,root])]
  rw [gated_arm_step _ a i s rfl]

 theorem after_right_arm_root (p q : Nat) (i : Fin q) (a : Arm) (s : Bool) :
    (view p q).step ((view p q).step (initialWhite p q) (.inr (arm a i s))) (.inr (root q))=
      whiteSum p q (white (whole p)) (gatedWhite (set (whole q) i (.reserve (!s)))) := by
  rw [(view p q).step_commute]
  change (view p q).step ((view p q).step
    (whiteSum p q (white (whole p)) (WhiteReserve.whiteRoot (whole q))) (.inr (root q))) _=_
  rw [root_right_step,right_local_step p q _ _ (by simp [root,white])
    (module_normalized _) _ (by cases a <;> simp [arm,root])]
  rw [gated_arm_step _ a i s rfl]

#print axioms after_left_arm_root
#print axioms after_right_arm_root
end IsolationGame.BWBridge
