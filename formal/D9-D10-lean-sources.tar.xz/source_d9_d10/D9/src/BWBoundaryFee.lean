import BoundaryFee
import BWBridge
namespace IsolationGame.MarkedBoundary
variable {V : Type} [Fintype V] [DecidableEq V] (G : SimpleGraph V) (z : V)
theorem S_fee_noMinus (hN : MarkedSum.NoMinus (isolateVertex G z)) (M X : Finset V) (hm : z∈M) :
    Marked.gameValue G M .staller X ≤ 1+Marked.gameValue (isolateVertex G z) M .staller X := by
  let H := isolateVertex G z
  have main : ∀n,∀X : Finset V, Marked.gameValue H M .staller X=n →
      Marked.gameValue G M .staller X≤1+Marked.gameValue H M .staller X := by
    intro n
    induction n using Nat.strong_induction_on with
    | h n ih =>
      intro X hrank
      by_cases hz : z∈X
      · have h := spent_value_bound G z M X hm hz .staller
        exact h.trans (Nat.le_add_left _ _)
      by_cases ht : Marked.Terminal H M X
      · have htG := (terminal_unspent G z M X hm hz).mpr ht
        rw [(Marked.value_zero_iff_terminal G M X .staller).mpr htG]
        omega
      have htG : ¬Marked.Terminal G M X := fun h=>ht ((terminal_unspent G z M X hm hz).mp h)
      obtain ⟨v,hv,he⟩ := Marked.exists_optimal_s_move G M X htG
      by_cases hvz : v=z
      · subst v
        have hspent := spent_value_bound G z M (insert z X) hm (Finset.mem_insert_self _ _) .dominator
        rw [isolated_z_value_insert G z M X hm .dominator] at hspent
        have hno := hN M X
        dsimp [H] at *
        omega
      have hvH : Marked.Legal H M X v := (legal_iff_unspent G z M X hm hz v hvz).mp hv
      have hfirst := Marked.s_move_lower H M X v hvH
      have hzv : z∉insert v X := by simp [hz,Ne.symm hvz]
      by_cases htv : Marked.Terminal H M (insert v X)
      · have htvG := (terminal_unspent G z M (insert v X) hm hzv).mpr htv
        have hzero := (Marked.value_zero_iff_terminal G M (insert v X) .dominator).mpr htvG
        omega
      obtain ⟨w,hw,hwopt⟩ := Marked.exists_optimal_d_move H M (insert v X) htv
      have hwz : w≠z := by
        intro heq;subst w
        exact isolated_z_illegal G z M (insert v X) hm hw
      have hwG := (legal_iff_unspent G z M (insert v X) hm hzv w hwz).mpr hw
      have hsmall : Marked.gameValue H M .staller (insert w (insert v X))<n := by omega
      have hrec := ih _ hsmall (insert w (insert v X)) rfl
      have hD := Marked.d_move_upper G M (insert v X) w hwG
      omega
  exact main _ X rfl

#print axioms S_fee_noMinus
end IsolationGame.MarkedBoundary

namespace IsolationGame.BWBridge
variable {V U : Type} [Fintype V] [DecidableEq V] [Fintype U] [DecidableEq U]

def leftPart (A : Finset (Sum V U)) : Finset V := Finset.univ.filter fun v=>Sum.inl v∈A
def rightPart (A : Finset (Sum V U)) : Finset U := Finset.univ.filter fun v=>Sum.inr v∈A

 theorem combine_parts (A : Finset (Sum V U)) : MarkedSum.combine (leftPart A) (rightPart A)=A := by
  ext v; cases v <;> simp [leftPart,rightPart]

 theorem noMinus_sum (G : SimpleGraph V) (H : SimpleGraph U)
    (hG : MarkedSum.NoMinus G) (hH : MarkedSum.NoMinus H) :
    MarkedSum.NoMinus (MarkedSum.original G H) := by
  intro M X
  have h := MarkedSum.sum_d_le_s G H hG hH (leftPart M) (leftPart X) (rightPart M) (rightPart X)
  rwa [combine_parts,combine_parts] at h

 theorem isolate_left_eq (p q : Nat) :
    MarkedBoundary.isolateVertex (original p q) (.inl (root p))=
      MarkedSum.original (MarkedBoundary.isolateVertex MarkedModule.original (root p))
        (MarkedModule.original (B:=Fin q)) := by
  ext v w
  cases v <;> cases w <;>
    simp [MarkedBoundary.isolateVertex,original,Attachment.original,MarkedSum.original,
      MarkedSum.graph,Isolation.Graph.disjointSum,GuardedEdge.view] <;> tauto

 theorem isolated_noMinus (p q : Nat) :
    MarkedSum.NoMinus (MarkedBoundary.isolateVertex (original p q) (.inl (root p))) := by
  rw [isolate_left_eq]
  apply noMinus_sum
  · exact Marked.forest_no_minus _ (MarkedBoundary.isolate_acyclic _ _ (module_acyclic p))
  · exact Marked.forest_no_minus _ (module_acyclic q)

 theorem left_boundary_fee (p q : Nat) (X : Finset (Vertex p q)) :
    Marked.gameValue (original p q) (marks p q) .staller X ≤
      1+Marked.gameValue
        (MarkedSum.original (MarkedBoundary.isolateVertex MarkedModule.original (root p))
          (MarkedModule.original (B:=Fin q))) (marks p q) .staller X := by
  have h := MarkedBoundary.S_fee_noMinus (original p q) (.inl (root p))
    (isolated_noMinus p q) (marks p q) X (by simp [marks])
  rwa [isolate_left_eq] at h

#print axioms isolate_left_eq
#print axioms left_boundary_fee
end IsolationGame.BWBridge
