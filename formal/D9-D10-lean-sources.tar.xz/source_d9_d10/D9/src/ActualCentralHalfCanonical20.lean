import MinimalCeil9OuterCanonical20

/-!
SOURCE-ONLY CANDIDATE, 2026-10-19. Not elaborated or native-checked.
This module consumes a genuine central cut and its actual radius-four half.
It does not assume or prove that a canonical family exhausts all trees.
-/
namespace IsolationGame.MinimalCeil9
open PartitionBridge IsolatedRestriction SmallPiece ActualRootBranches
variable {V : Type} [Fintype V] [DecidableEq V]

private theorem path_distance_add (G : SimpleGraph V) (hT : G.IsTree)
    {u v w : V} (p : G.Walk u v) (hp : p.IsPath) (hw : w∈p.support) :
    G.dist u v=G.dist u w+G.dist w v := by
  have hpre := tree_path_length_eq_dist hT (p.takeUntil w hw) (hp.takeUntil hw)
  have hpost := tree_path_length_eq_dist hT (p.dropUntil w hw) (hp.dropUntil hw)
  have hwhole := tree_path_length_eq_dist hT p hp
  have hsplit := congrArg SimpleGraph.Walk.length (p.take_spec hw)
  simp only [SimpleGraph.Walk.length_append] at hsplit
  omega

/-- A noncentral actual child branch lies wholly in its chosen half.
This statement is pure tree geometry, independent of all game bounds. -/
theorem noncentral_piece_subset_half (G : SimpleGraph V) (hT : G.IsTree)
    (A : Finset V) (x y : V) (hx : x∈A) (hcut : OneBridge G A x y)
    (a : Child G x) (hay : a.val≠y) : piece G x a⊆A := by
  have haA : a.val∈A := by
    by_contra ha
    exact hay ((hcut x a.val hx ha).mp (child_edge G x a)).2
  intro v hv
  by_contra hvA
  obtain ⟨p,hp,_⟩ := hT.isConnected.exists_path_of_dist v a.val
  have hpx : x∈p.support := walk_crosses_endpoint G A x y hcut p hvA haA
  have hadd := path_distance_add G hT p hp hpx
  have hdesc := (mem_piece G x a v).mp hv
  have hxa := child_depth G x a
  rw [G.dist_comm (u:=v) (v:=x),G.dist_comm (u:=v) (v:=a.val)] at hadd
  omega

/-- Central-half radius is transported to the original descendant branch,
with its unchanged original vertices and edges. -/
theorem noncentral_outer_radius_three (G : SimpleGraph V) (hT : G.IsTree)
    (A : Finset V) (x y : V) (hx : x∈A) (hcut : OneBridge G A x y)
    (hHalf : ∀v : Side A,(induced G A).dist ⟨x,hx⟩ v≤4)
    (a : Child G x) (hay : a.val≠y) :
    ∀v,(outerGraph G x a).dist (outerRoot G x a) v≤3 := by
  have hTA := retained_tree G hT A x y hx hcut
  have hs := noncentral_piece_subset_half G hT A x y hx hcut a hay
  apply actual_outer_radius_three_of_scoped_radius_four G hT x a
  intro v hv
  let v' : Side A := ⟨v,hs hv⟩
  have he := induced_dist_eq G hT A hTA.isConnected ⟨x,hx⟩ v'
  have hb := hHalf v'
  change (induced G A).dist ⟨x,hx⟩ v'=G.dist x v at he
  omega

/-- Full original-graph formulation for every noncentral branch on one side.
The opposite half has no radius premise in this local theorem. -/
theorem minimal_ceil9_noncentral_outer_canonical20 (G : SimpleGraph V) (hT : G.IsTree)
    (hDiam : G.diam≤9) (hSmall : SmallerCeil9 (Fintype.card V))
    (hCounter : ceil3n7 (Fintype.card V)< isolationNumber G)
    (A : Finset V) (x y : V) (hx : x∈A) (hcut : OneBridge G A x y)
    (hHalf : ∀v : Side A,(induced G A).dist ⟨x,hx⟩ v≤4)
    (a : Child G x) (hay : a.val≠y) :
    ∃t : CanonicalLocal.Index,
      RootedAssembly.RootedIso (outerGraph G x a) (outerRoot G x a)
        (CanonicalLocal.graph t) (CanonicalLocal.root t) :=
  minimal_ceil9_actual_outer_canonical20 G hT hDiam hSmall hCounter x a
    (noncentral_outer_radius_three G hT A x y hx hcut hHalf a hay)

noncomputable def halfGlobalChild (G : SimpleGraph V) (A : Finset V) (x : V) (hx : x∈A)
    (a : Child (induced G A) ⟨x,hx⟩) : Child G x :=
  ⟨a.val.val,by
    have he : G.Adj x a.val.val := child_edge (induced G A) ⟨x,hx⟩ a
    simp only [children,Finset.mem_filter,Finset.mem_univ,true_and]
    exact he⟩

/-- Exact half-to-global branch relabeling. Both directions preserve all
vertices, the attachment root, and original adjacency, rather than only values. -/
theorem half_outer_rooted_iso_global (G : SimpleGraph V) (hT : G.IsTree)
    (A : Finset V) (x y : V) (hx : x∈A) (hy : y∉A)
    (hcut : OneBridge G A x y) (a : Child (induced G A) ⟨x,hx⟩) :
    RootedAssembly.RootedIso
      (outerGraph (induced G A) ⟨x,hx⟩ a) (outerRoot (induced G A) ⟨x,hx⟩ a)
      (outerGraph G x (halfGlobalChild G A x hx a))
      (outerRoot G x (halfGlobalChild G A x hx a)) := by
  let H := induced G A
  let x' : Side A := ⟨x,hx⟩
  let aG := halfGlobalChild G A x hx a
  have hTA := retained_tree G hT A x y hx hcut
  have hay : aG.val≠y := by
    intro he
    exact hy (he ▸ a.val.property)
  have hs : piece G x aG⊆A := noncentral_piece_subset_half G hT A x y hx hcut aG hay
  have hpieces : piece H x' a=restrict A (piece G x aG) := by
    ext v
    rw [mem_piece,mem_restrict,mem_piece]
    have h1 := induced_dist_eq G hT A hTA.isConnected x' v
    have h2 := induced_dist_eq G hT A hTA.isConnected x' a.val
    have h3 := induced_dist_eq G hT A hTA.isConnected a.val v
    change H.dist x' v=H.dist x' a.val+H.dist a.val v ↔
      G.dist x v.val=G.dist x aG.val+G.dist aG.val v.val
    rw [h1,h2,h3]
    rfl
  let e : Outer H x' a ≃ Outer G x aG :=
    { toFun := fun v=>⟨v.val.val,(mem_restrict A (piece G x aG) v.val).mp
        (hpieces ▸ v.property)⟩
      invFun := fun v=>⟨⟨v.val,hs v.property⟩,hpieces.symm ▸
        (mem_restrict A (piece G x aG) ⟨v.val,hs v.property⟩).mpr v.property⟩
      left_inv := by intro v;apply Subtype.ext;apply Subtype.ext;rfl
      right_inv := by intro v;apply Subtype.ext;rfl }
  refine ⟨e,?_,?_⟩
  · apply Subtype.ext
    rfl
  · intro u v
    rfl

/-- Literal half-carrier statement. This is the requested twenty-class
classification of every actual noncentral branch of a radius-four half. -/
theorem minimal_ceil9_central_half_branch_canonical20 (G : SimpleGraph V) (hT : G.IsTree)
    (hDiam : G.diam≤9) (hSmall : SmallerCeil9 (Fintype.card V))
    (hCounter : ceil3n7 (Fintype.card V)< isolationNumber G)
    (A : Finset V) (x y : V) (hx : x∈A) (hy : y∉A)
    (hcut : OneBridge G A x y)
    (hHalf : ∀v : Side A,(induced G A).dist ⟨x,hx⟩ v≤4)
    (a : Child (induced G A) ⟨x,hx⟩) :
    ∃t : CanonicalLocal.Index,
      RootedAssembly.RootedIso
        (outerGraph (induced G A) ⟨x,hx⟩ a) (outerRoot (induced G A) ⟨x,hx⟩ a)
        (CanonicalLocal.graph t) (CanonicalLocal.root t) := by
  let aG := halfGlobalChild G A x hx a
  have hay : aG.val≠y := by intro he;exact hy (he ▸ a.val.property)
  obtain ⟨t,et,htr,hta⟩ := minimal_ceil9_noncentral_outer_canonical20
    G hT hDiam hSmall hCounter A x y hx hcut hHalf aG hay
  obtain ⟨e,her,hea⟩ := half_outer_rooted_iso_global G hT A x y hx hy hcut a
  refine ⟨t,e.trans et,?_,?_⟩
  · change et (e (outerRoot (induced G A) ⟨x,hx⟩ a))=CanonicalLocal.root t
    rw [her]
    exact htr
  · intro u v
    exact (hta (e u) (e v)).trans (hea u v)

#print axioms noncentral_piece_subset_half
#print axioms noncentral_outer_radius_three
#print axioms minimal_ceil9_noncentral_outer_canonical20
#print axioms half_outer_rooted_iso_global
#print axioms minimal_ceil9_central_half_branch_canonical20
end IsolationGame.MinimalCeil9
