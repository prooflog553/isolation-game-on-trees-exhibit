import FullCanonical16Base
namespace IsolationGame.FullCanonical.T16
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_0 : Finset (Fin 11) := {0,1,2,3,4,5,6,7,8,9,10}
theorem row_0 : Marked.gameValue original marks_0 .dominator ∅=0 ∧ Marked.gameValue original marks_0 .staller ∅=0 := by
  constructor <;> apply (Marked.value_zero_iff_terminal _ _ _ _).mpr <;> decide +kernel
def marks_1 : Finset (Fin 11) := {0,1,2,3,4,5,6,7,10}
theorem after_1_7 : Marked.gameValue original marks_1 .dominator {7}=0 ∧ Marked.gameValue original marks_1 .staller {7}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_1 marks_0 7 0 0 (by decide +kernel) row_0
theorem after_1_8 : Marked.gameValue original marks_1 .dominator {8}=0 ∧ Marked.gameValue original marks_1 .staller {8}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_1 marks_0 8 0 0 (by decide +kernel) row_0
theorem after_1_9 : Marked.gameValue original marks_1 .dominator {9}=0 ∧ Marked.gameValue original marks_1 .staller {9}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_1 marks_0 9 0 0 (by decide +kernel) row_0
theorem row_1 : Marked.gameValue original marks_1 .dominator ∅=1 ∧ Marked.gameValue original marks_1 .staller ∅=1 := by
  apply LocalProfile.DAG.bellman original marks_1 1 1 7 7 (by decide +kernel) (by decide +kernel)
  · rw [after_1_7.2]
  · rw [after_1_7.1]
  · intro v hv
    fin_cases v
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_1 ∅ 0) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_1 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_1 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_1 ∅ 3) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_1 ∅ 4) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_1 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_1 ∅ 6) hv)
    · have h := after_1_7
      change 1 ≤ 1+Marked.gameValue original marks_1 .staller {7} ∧ 1+Marked.gameValue original marks_1 .dominator {7} ≤ 1
      omega
    · have h := after_1_8
      change 1 ≤ 1+Marked.gameValue original marks_1 .staller {8} ∧ 1+Marked.gameValue original marks_1 .dominator {8} ≤ 1
      omega
    · have h := after_1_9
      change 1 ≤ 1+Marked.gameValue original marks_1 .staller {9} ∧ 1+Marked.gameValue original marks_1 .dominator {9} ≤ 1
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_1 ∅ 10) hv)
def marks_2 : Finset (Fin 11) := {1,2,3,4,5,6,7,8,9}
theorem after_2_0 : Marked.gameValue original marks_2 .dominator {0}=0 ∧ Marked.gameValue original marks_2 .staller {0}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_2 marks_0 0 0 0 (by decide +kernel) row_0
theorem after_2_1 : Marked.gameValue original marks_2 .dominator {1}=0 ∧ Marked.gameValue original marks_2 .staller {1}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_2 marks_0 1 0 0 (by decide +kernel) row_0
theorem after_2_4 : Marked.gameValue original marks_2 .dominator {4}=0 ∧ Marked.gameValue original marks_2 .staller {4}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_2 marks_0 4 0 0 (by decide +kernel) row_0
theorem after_2_7 : Marked.gameValue original marks_2 .dominator {7}=0 ∧ Marked.gameValue original marks_2 .staller {7}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_2 marks_0 7 0 0 (by decide +kernel) row_0
theorem after_2_10 : Marked.gameValue original marks_2 .dominator {10}=0 ∧ Marked.gameValue original marks_2 .staller {10}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_2 marks_0 10 0 0 (by decide +kernel) row_0
theorem row_2 : Marked.gameValue original marks_2 .dominator ∅=1 ∧ Marked.gameValue original marks_2 .staller ∅=1 := by
  apply LocalProfile.DAG.bellman original marks_2 1 1 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_2_0.2]
  · rw [after_2_0.1]
  · intro v hv
    fin_cases v
    · have h := after_2_0
      change 1 ≤ 1+Marked.gameValue original marks_2 .staller {0} ∧ 1+Marked.gameValue original marks_2 .dominator {0} ≤ 1
      omega
    · have h := after_2_1
      change 1 ≤ 1+Marked.gameValue original marks_2 .staller {1} ∧ 1+Marked.gameValue original marks_2 .dominator {1} ≤ 1
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_2 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_2 ∅ 3) hv)
    · have h := after_2_4
      change 1 ≤ 1+Marked.gameValue original marks_2 .staller {4} ∧ 1+Marked.gameValue original marks_2 .dominator {4} ≤ 1
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_2 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_2 ∅ 6) hv)
    · have h := after_2_7
      change 1 ≤ 1+Marked.gameValue original marks_2 .staller {7} ∧ 1+Marked.gameValue original marks_2 .dominator {7} ≤ 1
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_2 ∅ 8) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_2 ∅ 9) hv)
    · have h := after_2_10
      change 1 ≤ 1+Marked.gameValue original marks_2 .staller {10} ∧ 1+Marked.gameValue original marks_2 .dominator {10} ≤ 1
      omega
def marks_3 : Finset (Fin 11) := {0,1,2,3,4,5,6,10}
theorem after_3_0 : Marked.gameValue original marks_3 .dominator {0}=1 ∧ Marked.gameValue original marks_3 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_3 marks_1 0 1 1 (by decide +kernel) row_1
theorem after_3_7 : Marked.gameValue original marks_3 .dominator {7}=0 ∧ Marked.gameValue original marks_3 .staller {7}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_3 marks_0 7 0 0 (by decide +kernel) row_0
theorem after_3_8 : Marked.gameValue original marks_3 .dominator {8}=0 ∧ Marked.gameValue original marks_3 .staller {8}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_3 marks_0 8 0 0 (by decide +kernel) row_0
theorem after_3_9 : Marked.gameValue original marks_3 .dominator {9}=0 ∧ Marked.gameValue original marks_3 .staller {9}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_3 marks_0 9 0 0 (by decide +kernel) row_0
theorem row_3 : Marked.gameValue original marks_3 .dominator ∅=1 ∧ Marked.gameValue original marks_3 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_3 1 2 7 0 (by decide +kernel) (by decide +kernel)
  · rw [after_3_7.2]
  · rw [after_3_0.1]
  · intro v hv
    fin_cases v
    · have h := after_3_0
      change 1 ≤ 1+Marked.gameValue original marks_3 .staller {0} ∧ 1+Marked.gameValue original marks_3 .dominator {0} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_3 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_3 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_3 ∅ 3) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_3 ∅ 4) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_3 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_3 ∅ 6) hv)
    · have h := after_3_7
      change 1 ≤ 1+Marked.gameValue original marks_3 .staller {7} ∧ 1+Marked.gameValue original marks_3 .dominator {7} ≤ 2
      omega
    · have h := after_3_8
      change 1 ≤ 1+Marked.gameValue original marks_3 .staller {8} ∧ 1+Marked.gameValue original marks_3 .dominator {8} ≤ 2
      omega
    · have h := after_3_9
      change 1 ≤ 1+Marked.gameValue original marks_3 .staller {9} ∧ 1+Marked.gameValue original marks_3 .dominator {9} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_3 ∅ 10) hv)
end IsolationGame.FullCanonical.T16
