import ActualRootBranches
import PartitionGeometry

namespace IsolationGame.CanonicalLocal
open IsolatedRestriction PartitionBridge ActualRootBranches
variable {V : Type} [Fintype V] [DecidableEq V]

theorem reverse_cut (G : SimpleGraph V) (A : Finset V) (z b : V)
    (hcut : OneBridge G A z b) : OneBridge G (outside A) b z := by
  intro u v hu hv
  have huA : u∉A := (Finset.mem_sdiff.mp hu).2
  have hvA : v∈A := by simpa [outside] using hv
  constructor
  · intro h
    exact ((hcut v u hvA huA).mp h.symm).symm
  · rintro ⟨hub,hvz⟩
    exact ((hcut v u hvA huA).mpr ⟨hvz,hub⟩).symm

/-- Across an actual one-edge tree cut, all original distances pass through
that unique edge. Both sides keep every original vertex. -/
theorem cut_distance (G : SimpleGraph V) (hT : G.IsTree) (A : Finset V) (z b : V)
    (hz : z∈A) (hb : b∉A) (hcut : OneBridge G A z b) (v : Side (outside A)) :
    G.dist z v.val=1+G.dist b v.val := by
  have hbB : b∈outside A := by simp [outside,hb]
  have htB := retained_tree G hT (outside A) b z hbB (reverse_cut G A z b hcut)
  obtain ⟨q,hq,_⟩ := htB.isConnected.exists_path_of_dist (⟨b,hbB⟩ : Side (outside A)) v
  let f : induced G (outside A) →g G := ⟨Subtype.val,by intro u v h;exact h⟩
  have hp : (q.map f).IsPath := SimpleGraph.Walk.map_isPath_of_injective
    (show Function.Injective f from Subtype.val_injective) hq
  have hznot : z∉(q.map f).support := by
    rw [SimpleGraph.Walk.support_map]
    intro h
    obtain ⟨w,_,he⟩ := List.mem_map.mp h
    have he' : w.val=z := he
    exact (Finset.mem_sdiff.mp w.property).2 (he'.symm ▸ hz)
  have hzb : G.Adj z b := (hcut z b hz hb).mpr ⟨rfl,rfl⟩
  have hfull := tree_path_length_eq_dist hT ((q.map f).cons hzb) (hp.cons hznot)
  have htail := tree_path_length_eq_dist hT (q.map f) hp
  simp only [SimpleGraph.Walk.length_cons,SimpleGraph.Walk.length_map] at hfull htail
  change q.length+1=G.dist z v.val at hfull
  change q.length=G.dist b v.val at htail
  omega

/-- A supplied concrete root-branch cut is exactly the distance-defined
actual branch, enabling finite canonical adjacency tables to be attached to
the proved generic root decomposition. -/
theorem piece_eq_of_cut (G : SimpleGraph V) (hT : G.IsTree) (r : V) (a : Child G r)
    (A : Finset V) (hr : r∈A) (ha : a.val∉A) (hcut : OneBridge G A r a.val) :
    piece G r a=outside A := by
  ext v
  rw [mem_piece,child_depth]
  simp only [outside,Finset.mem_sdiff,Finset.mem_univ,true_and]
  by_cases hvA : v∈A
  · have haB : a.val∈outside A := by simp [outside,ha]
    have hrB : r∉outside A := by simp [outside,hr]
    have hvBB : v∈outside (outside A) := by simp [outside,hvA]
    have hback := cut_distance G hT (outside A) a.val r haB hrB (reverse_cut G A r a.val hcut) ⟨v,hvBB⟩
    change G.dist a.val v=1+G.dist r v at hback
    constructor
    · intro h;omega
    · intro h;exact False.elim (h hvA)
  · have hvB : v∈outside A := by simp [outside,hvA]
    have hf := cut_distance G hT A r a.val hr ha hcut ⟨v,hvB⟩
    change G.dist r v=1+G.dist a.val v at hf
    exact ⟨fun _=>hvA,fun _=>hf⟩

#print axioms cut_distance
#print axioms piece_eq_of_cut
end IsolationGame.CanonicalLocal
