import Mathlib.Data.Finset.Card
import GatedFormula

/-! The finite-set model of a one-level gated-unit position.  Empty gates may
remain in `closed`; legality and the active-gate count ignore them. -/
namespace Gated

structure State (I J : Type*) where
  live : Finset J
  closed : Finset I

namespace State

variable {I J : Type*} [DecidableEq I] [DecidableEq J]

def units (owner : J → I) (s : State I J) (i : I) : Finset J :=
  s.live.filter fun j => owner j = i

def count (owner : J → I) (s : State I J) (i : I) : ℕ :=
  (s.units owner i).card

def P (s : State I J) : ℕ := s.live.card

def active (owner : J → I) (s : State I J) : Finset I :=
  s.closed.filter fun i => 0 < s.count owner i

def singles (owner : J → I) (s : State I J) : Finset I :=
  s.closed.filter fun i => s.count owner i = 1

def A (owner : J → I) (s : State I J) : ℕ := (s.active owner).card

def sigma (owner : J → I) (s : State I J) : ℕ := (s.singles owner).card

def deleteUnit (s : State I J) (j : J) : State I J :=
  ⟨s.live.erase j, s.closed⟩

def openGate (s : State I J) (i : I) : State I J :=
  ⟨s.live, s.closed.erase i⟩

def Move (owner : J → I) (s t : State I J) : Prop :=
  (∃ j ∈ s.live, t = s.deleteUnit j) ∨
  (∃ i ∈ s.active owner, t = s.openGate i)

@[simp] theorem mem_units (owner : J → I) (s : State I J) (i : I) (j : J) :
    j ∈ s.units owner i ↔ j ∈ s.live ∧ owner j = i := by
  simp [units]

@[simp] theorem mem_active (owner : J → I) (s : State I J) (i : I) :
    i ∈ s.active owner ↔ i ∈ s.closed ∧ 0 < s.count owner i := by
  simp [active]

@[simp] theorem mem_singles (owner : J → I) (s : State I J) (i : I) :
    i ∈ s.singles owner ↔ i ∈ s.closed ∧ s.count owner i = 1 := by
  simp [singles]

theorem count_pos_iff (owner : J → I) (s : State I J) (i : I) :
    0 < s.count owner i ↔ ∃ j ∈ s.live, owner j = i := by
  simp [count, Finset.card_pos, Finset.Nonempty]

theorem count_pos_of_mem (owner : J → I) {s : State I J} {j : J}
    (hj : j ∈ s.live) : 0 < s.count owner (owner j) :=
  (count_pos_iff owner s (owner j)).2 ⟨j, hj, rfl⟩

@[simp] theorem deleteUnit_P (s : State I J) {j : J} (hj : j ∈ s.live) :
    (s.deleteUnit j).P + 1 = s.P := by
  exact Finset.card_erase_add_one hj

@[simp] theorem openGate_P (s : State I J) (i : I) :
    (s.openGate i).P = s.P := rfl

@[simp] theorem openGate_count (owner : J → I) (s : State I J) (i k : I) :
    (s.openGate i).count owner k = s.count owner k := rfl

theorem deleteUnit_units_same (owner : J → I) (s : State I J) (j : J) :
    (s.deleteUnit j).units owner (owner j) = (s.units owner (owner j)).erase j := by
  ext k
  simp [units, deleteUnit, and_assoc, and_left_comm, and_comm]

theorem deleteUnit_count_same (owner : J → I) {s : State I J} {j : J}
    (hj : j ∈ s.live) :
    (s.deleteUnit j).count owner (owner j) + 1 = s.count owner (owner j) := by
  unfold count
  rw [deleteUnit_units_same]
  exact Finset.card_erase_add_one (by simp [hj])

theorem deleteUnit_count_other (owner : J → I) (s : State I J) (j : J) {i : I}
    (hi : i ≠ owner j) :
    (s.deleteUnit j).count owner i = s.count owner i := by
  unfold count
  congr 1
  ext k
  simp only [units, deleteUnit, Finset.mem_filter, Finset.mem_erase]
  constructor
  · exact fun h => ⟨h.1.2, h.2⟩
  · rintro ⟨hk, ho⟩
    refine ⟨⟨?_, hk⟩, ho⟩
    intro heq
    subst k
    exact hi ho.symm

theorem singles_subset_active (owner : J → I) (s : State I J) :
    s.singles owner ⊆ s.active owner := by
  intro i hi
  simp only [mem_singles] at hi
  simp [hi.1, hi.2]

theorem sigma_le_A (owner : J → I) (s : State I J) :
    s.sigma owner ≤ s.A owner := Finset.card_le_card (singles_subset_active owner s)

theorem active_subset_image (owner : J → I) (s : State I J) :
    s.active owner ⊆ s.live.image owner := by
  intro i hi
  obtain ⟨j, hj, hji⟩ := (count_pos_iff owner s i).1 ((mem_active owner s i).mp hi).2
  exact Finset.mem_image.mpr ⟨j, hj, hji⟩

theorem A_le_P (owner : J → I) (s : State I J) : s.A owner ≤ s.P :=
  (Finset.card_le_card (active_subset_image owner s)).trans Finset.card_image_le

theorem sigma_le_P (owner : J → I) (s : State I J) : s.sigma owner ≤ s.P :=
  (sigma_le_A owner s).trans (A_le_P owner s)

@[simp] theorem P_eq_zero_iff (s : State I J) : s.P = 0 ↔ s.live = ∅ := by
  simp [P]

theorem exists_deleteUnit (owner : J → I) {s : State I J} (h : 0 < s.P) :
    ∃ j ∈ s.live, Move owner s (s.deleteUnit j) := by
  obtain ⟨j, hj⟩ := Finset.card_pos.mp h
  exact ⟨j, hj, Or.inl ⟨j, hj, rfl⟩⟩

theorem exists_openGate (owner : J → I) {s : State I J} (h : 0 < s.A owner) :
    ∃ i ∈ s.active owner, Move owner s (s.openGate i) := by
  obtain ⟨i, hi⟩ := Finset.card_pos.mp h
  exact ⟨i, hi, Or.inr ⟨i, hi, rfl⟩⟩

theorem exists_singleton (owner : J → I) {s : State I J} (h : 0 < s.sigma owner) :
    ∃ j ∈ s.live, owner j ∈ s.closed ∧ s.count owner (owner j) = 1 := by
  obtain ⟨i, hi⟩ := Finset.card_pos.mp h
  obtain ⟨hic, hicount⟩ := (mem_singles owner s i).mp hi
  obtain ⟨j, hj, rfl⟩ := (count_pos_iff owner s i).mp (by omega)
  exact ⟨j, hj, hic, hicount⟩

theorem sigma_lt_A_of_large (owner : J → I) (s : State I J) {i : I}
    (hic : i ∈ s.closed) (hi : 1 < s.count owner i) : s.sigma owner < s.A owner := by
  apply Finset.card_lt_card
  refine ⟨singles_subset_active owner s, ?_⟩
  intro hsub
  have hmem : i ∈ s.active owner := by simp [hic]; omega
  have hs := (mem_singles owner s i).mp (hsub hmem)
  omega

theorem sigma_pos_of_singleton (owner : J → I) (s : State I J) {i : I}
    (hic : i ∈ s.closed) (hi : s.count owner i = 1) : 0 < s.sigma owner := by
  apply Finset.card_pos.mpr
  exact ⟨i, by simp [hic, hi]⟩

theorem delete_open_active (owner : J → I) (s : State I J) (j : J)
    (ho : owner j ∉ s.closed) : (s.deleteUnit j).active owner = s.active owner := by
  ext i
  by_cases hi : i = owner j
  · subst i
    simp [active, deleteUnit, ho]
  · simp only [mem_active]
    rw [deleteUnit_count_other owner s j hi]
    rfl

theorem delete_open_singles (owner : J → I) (s : State I J) (j : J)
    (ho : owner j ∉ s.closed) : (s.deleteUnit j).singles owner = s.singles owner := by
  ext i
  by_cases hi : i = owner j
  · subst i
    simp [singles, deleteUnit, ho]
  · simp only [mem_singles]
    rw [deleteUnit_count_other owner s j hi]
    rfl

theorem delete_singleton_active (owner : J → I) {s : State I J} {j : J}
    (hj : j ∈ s.live) (hn : s.count owner (owner j) = 1) :
    (s.deleteUnit j).active owner = (s.active owner).erase (owner j) := by
  have hn' := deleteUnit_count_same owner hj
  ext i
  by_cases hi : i = owner j
  · subst i
    have hz : (s.deleteUnit j).count owner (owner j) = 0 := by omega
    simp [hz]
  · simp only [mem_active, Finset.mem_erase]
    rw [deleteUnit_count_other owner s j hi]
    simp [hi, deleteUnit]

theorem delete_singleton_singles (owner : J → I) {s : State I J} {j : J}
    (hj : j ∈ s.live) (hn : s.count owner (owner j) = 1) :
    (s.deleteUnit j).singles owner = (s.singles owner).erase (owner j) := by
  have hn' := deleteUnit_count_same owner hj
  ext i
  by_cases hi : i = owner j
  · subst i
    have hz : (s.deleteUnit j).count owner (owner j) = 0 := by omega
    simp [hz]
  · simp only [mem_singles, Finset.mem_erase]
    rw [deleteUnit_count_other owner s j hi]
    simp [hi, deleteUnit]

theorem delete_large_active (owner : J → I) {s : State I J} {j : J}
    (hj : j ∈ s.live) (hn : 1 < s.count owner (owner j)) :
    (s.deleteUnit j).active owner = s.active owner := by
  have hn' := deleteUnit_count_same owner hj
  ext i
  by_cases hi : i = owner j
  · subst i
    have hz : 0 < (s.deleteUnit j).count owner (owner j) := by omega
    have hz' : 0 < s.count owner (owner j) := by omega
    simp only [mem_active, hz, hz', and_true]
    rfl
  · simp only [mem_active]
    rw [deleteUnit_count_other owner s j hi]
    rfl

theorem delete_pair_singles (owner : J → I) {s : State I J} {j : J}
    (hj : j ∈ s.live) (hc : owner j ∈ s.closed)
    (hn : s.count owner (owner j) = 2) :
    (s.deleteUnit j).singles owner = insert (owner j) (s.singles owner) := by
  have hn' := deleteUnit_count_same owner hj
  ext i
  by_cases hi : i = owner j
  · subst i
    have hz : (s.deleteUnit j).count owner (owner j) = 1 := by omega
    simp only [mem_singles, hz, Finset.mem_insert, eq_self_iff_true, true_or, and_true]
    simpa only [deleteUnit, iff_true] using hc
  · simp only [mem_singles, Finset.mem_insert]
    rw [deleteUnit_count_other owner s j hi]
    simp [hi, deleteUnit]

theorem delete_larger_singles (owner : J → I) {s : State I J} {j : J}
    (hj : j ∈ s.live) (hn : 2 < s.count owner (owner j)) :
    (s.deleteUnit j).singles owner = s.singles owner := by
  have hn' := deleteUnit_count_same owner hj
  ext i
  by_cases hi : i = owner j
  · subst i
    have hz : (s.deleteUnit j).count owner (owner j) ≠ 1 := by omega
    have hz' : s.count owner (owner j) ≠ 1 := by omega
    simp [hz, hz']
  · simp only [mem_singles]
    rw [deleteUnit_count_other owner s j hi]
    rfl

@[simp] theorem openGate_active (owner : J → I) (s : State I J) (i : I) :
    (s.openGate i).active owner = (s.active owner).erase i := by
  ext k
  simp [active, openGate, count, units, and_assoc]

@[simp] theorem openGate_singles (owner : J → I) (s : State I J) (i : I) :
    (s.openGate i).singles owner = (s.singles owner).erase i := by
  ext k
  simp [singles, openGate, count, units, and_assoc]

def counts (owner : J → I) (s : State I J) : Counts :=
  ⟨s.P, s.A owner, s.sigma owner⟩

theorem counts_valid (owner : J → I) (s : State I J) : (s.counts owner).valid :=
  ⟨sigma_le_A owner s, A_le_P owner s⟩

theorem delete_open_counts (owner : J → I) {s : State I J} {j : J}
    (hj : j ∈ s.live) (hc : owner j ∉ s.closed) :
    (s.deleteUnit j).counts owner = ⟨s.P - 1, s.A owner, s.sigma owner⟩ := by
  have hp := deleteUnit_P s hj
  have ha := delete_open_active owner s j hc
  have hz := delete_open_singles owner s j hc
  simp only [counts, A, sigma, ha, hz]
  congr 1
  omega

theorem delete_singleton_counts (owner : J → I) {s : State I J} {j : J}
    (hj : j ∈ s.live) (hc : owner j ∈ s.closed) (hn : s.count owner (owner j) = 1) :
    (s.deleteUnit j).counts owner = ⟨s.P - 1, s.A owner - 1, s.sigma owner - 1⟩ := by
  have hp := deleteUnit_P s hj
  have ha : (s.deleteUnit j).A owner + 1 = s.A owner := by
    unfold A
    rw [delete_singleton_active owner hj hn]
    exact Finset.card_erase_add_one (by simp [hc, hn])
  have hz : (s.deleteUnit j).sigma owner + 1 = s.sigma owner := by
    unfold sigma
    rw [delete_singleton_singles owner hj hn]
    exact Finset.card_erase_add_one (by simp [hc, hn])
  unfold counts
  congr 1 <;> omega

theorem delete_pair_counts (owner : J → I) {s : State I J} {j : J}
    (hj : j ∈ s.live) (hc : owner j ∈ s.closed) (hn : s.count owner (owner j) = 2) :
    (s.deleteUnit j).counts owner = ⟨s.P - 1, s.A owner, s.sigma owner + 1⟩ := by
  have hp := deleteUnit_P s hj
  have ha : (s.deleteUnit j).A owner = s.A owner := by
    unfold A
    rw [delete_large_active owner hj (by omega)]
  have hz : (s.deleteUnit j).sigma owner = s.sigma owner + 1 := by
    unfold sigma
    rw [delete_pair_singles owner hj hc hn]
    exact Finset.card_insert_of_not_mem (by simp [hn])
  unfold counts
  congr 1 <;> omega

theorem delete_larger_counts (owner : J → I) {s : State I J} {j : J}
    (hj : j ∈ s.live) (hn : 2 < s.count owner (owner j)) :
    (s.deleteUnit j).counts owner = ⟨s.P - 1, s.A owner, s.sigma owner⟩ := by
  have hp := deleteUnit_P s hj
  have ha := delete_large_active owner hj (by omega)
  have hz := delete_larger_singles owner hj hn
  simp only [counts, A, sigma, ha, hz]
  congr 1
  omega

theorem open_singleton_counts (owner : J → I) {s : State I J} {i : I}
    (hc : i ∈ s.closed) (hn : s.count owner i = 1) :
    (s.openGate i).counts owner = ⟨s.P, s.A owner - 1, s.sigma owner - 1⟩ := by
  have ha : (s.openGate i).A owner + 1 = s.A owner := by
    unfold A
    rw [openGate_active]
    exact Finset.card_erase_add_one (by simp [hc, hn])
  have hz : (s.openGate i).sigma owner + 1 = s.sigma owner := by
    unfold sigma
    rw [openGate_singles]
    exact Finset.card_erase_add_one (by simp [hc, hn])
  simp only [counts, openGate_P]
  congr 1 <;> omega

theorem open_larger_counts (owner : J → I) {s : State I J} {i : I}
    (hc : i ∈ s.closed) (hn : 1 < s.count owner i) :
    (s.openGate i).counts owner = ⟨s.P, s.A owner - 1, s.sigma owner⟩ := by
  have ha : (s.openGate i).A owner + 1 = s.A owner := by
    unfold A
    rw [openGate_active]
    exact Finset.card_erase_add_one (by simp [hc]; omega)
  have hz : (s.openGate i).sigma owner = s.sigma owner := by
    unfold sigma
    rw [openGate_singles, Finset.erase_eq_of_not_mem]
    simp only [mem_singles, not_and]
    intro _
    omega
  simp only [counts, openGate_P]
  congr 1 <;> omega

theorem taxonomy (owner : J → I) {s t : State I J} (h : Move owner s t) :
    Step (s.counts owner) (t.counts owner) := by
  rcases h with ⟨j, hj, rfl⟩ | ⟨i, hi, rfl⟩
  · have hp : 0 < s.P := Finset.card_pos.mpr ⟨j, hj⟩
    have hnpos := count_pos_of_mem owner hj
    by_cases hc : owner j ∈ s.closed
    · by_cases hn : s.count owner (owner j) = 1
      · rw [delete_singleton_counts owner hj hc hn]
        exact Step.deleteSingleton _ _ _ (sigma_pos_of_singleton owner s hc hn)
      · by_cases hn2 : s.count owner (owner j) = 2
        · rw [delete_pair_counts owner hj hc hn2]
          exact Step.deletePair _ _ _ (sigma_lt_A_of_large owner s hc (by omega))
        · rw [delete_larger_counts owner hj (by omega)]
          exact Step.deleteLarge _ _ _ (sigma_lt_A_of_large owner s hc (by omega))
    · rw [delete_open_counts owner hj hc]
      exact Step.deleteOpen _ _ _ hp
  · obtain ⟨hc, hnpos⟩ := (mem_active owner s i).mp hi
    by_cases hn : s.count owner i = 1
    · rw [open_singleton_counts owner hc hn]
      exact Step.openSingleton _ _ _ (sigma_pos_of_singleton owner s hc hn)
    · rw [open_larger_counts owner hc (by omega)]
      exact Step.openLarge _ _ _ (sigma_lt_A_of_large owner s hc (by omega))

/-- Counting at least one unit in each singleton and at least two in every
other active gate gives this stronger occupancy bound. -/
theorem twice_A_le_P_add_sigma (owner : J → I) (s : State I J) :
    2 * s.A owner ≤ s.P + s.sigma owner := by
  have back : ∀ {c c' : Counts}, Step c c' → c'.P + 1 = c.P →
      2 * c'.A ≤ c'.P + c'.sigma → 2 * c.A ≤ c.P + c.sigma := by
    intro c c' hs hp hi
    cases hs <;> simp_all <;> omega
  generalize hn : s.P = n
  induction n using Nat.strong_induction_on generalizing s with
  | h n ih =>
    by_cases hz : s.P = 0
    · have := A_le_P owner s
      omega
    · have hpos : 0 < s.P := by omega
      obtain ⟨j, hj, hm⟩ := exists_deleteUnit owner hpos
      have hp := deleteUnit_P s hj
      have hi := ih (s.deleteUnit j).P (by omega) (s.deleteUnit j) rfl
      simpa only [counts, hn] using back (taxonomy owner hm) hp hi

theorem twice_A_sub_sigma_le_P (owner : J → I) (s : State I J) :
    2 * s.A owner - s.sigma owner ≤ s.P := by
  have := twice_A_le_P_add_sigma owner s
  omega

end State

section CertificateInstance
variable {I J : Type} [DecidableEq I] [DecidableEq J]

theorem state_certificate (owner : J → I) :
    Certificate (State.Move owner) (State.counts owner) where
  valid := State.counts_valid owner
  taxonomy := State.taxonomy owner
  delete_singleton := by
    intro s h
    obtain ⟨j, hj, hc, hn⟩ := State.exists_singleton owner h
    exact ⟨s.deleteUnit j, Or.inl ⟨j, hj, rfl⟩,
      State.delete_singleton_counts owner hj hc hn⟩
  open_singleton := by
    intro s h
    obtain ⟨j, hj, hc, hn⟩ := State.exists_singleton owner h
    refine ⟨s.openGate (owner j), Or.inr ⟨owner j, ?_, rfl⟩,
      State.open_singleton_counts owner hc hn⟩
    simp [hc, hn]
  delete_unit := by
    intro s h
    obtain ⟨j, hj, hm⟩ := State.exists_deleteUnit owner h
    refine ⟨s.deleteUnit j, hm, ?_⟩
    change (s.deleteUnit j).P = s.P - 1
    have := State.deleteUnit_P s hj
    omega
  open_group := by
    intro s h
    obtain ⟨i, hi, hm⟩ := State.exists_openGate owner h
    exact ⟨s.openGate i, hm, rfl⟩

/-- Exact all-horizon minimax formula for every finite-set gated-unit position. -/
theorem state_formula (owner : J → I) (s : State I J) (n : ℕ) (t : Turn) :
    winWithin (State.Move owner) State.P n t s ↔ (s.counts owner).value t ≤ n := by
  exact (state_certificate owner).formula n t s

end CertificateInstance
#print axioms State.delete_open_counts
#print axioms State.delete_singleton_counts
#print axioms State.delete_pair_counts
#print axioms State.delete_larger_counts
#print axioms State.open_singleton_counts
#print axioms State.open_larger_counts
#print axioms State.twice_A_le_P_add_sigma
#print axioms state_certificate
#print axioms state_formula

end Gated
