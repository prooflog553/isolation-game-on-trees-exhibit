import FullCanonicalDAG
namespace IsolationGame.FullCanonical.T18
abbrev original : SimpleGraph (Fin 9) := CanonicalLocal.graph CanonicalLocal.Index.t18
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
noncomputable def perm_0 : Fin 9 ≃ Fin 9 :=
  Equiv.ofBijective (fun v => ![0,1,2,3,4,5,6,7,8] v) (by decide +kernel)
theorem adjacency_0 : ∀u v,original.Adj (perm_0 u) (perm_0 v) ↔ original.Adj u v := by decide +kernel
end IsolationGame.FullCanonical.T18
