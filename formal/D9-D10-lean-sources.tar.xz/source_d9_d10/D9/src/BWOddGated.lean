import BWCenterBounds
import PureModuleStrict
namespace GatedGraph
open IsolationGame
variable {I J : Type} [Fintype I] [Fintype J] [DecidableEq I] [DecidableEq J]

 theorem connected_strict (owner : J→I) (R : SimpleGraph I) (s : Gated.State I J)
    (ho : (s.counts owner).sigma % 2=1) :
    MarkedSum.StrictCapacity (connected owner R) (marks owner s) ∅ (s.counts owner).s := by
  let H := connected owner R
  have hw : Marked.White H (marks owner s) ∅=stateWhite owner s := by
    funext v; exact propext (connected_white owner R s v)
  have hc : (GuardedEdge.view H).AgreeOnWhite (graph owner) (stateWhite owner s) := by
    intro v w hW
    exact (GuardedEdge.closed_agree H v w).trans
      ((connected_closed owner R s v w hW).trans (GuardedEdge.closed_agree (original owner) v w).symm)
  constructor
  · rw [connected_value]
    exact (Gated.odd_values (Gated.State.counts_valid owner s) ho).le
  · intro v hv
    have hleg := (ForestFoundation.marked_white_legal H (marks owner s) ∅ v).mpr hv
    rw [hw] at hleg
    have hleg' := ((GuardedEdge.view H).legal_congr (graph owner) _ hc v).mp hleg
    obtain ⟨t,hm,ht⟩ := graph_to_state owner s v hleg'
    have hn : Marked.White H (marks owner s) {v}=stateWhite owner t := by
      have hstep := ForestFoundation.marked_white_step H (marks owner s) ∅ v
      rw [hw] at hstep
      simp only [Finset.insert_empty] at hstep
      apply hstep.symm.trans
      calc
        _ = (graph owner).noniso ((graph owner).remove (stateWhite owner s) v) := by
          funext w; exact propext ((GuardedEdge.view H).move_congr (graph owner) _ hc v w)
        _ = stateWhite owner t := ht
    simp only [Finset.insert_empty]
    rw [value_from_white_agreement owner H (marks owner s) {v} t
      (fun w=>Iff.of_eq (congrFun hn w)) (connected_closed owner R t) .staller]
    exact Gated.odd_step_s (Gated.State.counts_valid owner s) (Gated.State.counts_valid owner t)
      ho (Gated.State.taxonomy owner hm)

#print axioms connected_strict
end GatedGraph

namespace IsolationGame.BWBridge
open MarkedModule

 theorem gated_one_reserve_strict (n : Nat) (σ : State (Fin n)) (hh : H σ=1) :
    MarkedSum.StrictCapacity MarkedModule.original (gatedMarks σ) ∅ (3*U σ+2+E σ) := by
  have ho : ((gatedState σ).counts MarkedModule.owner).sigma % 2=1 := by
    change (gatedState σ).sigma MarkedModule.owner % 2=1
    rw [gated_sigma,hh]
  have h := GatedGraph.connected_strict MarkedModule.owner MarkedModule.star (gatedState σ) ho
  have he : ((gatedState σ).counts MarkedModule.owner).s=3*U σ+2+E σ := by
    simp only [Gated.Counts.s,Gated.State.counts,gated_P,gated_A,gated_sigma,hh]
    omega
  rwa [he] at h

 theorem odd_left_module_S_bound (p q : Nat) (σ : State (Fin p)) (hh : H σ=1) :
    Marked.gameValue (MarkedSum.original MarkedModule.original MarkedModule.original)
      (MarkedSum.combine (gatedMarks σ) (MarkedModule.initialMarks (B:=Fin q))) .staller ∅ ≤
      3*U σ+2+E σ+3*q := by
  have h := MarkedSum.forest_strict_pair
    (MarkedModule.original (B:=Fin p)) (MarkedModule.original (B:=Fin q))
    (module_acyclic p) (module_acyclic q) (gatedMarks σ) ∅ MarkedModule.initialMarks ∅
    (3*U σ+2+E σ) (3*q+1) (gated_one_reserve_strict p σ hh) (PureModuleStrict.module_strict q)
  have he : MarkedSum.combine (∅ : Finset (Side p)) (∅ : Finset (Side q))=∅ := by
    simp [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight]
  rw [he] at h; omega

 theorem odd_right_module_S_bound (p q : Nat) (σ : State (Fin q)) (hh : H σ=1) :
    Marked.gameValue (MarkedSum.original MarkedModule.original MarkedModule.original)
      (MarkedSum.combine (MarkedModule.initialMarks (B:=Fin p)) (gatedMarks σ)) .staller ∅ ≤
      3*p+(3*U σ+2+E σ) := by
  have h := MarkedSum.forest_strict_pair
    (MarkedModule.original (B:=Fin p)) (MarkedModule.original (B:=Fin q))
    (module_acyclic p) (module_acyclic q) MarkedModule.initialMarks ∅ (gatedMarks σ) ∅
    (3*p+1) (3*U σ+2+E σ) (PureModuleStrict.module_strict p) (gated_one_reserve_strict q σ hh)
  have he : MarkedSum.combine (∅ : Finset (Side p)) (∅ : Finset (Side q))=∅ := by
    simp [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight]
  rw [he] at h; omega

#print axioms odd_left_module_S_bound
#print axioms odd_right_module_S_bound
end IsolationGame.BWBridge
