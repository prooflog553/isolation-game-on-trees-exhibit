import GeneralP4PairCenter

/-! Stronger uniform upper bounds for all natural k,p. These are upper bounds,
not equality or sharpness assertions. The marked centre remains selectable.
The proof uses a two-step independent centre-played induction, then outer k
induction with the exact one-pool p assembly at each level. -/
namespace IsolationGame.GeneralP4Receiver
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

/-- ceil(3k/2). -/
def cBudget (k : Nat) : Nat := (3*k+1)/2
/-- floor(3k/2)+1. -/
def sBudget (k : Nat) : Nat := (3*k)/2+1

/-- Independent paired-centre bound; the p=0 base is allowed to be terminal. -/
theorem root_played_S_strong (k p : Nat) :
    Marked.gameValue (graph k p)
      (SelectedVertex.playedMarks (graph k p) (marks k p) (centre k p)) .staller ∅ ≤
      3*p+cBudget k := by
  induction k using Nat.strong_induction_on with
  | h k hin =>
    cases k with
    | zero =>
      have h := root_played_S 0 p
      simpa [cBudget] using h
    | succ k =>
      cases k with
      | zero =>
        have h := root_played_S 1 p
        simpa [cBudget] using h
      | succ k =>
        have hp := hin k (by omega)
        have h := centre_pair_step k p (3*p+cBudget k) hp
        change Marked.gameValue (graph (k+2) p)
          (SelectedVertex.playedMarks (graph (k+2) p) (marks (k+2) p) (centre (k+2) p))
          .staller ∅ ≤ 3*p+cBudget (k+2)
        dsimp [cBudget] at h ⊢
        omega

theorem centre_paid_strong (k p : Nat) :
    1+Marked.gameValue (graph (k+1) p) (marks (k+1) p) .dominator
      {centre (k+1) p} ≤ 3*p+sBudget (k+1) := by
  rw [value_split]
  change 1+Marked.gameValue (P4Receiver.A (graph k p) (centre k p))
    (P4Receiver.AM (marks k p)) .dominator {Sum.inl (centre k p)} ≤ 3*p+sBudget (k+1)
  have h := P4Receiver.center_paid (graph k p) (centre k p) (marks k p)
    (graph_acyclic k p) (3*p+cBudget k) (root_played_S_strong k p)
  dsimp [cBudget,sBudget] at h ⊢
  omega

theorem zero_branch_paid_strong_of_D (k p : Nat)
    (hd : Marked.gameValue (graph k p) (marks k p) .dominator ∅ ≤ 3*p+cBudget k)
    (r : Fin 4) :
    1+Marked.gameValue (graph (k+1) p) (marks (k+1) p) .dominator
      {branch (k+1) p 0 r} ≤ 3*p+sBudget (k+1) := by
  rw [value_split]
  change 1+Marked.gameValue (P4Receiver.A (graph k p) (centre k p))
    (P4Receiver.AM (marks k p)) .dominator {Sum.inr r} ≤ 3*p+sBudget (k+1)
  have h := P4Receiver.right_paid (graph k p) (centre k p) (marks k p)
    (graph_acyclic k p) (root_marked k p) (3*p+cBudget k) hd
    (root_played_S_strong k p) r
  dsimp [cBudget,sBudget] at h ⊢
  omega

theorem branch_paid_strong_of_D (k p : Nat)
    (hd : Marked.gameValue (graph k p) (marks k p) .dominator ∅ ≤ 3*p+cBudget k)
    (i : Fin (k+1)) (r : Fin 4) :
    1+Marked.gameValue (graph (k+1) p) (marks (k+1) p) .dominator
      {branch (k+1) p i r} ≤ 3*p+sBudget (k+1) := by
  rw [value_permute (k+1) p (Equiv.swap i 0)]
  simpa only [Finset.image_singleton,permute_branch,Equiv.swap_apply_left] using
    zero_branch_paid_strong_of_D k p hd r

theorem fixed_paid_strong_of_D (k p : Nat)
    (hd : Marked.gameValue (graph k p) (marks k p) .dominator ∅ ≤ 3*p+cBudget k)
    (v : Fixed (k+1)) :
    1+Marked.gameValue (graph (k+1) p) (marks (k+1) p) .dominator
      {fixed (k+1) p v} ≤ 3*p+sBudget (k+1) := by
  cases v with
  | none => exact centre_paid_strong k p
  | some v =>
    rcases v with ⟨i,r⟩
    exact branch_paid_strong_of_D k p hd i r

private theorem pure_all_first (p : Nat) (v : Vertex 0 p) :
    1+Marked.gameValue (graph 0 p) (marks 0 p) .dominator {v} ≤ 3*p+1 := by
  have hn := Marked.forest_no_minus (graph 0 p) (graph_acyclic 0 p) (marks 0 p) {v}
  have hs : Marked.gameValue (graph 0 p) (marks 0 p) .staller {v} ≤ 3*p := by
    rw [value_pure]
    simpa only [Finset.image_singleton] using PureModuleStrict.follower_S p (pureEquiv p v)
  omega

/-- All k,p, including k=0 with the necessary pure S +1. -/
theorem strong_bounds (k : Nat) : ∀p : Nat,
    Marked.gameValue (graph k p) (marks k p) .dominator ∅ ≤ 3*p+cBudget k ∧
    Marked.gameValue (graph k p) (marks k p) .staller ∅ ≤ 3*p+sBudget k ∧
    ∀v : Vertex k p,
      1+Marked.gameValue (graph k p) (marks k p) .dominator {v} ≤ 3*p+sBudget k := by
  induction k with
  | zero =>
    intro p
    refine ⟨?_,?_,?_⟩
    · simpa [cBudget] using (pure_D p).le
    · simpa [sBudget] using pure_S_upper p
    · intro v
      simpa [sBudget] using pure_all_first p v
  | succ k ih =>
    intro p
    have hfixed : ∀q : Nat, ∀v : Fixed (k+1),
        1+Marked.gameValue (graph (k+1) q) (marks (k+1) q) .dominator
          {fixed (k+1) q v} ≤ 3*q+((3*(k+1))/2+1) := by
      intro q v
      exact fixed_paid_strong_of_D k q (ih q).1 v
    have hnew := onePool_bounds_of_fixed (fixedGraph (k+1)) (fixed_acyclic (k+1))
      (root (k+1)) ({root (k+1)} : Finset (Fixed (k+1))) ((3*(k+1))/2) hfixed p
    change Marked.gameValue (graph (k+1) p) (marks (k+1) p) .staller ∅ ≤
        3*p+sBudget (k+1) ∧
      ∀v : Vertex (k+1) p,
        1+Marked.gameValue (graph (k+1) p) (marks (k+1) p) .dominator {v} ≤
          3*p+sBudget (k+1) at hnew
    refine ⟨?_,hnew.1,hnew.2⟩
    have hd := D_clear_step k p
    have hs := (ih p).2.1
    dsimp [cBudget,sBudget] at hs ⊢
    omega

theorem S_upper_strong (k p : Nat) :
    Marked.gameValue (graph k p) (marks k p) .staller ∅ ≤ 3*p+(3*k)/2+1 := by
  have h := (strong_bounds k p).2.1
  dsimp [sBudget] at h
  omega

theorem D_upper_strong (k p : Nat) :
    Marked.gameValue (graph k p) (marks k p) .dominator ∅ ≤ 3*p+(3*k+1)/2 :=
  (strong_bounds k p).1

theorem all_first_bound_strong (k p : Nat) (v : Vertex k p) :
    1+Marked.gameValue (graph k p) (marks k p) .dominator {v} ≤ 3*p+(3*k)/2+1 := by
  have h := (strong_bounds k p).2.2 v
  dsimp [sBudget] at h
  omega

#print axioms root_played_S_strong
#print axioms fixed_paid_strong_of_D
#print axioms strong_bounds
#print axioms S_upper_strong
#print axioms D_upper_strong
#print axioms all_first_bound_strong
end IsolationGame.GeneralP4Receiver
