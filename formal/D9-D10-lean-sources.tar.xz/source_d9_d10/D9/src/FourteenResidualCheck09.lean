import FourteenResidualData

/-! Finite kernel arithmetic only: first profile fixed to t09.
All arithmetic is checked by kernel reduction; no graph or history search. -/
namespace IsolationGame.FourteenResidual
open CanonicalLocal
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

theorem check11_t09 (b : Index) :
    NumericResidual [.t09] [b] → MatchesFourteen [.t09] [b] := by
  cases b <;> decide +kernel

theorem check12_t09 (b c : Index) :
    NumericResidual [.t09] [b, c] → MatchesFourteen [.t09] [b, c] := by
  cases b <;> cases c <;> decide +kernel

#print axioms check11_t09
#print axioms check12_t09
end IsolationGame.FourteenResidual
