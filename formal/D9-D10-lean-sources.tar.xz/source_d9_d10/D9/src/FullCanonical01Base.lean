import FullCanonicalDAG
namespace IsolationGame.FullCanonical.T01
abbrev original : SimpleGraph (Fin 4) := CanonicalLocal.graph CanonicalLocal.Index.t01
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
noncomputable def perm_0 : Fin 4 ≃ Fin 4 :=
  Equiv.ofBijective (fun v => ![0,1,2,3] v) (by decide +kernel)
theorem adjacency_0 : ∀u v,original.Adj (perm_0 u) (perm_0 v) ↔ original.Adj u v := by decide +kernel
end IsolationGame.FullCanonical.T01
