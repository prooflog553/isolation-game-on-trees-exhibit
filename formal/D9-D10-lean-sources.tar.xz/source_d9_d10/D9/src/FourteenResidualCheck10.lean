import FourteenResidualData

/-! Finite kernel arithmetic only: first profile fixed to t10.
All arithmetic is checked by kernel reduction; no graph or history search. -/
namespace IsolationGame.FourteenResidual
open CanonicalLocal
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

theorem check11_t10 (b : Index) :
    NumericResidual [.t10] [b] → MatchesFourteen [.t10] [b] := by
  cases b <;> decide +kernel

theorem check12_t10 (b c : Index) :
    NumericResidual [.t10] [b, c] → MatchesFourteen [.t10] [b, c] := by
  cases b <;> cases c <;> decide +kernel

#print axioms check11_t10
#print axioms check12_t10
end IsolationGame.FourteenResidual
