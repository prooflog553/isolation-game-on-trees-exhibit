import FourteenResidualData

/-! Finite kernel arithmetic only: first profile fixed to t11.
All arithmetic is checked by kernel reduction; no graph or history search. -/
namespace IsolationGame.FourteenResidual
open CanonicalLocal
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

theorem check11_t11 (b : Index) :
    NumericResidual [.t11] [b] → MatchesFourteen [.t11] [b] := by
  cases b <;> decide +kernel

theorem check12_t11 (b c : Index) :
    NumericResidual [.t11] [b, c] → MatchesFourteen [.t11] [b, c] := by
  cases b <;> cases c <;> decide +kernel

#print axioms check11_t11
#print axioms check12_t11
end IsolationGame.FourteenResidual
