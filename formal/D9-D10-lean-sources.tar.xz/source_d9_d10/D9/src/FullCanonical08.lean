import FullCanonical08Rows08
namespace IsolationGame.FullCanonical.T08
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
theorem full_values : Marked.gameValue original ∅ .dominator ∅=4 ∧ Marked.gameValue original ∅ .staller ∅=5 := by
  constructor
  · exact (Marked.value_eq_of_white_eq original ∅ marks_34 ∅ ∅ .dominator (by decide +kernel)).trans row_34.1
  · exact (Marked.value_eq_of_white_eq original ∅ marks_34 ∅ ∅ .staller (by decide +kernel)).trans row_34.2
theorem strict_full : MarkedSum.StrictCapacity original ∅ ∅ 5 := by
  constructor
  · rw [full_values.1] <;> decide +kernel
  · intro v hv
    fin_cases v
    · change Marked.gameValue original marks_34 .staller {0}+1≤5
      rw [after_34_0.2] <;> decide +kernel
    · change Marked.gameValue original marks_34 .staller {1}+1≤5
      rw [after_34_1.2] <;> decide +kernel
    · change Marked.gameValue original marks_34 .staller {2}+1≤5
      rw [after_34_2.2] <;> decide +kernel
    · change Marked.gameValue original marks_34 .staller {3}+1≤5
      rw [after_34_3.2] <;> decide +kernel
    · change Marked.gameValue original marks_34 .staller {4}+1≤5
      rw [after_34_4.2] <;> decide +kernel
    · change Marked.gameValue original marks_34 .staller {5}+1≤5
      rw [after_34_5.2] <;> decide +kernel
    · change Marked.gameValue original marks_34 .staller {6}+1≤5
      rw [after_34_6.2] <;> decide +kernel
    · change Marked.gameValue original marks_34 .staller {7}+1≤5
      rw [after_34_7.2] <;> decide +kernel
    · change Marked.gameValue original marks_34 .staller {8}+1≤5
      rw [after_34_8.2] <;> decide +kernel
    · change Marked.gameValue original marks_34 .staller {9}+1≤5
      rw [after_34_9.2] <;> decide +kernel
    · change Marked.gameValue original marks_34 .staller {10}+1≤5
      rw [after_34_10.2] <;> decide +kernel
#print axioms full_values
#print axioms strict_full
end IsolationGame.FullCanonical.T08
