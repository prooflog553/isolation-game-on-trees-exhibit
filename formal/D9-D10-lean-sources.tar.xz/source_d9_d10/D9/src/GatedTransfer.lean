import Normalization
import GatedFormula

namespace Gated

universe u

/-- The two independent modules use the same players. -/
def Turn.toIsolation : Turn → Isolation.Graph.Turn
  | .D => .D
  | .S => .S

/-- Exact one-move correspondence with the original graph. Every graph vertex,
including an already dominated gate, is included in the forward coverage. -/
structure WhiteBisimulation {State : Type} {V : Type u}
    (G : Isolation.Graph V) (Move : State → State → Prop) (P : State → Nat)
    (white : State → V → Prop) : Prop where
  terminal : ∀ q, P q = 0 ↔ Isolation.Graph.TerminalWhite (white q)
  graph_to_state : ∀ q v, G.legal (white q) v →
    ∃ r, Move q r ∧ G.noniso (G.remove (white q) v) = white r
  state_to_graph : ∀ {q r}, Move q r →
    ∃ v, G.legal (white q) v ∧ G.noniso (G.remove (white q) v) = white r

namespace WhiteBisimulation

variable {State : Type} {V : Type u} {G : Isolation.Graph V}
    {Move : State → State → Prop} {P : State → Nat} {white : State → V → Prop}

/-- Exact move correspondence preserves all finite-horizon strategies for both
players. No minimax bounds or contextual equivalence are assumed. -/
theorem winWithin_iff_white (B : WhiteBisimulation G Move P white)
    (n : Nat) (t : Turn) (q : State) :
    winWithin Move P n t q ↔ G.WinsWhite n t.toIsolation (white q) := by
  induction n generalizing t q with
  | zero =>
    cases t <;> exact B.terminal q
  | succ n ih =>
    cases t with
    | D =>
      change (P q = 0 ∨ ∃ r, Move q r ∧ winWithin Move P n .S r) ↔
        (Isolation.Graph.TerminalWhite (white q) ∨
          ∃ v, G.legal (white q) v ∧
            G.WinsWhite n .S (G.noniso (G.remove (white q) v)))
      constructor
      · rintro (ht | ⟨r, hm, hw⟩)
        · exact Or.inl ((B.terminal q).mp ht)
        · obtain ⟨v, hv, heq⟩ := B.state_to_graph hm
          refine Or.inr ⟨v, hv, ?_⟩
          rw [heq]
          exact (ih .S r).mp hw
      · rintro (ht | ⟨v, hv, hw⟩)
        · exact Or.inl ((B.terminal q).mpr ht)
        · obtain ⟨r, hm, heq⟩ := B.graph_to_state q v hv
          refine Or.inr ⟨r, hm, (ih .S r).mpr ?_⟩
          rw [heq] at hw
          exact hw
    | S =>
      change (P q = 0 ∨ ∀ r, Move q r → winWithin Move P n .D r) ↔
        (Isolation.Graph.TerminalWhite (white q) ∨
          ∀ v, G.legal (white q) v →
            G.WinsWhite n .D (G.noniso (G.remove (white q) v)))
      constructor
      · rintro (ht | hw)
        · exact Or.inl ((B.terminal q).mp ht)
        · refine Or.inr ?_
          intro v hv
          obtain ⟨r, hm, heq⟩ := B.graph_to_state q v hv
          rw [heq]
          exact (ih .D r).mp (hw r hm)
      · rintro (ht | hw)
        · exact Or.inl ((B.terminal q).mpr ht)
        · refine Or.inr ?_
          intro r hm
          obtain ⟨v, hv, heq⟩ := B.state_to_graph hm
          apply (ih .D r).mpr
          have h := hw v hv
          rw [heq] at h
          exact h

/-- The same equivalence holds in the actual selected-vertex game whenever
its current normalized white predicate is represented by the abstract state. -/
theorem winWithin_iff_selected (B : WhiteBisimulation G Move P white)
    (M X : V → Prop) (q : State) (hwhite : G.noniso (G.raw M X) = white q)
    (n : Nat) (t : Turn) :
    winWithin Move P n t q ↔ G.WinsSelected M n t.toIsolation X := by
  rw [G.selected_white_strategy_equivalence M X n t.toIsolation, hwhite]
  exact B.winWithin_iff_white n t q

/-- A fully instantiated transition/count certificate yields the original-
graph closed formula for every horizon, without a finite size cutoff. -/
theorem white_formula {count : State → Counts}
    (B : WhiteBisimulation G Move (fun q => (count q).P) white)
    (C : Certificate Move count) (n : Nat) (t : Turn) (q : State) :
    G.WinsWhite n t.toIsolation (white q) ↔ (count q).value t ≤ n :=
  (B.winWithin_iff_white n t q).symm.trans (C.formula n t q)

/-- Closed formula in the actual selected-set semantics, preserving the
original graph and its complete set of possible move vertices. -/
theorem selected_formula {count : State → Counts}
    (B : WhiteBisimulation G Move (fun q => (count q).P) white)
    (C : Certificate Move count) (M X : V → Prop) (q : State)
    (hwhite : G.noniso (G.raw M X) = white q) (n : Nat) (t : Turn) :
    G.WinsSelected M n t.toIsolation X ↔ (count q).value t ≤ n :=
  (B.winWithin_iff_selected M X q hwhite n t).symm.trans (C.formula n t q)

end WhiteBisimulation

#print axioms WhiteBisimulation.winWithin_iff_white
#print axioms WhiteBisimulation.winWithin_iff_selected
#print axioms WhiteBisimulation.white_formula
#print axioms WhiteBisimulation.selected_formula

end Gated
