import CoreFamilyLegality

namespace IsolationGame.CoreFamilySemantics
open CanonicalLocal CoreFamily Isolation.Graph
variable (xs : List Nat) (p : Nat)

theorem step_root_nonwhite (W : LocalWhite xs p) (v : Vertex xs p) :
    ¬(GuardedEdge.view (CoreFamily.graph xs p)).step (white xs p W) v none :=
  fun h=>h.1.1

/-- Selecting the genuinely marked centre clears each LOCAL ROOT, not its
closed local neighbourhood. Every component is then normalized separately. -/
theorem step_centre (W : LocalWhite xs p) (i : Fin (xs.length+p)) (u : Fin (size (label xs p i))) :
    (GuardedEdge.view (CoreFamily.graph xs p)).step (white xs p W) none (some ⟨i,u⟩) ↔
      (GuardedEdge.view (CanonicalLocal.graph (label xs p i))).noniso
        (fun v=>W i v ∧ v≠root (label xs p i)) u := by
  constructor
  · rintro ⟨⟨hu,huc⟩,w,⟨hw,hwc⟩,ha⟩
    cases w with
    | none => exact False.elim hw
    | some w =>
      obtain ⟨j,v⟩ := w
      by_cases hij : i=j
      · subst j
        exact ⟨⟨hu,fun h=>huc ((closed_root xs p i u).mpr h)⟩,v,
          ⟨hw,fun h=>hwc ((closed_root xs p i v).mpr h)⟩,(same_adj xs p i u v).mp ha⟩
      · exact False.elim (distinct_no_adj xs p i j hij u v ha)
  · rintro ⟨⟨hu,huc⟩,v,⟨hv,hvc⟩,ha⟩
    exact ⟨⟨hu,fun h=>huc ((closed_root xs p i u).mp h)⟩,some ⟨i,v⟩,
      ⟨hv,fun h=>hvc ((closed_root xs p i v).mp h)⟩,(same_adj xs p i u v).mpr ha⟩

/-- A move inside one original branch has exactly its full local original
closed-neighbourhood effect, retaining legal moves at blue vertices. -/
theorem step_same (W : LocalWhite xs p) (i : Fin (xs.length+p))
    (v u : Fin (size (label xs p i))) :
    (GuardedEdge.view (CoreFamily.graph xs p)).step (white xs p W) (some ⟨i,v⟩) (some ⟨i,u⟩) ↔
      (GuardedEdge.view (CanonicalLocal.graph (label xs p i))).step (W i) v u := by
  constructor
  · rintro ⟨⟨hu,huc⟩,w,⟨hw,hwc⟩,ha⟩
    cases w with
    | none => exact False.elim hw
    | some w =>
      obtain ⟨j,t⟩ := w
      by_cases hij : i=j
      · subst j
        exact ⟨⟨hu,fun h=>huc ((closed_same xs p i v u).mpr h)⟩,t,
          ⟨hw,fun h=>hwc ((closed_same xs p i v t).mpr h)⟩,(same_adj xs p i u t).mp ha⟩
      · exact False.elim (distinct_no_adj xs p i j hij u t ha)
  · rintro ⟨⟨hu,huc⟩,t,⟨ht,htc⟩,ha⟩
    exact ⟨⟨hu,fun h=>huc ((closed_same xs p i v u).mp h)⟩,some ⟨i,t⟩,
      ⟨ht,fun h=>htc ((closed_same xs p i v t).mp h)⟩,(same_adj xs p i u t).mpr ha⟩

/-- Every other branch is untouched. This is a full original-state fact, not
an inference from equal component values. -/
theorem step_other (W : LocalWhite xs p) (hn : Normalized xs p W)
    (i j : Fin (xs.length+p)) (hij : i≠j)
    (v : Fin (size (label xs p i))) (u : Fin (size (label xs p j))) :
    (GuardedEdge.view (CoreFamily.graph xs p)).step (white xs p W) (some ⟨i,v⟩) (some ⟨j,u⟩) ↔ W j u := by
  constructor
  · exact fun h=>h.1.1
  · intro hu
    have hnu : (GuardedEdge.view (CanonicalLocal.graph (label xs p j))).noniso (W j) u := by
      rw [hn j]
      exact hu
    obtain ⟨_,t,ht,ha⟩ := hnu
    exact ⟨⟨hu,not_closed_distinct xs p i j hij v u⟩,some ⟨j,t⟩,
      ⟨ht,not_closed_distinct xs p i j hij v t⟩,(same_adj xs p j u t).mpr ha⟩

/-- Direct bridge for arbitrary actual original one-move followers. -/
theorem actual_follower_white (W : LocalWhite xs p) (hn : Normalized xs p W)
    (v w : Vertex xs p) :
    Marked.White (CoreFamily.graph xs p) (marks xs p W) {v} w ↔
      (GuardedEdge.view (CoreFamily.graph xs p)).step (white xs p W) v w := by
  have he : Marked.White (CoreFamily.graph xs p) (marks xs p W) ∅=white xs p W := by
    funext u
    exact propext (original_white xs p W hn u)
  have hs := ForestFoundation.marked_white_step (CoreFamily.graph xs p) (marks xs p W) ∅ v
  rw [he] at hs
  simp only [Finset.insert_empty] at hs
  exact (congrFun hs w).symm.to_iff

#print axioms step_centre
#print axioms step_same
#print axioms step_other
#print axioms actual_follower_white
end IsolationGame.CoreFamilySemantics
