import DoubleCentreP4Model
import AttachmentTreeGeometry

/-! SOURCE_ONLY. This file has not been elaborated or compiled. -/
namespace IsolationGame.DoubleCentreP4

theorem graph_connected (k l p q : Nat) : (graph k l p q).Connected :=
  Attachment.original_connected _ _ _ _
    (GeneralP4Receiver.graph_connected k p) (GeneralP4Receiver.graph_connected l q)

theorem graph_tree (k l p q : Nat) : (graph k l p q).IsTree :=
  Attachment.original_tree _ _ _ _
    (GeneralP4Receiver.graph_tree k p) (GeneralP4Receiver.graph_tree l q)

theorem graph_acyclic (k l p q : Nat) : (graph k l p q).IsAcyclic :=
  (graph_tree k l p q).IsAcyclic

#print axioms graph_connected
#print axioms graph_tree
#print axioms graph_acyclic
end IsolationGame.DoubleCentreP4
