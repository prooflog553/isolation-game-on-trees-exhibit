import InducedAssociativity
import DisconnectedPartition

namespace IsolationGame.FiniteForestComponents
open IsolatedRestriction PartitionBridge
variable {V : Type} [Fintype V] [DecidableEq V]

noncomputable def valueOn (G : SimpleGraph V) (A M X : Finset V) (p : Player) : Nat :=
  Marked.gameValue (induced G A) (restrict A M) p (restrict A X)

theorem outside_restrict (A B : Finset V) : outside (restrict A B)=restrict A (A\B) := by
  ext v
  simp [outside,v.property]

theorem subregion_s_upper (G : SimpleGraph V) (hG : G.IsAcyclic)
    (A B : Finset V) (hBA : B⊆A)
    (hcross : ∀u v,u∈B→v∈A→v∉B→¬G.Adj u v) (M X : Finset V) :
    valueOn G A M X .staller≤valueOn G B M X .staller+valueOn G (A\B) M X .staller := by
  have hn : DisconnectedPartition.NoCross (induced G A) (restrict A B) := by
    intro u v hu hv
    exact hcross u.val v.val (by simpa using hu) v.property (by simpa using hv)
  have hh := DisconnectedPartition.forest_s_upper (induced G A) (induced_acyclic G hG A)
    (restrict A B) hn (restrict A M) (restrict A X)
  rw [outside_restrict,
    InducedAssociativity.value_nested G A B hBA,
    InducedAssociativity.value_nested G A (A\B) Finset.sdiff_subset] at hh
  exact hh

theorem union_s_upper (G : SimpleGraph V) (hG : G.IsAcyclic)
    (A B : Finset V) (hdis : Disjoint A B)
    (hcross : ∀u v,u∈A→v∈B→¬G.Adj u v) (M X : Finset V) :
    valueOn G (A∪B) M X .staller≤valueOn G A M X .staller+valueOn G B M X .staller := by
  have hn : ∀u v,u∈A→v∈A∪B→v∉A→¬G.Adj u v := by
    intro u v hu hv hn
    exact hcross u v hu ((Finset.mem_union.mp hv).resolve_left hn)
  have he : (A∪B)\A=B := by
    ext v
    have hd : v∈B→v∉A := by intro hv ha;exact Finset.disjoint_left.mp hdis ha hv
    simp only [Finset.mem_sdiff,Finset.mem_union]
    tauto
  have hh := subregion_s_upper G hG (A∪B) A Finset.subset_union_left hn M X
  simpa only [he] using hh

def univEquiv : Active (Finset.univ : Finset V) ≃ V where
  toFun := Subtype.val
  invFun v := ⟨v,Finset.mem_univ v⟩
  left_inv v := rfl
  right_inv v := rfl

theorem univ_marks (M : Finset V) : (restrict Finset.univ M).image univEquiv=M := by
  ext v
  constructor
  · intro hv
    obtain ⟨w,hw,he⟩ := Finset.mem_image.mp hv
    have hwM : w.val∈M := by simpa using hw
    exact he ▸ hwM
  · intro hv
    exact Finset.mem_image.mpr ⟨⟨v,by simp⟩,by simpa using hv,rfl⟩

theorem univ_value (G : SimpleGraph V) (M X : Finset V) (p : Player) :
    valueOn G Finset.univ M X p=Marked.gameValue G M p X := by
  have h := Marked.gameValue_relabel (induced G Finset.univ) G univEquiv
    (by intro u v;rfl) (restrict Finset.univ M) (restrict Finset.univ X) p
  rw [univ_marks,univ_marks] at h
  exact h.symm

theorem empty_value (G : SimpleGraph V) (M X : Finset V) (p : Player) :
    valueOn G ∅ M X p=0 := by
  apply (Marked.value_zero_iff_terminal _ _ _ _).mpr
  intro v _
  exact Finset.not_mem_empty v.val v.property

/-- Finite genuine component subadditivity, in the original graph's induced
vertex sets. Empty families and empty components are included. -/
theorem finite_union_s_upper {Iota : Type} [DecidableEq Iota]
    (G : SimpleGraph V) (hG : G.IsAcyclic) (C : Iota→Finset V) (I : Finset Iota)
    (hdis : ∀i∈I,∀j∈I,i≠j→Disjoint (C i) (C j))
    (hcross : ∀i∈I,∀j∈I,i≠j→∀u∈C i,∀v∈C j,¬G.Adj u v)
    (M X : Finset V) :
    valueOn G (I.biUnion C) M X .staller≤∑i∈I,valueOn G (C i) M X .staller := by
  revert hdis hcross
  induction I using Finset.induction_on with
  | empty =>
    intro _ _
    simp [empty_value]
  | @insert i I hi ih =>
    intro hdis hcross
    have hd : Disjoint (C i) (I.biUnion C) := by
      apply Finset.disjoint_left.mpr
      intro v hvi hvI
      obtain ⟨j,hj,hvj⟩ := Finset.mem_biUnion.mp hvI
      have hij : i≠j := by intro he;subst j;exact hi hj
      exact Finset.disjoint_left.mp (hdis i (by simp) j (by simp [hj]) hij) hvi hvj
    have hc : ∀u v,u∈C i→v∈I.biUnion C→¬G.Adj u v := by
      intro u v hu hv
      obtain ⟨j,hj,hvj⟩ := Finset.mem_biUnion.mp hv
      have hij : i≠j := by intro he;subst j;exact hi hj
      exact hcross i (by simp) j (by simp [hj]) hij u hu v hvj
    have hh := union_s_upper G hG (C i) (I.biUnion C) hd hc M X
    have hI := ih
      (by intro a ha b hb hab;exact hdis a (by simp [ha]) b (by simp [hb]) hab)
      (by intro a ha b hb hab;exact hcross a (by simp [ha]) b (by simp [hb]) hab)
    rw [Finset.biUnion_insert,Finset.sum_insert hi]
    exact hh.trans (Nat.add_le_add_left hI _)

#print axioms finite_union_s_upper
#print axioms subregion_s_upper
#print axioms union_s_upper
end IsolationGame.FiniteForestComponents
