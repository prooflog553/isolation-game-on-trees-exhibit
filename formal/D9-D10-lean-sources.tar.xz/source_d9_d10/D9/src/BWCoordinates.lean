import BWBridge
import BWLiteralAdjacency
import Mathlib.Data.Fintype.EquivFin

namespace IsolationGame.BWCoordinates
open BWBridge

abbrev Local (n : Nat) := Option (Fin n × Fin 7)
abbrev Coordinates (p q : Nat) := Sum (Local p) (Local q)

def decode (n : Nat) : Local n → Side n
  | none => .gate none
  | some (i,k) => ![.gate (some i),.b (i,false),.c (i,false),.d (i,false),
      .b (i,true),.c (i,true),.d (i,true)] k

def code (n : Nat) : Side n → Local n
  | .gate none => none
  | .gate (some i) => some (i,0)
  | .b (i,false) => some (i,1)
  | .c (i,false) => some (i,2)
  | .d (i,false) => some (i,3)
  | .b (i,true) => some (i,4)
  | .c (i,true) => some (i,5)
  | .d (i,true) => some (i,6)

def sideEquiv (n : Nat) : Local n ≃ Side n where
  toFun := decode n
  invFun := code n
  left_inv := by
    intro v; cases v with
    | none => rfl
    | some v => obtain ⟨i,k⟩ := v; fin_cases k <;> rfl
  right_inv := by
    intro v; cases v with
    | gate o => cases o <;> rfl
    | b j => obtain ⟨i,s⟩ := j; cases s <;> rfl
    | c j => obtain ⟨i,s⟩ := j; cases s <;> rfl
    | d j => obtain ⟨i,s⟩ := j; cases s <;> rfl

def sides (p q : Nat) : Coordinates p q ≃ BWBridge.Vertex p q :=
  Equiv.sumCongr (sideEquiv p) (sideEquiv q)

def encode (p q : Nat) : Coordinates p q → LiteralBW.Vertex p q
  | .inl none => LiteralBW.x p q
  | .inr none => LiteralBW.y p q
  | .inl (some (i,k)) => LiteralBW.node p q (Fin.castAdd q i) k
  | .inr (some (j,k)) => LiteralBW.node p q (Fin.natAdd p j) k

 theorem left_ne_right (p q : Nat) (i : Fin p) (j : Fin q) :
    Fin.castAdd q i ≠ Fin.natAdd p j := by
  intro h; have he := congrArg Fin.val h; have hi := i.isLt
  simp only [Fin.coe_castAdd,Fin.coe_natAdd] at he; omega

 theorem left_index_inj (p q : Nat) (i j : Fin p) :
    Fin.castAdd q i=Fin.castAdd q j ↔ i=j := by
  constructor
  · intro h; apply Fin.ext; exact congrArg (fun z : Fin (p+q) => z.val) h
  · rintro rfl; rfl
 theorem right_index_inj (p q : Nat) (i j : Fin q) :
    Fin.natAdd p i=Fin.natAdd p j ↔ i=j := by
  constructor
  · intro h; apply Fin.ext; have he:=congrArg Fin.val h
    simp only [Fin.coe_natAdd] at he; omega
  · rintro rfl; rfl

 theorem encode_injective (p q : Nat) : Function.Injective (encode p q) := by
  intro u v h
  cases u with
  | inl u =>
    cases v with
    | inl v =>
      cases u with
      | none =>
        cases v with
        | none =>
          rfl
        | some v =>
          simp [encode,LiteralBW.node_ne_x,LiteralBW.node_ne_y,eq_comm] at h
      | some u =>
        cases v with
        | none =>
          simp [encode,LiteralBW.node_ne_x,LiteralBW.node_ne_y,eq_comm] at h
        | some v =>
          obtain ⟨i,a⟩ := u
          obtain ⟨j,b⟩ := v
          have hh := (LiteralBW.node_eq_node p q _ _ _ _).mp h
          have hij := (left_index_inj p q i j).mp hh.1
          obtain rfl := hij
          obtain rfl := hh.2
          rfl
    | inr v =>
      cases u with
      | none =>
        cases v with
        | none =>
          simp [encode,LiteralBW.x_ne_y,Ne.symm (LiteralBW.x_ne_y p q)] at h
        | some v =>
          simp [encode,LiteralBW.node_ne_x,LiteralBW.node_ne_y,eq_comm] at h
      | some u =>
        cases v with
        | none =>
          simp [encode,LiteralBW.node_ne_x,LiteralBW.node_ne_y,eq_comm] at h
        | some v =>
          obtain ⟨i,a⟩ := u
          obtain ⟨j,b⟩ := v
          have hh := (LiteralBW.node_eq_node p q _ _ _ _).mp h
          exact False.elim (left_ne_right p q i j hh.1)
  | inr u =>
    cases v with
    | inl v =>
      cases u with
      | none =>
        cases v with
        | none =>
          simp [encode,LiteralBW.x_ne_y,Ne.symm (LiteralBW.x_ne_y p q)] at h
        | some v =>
          simp [encode,LiteralBW.node_ne_x,LiteralBW.node_ne_y,eq_comm] at h
      | some u =>
        cases v with
        | none =>
          simp [encode,LiteralBW.node_ne_x,LiteralBW.node_ne_y,eq_comm] at h
        | some v =>
          obtain ⟨i,a⟩ := u
          obtain ⟨j,b⟩ := v
          have hh := (LiteralBW.node_eq_node p q _ _ _ _).mp h
          exact False.elim (left_ne_right p q j i hh.1.symm)
    | inr v =>
      cases u with
      | none =>
        cases v with
        | none =>
          rfl
        | some v =>
          simp [encode,LiteralBW.node_ne_x,LiteralBW.node_ne_y,eq_comm] at h
      | some u =>
        cases v with
        | none =>
          simp [encode,LiteralBW.node_ne_x,LiteralBW.node_ne_y,eq_comm] at h
        | some v =>
          obtain ⟨i,a⟩ := u
          obtain ⟨j,b⟩ := v
          have hh := (LiteralBW.node_eq_node p q _ _ _ _).mp h
          have hij := (right_index_inj p q i j).mp hh.1
          obtain rfl := hij
          obtain rfl := hh.2
          rfl

noncomputable def literalEquiv (p q : Nat) : Coordinates p q ≃ LiteralBW.Vertex p q :=
  Equiv.ofBijective (encode p q) ((Fintype.bijective_iff_injective_and_card _).mpr
    ⟨encode_injective p q,by simp [Coordinates,Local,Fintype.card_sum,Fintype.card_option,Fintype.card_prod]; omega⟩)

#print axioms encode_injective
end IsolationGame.BWCoordinates
