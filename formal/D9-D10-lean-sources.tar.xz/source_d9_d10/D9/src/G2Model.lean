import BWPositiveUpper
import P7GraftFirstMove

namespace IsolationGame.G2Family

abbrev Vertex (p q k : Nat) := Sum (BWBridge.Vertex q p) (Fin k × Fin 4)

def y (p q k : Nat) : Vertex p q k := .inl (.inl (BWBridge.root q))
def x (p q k : Nat) : Vertex p q k := .inl (.inr (BWBridge.root p))
def pathGraph : SimpleGraph (Fin 4) where
  Adj a b := a.val + 1 = b.val ∨ b.val + 1 = a.val
  symm := by intro a b h; exact h.symm
  loopless := by intro a; simp

instance : DecidableRel pathGraph.Adj := by intro a b; unfold pathGraph; infer_instance

abbrev YVertex (q k : Nat) := Sum (BWBridge.Side q) (Fin k × Fin 4)

def yGraph (q k : Nat) : SimpleGraph (YVertex q k) where
  Adj
    | .inl u, .inl v => MarkedModule.original.Adj u v
    | .inr (i,a), .inr (j,b) => i=j ∧ pathGraph.Adj a b
    | .inl u, .inr (_,a) => u=BWBridge.root q ∧ a=0
    | .inr (_,a), .inl u => a=0 ∧ u=BWBridge.root q
  symm := by
    intro u v h
    cases u <;> cases v
    · exact h.symm
    · exact h.symm
    · exact h.symm
    · exact ⟨h.1.symm,h.2.symm⟩
  loopless := by
    intro u h
    cases u with
    | inl u => exact MarkedModule.original.loopless u h
    | inr u => exact pathGraph.loopless u.2 h.2

def yMarks (q k : Nat) : Finset (YVertex q k) := {.inl (BWBridge.root q)}

/-- All original BW vertices plus k distinct full white P4 paths at marked y. -/
def graph (p q k : Nat) : SimpleGraph (Vertex p q k) where
  Adj
    | .inl u, .inl v => (BWBridge.original q p).Adj u v
    | .inr (i,a), .inr (j,b) => i=j ∧ pathGraph.Adj a b
    | .inl u, .inr (_,a) => u=.inl (BWBridge.root q) ∧ a=0
    | .inr (_,a), .inl u => a=0 ∧ u=.inl (BWBridge.root q)
  symm := by
    intro u v h
    cases u <;> cases v
    · exact h.symm
    · exact h.symm
    · exact h.symm
    · exact ⟨h.1.symm,h.2.symm⟩
  loopless := by
    intro u h
    cases u with
    | inl u => exact (BWBridge.original q p).loopless u h
    | inr u => exact pathGraph.loopless u.2 h.2

def marks (p q k : Nat) : Finset (Vertex p q k) := {y p q k}

end IsolationGame.G2Family
