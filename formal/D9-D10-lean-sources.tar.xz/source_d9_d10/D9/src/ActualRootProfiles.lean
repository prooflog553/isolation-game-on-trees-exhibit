import ActualRootBranches
import RootStrictBudget

namespace IsolationGame.ActualRootBranches
open IsolatedRestriction PartitionBridge FiniteForestComponents
variable {V : Type} [Fintype V] [DecidableEq V]

noncomputable def localMarks (G : SimpleGraph V) (r : V) (a : Child G r) : Finset (Active (piece G r a)) :=
  {⟨a.val,self_mem_piece G r a⟩}

noncomputable def capacity (G : SimpleGraph V) (r : V) (a : Child G r) : Nat :=
  Marked.gameValue (induced G (piece G r a)) (localMarks G r a) .staller ∅

def IsStrict (G : SimpleGraph V) (r : V) (a : Child G r) : Prop :=
  MarkedSum.StrictCapacity (induced G (piece G r a)) (localMarks G r a) ∅ (capacity G r a)

noncomputable def strictChildren (G : SimpleGraph V) (r : V) : Finset (Child G r) := by
  classical
  exact Finset.univ.filter (IsStrict G r)

theorem component_value (G : SimpleGraph V) (hT : G.IsTree) (r : V) (a : Child G r) (p : Player) :
    valueOn (MarkedBoundary.deleted G r) (component G r a) (RootMoveCapacity.neighbourMarks G r) ∅ p=
      Marked.gameValue (induced G (piece G r a)) (localMarks G r a) p ∅ := by
  have hp : G.dist r a.val=G.dist r r+1 := by simpa only [G.dist_self,Nat.zero_add] using child_depth G r a
  obtain ⟨hz,hr,ha,hcut,ht,hd⟩ := DescendantGeometry.descendant_partition_spec G hT r r a.val (child_edge G r a) hp
  exact RootBranchProfiles.local_value G (DescendantGeometry.retained G r a.val) r a.val hr ha hcut p

theorem component_strict (G : SimpleGraph V) (hT : G.IsTree) (r : V) (a : Child G r)
    (haStrict : a∈strictChildren G r) :
    MarkedSum.StrictCapacity (induced (MarkedBoundary.deleted G r) (component G r a))
      (restrict (component G r a) (RootMoveCapacity.neighbourMarks G r)) (restrict (component G r a) ∅)
      (capacity G r a) := by
  classical
  have hs : IsStrict G r a := (Finset.mem_filter.mp haStrict).2
  have hp : G.dist r a.val=G.dist r r+1 := by simpa only [G.dist_self,Nat.zero_add] using child_depth G r a
  obtain ⟨hz,hr,ha,hcut,ht,hd⟩ := DescendantGeometry.descendant_partition_spec G hT r r a.val (child_edge G r a) hp
  exact RootBranchProfiles.local_strict G (DescendantGeometry.retained G r a.val) r a.val hr ha hcut (capacity G r a) hs

theorem component_card (G : SimpleGraph V) (r : V) (a : Child G r) :
    (component G r a).card=(piece G r a).card := by
  have hsub : piece G r a⊆MarkedBoundary.retained r := by
    intro v hv
    have hvr : v≠r := by intro he;subst v;exact root_not_piece G r a hv
    simp [MarkedBoundary.retained,hvr]
  have hc := Fintype.card_congr (InducedAssociativity.flatten (MarkedBoundary.retained r) (piece G r a) hsub)
  simpa only [Fintype.card_coe] using hc

theorem actual_order (G : SimpleGraph V) (hT : G.IsTree) (r : V) :
    Fintype.card V=1+∑a : Child G r,(piece G r a).card := by
  have hh := RootMoveCapacity.original_order r (component G r) Finset.univ
    (components_cover G hT r) (components_disjoint G hT r)
  have hc : (∑a : Child G r,(component G r a).card)=∑a : Child G r,(piece G r a).card := by
    apply Finset.sum_congr rfl
    intro a _
    exact component_card G r a
  rw [hc] at hh
  exact hh

#print axioms component_value
#print axioms component_strict
#print axioms actual_order
end IsolationGame.ActualRootBranches
