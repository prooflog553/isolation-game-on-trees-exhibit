import FullCanonical07Rows02
namespace IsolationGame.FullCanonical.T07
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_12 : Finset (Fin 8) := {1,2,3}
theorem after_12_0 : Marked.gameValue original marks_12 .dominator {0}=1 ∧ Marked.gameValue original marks_12 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_3 0 1 1 (by decide +kernel) row_3
theorem after_12_1 : Marked.gameValue original marks_12 .dominator {1}=1 ∧ Marked.gameValue original marks_12 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_11 1 1 2 (by decide +kernel) row_11
theorem after_12_4 : Marked.gameValue original marks_12 .dominator {4}=0 ∧ Marked.gameValue original marks_12 .staller {4}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_0 4 0 0 (by decide +kernel) row_0
theorem after_12_5 : Marked.gameValue original marks_12 .dominator {5}=0 ∧ Marked.gameValue original marks_12 .staller {5}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_0 5 0 0 (by decide +kernel) row_0
theorem after_12_6 : Marked.gameValue original marks_12 .dominator {6}=1 ∧ Marked.gameValue original marks_12 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_6 6 1 2 (by decide +kernel) row_6
theorem after_12_7 : Marked.gameValue original marks_12 .dominator {7}=1 ∧ Marked.gameValue original marks_12 .staller {7}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_3 7 1 1 (by decide +kernel) row_3
theorem row_12 : Marked.gameValue original marks_12 .dominator ∅=1 ∧ Marked.gameValue original marks_12 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_12 1 2 4 0 (by decide +kernel) (by decide +kernel)
  · rw [after_12_4.2]
  · rw [after_12_0.1]
  · intro v hv
    fin_cases v
    · have h := after_12_0
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {0} ∧ 1+Marked.gameValue original marks_12 .dominator {0} ≤ 2
      omega
    · have h := after_12_1
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {1} ∧ 1+Marked.gameValue original marks_12 .dominator {1} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_12 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_12 ∅ 3) hv)
    · have h := after_12_4
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {4} ∧ 1+Marked.gameValue original marks_12 .dominator {4} ≤ 2
      omega
    · have h := after_12_5
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {5} ∧ 1+Marked.gameValue original marks_12 .dominator {5} ≤ 2
      omega
    · have h := after_12_6
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {6} ∧ 1+Marked.gameValue original marks_12 .dominator {6} ≤ 2
      omega
    · have h := after_12_7
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {7} ∧ 1+Marked.gameValue original marks_12 .dominator {7} ≤ 2
      omega
def marks_13 : Finset (Fin 8) := {4,7}
theorem after_13_0 : Marked.gameValue original marks_13 .dominator {0}=2 ∧ Marked.gameValue original marks_13 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_9 0 2 2 (by decide +kernel) row_9
theorem after_13_1 : Marked.gameValue original marks_13 .dominator {1}=1 ∧ Marked.gameValue original marks_13 .staller {1}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_3 1 1 1 (by decide +kernel) row_3
theorem after_13_2 : Marked.gameValue original marks_13 .dominator {2}=1 ∧ Marked.gameValue original marks_13 .staller {2}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_3 2 1 1 (by decide +kernel) row_3
theorem after_13_3 : Marked.gameValue original marks_13 .dominator {3}=1 ∧ Marked.gameValue original marks_13 .staller {3}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_8 3 1 2 (by decide +kernel) row_8
theorem after_13_4 : Marked.gameValue original marks_13 .dominator {4}=1 ∧ Marked.gameValue original marks_13 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_5 4 1 2 (by decide +kernel) row_5
theorem after_13_5 : Marked.gameValue original marks_13 .dominator {5}=1 ∧ Marked.gameValue original marks_13 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_7 5 1 2 (by decide +kernel) row_7
theorem after_13_6 : Marked.gameValue original marks_13 .dominator {6}=1 ∧ Marked.gameValue original marks_13 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_7 6 1 2 (by decide +kernel) row_7
theorem row_13 : Marked.gameValue original marks_13 .dominator ∅=2 ∧ Marked.gameValue original marks_13 .staller ∅=3 := by
  apply LocalProfile.DAG.bellman original marks_13 2 3 1 0 (by decide +kernel) (by decide +kernel)
  · rw [after_13_1.2]
  · rw [after_13_0.1]
  · intro v hv
    fin_cases v
    · have h := after_13_0
      change 2 ≤ 1+Marked.gameValue original marks_13 .staller {0} ∧ 1+Marked.gameValue original marks_13 .dominator {0} ≤ 3
      omega
    · have h := after_13_1
      change 2 ≤ 1+Marked.gameValue original marks_13 .staller {1} ∧ 1+Marked.gameValue original marks_13 .dominator {1} ≤ 3
      omega
    · have h := after_13_2
      change 2 ≤ 1+Marked.gameValue original marks_13 .staller {2} ∧ 1+Marked.gameValue original marks_13 .dominator {2} ≤ 3
      omega
    · have h := after_13_3
      change 2 ≤ 1+Marked.gameValue original marks_13 .staller {3} ∧ 1+Marked.gameValue original marks_13 .dominator {3} ≤ 3
      omega
    · have h := after_13_4
      change 2 ≤ 1+Marked.gameValue original marks_13 .staller {4} ∧ 1+Marked.gameValue original marks_13 .dominator {4} ≤ 3
      omega
    · have h := after_13_5
      change 2 ≤ 1+Marked.gameValue original marks_13 .staller {5} ∧ 1+Marked.gameValue original marks_13 .dominator {5} ≤ 3
      omega
    · have h := after_13_6
      change 2 ≤ 1+Marked.gameValue original marks_13 .staller {6} ∧ 1+Marked.gameValue original marks_13 .dominator {6} ≤ 3
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_13 ∅ 7) hv)
def marks_14 : Finset (Fin 8) := {5,6}
theorem after_14_0 : Marked.gameValue original marks_14 .dominator {0}=1 ∧ Marked.gameValue original marks_14 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_2 0 1 1 (by decide +kernel) row_2
theorem after_14_1 : Marked.gameValue original marks_14 .dominator {1}=1 ∧ Marked.gameValue original marks_14 .staller {1}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_4 1 1 1 (by decide +kernel) row_4
theorem after_14_2 : Marked.gameValue original marks_14 .dominator {2}=1 ∧ Marked.gameValue original marks_14 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_6 2 1 2 (by decide +kernel) row_6
theorem after_14_3 : Marked.gameValue original marks_14 .dominator {3}=1 ∧ Marked.gameValue original marks_14 .staller {3}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_10 3 1 2 (by decide +kernel) row_10
theorem after_14_4 : Marked.gameValue original marks_14 .dominator {4}=1 ∧ Marked.gameValue original marks_14 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_5 4 1 2 (by decide +kernel) row_5
theorem after_14_5 : Marked.gameValue original marks_14 .dominator {5}=1 ∧ Marked.gameValue original marks_14 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_7 5 1 2 (by decide +kernel) row_7
theorem after_14_7 : Marked.gameValue original marks_14 .dominator {7}=1 ∧ Marked.gameValue original marks_14 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_7 7 1 2 (by decide +kernel) row_7
theorem row_14 : Marked.gameValue original marks_14 .dominator ∅=2 ∧ Marked.gameValue original marks_14 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_14 2 2 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_14_0.2]
  · rw [after_14_0.1]
  · intro v hv
    fin_cases v
    · have h := after_14_0
      change 2 ≤ 1+Marked.gameValue original marks_14 .staller {0} ∧ 1+Marked.gameValue original marks_14 .dominator {0} ≤ 2
      omega
    · have h := after_14_1
      change 2 ≤ 1+Marked.gameValue original marks_14 .staller {1} ∧ 1+Marked.gameValue original marks_14 .dominator {1} ≤ 2
      omega
    · have h := after_14_2
      change 2 ≤ 1+Marked.gameValue original marks_14 .staller {2} ∧ 1+Marked.gameValue original marks_14 .dominator {2} ≤ 2
      omega
    · have h := after_14_3
      change 2 ≤ 1+Marked.gameValue original marks_14 .staller {3} ∧ 1+Marked.gameValue original marks_14 .dominator {3} ≤ 2
      omega
    · have h := after_14_4
      change 2 ≤ 1+Marked.gameValue original marks_14 .staller {4} ∧ 1+Marked.gameValue original marks_14 .dominator {4} ≤ 2
      omega
    · have h := after_14_5
      change 2 ≤ 1+Marked.gameValue original marks_14 .staller {5} ∧ 1+Marked.gameValue original marks_14 .dominator {5} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_14 ∅ 6) hv)
    · have h := after_14_7
      change 2 ≤ 1+Marked.gameValue original marks_14 .staller {7} ∧ 1+Marked.gameValue original marks_14 .dominator {7} ≤ 2
      omega
def marks_15 : Finset (Fin 8) := {2,3}
theorem after_15_0 : Marked.gameValue original marks_15 .dominator {0}=1 ∧ Marked.gameValue original marks_15 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_3 0 1 1 (by decide +kernel) row_3
theorem after_15_1 : Marked.gameValue original marks_15 .dominator {1}=1 ∧ Marked.gameValue original marks_15 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_11 1 1 2 (by decide +kernel) row_11
theorem after_15_2 : Marked.gameValue original marks_15 .dominator {2}=1 ∧ Marked.gameValue original marks_15 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_12 2 1 2 (by decide +kernel) row_12
theorem after_15_4 : Marked.gameValue original marks_15 .dominator {4}=0 ∧ Marked.gameValue original marks_15 .staller {4}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_0 4 0 0 (by decide +kernel) row_0
theorem after_15_5 : Marked.gameValue original marks_15 .dominator {5}=1 ∧ Marked.gameValue original marks_15 .staller {5}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_1 5 1 1 (by decide +kernel) row_1
theorem after_15_6 : Marked.gameValue original marks_15 .dominator {6}=1 ∧ Marked.gameValue original marks_15 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_10 6 1 2 (by decide +kernel) row_10
theorem after_15_7 : Marked.gameValue original marks_15 .dominator {7}=1 ∧ Marked.gameValue original marks_15 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_8 7 1 2 (by decide +kernel) row_8
theorem row_15 : Marked.gameValue original marks_15 .dominator ∅=1 ∧ Marked.gameValue original marks_15 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_15 1 2 4 0 (by decide +kernel) (by decide +kernel)
  · rw [after_15_4.2]
  · rw [after_15_0.1]
  · intro v hv
    fin_cases v
    · have h := after_15_0
      change 1 ≤ 1+Marked.gameValue original marks_15 .staller {0} ∧ 1+Marked.gameValue original marks_15 .dominator {0} ≤ 2
      omega
    · have h := after_15_1
      change 1 ≤ 1+Marked.gameValue original marks_15 .staller {1} ∧ 1+Marked.gameValue original marks_15 .dominator {1} ≤ 2
      omega
    · have h := after_15_2
      change 1 ≤ 1+Marked.gameValue original marks_15 .staller {2} ∧ 1+Marked.gameValue original marks_15 .dominator {2} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_15 ∅ 3) hv)
    · have h := after_15_4
      change 1 ≤ 1+Marked.gameValue original marks_15 .staller {4} ∧ 1+Marked.gameValue original marks_15 .dominator {4} ≤ 2
      omega
    · have h := after_15_5
      change 1 ≤ 1+Marked.gameValue original marks_15 .staller {5} ∧ 1+Marked.gameValue original marks_15 .dominator {5} ≤ 2
      omega
    · have h := after_15_6
      change 1 ≤ 1+Marked.gameValue original marks_15 .staller {6} ∧ 1+Marked.gameValue original marks_15 .dominator {6} ≤ 2
      omega
    · have h := after_15_7
      change 1 ≤ 1+Marked.gameValue original marks_15 .staller {7} ∧ 1+Marked.gameValue original marks_15 .dominator {7} ≤ 2
      omega
end IsolationGame.FullCanonical.T07
