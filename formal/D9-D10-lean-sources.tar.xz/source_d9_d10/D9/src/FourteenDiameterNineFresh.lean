import FourteenDiameterNineClosure

/-!
SOURCE_ONLY / NOT ELABORATED / NOT NATIVE / NOT ACCEPTED.
This candidate has no Lean result. Pending source providers are not accepted
objects. The corresponding dependency gate must open before any future build.
No slot was requested, acquired, or used in preparing this source.
-/
namespace IsolationGame.FourteenDiameterNineClosure
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

open FourteenResidual FourteenCounterexample

/-- Symbolic use of the assembled endpoint for arbitrary pattern and pools. -/
theorem fresh_all_patterns (k : Pattern) (p q : Nat) :
    isolationNumber (patternGraph k p q) ≤
      (3*Fintype.card (PatternVertex k p q)+6)/7 :=
  fourteen_ceiling_obligations k p q

theorem fresh_zero_axes (k : Pattern) (n : Nat) :
    isolationNumber (patternGraph k 0 n) ≤
      (3*Fintype.card (PatternVertex k 0 n)+6)/7 ∧
    isolationNumber (patternGraph k n 0) ≤
      (3*Fintype.card (PatternVertex k n 0)+6)/7 :=
  ⟨fourteen_ceiling_obligations k 0 n,fourteen_ceiling_obligations k n 0⟩

/-- The final application includes the actual arbitrary finite tree hypotheses. -/
theorem fresh_actual_finite_tree
    {V : Type} [Fintype V] [DecidableEq V]
    (G : SimpleGraph V) (hT : G.IsTree) (hDiam : G.diam ≤ 9) :
    isolationNumber G ≤ MinimalCeil9.ceil3n7 (Fintype.card V) :=
  diameter_nine_ordinary_ceiling G hT hDiam

#print axioms fresh_all_patterns
#print axioms fresh_zero_axes
#print axioms fresh_actual_finite_tree

end IsolationGame.FourteenDiameterNineClosure
