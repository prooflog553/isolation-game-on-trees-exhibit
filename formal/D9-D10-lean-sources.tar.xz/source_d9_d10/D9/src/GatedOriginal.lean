import GatedCorrespondence
import OriginalBridge

namespace GatedGraph
open Gated
open IsolationGame
variable {I J : Type} [Fintype I] [Fintype J] [DecidableEq I] [DecidableEq J]

instance vertexFintype : Fintype (Vertex I J) where
  elems := (Finset.univ.image Vertex.gate) ∪ (Finset.univ.image Vertex.b) ∪
    (Finset.univ.image Vertex.c) ∪ (Finset.univ.image Vertex.d)
  complete := by intro v; cases v <;> simp

def original (owner : J → I) : SimpleGraph (Vertex I J) where
  Adj := adj owner
  symm := by intro v w h; exact (graph owner).symm h
  loopless := (graph owner).loopless

 theorem original_view (owner : J → I) :
    IsolationGame.GuardedEdge.view (original owner) = graph owner := rfl

def playerTurn : IsolationGame.Player → Gated.Turn
  | .dominator => .D
  | .staller => .S

 theorem playerTurn_agree (p : IsolationGame.Player) :
    (playerTurn p).toIsolation = IsolationGame.GuardedEdge.turn p := by cases p <;> rfl

 theorem original_horizon (owner : J → I) (M X : Finset (Vertex I J))
    (s : Gated.State I J)
    (hw : ∀ v, Marked.White (original owner) M X v ↔ stateWhite owner s v)
    (n : Nat) (p : IsolationGame.Player) :
    Marked.WinsWithin (original owner) M n p X ↔
      Gated.winWithin (Gated.State.Move owner) Gated.State.P n (playerTurn p) s := by
  rw [← IsolationGame.GuardedEdge.wins_agree]
  rw [original_view, Isolation.Graph.selected_white_strategy_equivalence]
  have heq : (graph owner).noniso
      ((graph owner).raw (fun v => v ∈ M) (fun v => v ∈ X)) = stateWhite owner s := by
    funext v; apply propext
    exact (IsolationGame.GuardedEdge.white_agree (original owner) M X v).trans (hw v)
  rw [heq, ← playerTurn_agree]
  exact graph_horizon owner s n (playerTurn p)

noncomputable def marks (owner : J → I) (s : Gated.State I J) : Finset (Vertex I J) :=
  @Finset.filter _ (fun v => ¬ stateWhite owner s v) (Classical.decPred _) Finset.univ

@[simp] theorem mem_marks (owner : J → I) (s : Gated.State I J) (v : Vertex I J) :
    v ∈ marks owner s ↔ ¬ stateWhite owner s v := by simp [marks]

 theorem canonical_white (owner : J → I) (s : Gated.State I J) (v : Vertex I J) :
    Marked.White (original owner) (marks owner s) ∅ v ↔ stateWhite owner s v := by
  rw [← IsolationGame.GuardedEdge.white_agree]
  rw [original_view]
  have hr : (graph owner).raw (fun v => v ∈ marks owner s) (fun v => v ∈ (∅ : Finset (Vertex I J))) =
      stateWhite owner s := by
    funext v; apply propext; simp [Isolation.Graph.raw]
  rw [hr]
  exact white_normalized owner _ _ v

#print axioms original_horizon
#print axioms canonical_white
end GatedGraph

namespace GatedGraph
open Gated
open IsolationGame
variable {I J : Type} [Fintype I] [Fintype J] [DecidableEq I] [DecidableEq J]

/-- Exact graph-level gated-unit formula at any actual selected history whose
normalized white set has the displayed state. No forest inequality is assumed. -/
theorem marked_horizon_formula (owner : J → I) (M X : Finset (Vertex I J))
    (s : Gated.State I J)
    (hw : ∀ v, Marked.White (original owner) M X v ↔ stateWhite owner s v)
    (n : Nat) (p : IsolationGame.Player) :
    Marked.WinsWithin (original owner) M n p X ↔
      (s.counts owner).value (playerTurn p) ≤ n :=
  (original_horizon owner M X s hw n p).trans
    (Gated.state_formula owner s n (playerTurn p))

/-- The closed expression equals the archived game's least winning horizon. -/
theorem marked_value_formula (owner : J → I) (M X : Finset (Vertex I J))
    (s : Gated.State I J)
    (hw : ∀ v, Marked.White (original owner) M X v ↔ stateWhite owner s v)
    (p : IsolationGame.Player) :
    Marked.gameValue (original owner) M p X =
      (s.counts owner).value (playerTurn p) := by
  apply Nat.le_antisymm
  · exact (Marked.gameValue_le_iff (original owner) M p X _).mpr
      ((marked_horizon_formula owner M X s hw _ p).mpr (Nat.le_refl _))
  · exact (marked_horizon_formula owner M X s hw _ p).mp
      ((Marked.gameValue_le_iff (original owner) M p X _).mp (Nat.le_refl _))

 theorem canonical_value (owner : J → I) (s : Gated.State I J) (p : IsolationGame.Player) :
    Marked.gameValue (original owner) (marks owner s) p ∅ =
      (s.counts owner).value (playerTurn p) :=
  marked_value_formula owner (marks owner s) ∅ s (canonical_white owner s) p

 theorem canonical_d (owner : J → I) (s : Gated.State I J) :
    Marked.gameValue (original owner) (marks owner s) .dominator ∅ =
      s.P + s.A owner - (s.sigma owner + 1) / 2 :=
  canonical_value owner s .dominator

 theorem canonical_s (owner : J → I) (s : Gated.State I J) :
    Marked.gameValue (original owner) (marks owner s) .staller ∅ =
      s.P + s.A owner - s.sigma owner / 2 :=
  canonical_value owner s .staller

#print axioms marked_value_formula
#print axioms canonical_d
#print axioms canonical_s
end GatedGraph

namespace GatedGraph
open Gated
open IsolationGame
variable {I J : Type} [Fintype I] [Fintype J] [DecidableEq I] [DecidableEq J]

/-- Transfer the exact result to any original graph having the same actions
on the represented white set. This retains all blue vertices as move choices. -/
theorem horizon_from_white_agreement (owner : J → I) (H : SimpleGraph (Vertex I J))
    (M X : Finset (Vertex I J)) (s : Gated.State I J)
    (hw : ∀ v, Marked.White H M X v ↔ stateWhite owner s v)
    (hc : ∀ v w, stateWhite owner s w → (Closed H v w ↔ Closed (original owner) v w))
    (n : Nat) (p : IsolationGame.Player) :
    Marked.WinsWithin H M n p X ↔ (s.counts owner).value (playerTurn p) ≤ n := by
  rw [← IsolationGame.GuardedEdge.wins_agree,
    Isolation.Graph.selected_white_strategy_equivalence]
  have heq : (IsolationGame.GuardedEdge.view H).noniso
      ((IsolationGame.GuardedEdge.view H).raw (fun v => v ∈ M) (fun v => v ∈ X)) = stateWhite owner s := by
    funext v; apply propext
    exact (IsolationGame.GuardedEdge.white_agree H M X v).trans (hw v)
  rw [heq]
  have hsame : (IsolationGame.GuardedEdge.view H).AgreeOnWhite (graph owner) (stateWhite owner s) := by
    intro v w hW
    exact (IsolationGame.GuardedEdge.closed_agree H v w).trans
      ((hc v w hW).trans (IsolationGame.GuardedEdge.closed_agree (original owner) v w).symm)
  rw [(IsolationGame.GuardedEdge.view H).winsWhite_congr (graph owner) n _ _ hsame,
    ← playerTurn_agree, graph_horizon]
  exact Gated.state_formula owner s n (playerTurn p)

 theorem value_from_white_agreement (owner : J → I) (H : SimpleGraph (Vertex I J))
    (M X : Finset (Vertex I J)) (s : Gated.State I J)
    (hw : ∀ v, Marked.White H M X v ↔ stateWhite owner s v)
    (hc : ∀ v w, stateWhite owner s w → (Closed H v w ↔ Closed (original owner) v w))
    (p : IsolationGame.Player) :
    Marked.gameValue H M p X = (s.counts owner).value (playerTurn p) := by
  apply Nat.le_antisymm
  · exact (Marked.gameValue_le_iff H M p X _).mpr
      ((horizon_from_white_agreement owner H M X s hw hc _ p).mpr (Nat.le_refl _))
  · exact (horizon_from_white_agreement owner H M X s hw hc _ p).mp
      ((Marked.gameValue_le_iff H M p X _).mp (Nat.le_refl _))

/-- Arbitrary edges between gate vertices. They may retain a marked parent,
join marked group roots, or connect several marked centres. -/
def gateGraph (R : SimpleGraph I) : SimpleGraph (Vertex I J) where
  Adj v w := match v,w with
    | .gate i, .gate k => R.Adj i k
    | _,_ => False
  symm := by intro v w h; cases v <;> cases w <;> simp_all; exact h.symm
  loopless := by intro v; cases v <;> simp

def connected (owner : J → I) (R : SimpleGraph I) : SimpleGraph (Vertex I J) :=
  original owner ⊔ gateGraph R

 theorem connected_closed (owner : J → I) (R : SimpleGraph I) (s : Gated.State I J)
    (v w : Vertex I J) (hw : stateWhite owner s w) :
    Closed (connected owner R) v w ↔ Closed (original owner) v w := by
  cases w with
  | gate i => exact False.elim hw
  | b j => cases v <;> simp [Closed, connected, gateGraph]
  | c j => cases v <;> simp [Closed, connected, gateGraph]
  | d j => cases v <;> simp [Closed, connected, gateGraph]

 theorem connected_white (owner : J → I) (R : SimpleGraph I) (s : Gated.State I J)
    (v : Vertex I J) :
    Marked.White (connected owner R) (marks owner s) ∅ v ↔ stateWhite owner s v := by
  rw [← IsolationGame.GuardedEdge.white_agree]
  have hr : (IsolationGame.GuardedEdge.view (connected owner R)).raw
      (fun v => v ∈ marks owner s) (fun v => v ∈ (∅ : Finset (Vertex I J))) = stateWhite owner s := by
    funext w; apply propext; simp [Isolation.Graph.raw]
  rw [hr]
  constructor
  · exact fun h => h.1
  · intro hv
    obtain ⟨_,w,hw,ha⟩ := (white_normalized owner (fun j => j ∈ s.live)
      (fun i => i ∈ s.closed) v).mpr hv
    exact ⟨hv,w,hw,Or.inl ha⟩

/-- The formula survives any original gate-to-gate edges, with all gates
initially marked. No graph deletion or artificial change of marks is used. -/
theorem connected_value (owner : J → I) (R : SimpleGraph I)
    (s : Gated.State I J) (p : IsolationGame.Player) :
    Marked.gameValue (connected owner R) (marks owner s) p ∅ =
      (s.counts owner).value (playerTurn p) :=
  value_from_white_agreement owner (connected owner R) (marks owner s) ∅ s
    (connected_white owner R s) (connected_closed owner R s) p

#print axioms value_from_white_agreement
#print axioms connected_value
end GatedGraph
