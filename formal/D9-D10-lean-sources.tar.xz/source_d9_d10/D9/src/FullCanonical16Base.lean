import FullCanonicalDAG
namespace IsolationGame.FullCanonical.T16
abbrev original : SimpleGraph (Fin 11) := CanonicalLocal.graph CanonicalLocal.Index.t16
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
noncomputable def perm_0 : Fin 11 ≃ Fin 11 :=
  Equiv.ofBijective (fun v => ![0,1,2,3,4,5,6,7,8,9,10] v) (by decide +kernel)
theorem adjacency_0 : ∀u v,original.Adj (perm_0 u) (perm_0 v) ↔ original.Adj u v := by decide +kernel
noncomputable def perm_1 : Fin 11 ≃ Fin 11 :=
  Equiv.ofBijective (fun v => ![0,1,2,3,7,8,9,4,5,6,10] v) (by decide +kernel)
theorem adjacency_1 : ∀u v,original.Adj (perm_1 u) (perm_1 v) ↔ original.Adj u v := by decide +kernel
noncomputable def perm_2 : Fin 11 ≃ Fin 11 :=
  Equiv.ofBijective (fun v => ![0,4,5,6,1,2,3,7,8,9,10] v) (by decide +kernel)
theorem adjacency_2 : ∀u v,original.Adj (perm_2 u) (perm_2 v) ↔ original.Adj u v := by decide +kernel
noncomputable def perm_3 : Fin 11 ≃ Fin 11 :=
  Equiv.ofBijective (fun v => ![0,4,5,6,7,8,9,1,2,3,10] v) (by decide +kernel)
theorem adjacency_3 : ∀u v,original.Adj (perm_3 u) (perm_3 v) ↔ original.Adj u v := by decide +kernel
end IsolationGame.FullCanonical.T16
