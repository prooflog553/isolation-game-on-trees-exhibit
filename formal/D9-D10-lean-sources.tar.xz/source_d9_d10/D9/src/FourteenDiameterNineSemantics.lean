import FourteenDiameterNineFresh
import IsolationGame.DiameterSeven.Marked

/-! SOURCE ONLY. No elaboration, native compilation, audit, or acceptance claimed.
These fresh consumers expose actual empty marks, empty selected history, and
Dominator start. The edgeless check covers the empty and singleton carriers
without relying on any convention about whether an empty graph is a tree. -/
namespace IsolationGame.FourteenDiameterNineClosure

 theorem actual_empty_start
    {V : Type} [Fintype V] [DecidableEq V]
    (G : SimpleGraph V) (hT : G.IsTree) (hDiam : G.diam ≤ 9) :
    IsolationGame.gameValue G .dominator ∅ ≤ (3*Fintype.card V+6)/7 :=
  diameter_nine_ordinary_ceil_formula G hT hDiam

 theorem actual_empty_marks_and_history
    {V : Type} [Fintype V] [DecidableEq V]
    (G : SimpleGraph V) (hT : G.IsTree) (hDiam : G.diam ≤ 9) :
    Marked.gameValue G ∅ .dominator ∅ ≤ (3*Fintype.card V+6)/7 := by
  rw [Marked.value_empty_marks]
  exact actual_empty_start G hT hDiam

 theorem actual_strategy_bound
    {V : Type} [Fintype V] [DecidableEq V]
    (G : SimpleGraph V) (hT : G.IsTree) (hDiam : G.diam ≤ 9) :
    IsolationGame.WinsWithin G ((3*Fintype.card V+6)/7) .dominator ∅ :=
  (IsolationGame.isolationNumber_le_iff G _).mp
    (diameter_nine_ordinary_ceil_formula G hT hDiam)

 theorem fresh_all_patterns_and_zero_axes
    (k : FourteenResidual.Pattern) (p q : Nat) :
    isolationNumber (FourteenCounterexample.patternGraph k p q) ≤
      (3*Fintype.card (FourteenCounterexample.PatternVertex k p q)+6)/7 ∧
    isolationNumber (FourteenCounterexample.patternGraph k 0 q) ≤
      (3*Fintype.card (FourteenCounterexample.PatternVertex k 0 q)+6)/7 ∧
    isolationNumber (FourteenCounterexample.patternGraph k p 0) ≤
      (3*Fintype.card (FourteenCounterexample.PatternVertex k p 0)+6)/7 :=
  ⟨fourteen_ceiling_obligations k p q,
    fourteen_ceiling_obligations k 0 q, fourteen_ceiling_obligations k p 0⟩

 theorem edgeless_actual_value_zero
    {V : Type} [Fintype V] [DecidableEq V]
    (G : SimpleGraph V) (hEdges : ∀ u v, ¬ G.Adj u v) :
    isolationNumber G = 0 := by
  apply Nat.eq_zero_of_le_zero
  apply (IsolationGame.isolationNumber_le_iff G 0).mpr
  change IsolationGame.Terminal G ∅
  intro u hu
  obtain ⟨_, v, huv, _⟩ := hu
  exact hEdges u v huv

 theorem subsingleton_actual_value_zero
    {V : Type} [Fintype V] [DecidableEq V] [Subsingleton V]
    (G : SimpleGraph V) : isolationNumber G = 0 := by
  apply edgeless_actual_value_zero G
  intro u v huv
  have h : u = v := Subsingleton.elim u v
  subst v
  exact G.loopless u huv

#print axioms fourteen_ceiling_obligations
#print axioms diameter_nine_ordinary_ceil_formula
#print axioms actual_empty_start
#print axioms actual_empty_marks_and_history
#print axioms actual_strategy_bound
#print axioms fresh_all_patterns_and_zero_axes
#print axioms edgeless_actual_value_zero
#print axioms subsingleton_actual_value_zero
end IsolationGame.FourteenDiameterNineClosure
