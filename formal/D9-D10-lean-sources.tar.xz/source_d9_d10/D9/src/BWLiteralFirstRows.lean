import BWLiteralIso
import BWRightMiddleBound
namespace IsolationGame.LiteralBW
open BWCoordinates

 theorem bridge_value (p q : Nat) (X : Finset (BWBridge.Vertex p q)) (t : Player) :
    Marked.gameValue (graph p q) (marks p q) t (X.image (graphEquiv p q))=
      Marked.gameValue (BWBridge.original p q) (BWBridge.marks p q) t X := by
  have h := Marked.gameValue_relabel (BWBridge.original p q) (graph p q)
    (graphEquiv p q) (graphEquiv_adj p q) (BWBridge.marks p q) X t
  simpa [BWBridge.marks,marks,graphEquiv_left_root] using h

 theorem after_x_D_bound (p q : Nat) (hq : 1≤q) :
    Marked.gameValue (graph p q) (marks p q) .dominator {x p q}≤3*(p+q) := by
  have h := (bridge_value p q {.inl (BWBridge.root p)} .dominator).trans_le
    (BWBridge.left_center_D_bound p q hq)
  simpa only [Finset.image_singleton,graphEquiv_left_root] using h

 theorem after_y_D_bound (p q : Nat) (hp : 1≤p) (hq : 1≤q) :
    Marked.gameValue (graph p q) (marks p q) .dominator {y p q}≤3*(p+q) := by
  have h := (bridge_value p q {.inr (BWBridge.root q)} .dominator).trans_le
    (BWBridge.right_center_D_bound p q hp hq)
  simpa only [Finset.image_singleton,graphEquiv_right_root] using h

 theorem after_right_middle_D_bound (p q : Nat) (hp : 1≤p) (hq : 1≤q) (i : Fin q) :
    Marked.gameValue (graph p q) (marks p q) .dominator {node p q (Fin.natAdd p i) 0}≤3*(p+q) := by
  have h := (bridge_value p q {.inr (.gate (some i))} .dominator).trans_le
    (BWBridge.right_middle_D_bound p q hp hq i)
  have he : graphEquiv p q (.inr (.gate (some i)))=node p q (Fin.natAdd p i) 0 := rfl
  simpa only [Finset.image_singleton,he] using h

#print axioms after_x_D_bound
#print axioms after_y_D_bound
#print axioms after_right_middle_D_bound
end IsolationGame.LiteralBW
