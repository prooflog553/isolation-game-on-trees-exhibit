import FloorLocalBase
import FloorLocalRow001
set_option maxRecDepth 4096
set_option maxHeartbeats 1000000
namespace IsolationGame.FloorLocal
def marks_018 : Finset (Fin 7) := {1,2,3,5,6}
theorem normalized_018 : ∀v : Fin 7, Marked.White original_02 marks_018 ∅ v ↔ v∈({0,4} : Finset (Fin 7)) := by decide +kernel
theorem after_018_0 : Marked.gameValue original_02 marks_018 .dominator {0}=0 ∧ Marked.gameValue original_02 marks_018 .staller {0}=0 :=
  LocalProfile.DAG.transport original_02 marks_018 marks_001 0 0 0 (by decide +kernel) row_001
theorem after_018_1 : Marked.gameValue original_02 marks_018 .dominator {1}=0 ∧ Marked.gameValue original_02 marks_018 .staller {1}=0 :=
  LocalProfile.DAG.transport original_02 marks_018 marks_001 1 0 0 (by decide +kernel) row_001
theorem after_018_4 : Marked.gameValue original_02 marks_018 .dominator {4}=0 ∧ Marked.gameValue original_02 marks_018 .staller {4}=0 :=
  LocalProfile.DAG.transport original_02 marks_018 marks_001 4 0 0 (by decide +kernel) row_001
theorem after_018_5 : Marked.gameValue original_02 marks_018 .dominator {5}=0 ∧ Marked.gameValue original_02 marks_018 .staller {5}=0 :=
  LocalProfile.DAG.transport original_02 marks_018 marks_001 5 0 0 (by decide +kernel) row_001
theorem row_018 : Marked.gameValue original_02 marks_018 .dominator ∅=1 ∧ Marked.gameValue original_02 marks_018 .staller ∅=1 := by
  apply LocalProfile.DAG.bellman original_02 marks_018 1 1 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_018_0.2]
  · rw [after_018_0.1]
  · intro v hv
    fin_cases v
    · have h := after_018_0
      change 1≤1+Marked.gameValue original_02 marks_018 .staller {0} ∧ 1+Marked.gameValue original_02 marks_018 .dominator {0}≤1
      omega
    · have h := after_018_1
      change 1≤1+Marked.gameValue original_02 marks_018 .staller {1} ∧ 1+Marked.gameValue original_02 marks_018 .dominator {1}≤1
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_018 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_018 ∅ 3) hv)
    · have h := after_018_4
      change 1≤1+Marked.gameValue original_02 marks_018 .staller {4} ∧ 1+Marked.gameValue original_02 marks_018 .dominator {4}≤1
      omega
    · have h := after_018_5
      change 1≤1+Marked.gameValue original_02 marks_018 .staller {5} ∧ 1+Marked.gameValue original_02 marks_018 .dominator {5}≤1
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_018 ∅ 6) hv)
#print axioms row_018
end IsolationGame.FloorLocal
