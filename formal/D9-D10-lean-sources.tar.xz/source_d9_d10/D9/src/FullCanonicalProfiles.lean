import FullCanonical00
import FullCanonical01
import FullCanonical02
import FullCanonical03
import FullCanonical04
import FullCanonical05
import FullCanonical06
import FullCanonical07
import FullCanonical08
import FullCanonical09
import FullCanonical10
import FullCanonical11
import FullCanonical12
import FullCanonical13
import FullCanonical14
import FullCanonical15
import FullCanonical16
import FullCanonical17
import FullCanonical18
import FullCanonical19
namespace IsolationGame.CanonicalLocal
def fullD : Index → Nat
  | .t00 => 0
  | .t01 => 1
  | .t02 => 3
  | .t03 => 4
  | .t04 => 5
  | .t05 => 6
  | .t06 => 1
  | .t07 => 3
  | .t08 => 4
  | .t09 => 3
  | .t10 => 1
  | .t11 => 2
  | .t12 => 3
  | .t13 => 1
  | .t14 => 1
  | .t15 => 3
  | .t16 => 4
  | .t17 => 1
  | .t18 => 3
  | .t19 => 1
def fullS : Index → Nat
  | .t00 => 0
  | .t01 => 2
  | .t02 => 3
  | .t03 => 4
  | .t04 => 5
  | .t05 => 6
  | .t06 => 2
  | .t07 => 3
  | .t08 => 5
  | .t09 => 3
  | .t10 => 1
  | .t11 => 2
  | .t12 => 4
  | .t13 => 1
  | .t14 => 2
  | .t15 => 4
  | .t16 => 5
  | .t17 => 2
  | .t18 => 4
  | .t19 => 2
def fullPairable : Index → Bool
  | .t00 => false
  | .t01 => true
  | .t02 => false
  | .t03 => false
  | .t04 => false
  | .t05 => false
  | .t06 => true
  | .t07 => false
  | .t08 => true
  | .t09 => false
  | .t10 => false
  | .t11 => false
  | .t12 => false
  | .t13 => false
  | .t14 => false
  | .t15 => true
  | .t16 => true
  | .t17 => false
  | .t18 => true
  | .t19 => true
theorem full_D_value (t : Index) : Marked.gameValue (graph t) ∅ .dominator ∅=fullD t := by
  cases t with
  | t00 => exact FullCanonical.T00.full_values.1
  | t01 => exact FullCanonical.T01.full_values.1
  | t02 => exact FullCanonical.T02.full_values.1
  | t03 => exact FullCanonical.T03.full_values.1
  | t04 => exact FullCanonical.T04.full_values.1
  | t05 => exact FullCanonical.T05.full_values.1
  | t06 => exact FullCanonical.T06.full_values.1
  | t07 => exact FullCanonical.T07.full_values.1
  | t08 => exact FullCanonical.T08.full_values.1
  | t09 => exact FullCanonical.T09.full_values.1
  | t10 => exact FullCanonical.T10.full_values.1
  | t11 => exact FullCanonical.T11.full_values.1
  | t12 => exact FullCanonical.T12.full_values.1
  | t13 => exact FullCanonical.T13.full_values.1
  | t14 => exact FullCanonical.T14.full_values.1
  | t15 => exact FullCanonical.T15.full_values.1
  | t16 => exact FullCanonical.T16.full_values.1
  | t17 => exact FullCanonical.T17.full_values.1
  | t18 => exact FullCanonical.T18.full_values.1
  | t19 => exact FullCanonical.T19.full_values.1
theorem full_S_value (t : Index) : Marked.gameValue (graph t) ∅ .staller ∅=fullS t := by
  cases t with
  | t00 => exact FullCanonical.T00.full_values.2
  | t01 => exact FullCanonical.T01.full_values.2
  | t02 => exact FullCanonical.T02.full_values.2
  | t03 => exact FullCanonical.T03.full_values.2
  | t04 => exact FullCanonical.T04.full_values.2
  | t05 => exact FullCanonical.T05.full_values.2
  | t06 => exact FullCanonical.T06.full_values.2
  | t07 => exact FullCanonical.T07.full_values.2
  | t08 => exact FullCanonical.T08.full_values.2
  | t09 => exact FullCanonical.T09.full_values.2
  | t10 => exact FullCanonical.T10.full_values.2
  | t11 => exact FullCanonical.T11.full_values.2
  | t12 => exact FullCanonical.T12.full_values.2
  | t13 => exact FullCanonical.T13.full_values.2
  | t14 => exact FullCanonical.T14.full_values.2
  | t15 => exact FullCanonical.T15.full_values.2
  | t16 => exact FullCanonical.T16.full_values.2
  | t17 => exact FullCanonical.T17.full_values.2
  | t18 => exact FullCanonical.T18.full_values.2
  | t19 => exact FullCanonical.T19.full_values.2
theorem full_strict_exact (t : Index) : MarkedSum.StrictCapacity (graph t) ∅ ∅ (fullS t) ↔ fullPairable t=true := by
  cases t with
  | t00 =>
    constructor
    · intro h;exact False.elim (FullCanonical.T00.not_strict_full h)
    · intro h;cases h
  | t01 =>
    exact ⟨fun _=>rfl,fun _=>FullCanonical.T01.strict_full⟩
  | t02 =>
    constructor
    · intro h;exact False.elim (FullCanonical.T02.not_strict_full h)
    · intro h;cases h
  | t03 =>
    constructor
    · intro h;exact False.elim (FullCanonical.T03.not_strict_full h)
    · intro h;cases h
  | t04 =>
    constructor
    · intro h;exact False.elim (FullCanonical.T04.not_strict_full h)
    · intro h;cases h
  | t05 =>
    constructor
    · intro h;exact False.elim (FullCanonical.T05.not_strict_full h)
    · intro h;cases h
  | t06 =>
    exact ⟨fun _=>rfl,fun _=>FullCanonical.T06.strict_full⟩
  | t07 =>
    constructor
    · intro h;exact False.elim (FullCanonical.T07.not_strict_full h)
    · intro h;cases h
  | t08 =>
    exact ⟨fun _=>rfl,fun _=>FullCanonical.T08.strict_full⟩
  | t09 =>
    constructor
    · intro h;exact False.elim (FullCanonical.T09.not_strict_full h)
    · intro h;cases h
  | t10 =>
    constructor
    · intro h;exact False.elim (FullCanonical.T10.not_strict_full h)
    · intro h;cases h
  | t11 =>
    constructor
    · intro h;exact False.elim (FullCanonical.T11.not_strict_full h)
    · intro h;cases h
  | t12 =>
    constructor
    · intro h;exact False.elim (FullCanonical.T12.not_strict_full h)
    · intro h;cases h
  | t13 =>
    constructor
    · intro h;exact False.elim (FullCanonical.T13.not_strict_full h)
    · intro h;cases h
  | t14 =>
    constructor
    · intro h;exact False.elim (FullCanonical.T14.not_strict_full h)
    · intro h;cases h
  | t15 =>
    exact ⟨fun _=>rfl,fun _=>FullCanonical.T15.strict_full⟩
  | t16 =>
    exact ⟨fun _=>rfl,fun _=>FullCanonical.T16.strict_full⟩
  | t17 =>
    constructor
    · intro h;exact False.elim (FullCanonical.T17.not_strict_full h)
    · intro h;cases h
  | t18 =>
    exact ⟨fun _=>rfl,fun _=>FullCanonical.T18.strict_full⟩
  | t19 =>
    exact ⟨fun _=>rfl,fun _=>FullCanonical.T19.strict_full⟩
#print axioms full_D_value
#print axioms full_S_value
#print axioms full_strict_exact
end IsolationGame.CanonicalLocal
