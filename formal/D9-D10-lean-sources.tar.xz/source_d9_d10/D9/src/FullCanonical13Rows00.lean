import FullCanonical13Base
namespace IsolationGame.FullCanonical.T13
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_0 : Finset (Fin 2) := {0,1}
theorem row_0 : Marked.gameValue original marks_0 .dominator ∅=0 ∧ Marked.gameValue original marks_0 .staller ∅=0 := by
  constructor <;> apply (Marked.value_zero_iff_terminal _ _ _ _).mpr <;> decide +kernel
def marks_1 : Finset (Fin 2) := {}
theorem after_1_0 : Marked.gameValue original marks_1 .dominator {0}=0 ∧ Marked.gameValue original marks_1 .staller {0}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_1 marks_0 0 0 0 (by decide +kernel) row_0
theorem after_1_1 : Marked.gameValue original marks_1 .dominator {1}=0 ∧ Marked.gameValue original marks_1 .staller {1}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_1 marks_0 1 0 0 (by decide +kernel) row_0
theorem row_1 : Marked.gameValue original marks_1 .dominator ∅=1 ∧ Marked.gameValue original marks_1 .staller ∅=1 := by
  apply LocalProfile.DAG.bellman original marks_1 1 1 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_1_0.2]
  · rw [after_1_0.1]
  · intro v hv
    fin_cases v
    · have h := after_1_0
      change 1 ≤ 1+Marked.gameValue original marks_1 .staller {0} ∧ 1+Marked.gameValue original marks_1 .dominator {0} ≤ 1
      omega
    · have h := after_1_1
      change 1 ≤ 1+Marked.gameValue original marks_1 .staller {1} ∧ 1+Marked.gameValue original marks_1 .dominator {1} ≤ 1
      omega
end IsolationGame.FullCanonical.T13
