import FullCanonical08Rows07
namespace IsolationGame.FullCanonical.T08
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_32 : Finset (Fin 11) := {8,9}
theorem after_32_0 : Marked.gameValue original marks_32 .dominator {0}=2 ∧ Marked.gameValue original marks_32 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_32 marks_8 0 2 2 (by decide +kernel) row_8
theorem after_32_1 : Marked.gameValue original marks_32 .dominator {1}=2 ∧ Marked.gameValue original marks_32 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_32 marks_18 1 2 2 (by decide +kernel) row_18
theorem after_32_2 : Marked.gameValue original marks_32 .dominator {2}=2 ∧ Marked.gameValue original marks_32 .staller {2}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_32 marks_23 2 2 3 (by decide +kernel) row_23
theorem after_32_3 : Marked.gameValue original marks_32 .dominator {3}=2 ∧ Marked.gameValue original marks_32 .staller {3}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_32 marks_27 3 2 3 (by decide +kernel) row_27
theorem after_32_4 : Marked.gameValue original marks_32 .dominator {4}=2 ∧ Marked.gameValue original marks_32 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_32 marks_18 4 2 2 (by decide +kernel) row_18
theorem after_32_5 : Marked.gameValue original marks_32 .dominator {5}=2 ∧ Marked.gameValue original marks_32 .staller {5}=3 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_32 marks_23 5 2 3 (by decide +kernel) row_23
theorem after_32_6 : Marked.gameValue original marks_32 .dominator {6}=2 ∧ Marked.gameValue original marks_32 .staller {6}=3 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_32 marks_27 6 2 3 (by decide +kernel) row_27
theorem after_32_7 : Marked.gameValue original marks_32 .dominator {7}=3 ∧ Marked.gameValue original marks_32 .staller {7}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_32 marks_20 7 3 3 (by decide +kernel) row_20
theorem after_32_8 : Marked.gameValue original marks_32 .dominator {8}=3 ∧ Marked.gameValue original marks_32 .staller {8}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_32 marks_25 8 3 4 (by decide +kernel) row_25
theorem after_32_10 : Marked.gameValue original marks_32 .dominator {10}=3 ∧ Marked.gameValue original marks_32 .staller {10}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_32 marks_25 10 3 4 (by decide +kernel) row_25
theorem row_32 : Marked.gameValue original marks_32 .dominator ∅=3 ∧ Marked.gameValue original marks_32 .staller ∅=4 := by
  apply LocalProfile.DAG.bellman original marks_32 3 4 0 7 (by decide +kernel) (by decide +kernel)
  · rw [after_32_0.2]
  · rw [after_32_7.1]
  · intro v hv
    fin_cases v
    · have h := after_32_0
      change 3 ≤ 1+Marked.gameValue original marks_32 .staller {0} ∧ 1+Marked.gameValue original marks_32 .dominator {0} ≤ 4
      omega
    · have h := after_32_1
      change 3 ≤ 1+Marked.gameValue original marks_32 .staller {1} ∧ 1+Marked.gameValue original marks_32 .dominator {1} ≤ 4
      omega
    · have h := after_32_2
      change 3 ≤ 1+Marked.gameValue original marks_32 .staller {2} ∧ 1+Marked.gameValue original marks_32 .dominator {2} ≤ 4
      omega
    · have h := after_32_3
      change 3 ≤ 1+Marked.gameValue original marks_32 .staller {3} ∧ 1+Marked.gameValue original marks_32 .dominator {3} ≤ 4
      omega
    · have h := after_32_4
      change 3 ≤ 1+Marked.gameValue original marks_32 .staller {4} ∧ 1+Marked.gameValue original marks_32 .dominator {4} ≤ 4
      omega
    · have h := after_32_5
      change 3 ≤ 1+Marked.gameValue original marks_32 .staller {5} ∧ 1+Marked.gameValue original marks_32 .dominator {5} ≤ 4
      omega
    · have h := after_32_6
      change 3 ≤ 1+Marked.gameValue original marks_32 .staller {6} ∧ 1+Marked.gameValue original marks_32 .dominator {6} ≤ 4
      omega
    · have h := after_32_7
      change 3 ≤ 1+Marked.gameValue original marks_32 .staller {7} ∧ 1+Marked.gameValue original marks_32 .dominator {7} ≤ 4
      omega
    · have h := after_32_8
      change 3 ≤ 1+Marked.gameValue original marks_32 .staller {8} ∧ 1+Marked.gameValue original marks_32 .dominator {8} ≤ 4
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_32 ∅ 9) hv)
    · have h := after_32_10
      change 3 ≤ 1+Marked.gameValue original marks_32 .staller {10} ∧ 1+Marked.gameValue original marks_32 .dominator {10} ≤ 4
      omega
def marks_33 : Finset (Fin 11) := {2,3}
theorem after_33_0 : Marked.gameValue original marks_33 .dominator {0}=2 ∧ Marked.gameValue original marks_33 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_33 marks_11 0 2 2 (by decide +kernel) row_11
theorem after_33_1 : Marked.gameValue original marks_33 .dominator {1}=3 ∧ Marked.gameValue original marks_33 .staller {1}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_33 marks_29 1 3 3 (by decide +kernel) row_29
theorem after_33_2 : Marked.gameValue original marks_33 .dominator {2}=3 ∧ Marked.gameValue original marks_33 .staller {2}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_33 marks_30 2 3 4 (by decide +kernel) row_30
theorem after_33_4 : Marked.gameValue original marks_33 .dominator {4}=1 ∧ Marked.gameValue original marks_33 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_33 marks_13 4 1 2 (by decide +kernel) row_13
theorem after_33_5 : Marked.gameValue original marks_33 .dominator {5}=1 ∧ Marked.gameValue original marks_33 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_33 marks_24 5 1 2 (by decide +kernel) row_24
theorem after_33_6 : Marked.gameValue original marks_33 .dominator {6}=1 ∧ Marked.gameValue original marks_33 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_33 marks_28 6 1 2 (by decide +kernel) row_28
theorem after_33_7 : Marked.gameValue original marks_33 .dominator {7}=1 ∧ Marked.gameValue original marks_33 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_33 marks_6 7 1 2 (by decide +kernel) row_6
theorem after_33_8 : Marked.gameValue original marks_33 .dominator {8}=1 ∧ Marked.gameValue original marks_33 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_33 marks_14 8 1 2 (by decide +kernel) row_14
theorem after_33_9 : Marked.gameValue original marks_33 .dominator {9}=2 ∧ Marked.gameValue original marks_33 .staller {9}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_33 marks_27 9 2 3 (by decide +kernel) row_27
theorem after_33_10 : Marked.gameValue original marks_33 .dominator {10}=2 ∧ Marked.gameValue original marks_33 .staller {10}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_33 marks_26 10 2 3 (by decide +kernel) row_26
theorem row_33 : Marked.gameValue original marks_33 .dominator ∅=3 ∧ Marked.gameValue original marks_33 .staller ∅=4 := by
  apply LocalProfile.DAG.bellman original marks_33 3 4 0 1 (by decide +kernel) (by decide +kernel)
  · rw [after_33_0.2]
  · rw [after_33_1.1]
  · intro v hv
    fin_cases v
    · have h := after_33_0
      change 3 ≤ 1+Marked.gameValue original marks_33 .staller {0} ∧ 1+Marked.gameValue original marks_33 .dominator {0} ≤ 4
      omega
    · have h := after_33_1
      change 3 ≤ 1+Marked.gameValue original marks_33 .staller {1} ∧ 1+Marked.gameValue original marks_33 .dominator {1} ≤ 4
      omega
    · have h := after_33_2
      change 3 ≤ 1+Marked.gameValue original marks_33 .staller {2} ∧ 1+Marked.gameValue original marks_33 .dominator {2} ≤ 4
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_33 ∅ 3) hv)
    · have h := after_33_4
      change 3 ≤ 1+Marked.gameValue original marks_33 .staller {4} ∧ 1+Marked.gameValue original marks_33 .dominator {4} ≤ 4
      omega
    · have h := after_33_5
      change 3 ≤ 1+Marked.gameValue original marks_33 .staller {5} ∧ 1+Marked.gameValue original marks_33 .dominator {5} ≤ 4
      omega
    · have h := after_33_6
      change 3 ≤ 1+Marked.gameValue original marks_33 .staller {6} ∧ 1+Marked.gameValue original marks_33 .dominator {6} ≤ 4
      omega
    · have h := after_33_7
      change 3 ≤ 1+Marked.gameValue original marks_33 .staller {7} ∧ 1+Marked.gameValue original marks_33 .dominator {7} ≤ 4
      omega
    · have h := after_33_8
      change 3 ≤ 1+Marked.gameValue original marks_33 .staller {8} ∧ 1+Marked.gameValue original marks_33 .dominator {8} ≤ 4
      omega
    · have h := after_33_9
      change 3 ≤ 1+Marked.gameValue original marks_33 .staller {9} ∧ 1+Marked.gameValue original marks_33 .dominator {9} ≤ 4
      omega
    · have h := after_33_10
      change 3 ≤ 1+Marked.gameValue original marks_33 .staller {10} ∧ 1+Marked.gameValue original marks_33 .dominator {10} ≤ 4
      omega
def marks_34 : Finset (Fin 11) := {}
theorem after_34_0 : Marked.gameValue original marks_34 .dominator {0}=3 ∧ Marked.gameValue original marks_34 .staller {0}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_34 marks_21 0 3 3 (by decide +kernel) row_21
theorem after_34_1 : Marked.gameValue original marks_34 .dominator {1}=3 ∧ Marked.gameValue original marks_34 .staller {1}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_34 marks_29 1 3 3 (by decide +kernel) row_29
theorem after_34_2 : Marked.gameValue original marks_34 .dominator {2}=3 ∧ Marked.gameValue original marks_34 .staller {2}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_34 marks_30 2 3 4 (by decide +kernel) row_30
theorem after_34_3 : Marked.gameValue original marks_34 .dominator {3}=3 ∧ Marked.gameValue original marks_34 .staller {3}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_34 marks_33 3 3 4 (by decide +kernel) row_33
theorem after_34_4 : Marked.gameValue original marks_34 .dominator {4}=3 ∧ Marked.gameValue original marks_34 .staller {4}=3 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_34 marks_29 4 3 3 (by decide +kernel) row_29
theorem after_34_5 : Marked.gameValue original marks_34 .dominator {5}=3 ∧ Marked.gameValue original marks_34 .staller {5}=4 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_34 marks_30 5 3 4 (by decide +kernel) row_30
theorem after_34_6 : Marked.gameValue original marks_34 .dominator {6}=3 ∧ Marked.gameValue original marks_34 .staller {6}=4 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_34 marks_33 6 3 4 (by decide +kernel) row_33
theorem after_34_7 : Marked.gameValue original marks_34 .dominator {7}=3 ∧ Marked.gameValue original marks_34 .staller {7}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_34 marks_20 7 3 3 (by decide +kernel) row_20
theorem after_34_8 : Marked.gameValue original marks_34 .dominator {8}=3 ∧ Marked.gameValue original marks_34 .staller {8}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_34 marks_25 8 3 4 (by decide +kernel) row_25
theorem after_34_9 : Marked.gameValue original marks_34 .dominator {9}=3 ∧ Marked.gameValue original marks_34 .staller {9}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_34 marks_32 9 3 4 (by decide +kernel) row_32
theorem after_34_10 : Marked.gameValue original marks_34 .dominator {10}=4 ∧ Marked.gameValue original marks_34 .staller {10}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_34 marks_31 10 4 4 (by decide +kernel) row_31
theorem row_34 : Marked.gameValue original marks_34 .dominator ∅=4 ∧ Marked.gameValue original marks_34 .staller ∅=5 := by
  apply LocalProfile.DAG.bellman original marks_34 4 5 0 10 (by decide +kernel) (by decide +kernel)
  · rw [after_34_0.2]
  · rw [after_34_10.1]
  · intro v hv
    fin_cases v
    · have h := after_34_0
      change 4 ≤ 1+Marked.gameValue original marks_34 .staller {0} ∧ 1+Marked.gameValue original marks_34 .dominator {0} ≤ 5
      omega
    · have h := after_34_1
      change 4 ≤ 1+Marked.gameValue original marks_34 .staller {1} ∧ 1+Marked.gameValue original marks_34 .dominator {1} ≤ 5
      omega
    · have h := after_34_2
      change 4 ≤ 1+Marked.gameValue original marks_34 .staller {2} ∧ 1+Marked.gameValue original marks_34 .dominator {2} ≤ 5
      omega
    · have h := after_34_3
      change 4 ≤ 1+Marked.gameValue original marks_34 .staller {3} ∧ 1+Marked.gameValue original marks_34 .dominator {3} ≤ 5
      omega
    · have h := after_34_4
      change 4 ≤ 1+Marked.gameValue original marks_34 .staller {4} ∧ 1+Marked.gameValue original marks_34 .dominator {4} ≤ 5
      omega
    · have h := after_34_5
      change 4 ≤ 1+Marked.gameValue original marks_34 .staller {5} ∧ 1+Marked.gameValue original marks_34 .dominator {5} ≤ 5
      omega
    · have h := after_34_6
      change 4 ≤ 1+Marked.gameValue original marks_34 .staller {6} ∧ 1+Marked.gameValue original marks_34 .dominator {6} ≤ 5
      omega
    · have h := after_34_7
      change 4 ≤ 1+Marked.gameValue original marks_34 .staller {7} ∧ 1+Marked.gameValue original marks_34 .dominator {7} ≤ 5
      omega
    · have h := after_34_8
      change 4 ≤ 1+Marked.gameValue original marks_34 .staller {8} ∧ 1+Marked.gameValue original marks_34 .dominator {8} ≤ 5
      omega
    · have h := after_34_9
      change 4 ≤ 1+Marked.gameValue original marks_34 .staller {9} ∧ 1+Marked.gameValue original marks_34 .dominator {9} ≤ 5
      omega
    · have h := after_34_10
      change 4 ≤ 1+Marked.gameValue original marks_34 .staller {10} ∧ 1+Marked.gameValue original marks_34 .dominator {10} ≤ 5
      omega
end IsolationGame.FullCanonical.T08
