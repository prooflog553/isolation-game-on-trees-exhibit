import PartitionBridge
import PendantRemoval
import StrictCompanionPairing

namespace IsolationGame.DisconnectedPartition
open PartitionBridge
variable {V : Type} [Fintype V] [DecidableEq V]

def NoCross (G : SimpleGraph V) (A : Finset V) : Prop :=
  ∀u v,u∈A→v∉A→¬G.Adj u v

theorem adjacency_split (G : SimpleGraph V) (A : Finset V) (h : NoCross G A) (u v : V) :
    (MarkedSum.original (IsolatedRestriction.induced G A) (IsolatedRestriction.induced G (outside A))).Adj
      (splitEquiv A u) (splitEquiv A v) ↔ G.Adj u v := by
  by_cases hu : u∈A <;> by_cases hv : v∈A
  · rw [split_left A u hu,split_left A v hv]
    rfl
  · rw [split_left A u hu,split_right A v hv]
    change False ↔ G.Adj u v
    exact iff_of_false id (h u v hu hv)
  · rw [split_right A u hu,split_left A v hv]
    change False ↔ G.Adj u v
    exact iff_of_false id (fun ha=>h v u hv hu ha.symm)
  · rw [split_right A u hu,split_right A v hv]
    rfl

/-- Exact genuine-disjoint decomposition of an original graph with no cross
edges. All initial marks and selected labels are inherited on both sides. -/
theorem gameValue_split (G : SimpleGraph V) (A : Finset V) (h : NoCross G A)
    (M X : Finset V) (p : Player) :
    Marked.gameValue G M p X=
      Marked.gameValue (MarkedSum.original (IsolatedRestriction.induced G A)
        (IsolatedRestriction.induced G (outside A)))
        (MarkedSum.combine (IsolatedRestriction.restrict A M) (IsolatedRestriction.restrict (outside A) M)) p
        (MarkedSum.combine (IsolatedRestriction.restrict A X) (IsolatedRestriction.restrict (outside A) X)) := by
  have hh := Marked.gameValue_relabel G _ (splitEquiv A) (adjacency_split G A h) M X p
  rw [image_marks,image_marks] at hh
  exact hh.symm

theorem forest_s_upper (G : SimpleGraph V) (hG : G.IsAcyclic)
    (A : Finset V) (h : NoCross G A) (M X : Finset V) :
    Marked.gameValue G M .staller X≤
      Marked.gameValue (IsolatedRestriction.induced G A) (IsolatedRestriction.restrict A M)
        .staller (IsolatedRestriction.restrict A X)+
      Marked.gameValue (IsolatedRestriction.induced G (outside A)) (IsolatedRestriction.restrict (outside A) M)
        .staller (IsolatedRestriction.restrict (outside A) X) := by
  rw [gameValue_split G A h]
  exact (MarkedSum.forest_sum_bounds _ _ (induced_acyclic G hG A) (induced_acyclic G hG (outside A)) _ _ _ _).2.2

theorem forest_strict_pair (G : SimpleGraph V) (hG : G.IsAcyclic)
    (A : Finset V) (h : NoCross G A) (M X : Finset V) (c d : Nat)
    (hc : MarkedSum.StrictCapacity (IsolatedRestriction.induced G A)
      (IsolatedRestriction.restrict A M) (IsolatedRestriction.restrict A X) c)
    (hd : MarkedSum.StrictCapacity (IsolatedRestriction.induced G (outside A))
      (IsolatedRestriction.restrict (outside A) M) (IsolatedRestriction.restrict (outside A) X) d) :
    Marked.gameValue G M .staller X≤c+d-1 := by
  rw [gameValue_split G A h]
  exact MarkedSum.forest_strict_pair _ _ (induced_acyclic G hG A) (induced_acyclic G hG (outside A)) _ _ _ _ c d hc hd

#print axioms gameValue_split
#print axioms forest_s_upper
#print axioms forest_strict_pair
end IsolationGame.DisconnectedPartition
