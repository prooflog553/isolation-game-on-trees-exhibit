import CenterT08ReceiverFixedRows
import TwoPoolStrongInduction

/-! Fresh all-Nat one-pool receiver bound from all twelve independently
proved fixed rows. The unused second pool is literally Fin 0, not a
quantified spare pool. This file does not assert recovery of the old source. -/

namespace IsolationGame.CenterT08Receiver
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

/-- All ordinary P7 copy counts, including zero. -/
theorem S_upper (p : Nat) :
    Marked.gameValue (graph p) (marks p) .staller ∅ ≤ 3*p+5 := by
  induction p using Nat.strong_induction_on with
  | h p hin =>
    have hf (v : Vertex p) :
        1+Marked.gameValue (graph p) (marks p) .dominator {v} ≤ 3*p+5 := by
      rcases TwoPool.vertex_exhaustion p 0 v with
        ⟨a,rfl⟩ | ⟨i,r,rfl⟩ | ⟨i,r,rfl⟩
      · exact fixed_paid_bound p a
      · cases p with
        | zero => exact Fin.elim0 i
        | succ p =>
          have hc := TwoPool.ordinaryLeft_first_bound fixedGraph fixed_tree.IsAcyclic
            0 0 ({0} : Finset Fixed) p 0 i r
          have hs := hin p (by omega)
          change 1+Marked.gameValue (graph (p+1)) (marks (p+1)) .dominator
            {ordinary (p+1) i r} ≤
              3+Marked.gameValue (graph p) (marks p) .staller ∅ at hc
          change 1+Marked.gameValue (graph (p+1)) (marks (p+1)) .dominator
            {ordinary (p+1) i r} ≤ 3*(p+1)+5
          omega
      · exact Fin.elim0 i
    apply (Marked.gameValue_le_iff _ _ _ _ _).mpr
    apply Or.inr
    intro v _
    apply (Marked.gameValue_le_iff _ _ .dominator (insert v ∅) (3*p+4)).mp
    have hh := hf v
    simpa only [Finset.insert_empty] using (by omega :
      Marked.gameValue (graph p) (marks p) .dominator {v} ≤ 3*p+4)

theorem D_upper (p : Nat) :
    Marked.gameValue (graph p) (marks p) .dominator ∅ ≤ 3*p+5 := by
  exact (Marked.forest_no_minus (graph p) (graph_acyclic p) (marks p) ∅).trans
    (S_upper p)

theorem all_first_bound (p : Nat) (v : Vertex p) :
    1+Marked.gameValue (graph p) (marks p) .dominator {v} ≤ 3*p+5 := by
  rcases TwoPool.vertex_exhaustion p 0 v with
    ⟨a,rfl⟩ | ⟨i,r,rfl⟩ | ⟨i,r,rfl⟩
  · exact fixed_paid_bound p a
  · cases p with
    | zero => exact Fin.elim0 i
    | succ p =>
      have hc := TwoPool.ordinaryLeft_first_bound fixedGraph fixed_tree.IsAcyclic
        0 0 ({0} : Finset Fixed) p 0 i r
      have hs := S_upper p
      change 1+Marked.gameValue (graph (p+1)) (marks (p+1)) .dominator
        {ordinary (p+1) i r} ≤
          3+Marked.gameValue (graph p) (marks p) .staller ∅ at hc
      change 1+Marked.gameValue (graph (p+1)) (marks (p+1)) .dominator
        {ordinary (p+1) i r} ≤ 3*(p+1)+5
      omega
  · exact Fin.elim0 i

#print axioms S_upper
#print axioms D_upper
#print axioms all_first_bound
end IsolationGame.CenterT08Receiver
