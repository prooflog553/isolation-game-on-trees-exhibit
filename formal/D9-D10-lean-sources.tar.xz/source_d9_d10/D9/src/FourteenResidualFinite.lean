import FourteenResidualCheck00
import FourteenResidualCheck01
import FourteenResidualCheck02
import FourteenResidualCheck03
import FourteenResidualCheck04
import FourteenResidualCheck05
import FourteenResidualCheck06
import FourteenResidualCheck07
import FourteenResidualCheck08
import FourteenResidualCheck09
import FourteenResidualCheck10
import FourteenResidualCheck11
import FourteenResidualCheck12
import FourteenResidualCheck13
import FourteenResidualCheck14
import FourteenResidualCheck15
import FourteenResidualCheck16
import FourteenResidualCheck17
import FourteenResidualCheck18
import FourteenResidualCheck19

/-! These two theorems combine all twenty constructor cases. The list classifier
will invoke them only after its independent length/nonempty decomposition. -/
namespace IsolationGame.FourteenResidual
open CanonicalLocal

theorem classify11 (a b : Index) :
    NumericResidual [a] [b] → MatchesFourteen [a] [b] := by
  cases a
  · exact check11_t00 b
  · exact check11_t01 b
  · exact check11_t02 b
  · exact check11_t03 b
  · exact check11_t04 b
  · exact check11_t05 b
  · exact check11_t06 b
  · exact check11_t07 b
  · exact check11_t08 b
  · exact check11_t09 b
  · exact check11_t10 b
  · exact check11_t11 b
  · exact check11_t12 b
  · exact check11_t13 b
  · exact check11_t14 b
  · exact check11_t15 b
  · exact check11_t16 b
  · exact check11_t17 b
  · exact check11_t18 b
  · exact check11_t19 b

theorem classify12 (a b c : Index) :
    NumericResidual [a] [b, c] → MatchesFourteen [a] [b, c] := by
  cases a
  · exact check12_t00 b c
  · exact check12_t01 b c
  · exact check12_t02 b c
  · exact check12_t03 b c
  · exact check12_t04 b c
  · exact check12_t05 b c
  · exact check12_t06 b c
  · exact check12_t07 b c
  · exact check12_t08 b c
  · exact check12_t09 b c
  · exact check12_t10 b c
  · exact check12_t11 b c
  · exact check12_t12 b c
  · exact check12_t13 b c
  · exact check12_t14 b c
  · exact check12_t15 b c
  · exact check12_t16 b c
  · exact check12_t17 b c
  · exact check12_t18 b c
  · exact check12_t19 b c

#print axioms classify11
#print axioms classify12
end IsolationGame.FourteenResidual
