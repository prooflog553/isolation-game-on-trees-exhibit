import RootedProfileTransport

namespace IsolationGame.NecessaryCore
open CanonicalLocal ActualRootBranches
variable {V : Type} [Fintype V] [DecidableEq V]

noncomputable def branchType (G : SimpleGraph V) (hT : G.IsTree)
    (r : V) (hR : ∀v,G.dist r v≤4) (hSmall : RootedReduction.SmallerFloor (Fintype.card V))
    (hCounter : 3*Fintype.card V/7<Marked.gameValue G {r} .dominator ∅) (a : Child G r) : Index :=
  Classical.choose (minimal_outer_profile G hT r hR hSmall hCounter a)

theorem branch_type_facts (G : SimpleGraph V) (hT : G.IsTree)
    (r : V) (hR : ∀v,G.dist r v≤4) (hSmall : RootedReduction.SmallerFloor (Fintype.card V))
    (hCounter : 3*Fintype.card V/7<Marked.gameValue G {r} .dominator ∅) (a : Child G r) :
    let t := branchType G hT r hR hSmall hCounter a
    t≠.t00 ∧ (piece G r a).card=size t ∧ capacity G r a=expectedS t ∧
      (IsStrict G r a ↔ pairable t=true) := by
  have h := Classical.choose_spec (minimal_outer_profile G hT r hR hSmall hCounter a)
  exact ⟨h.1,h.2.1,h.2.2.1,h.2.2.2.2⟩

/-- Every supplied local label is certified from the actual original
branch. Its defect is therefore the actual capacity/order defect. -/
theorem branch_defect (G : SimpleGraph V) (hT : G.IsTree)
    (r : V) (hR : ∀v,G.dist r v≤4) (hSmall : RootedReduction.SmallerFloor (Fintype.card V))
    (hCounter : 3*Fintype.card V/7<Marked.gameValue G {r} .dominator ∅) (a : Child G r) :
    defect (branchType G hT r hR hSmall hCounter a)=7*(capacity G r a : Int)-3*((piece G r a).card : Int) := by
  have h := branch_type_facts G hT r hR hSmall hCounter a
  rw [defect,←h.2.1,←h.2.2.1]

#print axioms branch_type_facts
#print axioms branch_defect
end IsolationGame.NecessaryCore
