import DisjointCompanion
import PairableProfileSelectedBudget
import GeneralP4PureTransport
import GenericCoreReceiverBound

namespace IsolationGame.CoreCompanionPartition
open CanonicalLocal CoreFamily CoreFamilySemantics AllProfileCore PairableProfileCore
  IsolatedRestriction FiniteForestComponents
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

abbrev N (xs : List Nat) (q : Nat) := Fin (xs.length+q)
noncomputable abbrev P (xs : List Nat) (q : Nat) := SelectedVertex.playedMarks (CoreFamily.graph xs q) ∅ none
abbrev flat (xs : List Nat) (q : Nat) := MarkedBoundary.isolateVertex (CoreFamily.graph xs q) none

noncomputable def part (xs : List Nat) (q : Nat) : Option (N xs q) → Finset (CoreFamily.Vertex xs q)
  | none => {none}
  | some i => Finset.univ.filter (fun v=>∃u,v=some ⟨i,u⟩)

def cap (xs : List Nat) (q : Nat) : Option (N xs q) → Nat
  | none=>0
  | some i=>expectedS (label xs q i)

noncomputable def strictParts (xs : List Nat) (q : Nat) : Finset (Option (N xs q)) :=
  (pairIndices xs q).image some

@[simp] theorem mem_part_some (xs : List Nat) (q : Nat) (i : N xs q) (v : CoreFamily.Vertex xs q) :
    v∈part xs q (some i) ↔ ∃u,v=some ⟨i,u⟩ := by simp [part]

theorem played_none (xs : List Nat) (q : Nat) : none ∈ P xs q := by
  simp [P,SelectedVertex.mem_playedMarks,Closed]

theorem played_local (xs : List Nat) (q : Nat) (i : N xs q) (u : Fin (size (label xs q i))) :
    some ⟨i,u⟩ ∈ P xs q ↔ u=root (label xs q i) := by
  simp [P,SelectedVertex.mem_playedMarks,Closed,root_adj]

def embed (xs : List Nat) (q : Nat) (i : N xs q) (u : Fin (size (label xs q i))) :
    Active (part xs q (some i)) := ⟨some ⟨i,u⟩,(mem_part_some xs q i _).mpr ⟨u,rfl⟩⟩

theorem embed_bijective (xs : List Nat) (q : Nat) (i : N xs q) :
    Function.Bijective (embed xs q i) := by
  constructor
  · intro u v h
    have hs := Option.some.inj (congrArg Subtype.val h)
    exact eq_of_heq (Sigma.mk.inj_iff.mp hs).2
  · intro v
    obtain ⟨u,hu⟩ := (mem_part_some xs q i v.val).mp v.property
    exact ⟨u,Subtype.ext hu.symm⟩

noncomputable def localEquiv (xs : List Nat) (q : Nat) (i : N xs q) :
    Fin (size (label xs q i)) ≃ Active (part xs q (some i)) :=
  Equiv.ofBijective (embed xs q i) (embed_bijective xs q i)

theorem local_adj (xs : List Nat) (q : Nat) (i : N xs q) (u v : Fin (size (label xs q i))) :
    (induced (flat xs q) (part xs q (some i))).Adj
      (localEquiv xs q i u) (localEquiv xs q i v) ↔ (CanonicalLocal.graph (label xs q i)).Adj u v := by
  change ((CoreFamily.graph xs q).Adj (some ⟨i,u⟩) (some ⟨i,v⟩) ∧
    (some ⟨i,u⟩ : CoreFamily.Vertex xs q)≠none ∧ (some ⟨i,v⟩ : CoreFamily.Vertex xs q)≠none) ↔ _
  simp [same_adj,localEquiv,embed]

theorem local_marks (xs : List Nat) (q : Nat) (i : N xs q) :
    ({root (label xs q i)} : Finset _).image (localEquiv xs q i) =
      restrict (part xs q (some i)) (P xs q) := by
  classical
  ext v
  obtain ⟨u,rfl⟩ := (localEquiv xs q i).surjective v
  simp only [Finset.mem_image,(localEquiv xs q i).injective.eq_iff,exists_eq_right,
    Finset.mem_singleton,mem_restrict]
  exact (played_local xs q i u).symm

theorem local_value (xs : List Nat) (q : Nat) (i : N xs q) (t : Player) :
    valueOn (flat xs q) (part xs q (some i)) (P xs q) ∅ t =
      Marked.gameValue (CanonicalLocal.graph (label xs q i)) {root (label xs q i)} t ∅ := by
  have h := Marked.gameValue_relabel (CanonicalLocal.graph (label xs q i))
    (induced (flat xs q) (part xs q (some i))) (localEquiv xs q i) (local_adj xs q i)
    {root (label xs q i)} ∅ t
  simpa only [valueOn,local_marks,Finset.image_empty,show restrict (part xs q (some i)) ∅=∅ by ext v;simp] using h

theorem local_strict (xs : List Nat) (q : Nat) (i : N xs q) (hi : i∈pairIndices xs q) :
    MarkedSum.StrictCapacity (induced (flat xs q) (part xs q (some i)))
      (restrict (part xs q (some i)) (P xs q)) (restrict (part xs q (some i)) ∅)
      (expectedS (label xs q i)) := by
  have hs := (CanonicalLocal.strict_exact (label xs q i)).mpr (Finset.mem_filter.mp hi).2
  have h := MarkedSum.strict_relabel (CanonicalLocal.graph (label xs q i))
    (induced (flat xs q) (part xs q (some i))) (localEquiv xs q i) (local_adj xs q i)
    {root (label xs q i)} ∅ (expectedS (label xs q i)) hs
  simpa only [valueOn,local_marks,Finset.image_empty,show restrict (part xs q (some i)) ∅=∅ by ext v;simp] using h

theorem parts_cover (xs : List Nat) (q : Nat) : Finset.univ.biUnion (part xs q)=Finset.univ := by
  classical
  ext v
  simp only [Finset.mem_biUnion,Finset.mem_univ,true_and,iff_true]
  cases v with
  | none => exact ⟨none,by simp [part]⟩
  | some v => obtain ⟨i,u⟩ := v;exact ⟨some i,(mem_part_some xs q i _).mpr ⟨u,rfl⟩⟩

theorem parts_disjoint (xs : List Nat) (q : Nat) (i j : Option (N xs q)) (hij : i≠j) :
    Disjoint (part xs q i) (part xs q j) := by
  classical
  apply Finset.disjoint_left.mpr
  intro v hi hj
  cases i with
  | none =>
    have hv : v=none := Finset.mem_singleton.mp hi
    subst v
    cases j with
    | none => exact hij rfl
    | some j => obtain ⟨u,hu⟩ := (mem_part_some xs q j none).mp hj;cases hu
  | some i =>
    obtain ⟨u,rfl⟩ := (mem_part_some xs q i v).mp hi
    cases j with
    | none => have h := Finset.mem_singleton.mp hj;cases h
    | some j =>
      obtain ⟨w,hw⟩ := (mem_part_some xs q j _).mp hj
      have he := (Sigma.mk.inj_iff.mp (Option.some.inj hw)).1
      exact hij (congrArg some he)

theorem parts_no_cross (xs : List Nat) (q : Nat) (i j : Option (N xs q)) (hij : i≠j)
    (u : CoreFamily.Vertex xs q) (hu : u∈part xs q i)
    (v : CoreFamily.Vertex xs q) (hv : v∈part xs q j) : ¬(flat xs q).Adj u v := by
  cases i with
  | none => have he : u=none := Finset.mem_singleton.mp hu;subst u;exact fun h=>h.2.1 rfl
  | some i =>
    obtain ⟨a,rfl⟩ := (mem_part_some xs q i u).mp hu
    cases j with
    | none => have he : v=none := Finset.mem_singleton.mp hv;subst v;exact fun h=>h.2.2 rfl
    | some j =>
      obtain ⟨b,rfl⟩ := (mem_part_some xs q j v).mp hv
      exact fun h=>distinct_no_adj xs q i j (by intro h;exact hij (congrArg some h)) a b h.1

theorem parts_S (xs : List Nat) (q : Nat) (i : Option (N xs q)) :
    valueOn (flat xs q) (part xs q i) (P xs q) ∅ .staller ≤ cap xs q i := by
  cases i with
  | none =>
    apply le_of_eq
    apply (Marked.value_zero_iff_terminal _ _ _ _).mpr
    intro v hv
    apply hv.1.1
    rw [mem_restrict]
    have he : v.val=none := Finset.mem_singleton.mp v.property
    rw [he]
    exact played_none xs q
  | some i => rw [local_value];exact (CanonicalLocal.S_value (label xs q i)).le

theorem parts_strict (xs : List Nat) (q : Nat) (i : Option (N xs q)) (hi : i∈strictParts xs q) :
    MarkedSum.StrictCapacity (induced (flat xs q) (part xs q i))
      (restrict (part xs q i) (P xs q)) (restrict (part xs q i) ∅) (cap xs q i) := by
  obtain ⟨j,hj,rfl⟩ := Finset.mem_image.mp hi
  exact local_strict xs q j hj

theorem strict_card (xs : List Nat) (q : Nat) : (strictParts xs q).card=pairCount xs := by
  rw [strictParts,Finset.card_image_of_injective _ (Option.some_injective _),pairIndices_card]

theorem cap_sum (xs : List Nat) (q : Nat) : (∑i,cap xs q i)=3*q+cost xs := by
  classical
  rw [Fintype.sum_option]
  change 0+(∑i,expectedS (label xs q i))=3*q+cost xs
  rw [AllProfileCore.sum_label]
  simp [cost,expectedS,Nat.mul_comm,Nat.add_comm]

/-- Erase only edges whose two endpoints are genuinely marked. The full
original carrier, marks, and arbitrary selected history remain unchanged. -/
theorem flat_sum_value {U : Type} [Fintype U] [DecidableEq U]
    (xs : List Nat) (q : Nat) (H : SimpleGraph U) (M : Finset U)
    (X : Finset (CoreFamily.Vertex xs q ⊕ U)) (t : Player) :
    Marked.gameValue (MarkedSum.original (CoreFamily.graph xs q) H)
      (MarkedSum.combine (P xs q) M) t X =
    Marked.gameValue (MarkedSum.original (flat xs q) H)
      (MarkedSum.combine (P xs q) M) t X := by
  apply Marked.value_eq_of_adj_agree_unmarked
  intro u v hv
  cases u with
  | inr u => cases v <;> rfl
  | inl u => cases v with
    | inr v => rfl
    | inl v =>
      have hvm : v∉P xs q := fun h=>hv ((MarkedSum.combine_inl _ _ _).mpr h)
      change (CoreFamily.graph xs q).Adj u v ↔ (CoreFamily.graph xs q).Adj u v ∧ u≠none ∧ v≠none
      constructor
      · intro ha
        refine ⟨ha,?_,?_⟩
        · intro he;subst u
          cases v with
          | none => exact (CoreFamily.graph xs q).loopless none ha
          | some v =>
            obtain ⟨i,w⟩ := v
            exact hvm ((played_local xs q i w).mpr ((root_adj xs q i w).mp ha))
        · intro he;subst v;exact hvm (played_none xs q)
      · exact fun h=>h.1

/-- Existing complete pure-family bijection transports every original legal
follower in StrictCapacity, including the marked but unselected centre. -/
theorem pure_strict (p : Nat) :
    MarkedSum.StrictCapacity (GeneralP4Receiver.graph 0 p) (GeneralP4Receiver.marks 0 p) ∅ (3*p+1) := by
  constructor
  · rw [GeneralP4Receiver.pure_D]
  · intro v _
    simp only [Finset.insert_empty]
    rw [GeneralP4Receiver.value_pure]
    simp only [Finset.image_singleton]
    have h := PureModuleStrict.follower_S p (GeneralP4Receiver.pureEquiv p v)
    omega

#print axioms local_adj
#print axioms local_marks
#print axioms local_value
#print axioms local_strict
#print axioms parts_cover
#print axioms parts_disjoint
#print axioms parts_no_cross
#print axioms parts_S
#print axioms parts_strict
#print axioms strict_card
#print axioms cap_sum
#print axioms flat_sum_value
#print axioms pure_strict
#print axioms played_none
#print axioms played_local
#print axioms embed_bijective
end IsolationGame.CoreCompanionPartition
