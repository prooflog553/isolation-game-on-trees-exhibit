import DoubleCentreP4Bounds

namespace IsolationGame.DoubleCentreP4
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

theorem D_ceil (k l p q : Nat) (h : 1 ≤ k+l) :
    Marked.gameValue (graph k l p q) ∅ .dominator ∅ ≤
      (3*(2+4*(k+l)+7*(p+q))+6)/7 := by
  have hd := D_upper k l p q
  omega

theorem D_floor (k l p q : Nat) (h : k+l=3 ∨ 5≤k+l) :
    Marked.gameValue (graph k l p q) ∅ .dominator ∅ ≤
      (3*(2+4*(k+l)+7*(p+q)))/7 := by
  have hd := D_upper k l p q
  rcases h with h | h <;> omega

theorem D_ceil_order (k l p q : Nat) (h : 1≤k+l) :
    Marked.gameValue (graph k l p q) ∅ .dominator ∅ ≤
      (3*Fintype.card (Vertex k l p q)+6)/7 := by
  rw [order]
  exact D_ceil k l p q h

theorem D_floor_order (k l p q : Nat) (h : k+l=3 ∨ 5≤k+l) :
    Marked.gameValue (graph k l p q) ∅ .dominator ∅ ≤
      (3*Fintype.card (Vertex k l p q))/7 := by
  rw [order]
  exact D_floor k l p q h

/-- The arithmetic proof deliberately leaves the small floor gaps open. -/
theorem budget_floor_small_gaps (r s : Nat) (h : r=0 ∨ r=1 ∨ r=2 ∨ r=4) :
    (3*(2+4*r+7*s))/7 < 3*s+(3*r)/2+2 := by
  rcases h with h | h | h | h <;> omega

#print axioms D_ceil
#print axioms D_floor
#print axioms D_ceil_order
#print axioms D_floor_order
#print axioms budget_floor_small_gaps
end IsolationGame.DoubleCentreP4
