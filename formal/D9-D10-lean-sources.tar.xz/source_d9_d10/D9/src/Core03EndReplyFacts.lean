import Core03MiddleEndFacts
import ReplyStrictPairing

/-! SOURCE-ONLY. Accepted full03 DAG evidence plus the accepted genuine
ReplyStrictCapacity mechanism. No new game DAG or multiplicity search. -/
namespace IsolationGame.CompositeWhiteCore03Facts
open FullCanonical.T03
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

/-- The accepted row_4 is strict2 on its FULL ten-vertex original carrier.
In particular original blue root0 has a balanced1 follower. -/
theorem row_four_strict : MarkedSum.StrictCapacity original marks_4 ∅ 2 := by
  constructor
  · rw [row_4.1] <;> omega
  · intro v hv
    fin_cases v
    · change Marked.gameValue original marks_4 .staller {0}+1≤2
      rw [after_4_0.2] <;> omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 3) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 4) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 6) hv)
    · change Marked.gameValue original marks_4 .staller {7}+1≤2
      rw [after_4_7.2] <;> omega
    · change Marked.gameValue original marks_4 .staller {8}+1≤2
      rw [after_4_8.2] <;> omega
    · change Marked.gameValue original marks_4 .staller {9}+1≤2
      rw [after_4_9.2] <;> omega

/-- A finite WHITE identity, valid with every additional selected history X.
The two actual moves 2 then4 dominate 0,1,2,3,4,5; the surviving original leaf6
has support5 dominated and is nonwhite. marks_4 additionally marks only this
already-inert leaf. Every original action stays present. -/
theorem end_bad_reply_white (X : Finset (Fin 10)) (w : Fin 10) :
    Marked.White original marks_13 (insert 4 (insert 2 X)) w ↔
      Marked.White original marks_4 X w := by
  let M : Finset (Fin 10) := {0,1,2,3,4,5}
  have hm : SelectedVertex.playedMarks original
      (SelectedVertex.playedMarks original marks_13 4) 2 = M := by
    ext v
    simp only [SelectedVertex.mem_playedMarks]
    fin_cases v <;> decide +kernel
  have hl : ∀ v : Fin 10, original.Adj 6 v ↔ v=5 := by decide +kernel
  have hs : (5 : Fin 10) ∈ M := by decide +kernel
  have hmark : insert (6 : Fin 10) M = marks_4 := by decide +kernel
  rw [SelectedVertex.absorb_white,SelectedVertex.absorb_white,hm]
  rw [←hmark,MarkedLeaf.mark_leaf_white original 6 5 hl M X hs]

/-- The real bad blue2 is answered by real local4, NOT by localroot0.
Root0 would leave two balanced edges and would not supply strict2. -/
theorem end_bad_reply_strict :
    MarkedSum.StrictCapacity original marks_13 (insert 4 {2}) 2 := by
  have hval (turn : Player) (X : Finset (Fin 10)) :
      Marked.gameValue original marks_13 turn (insert 4 (insert 2 X)) =
        Marked.gameValue original marks_4 turn X := by
    exact Marked.value_eq_of_white_eq original marks_13 marks_4
      (insert 4 (insert 2 X)) X turn (end_bad_reply_white X)
  constructor
  · change Marked.gameValue original marks_13 .dominator (insert 4 (insert 2 ∅))+1≤2
    rw [hval .dominator ∅,row_4.1] <;> omega
  · intro v hv
    have hv' : Marked.Legal original marks_4 ∅ v := by
      obtain ⟨w,hc,hw⟩ := hv
      exact ⟨w,hc,(end_bad_reply_white ∅ w).mp hw⟩
    have hh := row_four_strict.2 v hv'
    have he : insert v (insert 4 ({2} : Finset (Fin 10))) =
        insert 4 (insert 2 ({v} : Finset (Fin 10))) := by
      ext w; simp [or_comm,or_left_comm,or_assoc]
    rw [he,hval .staller {v}]
    exact hh

/-- End row13 is ReplyStrict4 although it is provably not Strict4.
Every original legal action is covered, including bad original blue2. -/
theorem end_reply_four : MarkedSum.ReplyStrictCapacity original marks_13 ∅ 4 := by
  constructor
  · rw [row_13.1] <;> omega
  · intro v hv
    by_cases hb : v=2
    · subst v
      apply Or.inr
      refine ⟨4,?_,?_⟩
      · change Marked.Legal original marks_13 {2} 4
        decide +kernel
      · simpa only [Finset.insert_empty] using end_bad_reply_strict
    · apply Or.inl
      fin_cases v
      · change Marked.gameValue original marks_13 .staller {0}+1≤4
        rw [after_13_0.2] <;> omega
      · change Marked.gameValue original marks_13 .staller {1}+1≤4
        rw [after_13_1.2] <;> omega
      · exact False.elim (hb rfl)
      · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_13 ∅ 3) hv)
      · change Marked.gameValue original marks_13 .staller {4}+1≤4
        rw [after_13_4.2] <;> omega
      · change Marked.gameValue original marks_13 .staller {5}+1≤4
        rw [after_13_5.2] <;> omega
      · change Marked.gameValue original marks_13 .staller {6}+1≤4
        rw [after_13_6.2] <;> omega
      · change Marked.gameValue original marks_13 .staller {7}+1≤4
        rw [after_13_7.2] <;> omega
      · change Marked.gameValue original marks_13 .staller {8}+1≤4
        rw [after_13_8.2] <;> omega
      · change Marked.gameValue original marks_13 .staller {9}+1≤4
        rw [after_13_9.2] <;> omega

/-- Complete all-p END follower bound on the ACTUAL active-port attachment.
Private-switch edge simulation handles the blue global port. The saving uses
Reply4 plus genuine pure Strict(3p+1), never the false local Strict4 claim. -/
theorem end_follower_S_upper (p : Nat) :
    Marked.gameValue (Attachment.original (P p) original none 0)
      (MarkedSum.combine {none} marks_13) .staller ∅ ≤ 3*p+4 := by
  have hg := (CoreFamily.family_tree [] p).IsAcyclic
  have hT : original.IsAcyclic := by
    have ht : original.IsTree := CanonicalLocal.tree_of_certificate original 0
      (by unfold CanonicalLocal.ReachThree; decide +kernel) (by decide +kernel)
    exact ht.IsAcyclic
  have hp := MarkedSum.strict_reply_value (P p) original
    (MarkedSum.forest_no_minus (P p) hg) (MarkedSum.forest_no_minus original hT)
    {none} ∅ marks_13 ∅ (3*p+1) 4 (PureModuleStrict.family_strict p) end_reply_four
  have he0 : MarkedSum.combine (∅ : Finset (CoreFamily.Vertex [] p))
      (∅ : Finset (Fin 10)) = ∅ := by
    simp [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight]
  rw [he0] at hp
  have hb := end_blue_port_bound p .staller
  omega

#print axioms row_four_strict
#print axioms end_bad_reply_strict
#print axioms end_reply_four
#print axioms end_follower_S_upper
end IsolationGame.CompositeWhiteCore03Facts
