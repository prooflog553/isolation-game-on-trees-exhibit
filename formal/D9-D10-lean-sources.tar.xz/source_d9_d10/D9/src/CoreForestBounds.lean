import CoreForestComponents
import IllegalMarkedBoundary

namespace IsolationGame.CoreForest
open CanonicalLocal CoreFamily CoreFamilySemantics IsolatedRestriction FiniteForestComponents
variable (xs : List Nat) (p : Nat)

theorem forest_acyclic (hA : (CoreFamily.graph xs p).IsAcyclic) : (forest xs p).IsAcyclic :=
  PartitionBridge.induced_acyclic _ hA _

/-- The exact strict-pairing forest rule on genuine original components, with
arbitrary live local whites and arbitrary ordinary multiplicity. -/
theorem mixed_s_upper (hA : (CoreFamily.graph xs p).IsAcyclic) (W : LocalWhite xs p)
    (c : Fin (xs.length+p)→Nat) (J : Finset (Fin (xs.length+p)))
    (hc : ∀i,Marked.gameValue (CanonicalLocal.graph (label xs p i))
      (ForestFoundation.canonicalMarks (W i)) .staller ∅≤c i)
    (hj : ∀i∈J,MarkedSum.StrictCapacity (CanonicalLocal.graph (label xs p i))
      (ForestFoundation.canonicalMarks (W i)) ∅ (c i)) :
    Marked.gameValue (forest xs p) (forestMarks xs p W) .staller ∅≤(∑i,c i)-J.card/2 := by
  classical
  have hX (i) : restrict (component xs p i) (∅ : Finset (DeletedVertex xs p))=∅ := by
    ext v
    simp
  have hcap : ∀i∈(Finset.univ : Finset (Fin (xs.length+p))),
      valueOn (forest xs p) (component xs p i) (forestMarks xs p W) ∅ .staller≤c i := by
    intro i _
    unfold valueOn
    rw [hX,local_value]
    exact hc i
  have hstrict : ∀i∈J,MarkedSum.StrictCapacity (induced (forest xs p) (component xs p i))
      (restrict (component xs p i) (forestMarks xs p W)) (restrict (component xs p i) ∅) (c i) := by
    intro i hi
    rw [hX]
    exact local_strict xs p W i (c i) (hj i hi)
  have hf := finite_mixed_s_upper (forest xs p) (forest_acyclic xs p hA)
    (component xs p) (components_disjoint xs p) (components_no_cross xs p)
    Finset.univ J (Finset.subset_univ _) (forestMarks xs p W) ∅ c hcap hstrict
  rw [components_cover,univ_value] at hf
  exact hf

theorem paid_s_upper (hA : (CoreFamily.graph xs p).IsAcyclic) (W : LocalWhite xs p)
    (k : Nat) (hk : Marked.gameValue (forest xs p) (forestMarks xs p W) .staller ∅≤k) :
    Marked.gameValue (CoreFamily.graph xs p) (marks xs p W) .staller ∅≤1+k := by
  have h := (MarkedBoundary.marked_vertex_fee (CoreFamily.graph xs p) none hA
    (marks xs p W) ∅ (root_marked xs p W)).2
  have hX : restrict (MarkedBoundary.retained (none : Vertex xs p)) ∅=∅ := by ext v;simp
  rw [hX] at h
  change Marked.gameValue (CoreFamily.graph xs p) (marks xs p W) .staller ∅≤
    1+Marked.gameValue (forest xs p) (forestMarks xs p W) .staller ∅ at h
  omega

theorem paid_d_upper (hA : (CoreFamily.graph xs p).IsAcyclic) (W : LocalWhite xs p)
    (k : Nat) (hk : Marked.gameValue (forest xs p) (forestMarks xs p W) .dominator ∅≤k) :
    Marked.gameValue (CoreFamily.graph xs p) (marks xs p W) .dominator ∅≤1+k := by
  have h := (MarkedBoundary.marked_vertex_fee (CoreFamily.graph xs p) none hA
    (marks xs p W) ∅ (root_marked xs p W)).1
  have hX : restrict (MarkedBoundary.retained (none : Vertex xs p)) ∅=∅ := by ext v;simp
  rw [hX] at h
  change Marked.gameValue (CoreFamily.graph xs p) (marks xs p W) .dominator ∅≤
    1+Marked.gameValue (forest xs p) (forestMarks xs p W) .dominator ∅ at h
  omega

theorem free_root_value (W : LocalWhite xs p) (hn : Normalized xs p W)
    (hi : ∀i,¬W i (root (label xs p i))) (turn : Player) :
    Marked.gameValue (CoreFamily.graph xs p) (marks xs p W) turn ∅=
      Marked.gameValue (forest xs p) (forestMarks xs p W) turn ∅ := by
  have hl : ¬Marked.Legal (CoreFamily.graph xs p) (marks xs p W) ∅ none := by
    rw [actual_legal_root xs p W hn]
    exact fun ⟨i,h⟩=>hi i h
  have h := MarkedBoundary.illegal_marked_vertex_value (CoreFamily.graph xs p) none
    (marks xs p W) ∅ (root_marked xs p W) (by simp) hl turn
  have hX : restrict (MarkedBoundary.retained (none : Vertex xs p)) ∅=∅ := by ext v;simp
  rw [hX] at h
  exact h

#print axioms mixed_s_upper
#print axioms paid_s_upper
#print axioms paid_d_upper
#print axioms free_root_value
end IsolationGame.CoreForest
