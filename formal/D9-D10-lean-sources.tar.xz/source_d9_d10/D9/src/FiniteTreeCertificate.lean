import CutPieceEquivalence
import ProfileBase

namespace IsolationGame.CanonicalLocal
variable {V : Type} [Fintype V] [DecidableEq V]

def ReachThree (G : SimpleGraph V) (r : V) : Prop := ∀v,
  v=r ∨ G.Adj r v ∨ (∃a,G.Adj r a ∧ G.Adj a v) ∨
    ∃a b,G.Adj r a ∧ G.Adj a b ∧ G.Adj b v

theorem connected_of_reachThree (G : SimpleGraph V) (r : V) (h : ReachThree G r) : G.Connected := by
  apply (SimpleGraph.connected_iff_exists_forall_reachable G).mpr
  refine ⟨r,?_⟩
  intro v
  rcases h v with rfl | hv | ⟨a,ha,hv⟩ | ⟨a,b,ha,hab,hbv⟩
  · exact SimpleGraph.Reachable.refl _
  · exact hv.reachable
  · exact ha.reachable.trans hv.reachable
  · exact (ha.reachable.trans hab.reachable).trans hbv.reachable

theorem tree_of_certificate (G : SimpleGraph V) [Fintype G.edgeSet] (r : V)
    (hreach : ReachThree G r) (hcard : G.edgeFinset.card+1=Fintype.card V) : G.IsTree := by
  apply SimpleGraph.isTree_iff_connected_and_card.mpr
  refine ⟨connected_of_reachThree G r hreach,?_⟩
  simpa only [Nat.card_eq_fintype_card,SimpleGraph.edgeFinset_card] using hcard

#print axioms tree_of_certificate
end IsolationGame.CanonicalLocal
