import ActualRootProfiles
import RootInitialLegality
import RootNecessaryBudget

namespace IsolationGame.ActualRootBranches
open IsolatedRestriction FiniteForestComponents
variable {V : Type} [Fintype V] [DecidableEq V]

/-- The complete actual-tree root strategy. All branch geometry, original
marks, complete strict profiles and the finite strict-pair saving are wired
in. Capacities are the actual S values of the original rooted branches. -/
theorem actual_root_budget (G : SimpleGraph V) (hT : G.IsTree) (r : V) :
    Marked.gameValue G {r} .dominator ∅≤
      1+((∑a : Child G r,capacity G r a)-(strictChildren G r).card/2) := by
  classical
  by_cases ht : Marked.Terminal G {r} ∅
  · rw [(Marked.value_zero_iff_terminal G {r} ∅ .dominator).mpr ht]
    exact Nat.zero_le _
  · have hr := root_legal_of_nonterminal G hT r ht
    have hc : ∀a∈(Finset.univ : Finset (Child G r)),
        valueOn (MarkedBoundary.deleted G r) (component G r a) (RootMoveCapacity.neighbourMarks G r) ∅ .staller≤capacity G r a := by
      intro a _
      rw [component_value G hT r a .staller]
      exact Nat.le_refl _
    exact RootMoveCapacity.finite_strict_component_bound G r hT.IsAcyclic hr (component G r)
      Finset.univ (strictChildren G r) (components_cover G hT r) (Finset.subset_univ _)
      (components_disjoint G hT r) (components_noCross G hT r) (capacity G r) hc
      (fun a ha=>component_strict G hT r a ha)

/-- Every actual rooted-tree floor counterexample has defect at least -3.
There is no supplied partition or hypothetical local-capacity premise: the
terms are defined from that original tree's actual root branches and values. -/
theorem actual_necessary_defect (G : SimpleGraph V) (hT : G.IsTree) (r : V)
    (hCounter : 3*Fintype.card V/7<Marked.gameValue G {r} .dominator ∅) :
    (-3 : Int)≤7*((∑a : Child G r,capacity G r a : Nat):Int)-
      3*((∑a : Child G r,(piece G r a).card : Nat):Int)-7*(((strictChildren G r).card/2 : Nat):Int) := by
  classical
  have ht : ¬Marked.Terminal G {r} ∅ := by
    intro ht
    have hz := (Marked.value_zero_iff_terminal G {r} ∅ .dominator).mpr ht
    omega
  have hr := root_legal_of_nonterminal G hT r ht
  have hc : ∀a∈(Finset.univ : Finset (Child G r)),
      valueOn (MarkedBoundary.deleted G r) (component G r a) (RootMoveCapacity.neighbourMarks G r) ∅ .staller≤capacity G r a := by
    intro a _
    rw [component_value G hT r a .staller]
    exact Nat.le_refl _
  have hh := RootMoveCapacity.necessary_raw_defect G r hT.IsAcyclic hr (component G r)
    Finset.univ (strictChildren G r) (components_cover G hT r) (Finset.subset_univ _)
    (components_disjoint G hT r) (components_noCross G hT r) (capacity G r) hc
    (fun a ha=>component_strict G hT r a ha) hCounter
  simp_rw [component_card] at hh
  exact hh

/-- The real-tree capacity-defect criterion. Evaluating its actual local
profiles remains a separate obligation from this semantic strategy theorem. -/
theorem actual_floor_of_defect (G : SimpleGraph V) (hT : G.IsTree) (r : V)
    (hDelta : 7*((∑a : Child G r,capacity G r a : Nat):Int)-
      3*((∑a : Child G r,(piece G r a).card : Nat):Int)-7*(((strictChildren G r).card/2 : Nat):Int)≤(-4 : Int)) :
    Marked.gameValue G {r} .dominator ∅≤3*Fintype.card V/7 := by
  by_contra hh
  have hc : 3*Fintype.card V/7<Marked.gameValue G {r} .dominator ∅ := by omega
  have hd := actual_necessary_defect G hT r hc
  omega

#print axioms actual_root_budget
#print axioms actual_necessary_defect
#print axioms actual_floor_of_defect
end IsolationGame.ActualRootBranches
