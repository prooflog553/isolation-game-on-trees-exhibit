import CoreFamilyHeadAttachment
import GeneralP4PureTransport
import OriginalIsoTransport

/-! SOURCE-ONLY candidate. Exact all-t01 core / general-P4 receiver bridge.
Only original graph isomorphisms, GeneralP4PureTransport.pureEquiv, and the
existing literal GeneralP4Receiver.splitEquiv are used. No game is redefined.
-/
namespace IsolationGame.CoreFamily
open CanonicalLocal NecessaryCore

private theorem canonical_t01_P4_adj : ∀u v : Fin 4,
    P4Receiver.T.Adj u v ↔ (CanonicalLocal.graph .t01).Adj u v := by
  decide +kernel

/-- Complete endpoint-rooted canonical P4 to the established receiver P4. -/
def localP4Iso (n : Nat) (hn : decode n = .t01) :
    CanonicalLocal.graph (decode n) ≃g P4Receiver.T where
  toEquiv := coordinateEquiv hn
  map_rel_iff' := by
    intro u v
    exact (canonical_t01_P4_adj _ _).trans (coordinateEquiv_adj hn u v)

@[simp] theorem localP4Iso_root (n : Nat) (hn : decode n = .t01) :
    localP4Iso n hn (root (decode n)) = 0 := by
  exact coordinateEquiv_root hn

/-- The established pure bridge in standard graph-isomorphism form. -/
def receiverPureIso (q : Nat) : GeneralP4Receiver.graph 0 q ≃g graph [] q where
  toEquiv := GeneralP4Receiver.pureEquiv q
  map_rel_iff' := fun {u v} => GeneralP4Receiver.pureEquiv_adj q u v

@[simp] theorem receiverPureIso_root (q : Nat) :
    receiverPureIso q (GeneralP4Receiver.centre 0 q) = none := rfl

/-- The established split bridge in standard graph-isomorphism form. -/
def receiverSplitIso (k q : Nat) :
    GeneralP4Receiver.graph (k+1) q ≃g GeneralP4Receiver.splitGraph k q where
  toEquiv := GeneralP4Receiver.splitEquiv k q
  map_rel_iff' := fun {u v} => GeneralP4Receiver.splitEquiv_adj k q u v

@[simp] theorem receiverSplitIso_root (k q : Nat) :
    receiverSplitIso k q (GeneralP4Receiver.centre (k+1) q) =
      .inl (GeneralP4Receiver.centre k q) := rfl

/-- A complete rooted iso for an arbitrary list whose every decoded profile
is t01. Its raw codes and order need not be normalized separately. -/
theorem exists_allP4ReceiverIso (xs : List Nat) (q : Nat)
    (hxs : ∀n∈xs,decode n = .t01) :
    ∃e : graph xs q ≃g GeneralP4Receiver.graph xs.length q,
      e none = GeneralP4Receiver.centre xs.length q := by
  revert hxs
  induction xs with
  | nil =>
    intro hxs
    refine ⟨(receiverPureIso q).symm,?_⟩
    rw [←receiverPureIso_root q]
    exact (receiverPureIso q).symm_apply_apply _
  | cons n xs ih =>
    intro hxs
    have hn : decode n = .t01 := hxs n (by simp)
    have ht : ∀m∈xs,decode m = .t01 := fun m hm => hxs m (by simp [hm])
    obtain ⟨e,he⟩ := ih ht
    let a := headAttachmentIso n xs q
    let b := OriginalIsoTransport.attachmentIso
      (graph xs q) (CanonicalLocal.graph (decode n))
      (GeneralP4Receiver.graph xs.length q) P4Receiver.T
      none (root (decode n)) (GeneralP4Receiver.centre xs.length q) 0
      e (localP4Iso n hn) he (localP4Iso_root n hn)
    let c := receiverSplitIso xs.length q
    refine ⟨a.symm.trans (b.trans c.symm),?_⟩
    change c.symm (b (a.symm none)) = _
    have ha : a.symm none = .inl none := by
      rw [←headAttachmentIso_root n xs q]
      exact a.symm_apply_apply _
    rw [ha]
    have hb : b (.inl none) = .inl (GeneralP4Receiver.centre xs.length q) := by
      change Sum.inl (e none) = _
      rw [he]
    rw [hb,←receiverSplitIso_root xs.length q]
    exact c.symm_apply_apply _

noncomputable def allP4ReceiverIso (xs : List Nat) (q : Nat)
    (hxs : ∀n∈xs,decode n = .t01) :
    graph xs q ≃g GeneralP4Receiver.graph xs.length q :=
  Classical.choose (exists_allP4ReceiverIso xs q hxs)

@[simp] theorem allP4ReceiverIso_root (xs : List Nat) (q : Nat)
    (hxs : ∀n∈xs,decode n = .t01) :
    allP4ReceiverIso xs q hxs none = GeneralP4Receiver.centre xs.length q :=
  Classical.choose_spec (exists_allP4ReceiverIso xs q hxs)

/-- First pool every t02 position, then transport an all-t01 residual core.
The receiver has exactly the retained P4 count and the enlarged ordinary pool. -/
noncomputable def normalizedAllP4ReceiverIso (xs : List Nat) (q : Nat)
    (hxs : ∀n∈nonordinaryCodes xs,decode n = .t01) :
    graph xs q ≃g GeneralP4Receiver.graph (nonordinaryCodes xs).length
      (q+ordinaryCount xs) :=
  (ordinaryNormalizationIso xs q).trans
    (allP4ReceiverIso (nonordinaryCodes xs) (q+ordinaryCount xs) hxs)

@[simp] theorem normalizedAllP4ReceiverIso_root (xs : List Nat) (q : Nat)
    (hxs : ∀n∈nonordinaryCodes xs,decode n = .t01) :
    normalizedAllP4ReceiverIso xs q hxs none =
      GeneralP4Receiver.centre (nonordinaryCodes xs).length (q+ordinaryCount xs) := by
  simp [normalizedAllP4ReceiverIso]

/-- Full marks/history/game transport, rather than a static shape tag. -/
theorem normalizedAllP4Receiver_value (xs : List Nat) (q : Nat)
    (hxs : ∀n∈nonordinaryCodes xs,decode n = .t01)
    (M X : Finset (Vertex xs q)) (t : Player) :
    Marked.gameValue
      (GeneralP4Receiver.graph (nonordinaryCodes xs).length (q+ordinaryCount xs))
      (M.image (normalizedAllP4ReceiverIso xs q hxs)) t
      (X.image (normalizedAllP4ReceiverIso xs q hxs)) =
      Marked.gameValue (graph xs q) M t X :=
  OriginalIsoTransport.marked_gameValue _ _ (normalizedAllP4ReceiverIso xs q hxs) M X t

theorem normalizedAllP4Receiver_white (xs : List Nat) (q : Nat)
    (hxs : ∀n∈nonordinaryCodes xs,decode n = .t01)
    (M X : Finset (Vertex xs q)) (v : Vertex xs q) :
    Marked.White
      (GeneralP4Receiver.graph (nonordinaryCodes xs).length (q+ordinaryCount xs))
      (M.image (normalizedAllP4ReceiverIso xs q hxs))
      (X.image (normalizedAllP4ReceiverIso xs q hxs))
      (normalizedAllP4ReceiverIso xs q hxs v) ↔ Marked.White (graph xs q) M X v :=
  Marked.white_relabel _ _ (normalizedAllP4ReceiverIso xs q hxs).toEquiv
    (fun _ _ => (normalizedAllP4ReceiverIso xs q hxs).map_adj_iff) M X v

theorem normalizedAllP4Receiver_legal (xs : List Nat) (q : Nat)
    (hxs : ∀n∈nonordinaryCodes xs,decode n = .t01)
    (M X : Finset (Vertex xs q)) (v : Vertex xs q) :
    Marked.Legal
      (GeneralP4Receiver.graph (nonordinaryCodes xs).length (q+ordinaryCount xs))
      (M.image (normalizedAllP4ReceiverIso xs q hxs))
      (X.image (normalizedAllP4ReceiverIso xs q hxs))
      (normalizedAllP4ReceiverIso xs q hxs v) ↔ Marked.Legal (graph xs q) M X v :=
  Marked.legal_relabel _ _ (normalizedAllP4ReceiverIso xs q hxs).toEquiv
    (fun _ _ => (normalizedAllP4ReceiverIso xs q hxs).map_adj_iff) M X v

theorem normalizedAllP4Receiver_centerMarks (xs : List Nat) (q : Nat)
    (hxs : ∀n∈nonordinaryCodes xs,decode n = .t01) :
    ({none} : Finset (Vertex xs q)).image (normalizedAllP4ReceiverIso xs q hxs) =
      GeneralP4Receiver.marks (nonordinaryCodes xs).length (q+ordinaryCount xs) := by
  simp [GeneralP4Receiver.marks,TwoPool.marks,GeneralP4Receiver.root,
    GeneralP4Receiver.centre,GeneralP4Receiver.fixed,TwoPool.fixed]

theorem normalizedAllP4Receiver_centerValue (xs : List Nat) (q : Nat)
    (hxs : ∀n∈nonordinaryCodes xs,decode n = .t01)
    (X : Finset (Vertex xs q)) (t : Player) :
    Marked.gameValue
      (GeneralP4Receiver.graph (nonordinaryCodes xs).length (q+ordinaryCount xs))
      (GeneralP4Receiver.marks (nonordinaryCodes xs).length (q+ordinaryCount xs)) t
      (X.image (normalizedAllP4ReceiverIso xs q hxs)) =
      Marked.gameValue (graph xs q) {none} t X := by
  rw [←normalizedAllP4Receiver_centerMarks xs q hxs]
  exact normalizedAllP4Receiver_value xs q hxs {none} X t

#print axioms exists_allP4ReceiverIso
#print axioms allP4ReceiverIso
#print axioms normalizedAllP4ReceiverIso
#print axioms normalizedAllP4Receiver_value
end IsolationGame.CoreFamily
