import BWBridge
import ModuleWithEdges

namespace IsolationGame.BWBridge
open Isolation.Graph
open MarkedModule

abbrev gatedWhite {n : Nat} (σ : State (Fin n)) :=
  GatedGraph.stateWhite MarkedModule.owner (gatedState σ)
noncomputable abbrev gatedMarks {n : Nat} (σ : State (Fin n)) :=
  GatedGraph.marks MarkedModule.owner (gatedState σ)

 theorem gated_marks_white {n : Nat} (σ : State (Fin n)) (v : Side n) :
    Marked.White MarkedModule.original (gatedMarks σ) ∅ v ↔ gatedWhite σ v :=
  GatedGraph.connected_white MarkedModule.owner MarkedModule.star (gatedState σ) v

 theorem root_left_remove (p q : Nat) (σ : State (Fin p)) (τ : State (Fin q)) :
    (view p q).remove (whiteSum p q (white σ) (WhiteReserve.whiteRoot τ)) (.inl (root p)) =
      whiteSum p q (gatedWhite σ) (white τ) := by
  funext v; apply propext
  cases v with
  | inl v =>
    simpa [Isolation.Graph.remove,Isolation.Graph.closed,view,original,Attachment.original,
      GuardedEdge.view,whiteSum,Isolation.Graph.whiteSum,root,MarkedModule.graph] using
      Iff.of_eq (congrFun (root_remove σ) v)
  | inr v => cases v with
    | gate o => cases o <;>
        simp [Isolation.Graph.remove,Isolation.Graph.closed,view,original,Attachment.original,
          GuardedEdge.view,whiteSum,Isolation.Graph.whiteSum,root,WhiteReserve.whiteRoot,white]
    | b j => simp [Isolation.Graph.remove,Isolation.Graph.closed,view,original,Attachment.original,
          GuardedEdge.view,whiteSum,Isolation.Graph.whiteSum,root,WhiteReserve.whiteRoot]
    | c j => simp [Isolation.Graph.remove,Isolation.Graph.closed,view,original,Attachment.original,
          GuardedEdge.view,whiteSum,Isolation.Graph.whiteSum,root,WhiteReserve.whiteRoot]
    | d j => simp [Isolation.Graph.remove,Isolation.Graph.closed,view,original,Attachment.original,
          GuardedEdge.view,whiteSum,Isolation.Graph.whiteSum,root,WhiteReserve.whiteRoot]

 theorem root_right_remove (p q : Nat) (σ : State (Fin p)) (τ : State (Fin q)) :
    (view p q).remove (whiteSum p q (white σ) (WhiteReserve.whiteRoot τ)) (.inr (root q)) =
      whiteSum p q (white σ) (gatedWhite τ) := by
  funext v; apply propext
  cases v with
  | inr v =>
    have he := (WhiteReserve.remove_root_agree τ).trans (root_remove τ)
    simpa [Isolation.Graph.remove,Isolation.Graph.closed,view,original,Attachment.original,
      GuardedEdge.view,whiteSum,Isolation.Graph.whiteSum,root,MarkedModule.graph] using
      Iff.of_eq (congrFun he v)
  | inl v => cases v with
    | gate o => cases o <;>
        simp [Isolation.Graph.remove,Isolation.Graph.closed,view,original,Attachment.original,
          GuardedEdge.view,whiteSum,Isolation.Graph.whiteSum,root,white]
    | b j => simp [Isolation.Graph.remove,Isolation.Graph.closed,view,original,Attachment.original,
          GuardedEdge.view,whiteSum,Isolation.Graph.whiteSum,root,white]
    | c j => simp [Isolation.Graph.remove,Isolation.Graph.closed,view,original,Attachment.original,
          GuardedEdge.view,whiteSum,Isolation.Graph.whiteSum,root,white]
    | d j => simp [Isolation.Graph.remove,Isolation.Graph.closed,view,original,Attachment.original,
          GuardedEdge.view,whiteSum,Isolation.Graph.whiteSum,root,white]

 theorem root_left_step (p q : Nat) (σ : State (Fin p)) (τ : State (Fin q)) :
    (view p q).step (whiteSum p q (white σ) (WhiteReserve.whiteRoot τ)) (.inl (root p)) =
      whiteSum p q (gatedWhite σ) (white τ) := by
  unfold Isolation.Graph.step
  rw [root_left_remove,normalize_sum p q _ _ (gated_normalized _) (module_normalized _)]

 theorem root_right_step (p q : Nat) (σ : State (Fin p)) (τ : State (Fin q)) :
    (view p q).step (whiteSum p q (white σ) (WhiteReserve.whiteRoot τ)) (.inr (root q)) =
      whiteSum p q (white σ) (gatedWhite τ) := by
  unfold Isolation.Graph.step
  rw [root_right_remove,normalize_sum p q _ _ (module_normalized _) (gated_normalized _)]

/-- Exact bridge to the actual disjoint marked game, with every blue
vertex preserved, whenever both original centres are nonwhite. -/
 theorem split_value (p q : Nat) (M X : Finset (Vertex p q))
    (N : Finset (Side p)) (K : Finset (Side q)) (L : Side p→Prop) (R : Side q→Prop)
    (hw : Marked.White (original p q) M X=whiteSum p q L R)
    (hl : ∀v,Marked.White MarkedModule.original N ∅ v ↔ L v)
    (hr : ∀v,Marked.White MarkedModule.original K ∅ v ↔ R v)
    (hL : ¬L (root p)) (hR : ¬R (root q)) (t : Player) :
    Marked.gameValue (original p q) M t X =
      Marked.gameValue (MarkedSum.original MarkedModule.original MarkedModule.original)
        (MarkedSum.combine N K) t ∅ := by
  have he : MarkedSum.white MarkedModule.original MarkedModule.original N ∅ K ∅=whiteSum p q L R := by
    funext v; apply propext; cases v with
    | inl v => exact hl v
    | inr v => exact hr v
  have hn (n : Nat) : Marked.WinsWithin (original p q) M n t X ↔
      Marked.WinsWithin (MarkedSum.original MarkedModule.original MarkedModule.original)
        (MarkedSum.combine N K) n t ∅ := by
    rw [←ForestFoundation.white_horizon,hw,split_horizon p q L R hL hR]
    have hh := MarkedSum.original_horizon (MarkedModule.original (B:=Fin p))
      (MarkedModule.original (B:=Fin q)) N ∅ K ∅ n t
    rw [he] at hh
    simpa [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight] using hh.symm
  apply Nat.le_antisymm
  · exact (Marked.gameValue_le_iff _ _ _ _ _).mpr ((hn _).mpr
      ((Marked.gameValue_le_iff _ _ _ _ _).mp (Nat.le_refl _)))
  · exact (Marked.gameValue_le_iff _ _ _ _ _).mpr ((hn _).mp
      ((Marked.gameValue_le_iff _ _ _ _ _).mp (Nat.le_refl _)))

 theorem pure_white (n : Nat) (v : Side n) :
    Marked.White MarkedModule.original MarkedModule.initialMarks ∅ v ↔ white (whole n) v :=
  MarkedModule.initial_white v

 theorem left_center_value (p q : Nat) (hq : 1≤q) (t : Player) :
    Marked.gameValue (original p q) (marks p q) t {.inl (root p)} =
      Marked.gameValue (MarkedSum.original MarkedModule.original MarkedModule.original)
        (MarkedSum.combine (gatedMarks (whole p)) (MarkedModule.initialMarks (B:=Fin q))) t ∅ := by
  apply split_value p q _ _ _ _ (gatedWhite (whole p)) (white (whole q))
  · have h := ForestFoundation.marked_white_step (original p q) (marks p q) ∅ (.inl (root p))
    rw [initial_white p q hq] at h
    simp only [Finset.insert_empty] at h
    exact h.symm.trans (root_left_step p q (whole p) (whole q))
  · exact gated_marks_white _
  · exact pure_white q
  · simp [root,gatedWhite,GatedGraph.stateWhite,GatedGraph.white]
  · simp [root,white]

 theorem right_center_value (p q : Nat) (hq : 1≤q) (t : Player) :
    Marked.gameValue (original p q) (marks p q) t {.inr (root q)} =
      Marked.gameValue (MarkedSum.original MarkedModule.original MarkedModule.original)
        (MarkedSum.combine (MarkedModule.initialMarks (B:=Fin p)) (gatedMarks (whole q))) t ∅ := by
  apply split_value p q _ _ _ _ (white (whole p)) (gatedWhite (whole q))
  · have h := ForestFoundation.marked_white_step (original p q) (marks p q) ∅ (.inr (root q))
    rw [initial_white p q hq] at h
    simp only [Finset.insert_empty] at h
    exact h.symm.trans (root_right_step p q (whole p) (whole q))
  · exact pure_white p
  · exact gated_marks_white _
  · simp [root,white]
  · simp [root,gatedWhite,GatedGraph.stateWhite,GatedGraph.white]

#print axioms left_center_value
#print axioms right_center_value
end IsolationGame.BWBridge
