import FourteenResidualData

/-! Finite kernel arithmetic only: first profile fixed to t08.
All arithmetic is checked by kernel reduction; no graph or history search. -/
namespace IsolationGame.FourteenResidual
open CanonicalLocal
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

theorem check11_t08 (b : Index) :
    NumericResidual [.t08] [b] → MatchesFourteen [.t08] [b] := by
  cases b <;> decide +kernel

theorem check12_t08 (b c : Index) :
    NumericResidual [.t08] [b, c] → MatchesFourteen [.t08] [b, c] := by
  cases b <;> cases c <;> decide +kernel

#print axioms check11_t08
#print axioms check12_t08
end IsolationGame.FourteenResidual
