import FullCanonical19Rows00
namespace IsolationGame.FullCanonical.T19
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
theorem full_values : Marked.gameValue original ∅ .dominator ∅=1 ∧ Marked.gameValue original ∅ .staller ∅=2 := by
  constructor
  · exact (Marked.value_eq_of_white_eq original ∅ marks_3 ∅ ∅ .dominator (by decide +kernel)).trans row_3.1
  · exact (Marked.value_eq_of_white_eq original ∅ marks_3 ∅ ∅ .staller (by decide +kernel)).trans row_3.2
theorem strict_full : MarkedSum.StrictCapacity original ∅ ∅ 2 := by
  constructor
  · rw [full_values.1] <;> decide +kernel
  · intro v hv
    fin_cases v
    · change Marked.gameValue original marks_3 .staller {0}+1≤2
      rw [after_3_0.2] <;> decide +kernel
    · change Marked.gameValue original marks_3 .staller {1}+1≤2
      rw [after_3_1.2] <;> decide +kernel
    · change Marked.gameValue original marks_3 .staller {2}+1≤2
      rw [after_3_2.2] <;> decide +kernel
    · change Marked.gameValue original marks_3 .staller {3}+1≤2
      rw [after_3_3.2] <;> decide +kernel
#print axioms full_values
#print axioms strict_full
end IsolationGame.FullCanonical.T19
