import WhiteReserveOriginal
import AttachmentGraph
import PureModuleGeometry
import MarkedRelabel

namespace IsolationGame.BWBridge
open Isolation.Graph
abbrev Side (n : Nat) := MarkedModule.Vertex (Fin n)
abbrev Vertex (p q : Nat) := Sum (Side p) (Side q)
def root (n : Nat) : Side n := .gate none

def original (p q : Nat) : SimpleGraph (Vertex p q) :=
  Attachment.original MarkedModule.original MarkedModule.original (root p) (root q)
abbrev view (p q : Nat) := GuardedEdge.view (original p q)
def marks (p q : Nat) : Finset (Vertex p q) := {.inl (root p)}
def whole (n : Nat) : MarkedModule.State (Fin n) := fun _ => .whole
abbrev whiteSum (p q : Nat) (L : Side p → Prop) (R : Side q → Prop) :=
  Isolation.Graph.whiteSum L R

theorem module_acyclic (n : Nat) : (MarkedModule.original (B:=Fin n)).IsAcyclic := by
  obtain ⟨e,_,he⟩ := CoreFamily.pure_module_family_iso n
  let f : (MarkedModule.original (B:=Fin n)) →g CoreFamily.graph [] n :=
    ⟨e.symm,by intro v w h; exact (he (e.symm v) (e.symm w)).mp (by simpa using h)⟩
  intro v c hc
  exact (CoreFamily.family_tree [] n).IsAcyclic (c.map f) (hc.map e.symm.injective)

theorem normalize_sum (p q : Nat) (L : Side p → Prop) (R : Side q → Prop)
    (hL : MarkedModule.graph.noniso L=L) (hR : MarkedModule.graph.noniso R=R) :
    (view p q).noniso (whiteSum p q L R)=whiteSum p q L R := by
  funext v; apply propext
  constructor
  · exact fun h=>h.1
  · intro hv
    cases v with
    | inl v =>
      have hv' : MarkedModule.graph.noniso L v := by rw [hL]; exact hv
      obtain ⟨_,w,hw,ha⟩ := hv'
      exact ⟨hv,.inl w,hw,ha⟩
    | inr v =>
      have hv' : MarkedModule.graph.noniso R v := by rw [hR]; exact hv
      obtain ⟨_,w,hw,ha⟩ := hv'
      exact ⟨hv,.inr w,hw,ha⟩

theorem module_normalized {n : Nat} (σ : MarkedModule.State (Fin n)) :
    MarkedModule.graph.noniso (MarkedModule.white σ)=MarkedModule.white σ := by
  funext v; exact propext (MarkedModule.white_normalized σ v)

theorem white_root_normalized {n : Nat} (σ : MarkedModule.State (Fin n)) :
    MarkedModule.graph.noniso (MarkedModule.WhiteReserve.whiteRoot σ)=
      MarkedModule.WhiteReserve.whiteRoot σ := by
  funext v; exact propext (MarkedModule.WhiteReserve.normalized σ v)

theorem gated_normalized {n : Nat} (σ : MarkedModule.State (Fin n)) :
    MarkedModule.graph.noniso (GatedGraph.stateWhite MarkedModule.owner (MarkedModule.gatedState σ))=
      GatedGraph.stateWhite MarkedModule.owner (MarkedModule.gatedState σ) := by
  have h := MarkedModule.root_step σ
  change MarkedModule.graph.noniso (MarkedModule.graph.remove (MarkedModule.white σ) (.gate none))=_ at h
  rwa [MarkedModule.root_remove] at h

/-- Removing only the bridge changes no original action on a white set
whose two bridge endpoints are nonwhite; all blue vertices are retained. -/
theorem split_horizon (p q : Nat) (L : Side p → Prop) (R : Side q → Prop)
    (hL : ¬L (root p)) (hR : ¬R (root q)) (n : Nat) (t : Isolation.Graph.Turn) :
    (view p q).WinsWhite n t (whiteSum p q L R) ↔
      (MarkedSum.graph (MarkedModule.original (B:=Fin p)) (MarkedModule.original (B:=Fin q))).WinsWhite
        n t (whiteSum p q L R) := by
  apply (view p q).winsWhite_congr
  intro v w hw
  rw [GuardedEdge.closed_agree]
  cases v with
  | inl v => cases w with
    | inl w => simp [Closed,original,Attachment.original,MarkedSum.graph,Isolation.Graph.closed,Isolation.Graph.disjointSum,GuardedEdge.view,eq_comm]
    | inr w =>
      have hne : w≠root q := by intro h; subst w; exact hR hw
      simp [Closed,original,Attachment.original,MarkedSum.graph,Isolation.Graph.closed,
        Isolation.Graph.disjointSum,hne]
  | inr v => cases w with
    | inl w =>
      have hne : w≠root p := by intro h; subst w; exact hL hw
      simp [Closed,original,Attachment.original,MarkedSum.graph,Isolation.Graph.closed,
        Isolation.Graph.disjointSum,hne]
    | inr w => simp [Closed,original,Attachment.original,MarkedSum.graph,Isolation.Graph.closed,Isolation.Graph.disjointSum,GuardedEdge.view,eq_comm]

def initialWhite (p q : Nat) : Vertex p q → Prop :=
  whiteSum p q (MarkedModule.white (whole p)) (MarkedModule.WhiteReserve.whiteRoot (whole q))

theorem initial_white (p q : Nat) (hq : 1≤q) :
    Marked.White (original p q) (marks p q) ∅=initialWhite p q := by
  have hnon : Nonempty (Fin q) := ⟨⟨0,by omega⟩⟩
  have hex : ∃ i : Fin q, whole q i = .whole := ⟨⟨0,by omega⟩,rfl⟩
  have hraw : (view p q).raw (fun v=>v∈marks p q) (fun v=>v∈(∅ : Finset (Vertex p q)))=
      initialWhite p q := by
    funext v; apply propext
    cases v with
    | inl v => cases v with
      | gate o => cases o <;> simp [Isolation.Graph.raw,marks,root,initialWhite,whiteSum,
          Isolation.Graph.whiteSum,MarkedModule.white,whole,MarkedModule.Status.middle]
      | b j => simp [Isolation.Graph.raw,marks,root,initialWhite,whiteSum,
          Isolation.Graph.whiteSum,MarkedModule.white,whole,MarkedModule.Status.live,MarkedModule.Status.closed]
      | c j => simp [Isolation.Graph.raw,marks,root,initialWhite,whiteSum,
          Isolation.Graph.whiteSum,MarkedModule.white,whole,MarkedModule.Status.live]
      | d j => simp [Isolation.Graph.raw,marks,root,initialWhite,whiteSum,
          Isolation.Graph.whiteSum,MarkedModule.white,whole,MarkedModule.Status.live]
    | inr v => cases v with
      | gate o => cases o <;> simp [Isolation.Graph.raw,marks,root,initialWhite,whiteSum,
          Isolation.Graph.whiteSum,MarkedModule.WhiteReserve.whiteRoot,MarkedModule.white,whole,
          MarkedModule.Status.middle,hex,hnon]
      | b j => simp [Isolation.Graph.raw,marks,root,initialWhite,whiteSum,
          Isolation.Graph.whiteSum,MarkedModule.WhiteReserve.whiteRoot,MarkedModule.white,whole,
          MarkedModule.Status.live,MarkedModule.Status.closed]
      | c j => simp [Isolation.Graph.raw,marks,root,initialWhite,whiteSum,
          Isolation.Graph.whiteSum,MarkedModule.WhiteReserve.whiteRoot,MarkedModule.white,whole,MarkedModule.Status.live]
      | d j => simp [Isolation.Graph.raw,marks,root,initialWhite,whiteSum,
          Isolation.Graph.whiteSum,MarkedModule.WhiteReserve.whiteRoot,MarkedModule.white,whole,MarkedModule.Status.live]
  funext v; apply propext
  rw [←GuardedEdge.white_agree]
  change (view p q).noniso ((view p q).raw _ _) v ↔ _
  rw [hraw,initialWhite,normalize_sum p q _ _ (module_normalized _) (white_root_normalized _)]

#print axioms module_acyclic
#print axioms split_horizon
#print axioms initial_white
end IsolationGame.BWBridge
