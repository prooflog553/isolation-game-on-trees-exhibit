import FourteenResidualData

/-! Finite kernel arithmetic only: first profile fixed to t18.
All arithmetic is checked by kernel reduction; no graph or history search. -/
namespace IsolationGame.FourteenResidual
open CanonicalLocal
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

theorem check11_t18 (b : Index) :
    NumericResidual [.t18] [b] → MatchesFourteen [.t18] [b] := by
  cases b <;> decide +kernel

theorem check12_t18 (b c : Index) :
    NumericResidual [.t18] [b, c] → MatchesFourteen [.t18] [b, c] := by
  cases b <;> cases c <;> decide +kernel

#print axioms check11_t18
#print axioms check12_t18
end IsolationGame.FourteenResidual
