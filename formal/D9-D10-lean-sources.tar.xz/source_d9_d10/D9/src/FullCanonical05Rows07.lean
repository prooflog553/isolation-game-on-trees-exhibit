import FullCanonical05Rows06
namespace IsolationGame.FullCanonical.T05
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_28 : Finset (Fin 16) := {2,3}
theorem after_28_0 : Marked.gameValue original marks_28 .dominator {0}=4 ∧ Marked.gameValue original marks_28 .staller {0}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_28 marks_16 0 4 4 (by decide +kernel) row_16
theorem after_28_1 : Marked.gameValue original marks_28 .dominator {1}=5 ∧ Marked.gameValue original marks_28 .staller {1}=5 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_28 marks_26 1 5 5 (by decide +kernel) row_26
theorem after_28_2 : Marked.gameValue original marks_28 .dominator {2}=5 ∧ Marked.gameValue original marks_28 .staller {2}=6 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_28 marks_27 2 5 6 (by decide +kernel) row_27
theorem after_28_4 : Marked.gameValue original marks_28 .dominator {4}=4 ∧ Marked.gameValue original marks_28 .staller {4}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_28 marks_20 4 4 4 (by decide +kernel) row_20
theorem after_28_5 : Marked.gameValue original marks_28 .dominator {5}=4 ∧ Marked.gameValue original marks_28 .staller {5}=5 :=
  FullCanonicalDAG.transport_perm original perm_7 adjacency_7 marks_28 marks_24 5 4 5 (by decide +kernel) row_24
theorem after_28_6 : Marked.gameValue original marks_28 .dominator {6}=4 ∧ Marked.gameValue original marks_28 .staller {6}=5 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_28 marks_25 6 4 5 (by decide +kernel) row_25
theorem after_28_7 : Marked.gameValue original marks_28 .dominator {7}=4 ∧ Marked.gameValue original marks_28 .staller {7}=4 :=
  FullCanonicalDAG.transport_perm original perm_4 adjacency_4 marks_28 marks_20 7 4 4 (by decide +kernel) row_20
theorem after_28_8 : Marked.gameValue original marks_28 .dominator {8}=4 ∧ Marked.gameValue original marks_28 .staller {8}=5 :=
  FullCanonicalDAG.transport_perm original perm_8 adjacency_8 marks_28 marks_24 8 4 5 (by decide +kernel) row_24
theorem after_28_9 : Marked.gameValue original marks_28 .dominator {9}=4 ∧ Marked.gameValue original marks_28 .staller {9}=5 :=
  FullCanonicalDAG.transport_perm original perm_4 adjacency_4 marks_28 marks_25 9 4 5 (by decide +kernel) row_25
theorem after_28_10 : Marked.gameValue original marks_28 .dominator {10}=4 ∧ Marked.gameValue original marks_28 .staller {10}=4 :=
  FullCanonicalDAG.transport_perm original perm_5 adjacency_5 marks_28 marks_20 10 4 4 (by decide +kernel) row_20
theorem after_28_11 : Marked.gameValue original marks_28 .dominator {11}=4 ∧ Marked.gameValue original marks_28 .staller {11}=5 :=
  FullCanonicalDAG.transport_perm original perm_9 adjacency_9 marks_28 marks_24 11 4 5 (by decide +kernel) row_24
theorem after_28_12 : Marked.gameValue original marks_28 .dominator {12}=4 ∧ Marked.gameValue original marks_28 .staller {12}=5 :=
  FullCanonicalDAG.transport_perm original perm_5 adjacency_5 marks_28 marks_25 12 4 5 (by decide +kernel) row_25
theorem after_28_13 : Marked.gameValue original marks_28 .dominator {13}=4 ∧ Marked.gameValue original marks_28 .staller {13}=4 :=
  FullCanonicalDAG.transport_perm original perm_6 adjacency_6 marks_28 marks_20 13 4 4 (by decide +kernel) row_20
theorem after_28_14 : Marked.gameValue original marks_28 .dominator {14}=4 ∧ Marked.gameValue original marks_28 .staller {14}=5 :=
  FullCanonicalDAG.transport_perm original perm_10 adjacency_10 marks_28 marks_24 14 4 5 (by decide +kernel) row_24
theorem after_28_15 : Marked.gameValue original marks_28 .dominator {15}=4 ∧ Marked.gameValue original marks_28 .staller {15}=5 :=
  FullCanonicalDAG.transport_perm original perm_6 adjacency_6 marks_28 marks_25 15 4 5 (by decide +kernel) row_25
theorem row_28 : Marked.gameValue original marks_28 .dominator ∅=5 ∧ Marked.gameValue original marks_28 .staller ∅=6 := by
  apply LocalProfile.DAG.bellman original marks_28 5 6 0 1 (by decide +kernel) (by decide +kernel)
  · rw [after_28_0.2]
  · rw [after_28_1.1]
  · intro v hv
    fin_cases v
    · have h := after_28_0
      change 5 ≤ 1+Marked.gameValue original marks_28 .staller {0} ∧ 1+Marked.gameValue original marks_28 .dominator {0} ≤ 6
      omega
    · have h := after_28_1
      change 5 ≤ 1+Marked.gameValue original marks_28 .staller {1} ∧ 1+Marked.gameValue original marks_28 .dominator {1} ≤ 6
      omega
    · have h := after_28_2
      change 5 ≤ 1+Marked.gameValue original marks_28 .staller {2} ∧ 1+Marked.gameValue original marks_28 .dominator {2} ≤ 6
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_28 ∅ 3) hv)
    · have h := after_28_4
      change 5 ≤ 1+Marked.gameValue original marks_28 .staller {4} ∧ 1+Marked.gameValue original marks_28 .dominator {4} ≤ 6
      omega
    · have h := after_28_5
      change 5 ≤ 1+Marked.gameValue original marks_28 .staller {5} ∧ 1+Marked.gameValue original marks_28 .dominator {5} ≤ 6
      omega
    · have h := after_28_6
      change 5 ≤ 1+Marked.gameValue original marks_28 .staller {6} ∧ 1+Marked.gameValue original marks_28 .dominator {6} ≤ 6
      omega
    · have h := after_28_7
      change 5 ≤ 1+Marked.gameValue original marks_28 .staller {7} ∧ 1+Marked.gameValue original marks_28 .dominator {7} ≤ 6
      omega
    · have h := after_28_8
      change 5 ≤ 1+Marked.gameValue original marks_28 .staller {8} ∧ 1+Marked.gameValue original marks_28 .dominator {8} ≤ 6
      omega
    · have h := after_28_9
      change 5 ≤ 1+Marked.gameValue original marks_28 .staller {9} ∧ 1+Marked.gameValue original marks_28 .dominator {9} ≤ 6
      omega
    · have h := after_28_10
      change 5 ≤ 1+Marked.gameValue original marks_28 .staller {10} ∧ 1+Marked.gameValue original marks_28 .dominator {10} ≤ 6
      omega
    · have h := after_28_11
      change 5 ≤ 1+Marked.gameValue original marks_28 .staller {11} ∧ 1+Marked.gameValue original marks_28 .dominator {11} ≤ 6
      omega
    · have h := after_28_12
      change 5 ≤ 1+Marked.gameValue original marks_28 .staller {12} ∧ 1+Marked.gameValue original marks_28 .dominator {12} ≤ 6
      omega
    · have h := after_28_13
      change 5 ≤ 1+Marked.gameValue original marks_28 .staller {13} ∧ 1+Marked.gameValue original marks_28 .dominator {13} ≤ 6
      omega
    · have h := after_28_14
      change 5 ≤ 1+Marked.gameValue original marks_28 .staller {14} ∧ 1+Marked.gameValue original marks_28 .dominator {14} ≤ 6
      omega
    · have h := after_28_15
      change 5 ≤ 1+Marked.gameValue original marks_28 .staller {15} ∧ 1+Marked.gameValue original marks_28 .dominator {15} ≤ 6
      omega
def marks_29 : Finset (Fin 16) := {}
theorem after_29_0 : Marked.gameValue original marks_29 .dominator {0}=5 ∧ Marked.gameValue original marks_29 .staller {0}=5 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_29 marks_21 0 5 5 (by decide +kernel) row_21
theorem after_29_1 : Marked.gameValue original marks_29 .dominator {1}=5 ∧ Marked.gameValue original marks_29 .staller {1}=5 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_29 marks_26 1 5 5 (by decide +kernel) row_26
theorem after_29_2 : Marked.gameValue original marks_29 .dominator {2}=5 ∧ Marked.gameValue original marks_29 .staller {2}=6 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_29 marks_27 2 5 6 (by decide +kernel) row_27
theorem after_29_3 : Marked.gameValue original marks_29 .dominator {3}=5 ∧ Marked.gameValue original marks_29 .staller {3}=6 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_29 marks_28 3 5 6 (by decide +kernel) row_28
theorem after_29_4 : Marked.gameValue original marks_29 .dominator {4}=5 ∧ Marked.gameValue original marks_29 .staller {4}=5 :=
  FullCanonicalDAG.transport_perm original perm_7 adjacency_7 marks_29 marks_26 4 5 5 (by decide +kernel) row_26
theorem after_29_5 : Marked.gameValue original marks_29 .dominator {5}=5 ∧ Marked.gameValue original marks_29 .staller {5}=6 :=
  FullCanonicalDAG.transport_perm original perm_7 adjacency_7 marks_29 marks_27 5 5 6 (by decide +kernel) row_27
theorem after_29_6 : Marked.gameValue original marks_29 .dominator {6}=5 ∧ Marked.gameValue original marks_29 .staller {6}=6 :=
  FullCanonicalDAG.transport_perm original perm_7 adjacency_7 marks_29 marks_28 6 5 6 (by decide +kernel) row_28
theorem after_29_7 : Marked.gameValue original marks_29 .dominator {7}=5 ∧ Marked.gameValue original marks_29 .staller {7}=5 :=
  FullCanonicalDAG.transport_perm original perm_8 adjacency_8 marks_29 marks_26 7 5 5 (by decide +kernel) row_26
theorem after_29_8 : Marked.gameValue original marks_29 .dominator {8}=5 ∧ Marked.gameValue original marks_29 .staller {8}=6 :=
  FullCanonicalDAG.transport_perm original perm_8 adjacency_8 marks_29 marks_27 8 5 6 (by decide +kernel) row_27
theorem after_29_9 : Marked.gameValue original marks_29 .dominator {9}=5 ∧ Marked.gameValue original marks_29 .staller {9}=6 :=
  FullCanonicalDAG.transport_perm original perm_8 adjacency_8 marks_29 marks_28 9 5 6 (by decide +kernel) row_28
theorem after_29_10 : Marked.gameValue original marks_29 .dominator {10}=5 ∧ Marked.gameValue original marks_29 .staller {10}=5 :=
  FullCanonicalDAG.transport_perm original perm_9 adjacency_9 marks_29 marks_26 10 5 5 (by decide +kernel) row_26
theorem after_29_11 : Marked.gameValue original marks_29 .dominator {11}=5 ∧ Marked.gameValue original marks_29 .staller {11}=6 :=
  FullCanonicalDAG.transport_perm original perm_9 adjacency_9 marks_29 marks_27 11 5 6 (by decide +kernel) row_27
theorem after_29_12 : Marked.gameValue original marks_29 .dominator {12}=5 ∧ Marked.gameValue original marks_29 .staller {12}=6 :=
  FullCanonicalDAG.transport_perm original perm_9 adjacency_9 marks_29 marks_28 12 5 6 (by decide +kernel) row_28
theorem after_29_13 : Marked.gameValue original marks_29 .dominator {13}=5 ∧ Marked.gameValue original marks_29 .staller {13}=5 :=
  FullCanonicalDAG.transport_perm original perm_10 adjacency_10 marks_29 marks_26 13 5 5 (by decide +kernel) row_26
theorem after_29_14 : Marked.gameValue original marks_29 .dominator {14}=5 ∧ Marked.gameValue original marks_29 .staller {14}=6 :=
  FullCanonicalDAG.transport_perm original perm_10 adjacency_10 marks_29 marks_27 14 5 6 (by decide +kernel) row_27
theorem after_29_15 : Marked.gameValue original marks_29 .dominator {15}=5 ∧ Marked.gameValue original marks_29 .staller {15}=6 :=
  FullCanonicalDAG.transport_perm original perm_10 adjacency_10 marks_29 marks_28 15 5 6 (by decide +kernel) row_28
theorem row_29 : Marked.gameValue original marks_29 .dominator ∅=6 ∧ Marked.gameValue original marks_29 .staller ∅=6 := by
  apply LocalProfile.DAG.bellman original marks_29 6 6 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_29_0.2]
  · rw [after_29_0.1]
  · intro v hv
    fin_cases v
    · have h := after_29_0
      change 6 ≤ 1+Marked.gameValue original marks_29 .staller {0} ∧ 1+Marked.gameValue original marks_29 .dominator {0} ≤ 6
      omega
    · have h := after_29_1
      change 6 ≤ 1+Marked.gameValue original marks_29 .staller {1} ∧ 1+Marked.gameValue original marks_29 .dominator {1} ≤ 6
      omega
    · have h := after_29_2
      change 6 ≤ 1+Marked.gameValue original marks_29 .staller {2} ∧ 1+Marked.gameValue original marks_29 .dominator {2} ≤ 6
      omega
    · have h := after_29_3
      change 6 ≤ 1+Marked.gameValue original marks_29 .staller {3} ∧ 1+Marked.gameValue original marks_29 .dominator {3} ≤ 6
      omega
    · have h := after_29_4
      change 6 ≤ 1+Marked.gameValue original marks_29 .staller {4} ∧ 1+Marked.gameValue original marks_29 .dominator {4} ≤ 6
      omega
    · have h := after_29_5
      change 6 ≤ 1+Marked.gameValue original marks_29 .staller {5} ∧ 1+Marked.gameValue original marks_29 .dominator {5} ≤ 6
      omega
    · have h := after_29_6
      change 6 ≤ 1+Marked.gameValue original marks_29 .staller {6} ∧ 1+Marked.gameValue original marks_29 .dominator {6} ≤ 6
      omega
    · have h := after_29_7
      change 6 ≤ 1+Marked.gameValue original marks_29 .staller {7} ∧ 1+Marked.gameValue original marks_29 .dominator {7} ≤ 6
      omega
    · have h := after_29_8
      change 6 ≤ 1+Marked.gameValue original marks_29 .staller {8} ∧ 1+Marked.gameValue original marks_29 .dominator {8} ≤ 6
      omega
    · have h := after_29_9
      change 6 ≤ 1+Marked.gameValue original marks_29 .staller {9} ∧ 1+Marked.gameValue original marks_29 .dominator {9} ≤ 6
      omega
    · have h := after_29_10
      change 6 ≤ 1+Marked.gameValue original marks_29 .staller {10} ∧ 1+Marked.gameValue original marks_29 .dominator {10} ≤ 6
      omega
    · have h := after_29_11
      change 6 ≤ 1+Marked.gameValue original marks_29 .staller {11} ∧ 1+Marked.gameValue original marks_29 .dominator {11} ≤ 6
      omega
    · have h := after_29_12
      change 6 ≤ 1+Marked.gameValue original marks_29 .staller {12} ∧ 1+Marked.gameValue original marks_29 .dominator {12} ≤ 6
      omega
    · have h := after_29_13
      change 6 ≤ 1+Marked.gameValue original marks_29 .staller {13} ∧ 1+Marked.gameValue original marks_29 .dominator {13} ≤ 6
      omega
    · have h := after_29_14
      change 6 ≤ 1+Marked.gameValue original marks_29 .staller {14} ∧ 1+Marked.gameValue original marks_29 .dominator {14} ≤ 6
      omega
    · have h := after_29_15
      change 6 ≤ 1+Marked.gameValue original marks_29 .staller {15} ∧ 1+Marked.gameValue original marks_29 .dominator {15} ≤ 6
      omega
end IsolationGame.FullCanonical.T05
