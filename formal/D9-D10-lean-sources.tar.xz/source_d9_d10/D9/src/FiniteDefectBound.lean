import BranchTypeAssignment

namespace IsolationGame.NecessaryCore
open CanonicalLocal
variable {A : Type} [DecidableEq A]

def strictCount (f : A→Index) (I : Finset A) : Nat :=
  (I.filter (fun a=>pairable (f a)=true)).card

def nonstrictCount (f : A→Index) (I : Finset A) : Nat :=
  (I.filter (fun a=>f a≠.t02 ∧ pairable (f a)=false)).card

/-- Uniform finite defect bound from the fully checked twenty-profile
catalogue. Ordinary branches contribute zero and are not counted. -/
theorem finite_defect_bound (f : A→Index) (I : Finset A) :
    (∑a∈I,defect (f a))≤2*(strictCount f I : Int)-2*(nonstrictCount f I : Int) := by
  induction I using Finset.induction_on with
  | empty => simp [strictCount,nonstrictCount]
  | @insert a I ha ih =>
    rw [Finset.sum_insert ha]
    cases hf : f a <;>
      simp [strictCount,nonstrictCount,Finset.filter_insert,ha,hf,pairable,defect,expectedS,size] at * <;> omega

#print axioms finite_defect_bound
end IsolationGame.NecessaryCore
