import FullCanonical12
import StrictCapacityWhiteTransport

namespace IsolationGame.FullCanonical.T12
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

/-- Full t12 really has D=3, although its S value is four. -/
theorem weak_D_upper : Marked.gameValue original ∅ .dominator ∅≤3 := full_values.1.le

theorem weak_bad_legal : Marked.Legal original ∅ ∅ (8 : Fin 9) := by decide +kernel

theorem weak_normal_follower_S (v : Fin 9) (hv : v≠8) :
    Marked.gameValue original ∅ .staller {v}≤3 := by
  fin_cases v
  · change Marked.gameValue original marks_17 .staller {0}≤3
    rw [after_17_0.2] <;> decide
  · change Marked.gameValue original marks_17 .staller {1}≤3
    rw [after_17_1.2] <;> decide
  · change Marked.gameValue original marks_17 .staller {2}≤3
    rw [after_17_2.2] <;> decide
  · change Marked.gameValue original marks_17 .staller {3}≤3
    rw [after_17_3.2] <;> decide
  · change Marked.gameValue original marks_17 .staller {4}≤3
    rw [after_17_4.2] <;> decide
  · change Marked.gameValue original marks_17 .staller {5}≤3
    rw [after_17_5.2] <;> decide
  · change Marked.gameValue original marks_17 .staller {6}≤3
    rw [after_17_6.2] <;> decide
  · change Marked.gameValue original marks_17 .staller {7}≤3
    rw [after_17_7.2] <;> decide
  · exact False.elim (hv rfl)

theorem weak_bad_follower_S : Marked.gameValue original ∅ .staller {(8 : Fin 9)}=4 :=
  after_17_8.2

/-- D's reply is legal on the unchanged original nine-vertex graph. -/
theorem weak_bad_reply_legal : Marked.Legal original ∅ {(8 : Fin 9)} 1 := by decide +kernel

/-- The normalized state still has original blue vertex zero available. -/
theorem weak_reply_normalized_strict : MarkedSum.StrictCapacity original marks_5 ∅ 2 := by
  constructor
  · rw [row_5.1] <;> decide
  · intro v hv
    fin_cases v
    · change Marked.gameValue original marks_5 .staller {0}+1≤2
      rw [after_5_0.2] <;> decide
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 3) hv)
    · change Marked.gameValue original marks_5 .staller {4}+1≤2
      rw [after_5_4.2] <;> decide
    · change Marked.gameValue original marks_5 .staller {5}+1≤2
      rw [after_5_5.2] <;> decide
    · change Marked.gameValue original marks_5 .staller {6}+1≤2
      rw [after_5_6.2] <;> decide
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 7) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 8) hv)

/-- Exact white transport includes every legal follower at every original
vertex, rather than inferring strictness from only the displayed D/S values. -/
theorem weak_bad_reply_strict :
    MarkedSum.StrictCapacity original ∅ {(1 : Fin 9),8} 2 :=
  (MarkedSum.strictCapacity_iff_of_white_iff original ∅ marks_5 {(1 : Fin 9),8} ∅ 2
    (by decide +kernel)).mpr weak_reply_normalized_strict

theorem weak_bad_reply_values :
    Marked.gameValue original ∅ .dominator {(1 : Fin 9),8}=1 ∧
    Marked.gameValue original ∅ .staller {(1 : Fin 9),8}=2 := by
  constructor
  · exact (Marked.value_eq_of_white_eq original ∅ marks_5 {(1 : Fin 9),8} ∅ .dominator
      (by decide +kernel)).trans row_5.1
  · exact (Marked.value_eq_of_white_eq original ∅ marks_5 {(1 : Fin 9),8} ∅ .staller
      (by decide +kernel)).trans row_5.2

#print axioms weak_D_upper
#print axioms weak_bad_legal
#print axioms weak_normal_follower_S
#print axioms weak_bad_follower_S
#print axioms weak_bad_reply_legal
#print axioms weak_reply_normalized_strict
#print axioms weak_bad_reply_strict
#print axioms weak_bad_reply_values
end IsolationGame.FullCanonical.T12
