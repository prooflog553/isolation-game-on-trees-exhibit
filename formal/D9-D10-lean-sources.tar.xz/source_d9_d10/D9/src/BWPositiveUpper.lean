import BWArmBounds
import BWLeftMiddle
import BWLiteralFirstRows

/-!
The positive-parameter upper bound for the literal finite BW graph.

All first moves are covered on the structured vertex type, before transporting
the empty-history value to the literal `Fin (2 + 7 * (p + q))` graph.  The
parameters remain arbitrary natural numbers throughout.
-/

namespace IsolationGame.BWBridge

/-- Every vertex of the original BW graph has a bounded D-start follower.
This statement also covers any vertex whose first move would be illegal; the
Staller Bellman step below uses it only for legal first moves. -/
theorem first_move_D_bound (p q : Nat) (hp : 1 ≤ p) (hq : 1 ≤ q)
    (v : Vertex p q) :
    Marked.gameValue (original p q) (marks p q) .dominator {v} ≤ 3 * (p + q) := by
  cases v with
  | inl v =>
    cases v with
    | gate o =>
      cases o with
      | none => exact left_center_D_bound p q hq
      | some i => exact left_middle_D_bound p q hp hq i
    | b j =>
      obtain ⟨i, s⟩ := j
      exact left_arm_D_bound p q hp hq i .b s
    | c j =>
      obtain ⟨i, s⟩ := j
      exact left_arm_D_bound p q hp hq i .c s
    | d j =>
      obtain ⟨i, s⟩ := j
      exact left_arm_D_bound p q hp hq i .d s
  | inr v =>
    cases v with
    | gate o =>
      cases o with
      | none => exact right_center_D_bound p q hp hq
      | some i => exact right_middle_D_bound p q hp hq i
    | b j =>
      obtain ⟨i, s⟩ := j
      exact right_arm_D_bound p q hp hq i .b s
    | c j =>
      obtain ⟨i, s⟩ := j
      exact right_arm_D_bound p q hp hq i .c s
    | d j =>
      obtain ⟨i, s⟩ := j
      exact right_arm_D_bound p q hp hq i .d s

/-- The Bellman upper bound on the unchanged original marked BW graph. -/
theorem positive_S_upper_bound (p q : Nat) (hp : 1 ≤ p) (hq : 1 ≤ q) :
    Marked.gameValue (original p q) (marks p q) .staller ∅ ≤ 3 * (p + q) + 1 := by
  apply (Marked.gameValue_le_iff (original p q) (marks p q) .staller ∅ _).mpr
  apply Or.inr
  intro v _
  apply (Marked.gameValue_le_iff (original p q) (marks p q) .dominator
    (insert v ∅) (3 * (p + q))).mp
  simpa only [Finset.insert_empty] using first_move_D_bound p q hp hq v

end IsolationGame.BWBridge

namespace IsolationGame.LiteralBW

/-- The upper bound for the literal original graph, with only `x` marked and
an empty selected set, for all positive parameters. -/
theorem positive_S_upper_bound (p q : Nat) (hp : 1 ≤ p) (hq : 1 ≤ q) :
    Marked.gameValue (graph p q) (marks p q) .staller ∅ ≤ 3 * (p + q) + 1 := by
  have h := (bridge_value p q ∅ .staller).trans_le
    (BWBridge.positive_S_upper_bound p q hp hq)
  simpa only [Finset.image_empty] using h

/-- A proof of the exact requested literal BW proposition. -/
theorem positive_upper_contract : PositiveUpperContract := by
  intro p q hp hq
  exact positive_S_upper_bound p q hp hq

#print axioms positive_S_upper_bound
#print axioms positive_upper_contract

end IsolationGame.LiteralBW
