import ActualTreeCoreAssembly
import OriginalIsoTransport
import PartitionGeometry

/-!
Candidate generated 2026-10-19. Verification status is recorded in native receipts.
An actual original tree is assembled into a joined pair of unrestricted
literal cores. This module has no minimality or game-value assumptions.
-/
namespace IsolationGame.ActualCoreAssembly
open CanonicalLocal ActualRootBranches SmallPiece IsolatedRestriction PartitionBridge
variable {V : Type} [Fintype V] [DecidableEq V]

/-- Reverse the exact one-bridge adjacency condition. -/
theorem oneBridge_reverse (G : SimpleGraph V) (A : Finset V) (r s : V)
    (hcut : OneBridge G A r s) : OneBridge G (outside A) s r := by
  classical
  intro u v hu hv
  have huA : u∉A := (Finset.mem_sdiff.mp hu).2
  have hvA : v∈A := by simpa [outside] using hv
  constructor
  · intro huv
    exact ((hcut v u hvA huA).mp huv.symm).symm
  · intro h
    exact ((hcut v u hvA huA).mpr ⟨h.2,h.1⟩).symm

/-- Glue any two full rooted half-isomorphisms across the actual bridge.
The output records both actual central endpoints and all adjacency. -/
theorem assemble_one_bridge_of_halves (G : SimpleGraph V) (A : Finset V) (r s : V)
    (hr : r∈A) (hs : s∉A) (hcut : OneBridge G A r s)
    (xs ys : List Nat)
    (hleft : RootedAssembly.RootedIso (induced G A) ⟨r,hr⟩ (CoreFamily.graph xs 0) none)
    (hright : RootedAssembly.RootedIso (induced G (outside A))
      ⟨s,by simp [outside,hs]⟩ (CoreFamily.graph ys 0) none) :
    ∃e : G ≃g Attachment.original (CoreFamily.graph xs 0) (CoreFamily.graph ys 0) none none,
      e r = .inl none ∧ e s = .inr none := by
  classical
  let eL := OriginalIsoTransport.ofRootedIso _ _ _ _ hleft
  let eR := OriginalIsoTransport.ofRootedIso _ _ _ _ hright
  have heL : eL ⟨r,hr⟩ = none := OriginalIsoTransport.ofRootedIso_root _ _ _ _ hleft
  have heR : eR ⟨s,by simp [outside,hs]⟩ = none :=
    OriginalIsoTransport.ofRootedIso_root _ _ _ _ hright
  let j := OriginalIsoTransport.attachmentIso
    (induced G A) (induced G (outside A)) (CoreFamily.graph xs 0) (CoreFamily.graph ys 0)
    ⟨r,hr⟩ ⟨s,by simp [outside,hs]⟩ none none eL eR heL heR
  let e := (OriginalIsoTransport.partitionIso G A r s hr hs hcut).trans j
  refine ⟨e,?_,?_⟩
  · change j (splitEquiv A r) = .inl none
    rw [split_left A r hr]
    change Sum.inl (eL ⟨r,hr⟩) = .inl none
    rw [heL]
  · change j (splitEquiv A s) = .inr none
    rw [split_right A s hs]
    change Sum.inr (eR ⟨s,by simp [outside,hs]⟩) = .inr none
    rw [heR]

/-- Actual-tree to unrestricted literal two-core family. Canonical coverage
is supplied only for the actual root-neighbor components of the two halves. -/
theorem assemble_one_bridge_core_family (G : SimpleGraph V) (hG : G.IsTree)
    (A : Finset V) (r s : V) (hr : r∈A) (hs : s∉A) (hcut : OneBridge G A r s)
    (hleft : ∀a : Child (induced G A) ⟨r,hr⟩, ∃t : Index,
      RootedAssembly.RootedIso
        (outerGraph (induced G A) ⟨r,hr⟩ a) (outerRoot (induced G A) ⟨r,hr⟩ a)
        (CanonicalLocal.graph t) (root t))
    (hright : ∀a : Child (induced G (outside A)) ⟨s,by simp [outside,hs]⟩, ∃t : Index,
      RootedAssembly.RootedIso
        (outerGraph (induced G (outside A)) ⟨s,by simp [outside,hs]⟩ a)
        (outerRoot (induced G (outside A)) ⟨s,by simp [outside,hs]⟩ a)
        (CanonicalLocal.graph t) (root t)) :
    ∃xs ys : List Nat,
      ∃e : G ≃g Attachment.original (CoreFamily.graph xs 0) (CoreFamily.graph ys 0) none none,
        e r = .inl none ∧ e s = .inr none := by
  classical
  have hTA := retained_tree G hG A r s hr hcut
  have hsB : s∈outside A := by simp [outside,hs]
  have hTB := retained_tree G hG (outside A) s r hsB (oneBridge_reverse G A r s hcut)
  obtain ⟨xs,_,hxs⟩ := CoreFamily.assemble_core_family (induced G A) hTA ⟨r,hr⟩ hleft
  obtain ⟨ys,_,hys⟩ := CoreFamily.assemble_core_family (induced G (outside A)) hTB
    ⟨s,hsB⟩ hright
  obtain ⟨e,her,hes⟩ := assemble_one_bridge_of_halves G A r s hr hs hcut xs ys hxs hys
  exact ⟨xs,ys,e,her,hes⟩

/-- The same isomorphism transports the original game's arbitrary marked
states and histories, without any loss of original legal actions. -/
theorem assembled_gameValue (G : SimpleGraph V) (xs ys : List Nat)
    (e : G ≃g Attachment.original (CoreFamily.graph xs 0) (CoreFamily.graph ys 0) none none)
    (M X : Finset V) (p : Player) :
    Marked.gameValue
      (Attachment.original (CoreFamily.graph xs 0) (CoreFamily.graph ys 0) none none)
      (M.image e) p (X.image e) = Marked.gameValue G M p X :=
  OriginalIsoTransport.marked_gameValue G _ e M X p

/-- In particular the two original unmarked isolation numbers are equal. -/
theorem assembled_isolationNumber (G : SimpleGraph V) (xs ys : List Nat)
    (e : G ≃g Attachment.original (CoreFamily.graph xs 0) (CoreFamily.graph ys 0) none none) :
    isolationNumber G = isolationNumber
      (Attachment.original (CoreFamily.graph xs 0) (CoreFamily.graph ys 0) none none) :=
  OriginalIsoTransport.isolationNumber_eq G _ e

#print axioms oneBridge_reverse
#print axioms assemble_one_bridge_of_halves
#print axioms assemble_one_bridge_core_family
#print axioms assembled_gameValue
#print axioms assembled_isolationNumber
end IsolationGame.ActualCoreAssembly
