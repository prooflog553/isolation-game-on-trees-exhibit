import FullCanonical07Rows03
namespace IsolationGame.FullCanonical.T07
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_16 : Finset (Fin 8) := {}
theorem after_16_0 : Marked.gameValue original marks_16 .dominator {0}=2 ∧ Marked.gameValue original marks_16 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_9 0 2 2 (by decide +kernel) row_9
theorem after_16_1 : Marked.gameValue original marks_16 .dominator {1}=1 ∧ Marked.gameValue original marks_16 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_11 1 1 2 (by decide +kernel) row_11
theorem after_16_2 : Marked.gameValue original marks_16 .dominator {2}=1 ∧ Marked.gameValue original marks_16 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_12 2 1 2 (by decide +kernel) row_12
theorem after_16_3 : Marked.gameValue original marks_16 .dominator {3}=1 ∧ Marked.gameValue original marks_16 .staller {3}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_15 3 1 2 (by decide +kernel) row_15
theorem after_16_4 : Marked.gameValue original marks_16 .dominator {4}=1 ∧ Marked.gameValue original marks_16 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_5 4 1 2 (by decide +kernel) row_5
theorem after_16_5 : Marked.gameValue original marks_16 .dominator {5}=1 ∧ Marked.gameValue original marks_16 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_7 5 1 2 (by decide +kernel) row_7
theorem after_16_6 : Marked.gameValue original marks_16 .dominator {6}=2 ∧ Marked.gameValue original marks_16 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_14 6 2 2 (by decide +kernel) row_14
theorem after_16_7 : Marked.gameValue original marks_16 .dominator {7}=2 ∧ Marked.gameValue original marks_16 .staller {7}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_13 7 2 3 (by decide +kernel) row_13
theorem row_16 : Marked.gameValue original marks_16 .dominator ∅=3 ∧ Marked.gameValue original marks_16 .staller ∅=3 := by
  apply LocalProfile.DAG.bellman original marks_16 3 3 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_16_0.2]
  · rw [after_16_0.1]
  · intro v hv
    fin_cases v
    · have h := after_16_0
      change 3 ≤ 1+Marked.gameValue original marks_16 .staller {0} ∧ 1+Marked.gameValue original marks_16 .dominator {0} ≤ 3
      omega
    · have h := after_16_1
      change 3 ≤ 1+Marked.gameValue original marks_16 .staller {1} ∧ 1+Marked.gameValue original marks_16 .dominator {1} ≤ 3
      omega
    · have h := after_16_2
      change 3 ≤ 1+Marked.gameValue original marks_16 .staller {2} ∧ 1+Marked.gameValue original marks_16 .dominator {2} ≤ 3
      omega
    · have h := after_16_3
      change 3 ≤ 1+Marked.gameValue original marks_16 .staller {3} ∧ 1+Marked.gameValue original marks_16 .dominator {3} ≤ 3
      omega
    · have h := after_16_4
      change 3 ≤ 1+Marked.gameValue original marks_16 .staller {4} ∧ 1+Marked.gameValue original marks_16 .dominator {4} ≤ 3
      omega
    · have h := after_16_5
      change 3 ≤ 1+Marked.gameValue original marks_16 .staller {5} ∧ 1+Marked.gameValue original marks_16 .dominator {5} ≤ 3
      omega
    · have h := after_16_6
      change 3 ≤ 1+Marked.gameValue original marks_16 .staller {6} ∧ 1+Marked.gameValue original marks_16 .dominator {6} ≤ 3
      omega
    · have h := after_16_7
      change 3 ≤ 1+Marked.gameValue original marks_16 .staller {7} ∧ 1+Marked.gameValue original marks_16 .dominator {7} ≤ 3
      omega
end IsolationGame.FullCanonical.T07
