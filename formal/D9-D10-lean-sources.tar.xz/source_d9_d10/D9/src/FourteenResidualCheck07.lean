import FourteenResidualData

/-! Finite kernel arithmetic only: first profile fixed to t07.
All arithmetic is checked by kernel reduction; no graph or history search. -/
namespace IsolationGame.FourteenResidual
open CanonicalLocal
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

theorem check11_t07 (b : Index) :
    NumericResidual [.t07] [b] → MatchesFourteen [.t07] [b] := by
  cases b <;> decide +kernel

theorem check12_t07 (b c : Index) :
    NumericResidual [.t07] [b, c] → MatchesFourteen [.t07] [b, c] := by
  cases b <;> cases c <;> decide +kernel

#print axioms check11_t07
#print axioms check12_t07
end IsolationGame.FourteenResidual
