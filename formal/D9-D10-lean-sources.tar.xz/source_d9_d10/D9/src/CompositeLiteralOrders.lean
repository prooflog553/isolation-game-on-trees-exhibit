import TwoCoreOpeningArithmetic

/-!
SOURCE_ONLY / NOT ELABORATED / NOT NATIVE / NOT ACCEPTED.
This candidate has no Lean result. Pending source providers are not accepted
objects. The corresponding dependency gate must open before any future build.
No slot was requested, acquired, or used in preparing this source.
-/
namespace IsolationGame.CompositeOuterRootApplications
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

/-- Exact original carrier orders and ordinary ceiling identities.
No positivity condition is imposed on either ordinary pool. -/
theorem r10_order (p q : Nat) :
    Fintype.card (TwoCoreOpening.Vertex [8] [8,8] p q) = 35+7*(p+q) := by
  have h := TwoCoreOpening.carrier_order [8] [8,8] p q
  simpa [TwoCoreOpening.localSizeSum,NecessaryCore.decode,CanonicalLocal.size] using h

theorem r10_ceil_identity (p q : Nat) :
    (3*Fintype.card (TwoCoreOpening.Vertex [8] [8,8] p q)+6)/7 = 15+3*(p+q) := by
  rw [r10_order]
  omega

theorem r12_order (p q : Nat) :
    Fintype.card (TwoCoreOpening.Vertex [15] [3,15] p q) = 28+7*(p+q) := by
  have h := TwoCoreOpening.carrier_order [15] [3,15] p q
  simpa [TwoCoreOpening.localSizeSum,NecessaryCore.decode,CanonicalLocal.size] using h

theorem r12_ceil_identity (p q : Nat) :
    (3*Fintype.card (TwoCoreOpening.Vertex [15] [3,15] p q)+6)/7 = 12+3*(p+q) := by
  rw [r12_order]
  omega

theorem r13_order (p q : Nat) :
    Fintype.card (TwoCoreOpening.Vertex [15] [10,15] p q) = 21+7*(p+q) := by
  have h := TwoCoreOpening.carrier_order [15] [10,15] p q
  simpa [TwoCoreOpening.localSizeSum,NecessaryCore.decode,CanonicalLocal.size] using h

theorem r13_ceil_identity (p q : Nat) :
    (3*Fintype.card (TwoCoreOpening.Vertex [15] [10,15] p q)+6)/7 = 9+3*(p+q) := by
  rw [r13_order]
  omega


#print axioms r10_order
#print axioms r10_ceil_identity
#print axioms r12_order
#print axioms r12_ceil_identity
#print axioms r13_order
#print axioms r13_ceil_identity

end IsolationGame.CompositeOuterRootApplications
