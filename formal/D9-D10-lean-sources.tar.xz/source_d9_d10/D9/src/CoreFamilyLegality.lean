import CoreFamilyWhite

namespace IsolationGame.CoreFamilySemantics
open CanonicalLocal CoreFamily Isolation.Graph
variable (xs : List Nat) (p : Nat)

theorem closed_root (i : Fin (xs.length+p)) (v : Fin (size (label xs p i))) :
    (GuardedEdge.view (CoreFamily.graph xs p)).closed none (some ⟨i,v⟩) ↔ v=root (label xs p i) := by
  simpa [closed,GuardedEdge.view] using root_adj xs p i v

theorem closed_same (i : Fin (xs.length+p)) (u v : Fin (size (label xs p i))) :
    (GuardedEdge.view (CoreFamily.graph xs p)).closed (some ⟨i,u⟩) (some ⟨i,v⟩) ↔
      (GuardedEdge.view (CanonicalLocal.graph (label xs p i))).closed u v := by
  simp only [closed,Option.some.injEq,Sigma.mk.inj_iff,heq_eq_eq,true_and,GuardedEdge.view]
  rw [same_adj]

theorem not_closed_distinct (i j : Fin (xs.length+p)) (hij : i≠j)
    (u : Fin (size (label xs p i))) (v : Fin (size (label xs p j))) :
    ¬(GuardedEdge.view (CoreFamily.graph xs p)).closed (some ⟨i,u⟩) (some ⟨j,v⟩) := by
  rintro (he|ha)
  · have h := congrArg (fun x : Vertex xs p=>x.map Sigma.fst) he
    exact hij (Option.some.inj h)
  · exact distinct_no_adj xs p i j hij u v ha

theorem legal_root (W : LocalWhite xs p) :
    (GuardedEdge.view (CoreFamily.graph xs p)).legal (white xs p W) none ↔
      ∃i,W i (root (label xs p i)) := by
  constructor
  · rintro ⟨w,hw,hc⟩
    cases w with
    | none => exact False.elim hw
    | some w =>
      obtain ⟨i,v⟩ := w
      have he := (closed_root xs p i v).mp hc
      subst v
      exact ⟨i,hw⟩
  · rintro ⟨i,hi⟩
    exact ⟨some ⟨i,root (label xs p i)⟩,hi,(closed_root xs p i _).mpr rfl⟩

theorem legal_local (W : LocalWhite xs p) (i : Fin (xs.length+p)) (u : Fin (size (label xs p i))) :
    (GuardedEdge.view (CoreFamily.graph xs p)).legal (white xs p W) (some ⟨i,u⟩) ↔
      (GuardedEdge.view (CanonicalLocal.graph (label xs p i))).legal (W i) u := by
  constructor
  · rintro ⟨w,hw,hc⟩
    cases w with
    | none => exact False.elim hw
    | some w =>
      obtain ⟨j,v⟩ := w
      by_cases hij : i=j
      · subst j
        exact ⟨v,hw,(closed_same xs p i u v).mp hc⟩
      · exact False.elim (not_closed_distinct xs p i j hij u v hc)
  · rintro ⟨v,hv,hc⟩
    exact ⟨some ⟨i,v⟩,hv,(closed_same xs p i u v).mpr hc⟩

theorem actual_legal_root (W : LocalWhite xs p) (hn : Normalized xs p W) :
    Marked.Legal (CoreFamily.graph xs p) (marks xs p W) ∅ none ↔
      ∃i,W i (root (label xs p i)) := by
  rw [←GuardedEdge.legal_agree]
  have he : (GuardedEdge.view (CoreFamily.graph xs p)).noniso
      ((GuardedEdge.view (CoreFamily.graph xs p)).raw
        (fun v=>v∈marks xs p W) (fun v=>v∈(∅ : Finset (Vertex xs p))))=white xs p W := by
    funext v
    exact propext ((GuardedEdge.white_agree _ _ _ v).trans (original_white xs p W hn v))
  rw [he,legal_root]

theorem actual_legal_local (W : LocalWhite xs p) (hn : Normalized xs p W)
    (i : Fin (xs.length+p)) (u : Fin (size (label xs p i))) :
    Marked.Legal (CoreFamily.graph xs p) (marks xs p W) ∅ (some ⟨i,u⟩) ↔
      (GuardedEdge.view (CanonicalLocal.graph (label xs p i))).legal (W i) u := by
  rw [←GuardedEdge.legal_agree]
  have he : (GuardedEdge.view (CoreFamily.graph xs p)).noniso
      ((GuardedEdge.view (CoreFamily.graph xs p)).raw
        (fun v=>v∈marks xs p W) (fun v=>v∈(∅ : Finset (Vertex xs p))))=white xs p W := by
    funext v
    exact propext ((GuardedEdge.white_agree _ _ _ v).trans (original_white xs p W hn v))
  rw [he,legal_local]

#print axioms actual_legal_root
#print axioms actual_legal_local
end IsolationGame.CoreFamilySemantics
