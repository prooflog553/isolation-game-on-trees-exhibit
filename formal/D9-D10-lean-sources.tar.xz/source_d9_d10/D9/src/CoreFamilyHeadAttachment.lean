import CoreOrdinaryIndexNormalization
import AttachmentGraph

/-! SOURCE-ONLY candidate. Split one complete head branch from the literal
core. This is an original-carrier attachment isomorphism, with its root.
-/
namespace IsolationGame.CoreFamily
open CanonicalLocal NecessaryCore

/-- Optional index used only to separate the actual head from the old tail. -/
def HeadFiber (n : Nat) (xs : List Nat) (q : Nat) :
    Option (Fin (xs.length+q)) → Type
  | none => Fin (size (decode n))
  | some i => Fin (size (label xs q i))

/-- Reassociation of tagged sums/options; no cardinality choice. -/
def attachmentOptionEquiv (n : Nat) (xs : List Nat) (q : Nat) :
    (Vertex xs q ⊕ Fin (size (decode n))) ≃
      Option (Σi : Option (Fin (xs.length+q)), HeadFiber n xs q i) where
  toFun
    | .inl none => none
    | .inl (some ⟨i,v⟩) => some ⟨some i,v⟩
    | .inr v => some ⟨none,v⟩
  invFun
    | none => .inl none
    | some ⟨none,v⟩ => .inr v
    | some ⟨some i,v⟩ => .inl (some ⟨i,v⟩)
  left_inv := by intro v; rcases v with (_ | ⟨i,v⟩) | v <;> rfl
  right_inv := by
    intro v
    cases v with
    | none => rfl
    | some v => obtain ⟨i,v⟩ := v; cases i <;> rfl

/-- Local coordinates are carried along full label equalities. -/
def headFiberEquiv (n : Nat) (xs : List Nat) (q : Nat)
    (i : Option (Fin (xs.length+q))) :
    HeadFiber n xs q i ≃
      Fin (size (label (n::xs) q (headTailEquiv n xs q i))) := by
  cases i with
  | none => exact coordinateEquiv (label_headIndex n xs q).symm
  | some i => exact coordinateEquiv (label_tailIndex n xs q i).symm

/-- Complete attachment carrier to the complete core carrier. -/
def headAttachmentEquiv (n : Nat) (xs : List Nat) (q : Nat) :
    (Vertex xs q ⊕ Fin (size (decode n))) ≃ Vertex (n::xs) q :=
  (attachmentOptionEquiv n xs q).trans
    (Equiv.optionCongr (Equiv.sigmaCongr (headTailEquiv n xs q)
      (headFiberEquiv n xs q)))

@[simp] theorem headAttachmentEquiv_root (n : Nat) (xs : List Nat) (q : Nat) :
    headAttachmentEquiv n xs q (.inl none) = none := rfl

@[simp] theorem headAttachmentEquiv_old (n : Nat) (xs : List Nat) (q : Nat)
    (i : Fin (xs.length+q)) (v : Fin (size (label xs q i))) :
    headAttachmentEquiv n xs q (.inl (some ⟨i,v⟩)) =
      some ⟨tailIndex n xs q i,coordinateEquiv (label_tailIndex n xs q i).symm v⟩ := rfl

@[simp] theorem headAttachmentEquiv_new (n : Nat) (xs : List Nat) (q : Nat)
    (v : Fin (size (decode n))) :
    headAttachmentEquiv n xs q (.inr v) =
      some ⟨headIndex n xs q,coordinateEquiv (label_headIndex n xs q).symm v⟩ := rfl

private theorem tailIndex_injective (n : Nat) (xs : List Nat) (q : Nat) :
    Function.Injective (tailIndex n xs q) := by
  intro i j h
  apply Fin.ext
  have hv := congrArg Fin.val h
  dsimp [tailIndex] at hv
  omega

private theorem tailIndex_ne_head (n : Nat) (xs : List Nat) (q : Nat)
    (i : Fin (xs.length+q)) : tailIndex n xs q i ≠ headIndex n xs q := by
  intro h
  have hv := congrArg Fin.val h
  dsimp [tailIndex,headIndex] at hv
  omega

private theorem headAttachment_old_adj (n : Nat) (xs : List Nat) (q : Nat)
    (u v : Vertex xs q) :
    (graph (n::xs) q).Adj (headAttachmentEquiv n xs q (.inl u))
      (headAttachmentEquiv n xs q (.inl v)) ↔ (graph xs q).Adj u v := by
  have hr (i : Fin (xs.length+q)) (a : Fin (size (label xs q i))) :
      (graph (n::xs) q).Adj none
          (some ⟨tailIndex n xs q i,coordinateEquiv (label_tailIndex n xs q i).symm a⟩) ↔
        (graph xs q).Adj none (some ⟨i,a⟩) := by
    rw [CoreFamilySemantics.root_adj,CoreFamilySemantics.root_adj]
    rw [←coordinateEquiv_root (label_tailIndex n xs q i).symm]
    exact (coordinateEquiv (label_tailIndex n xs q i).symm).injective.eq_iff
  cases u with
  | none =>
    cases v with
    | none => exact iff_of_false (graph (n::xs) q).irrefl (graph xs q).irrefl
    | some v => obtain ⟨i,a⟩ := v; exact hr i a
  | some u =>
    obtain ⟨i,a⟩ := u
    cases v with
    | none =>
      simp only [headAttachmentEquiv_old,headAttachmentEquiv_root]
      rw [(graph (n::xs) q).adj_comm,(graph xs q).adj_comm]
      exact hr i a
    | some v =>
      obtain ⟨j,b⟩ := v
      simp only [headAttachmentEquiv_old]
      by_cases hij : i=j
      · subst j
        rw [CoreFamilySemantics.same_adj,CoreFamilySemantics.same_adj]
        exact coordinateEquiv_adj (label_tailIndex n xs q i).symm a b
      · exact iff_of_false
          (CoreFamilySemantics.distinct_no_adj (n::xs) q _ _
            (fun h => hij (tailIndex_injective n xs q h)) _ _)
          (CoreFamilySemantics.distinct_no_adj xs q i j hij a b)

/-- Full head-attachment isomorphism. The central root maps to none. -/
def headAttachmentIso (n : Nat) (xs : List Nat) (q : Nat) :
    Attachment.original (graph xs q) (CanonicalLocal.graph (decode n))
      none (root (decode n)) ≃g graph (n::xs) q where
  toEquiv := headAttachmentEquiv n xs q
  map_rel_iff' := by
    intro u v
    have hc (a : Vertex xs q) (b : Fin (size (decode n))) :
        (graph (n::xs) q).Adj (headAttachmentEquiv n xs q (.inl a))
          (headAttachmentEquiv n xs q (.inr b)) ↔
        (a=none ∧ b=root (decode n)) := by
      cases a with
      | none =>
        simp only [headAttachmentEquiv_root,headAttachmentEquiv_new,
          CoreFamilySemantics.root_adj,true_and]
        rw [←coordinateEquiv_root (label_headIndex n xs q).symm]
        exact (coordinateEquiv (label_headIndex n xs q).symm).injective.eq_iff
      | some a =>
        obtain ⟨i,a⟩ := a
        simp only [headAttachmentEquiv_old,headAttachmentEquiv_new,
          reduceCtorEq,false_and,iff_false]
        exact CoreFamilySemantics.distinct_no_adj (n::xs) q _ _
          (tailIndex_ne_head n xs q i) _ _
    cases u with
    | inl u =>
      cases v with
      | inl v => exact headAttachment_old_adj n xs q u v
      | inr v => exact hc u v
    | inr u =>
      cases v with
      | inl v =>
        rw [(graph (n::xs) q).adj_comm]
        exact (hc v u).trans and_comm
      | inr v =>
        simp only [headAttachmentEquiv_new,CoreFamilySemantics.same_adj]
        exact coordinateEquiv_adj (label_headIndex n xs q).symm u v

@[simp] theorem headAttachmentIso_root (n : Nat) (xs : List Nat) (q : Nat) :
    headAttachmentIso n xs q (.inl none) = none := rfl

#print axioms headAttachmentIso
end IsolationGame.CoreFamily
