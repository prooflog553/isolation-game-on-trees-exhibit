import FullCanonical03Rows00
namespace IsolationGame.FullCanonical.T03
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_4 : Finset (Fin 10) := {0,1,2,3,4,5,6}
theorem after_4_0 : Marked.gameValue original marks_4 .dominator {0}=1 ∧ Marked.gameValue original marks_4 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_4 marks_2 0 1 1 (by decide +kernel) row_2
theorem after_4_7 : Marked.gameValue original marks_4 .dominator {7}=0 ∧ Marked.gameValue original marks_4 .staller {7}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_4 marks_0 7 0 0 (by decide +kernel) row_0
theorem after_4_8 : Marked.gameValue original marks_4 .dominator {8}=0 ∧ Marked.gameValue original marks_4 .staller {8}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_4 marks_0 8 0 0 (by decide +kernel) row_0
theorem after_4_9 : Marked.gameValue original marks_4 .dominator {9}=0 ∧ Marked.gameValue original marks_4 .staller {9}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_4 marks_0 9 0 0 (by decide +kernel) row_0
theorem row_4 : Marked.gameValue original marks_4 .dominator ∅=1 ∧ Marked.gameValue original marks_4 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_4 1 2 7 0 (by decide +kernel) (by decide +kernel)
  · rw [after_4_7.2]
  · rw [after_4_0.1]
  · intro v hv
    fin_cases v
    · have h := after_4_0
      change 1 ≤ 1+Marked.gameValue original marks_4 .staller {0} ∧ 1+Marked.gameValue original marks_4 .dominator {0} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 3) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 4) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 6) hv)
    · have h := after_4_7
      change 1 ≤ 1+Marked.gameValue original marks_4 .staller {7} ∧ 1+Marked.gameValue original marks_4 .dominator {7} ≤ 2
      omega
    · have h := after_4_8
      change 1 ≤ 1+Marked.gameValue original marks_4 .staller {8} ∧ 1+Marked.gameValue original marks_4 .dominator {8} ≤ 2
      omega
    · have h := after_4_9
      change 1 ≤ 1+Marked.gameValue original marks_4 .staller {9} ∧ 1+Marked.gameValue original marks_4 .dominator {9} ≤ 2
      omega
def marks_5 : Finset (Fin 10) := {2,3,5,6,8,9}
theorem after_5_0 : Marked.gameValue original marks_5 .dominator {0}=0 ∧ Marked.gameValue original marks_5 .staller {0}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_5 marks_0 0 0 0 (by decide +kernel) row_0
theorem after_5_1 : Marked.gameValue original marks_5 .dominator {1}=0 ∧ Marked.gameValue original marks_5 .staller {1}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_5 marks_0 1 0 0 (by decide +kernel) row_0
theorem after_5_2 : Marked.gameValue original marks_5 .dominator {2}=1 ∧ Marked.gameValue original marks_5 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_5 marks_3 2 1 2 (by decide +kernel) row_3
theorem after_5_4 : Marked.gameValue original marks_5 .dominator {4}=0 ∧ Marked.gameValue original marks_5 .staller {4}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_5 marks_0 4 0 0 (by decide +kernel) row_0
theorem after_5_5 : Marked.gameValue original marks_5 .dominator {5}=1 ∧ Marked.gameValue original marks_5 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_5 marks_3 5 1 2 (by decide +kernel) row_3
theorem after_5_7 : Marked.gameValue original marks_5 .dominator {7}=0 ∧ Marked.gameValue original marks_5 .staller {7}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_5 marks_0 7 0 0 (by decide +kernel) row_0
theorem after_5_8 : Marked.gameValue original marks_5 .dominator {8}=1 ∧ Marked.gameValue original marks_5 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_5 marks_3 8 1 2 (by decide +kernel) row_3
theorem row_5 : Marked.gameValue original marks_5 .dominator ∅=1 ∧ Marked.gameValue original marks_5 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_5 1 2 0 2 (by decide +kernel) (by decide +kernel)
  · rw [after_5_0.2]
  · rw [after_5_2.1]
  · intro v hv
    fin_cases v
    · have h := after_5_0
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {0} ∧ 1+Marked.gameValue original marks_5 .dominator {0} ≤ 2
      omega
    · have h := after_5_1
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {1} ∧ 1+Marked.gameValue original marks_5 .dominator {1} ≤ 2
      omega
    · have h := after_5_2
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {2} ∧ 1+Marked.gameValue original marks_5 .dominator {2} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 3) hv)
    · have h := after_5_4
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {4} ∧ 1+Marked.gameValue original marks_5 .dominator {4} ≤ 2
      omega
    · have h := after_5_5
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {5} ∧ 1+Marked.gameValue original marks_5 .dominator {5} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 6) hv)
    · have h := after_5_7
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {7} ∧ 1+Marked.gameValue original marks_5 .dominator {7} ≤ 2
      omega
    · have h := after_5_8
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {8} ∧ 1+Marked.gameValue original marks_5 .dominator {8} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 9) hv)
def marks_6 : Finset (Fin 10) := {0,1,2,3,4,7}
theorem after_6_4 : Marked.gameValue original marks_6 .dominator {4}=1 ∧ Marked.gameValue original marks_6 .staller {4}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_6 marks_2 4 1 1 (by decide +kernel) row_2
theorem after_6_5 : Marked.gameValue original marks_6 .dominator {5}=1 ∧ Marked.gameValue original marks_6 .staller {5}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_6 marks_2 5 1 1 (by decide +kernel) row_2
theorem after_6_6 : Marked.gameValue original marks_6 .dominator {6}=1 ∧ Marked.gameValue original marks_6 .staller {6}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_6 marks_2 6 1 1 (by decide +kernel) row_2
theorem after_6_7 : Marked.gameValue original marks_6 .dominator {7}=1 ∧ Marked.gameValue original marks_6 .staller {7}=1 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_6 marks_2 7 1 1 (by decide +kernel) row_2
theorem after_6_8 : Marked.gameValue original marks_6 .dominator {8}=1 ∧ Marked.gameValue original marks_6 .staller {8}=1 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_6 marks_2 8 1 1 (by decide +kernel) row_2
theorem after_6_9 : Marked.gameValue original marks_6 .dominator {9}=1 ∧ Marked.gameValue original marks_6 .staller {9}=1 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_6 marks_2 9 1 1 (by decide +kernel) row_2
theorem row_6 : Marked.gameValue original marks_6 .dominator ∅=2 ∧ Marked.gameValue original marks_6 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_6 2 2 4 4 (by decide +kernel) (by decide +kernel)
  · rw [after_6_4.2]
  · rw [after_6_4.1]
  · intro v hv
    fin_cases v
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_6 ∅ 0) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_6 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_6 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_6 ∅ 3) hv)
    · have h := after_6_4
      change 2 ≤ 1+Marked.gameValue original marks_6 .staller {4} ∧ 1+Marked.gameValue original marks_6 .dominator {4} ≤ 2
      omega
    · have h := after_6_5
      change 2 ≤ 1+Marked.gameValue original marks_6 .staller {5} ∧ 1+Marked.gameValue original marks_6 .dominator {5} ≤ 2
      omega
    · have h := after_6_6
      change 2 ≤ 1+Marked.gameValue original marks_6 .staller {6} ∧ 1+Marked.gameValue original marks_6 .dominator {6} ≤ 2
      omega
    · have h := after_6_7
      change 2 ≤ 1+Marked.gameValue original marks_6 .staller {7} ∧ 1+Marked.gameValue original marks_6 .dominator {7} ≤ 2
      omega
    · have h := after_6_8
      change 2 ≤ 1+Marked.gameValue original marks_6 .staller {8} ∧ 1+Marked.gameValue original marks_6 .dominator {8} ≤ 2
      omega
    · have h := after_6_9
      change 2 ≤ 1+Marked.gameValue original marks_6 .staller {9} ∧ 1+Marked.gameValue original marks_6 .dominator {9} ≤ 2
      omega
def marks_7 : Finset (Fin 10) := {1,2,3,4,5,6}
theorem after_7_0 : Marked.gameValue original marks_7 .dominator {0}=1 ∧ Marked.gameValue original marks_7 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_2 0 1 1 (by decide +kernel) row_2
theorem after_7_1 : Marked.gameValue original marks_7 .dominator {1}=1 ∧ Marked.gameValue original marks_7 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_4 1 1 2 (by decide +kernel) row_4
theorem after_7_4 : Marked.gameValue original marks_7 .dominator {4}=1 ∧ Marked.gameValue original marks_7 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_4 4 1 2 (by decide +kernel) row_4
theorem after_7_7 : Marked.gameValue original marks_7 .dominator {7}=0 ∧ Marked.gameValue original marks_7 .staller {7}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_0 7 0 0 (by decide +kernel) row_0
theorem after_7_8 : Marked.gameValue original marks_7 .dominator {8}=0 ∧ Marked.gameValue original marks_7 .staller {8}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_0 8 0 0 (by decide +kernel) row_0
theorem after_7_9 : Marked.gameValue original marks_7 .dominator {9}=1 ∧ Marked.gameValue original marks_7 .staller {9}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_1 9 1 1 (by decide +kernel) row_1
theorem row_7 : Marked.gameValue original marks_7 .dominator ∅=1 ∧ Marked.gameValue original marks_7 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_7 1 2 7 0 (by decide +kernel) (by decide +kernel)
  · rw [after_7_7.2]
  · rw [after_7_0.1]
  · intro v hv
    fin_cases v
    · have h := after_7_0
      change 1 ≤ 1+Marked.gameValue original marks_7 .staller {0} ∧ 1+Marked.gameValue original marks_7 .dominator {0} ≤ 2
      omega
    · have h := after_7_1
      change 1 ≤ 1+Marked.gameValue original marks_7 .staller {1} ∧ 1+Marked.gameValue original marks_7 .dominator {1} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_7 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_7 ∅ 3) hv)
    · have h := after_7_4
      change 1 ≤ 1+Marked.gameValue original marks_7 .staller {4} ∧ 1+Marked.gameValue original marks_7 .dominator {4} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_7 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_7 ∅ 6) hv)
    · have h := after_7_7
      change 1 ≤ 1+Marked.gameValue original marks_7 .staller {7} ∧ 1+Marked.gameValue original marks_7 .dominator {7} ≤ 2
      omega
    · have h := after_7_8
      change 1 ≤ 1+Marked.gameValue original marks_7 .staller {8} ∧ 1+Marked.gameValue original marks_7 .dominator {8} ≤ 2
      omega
    · have h := after_7_9
      change 1 ≤ 1+Marked.gameValue original marks_7 .staller {9} ∧ 1+Marked.gameValue original marks_7 .dominator {9} ≤ 2
      omega
end IsolationGame.FullCanonical.T03
