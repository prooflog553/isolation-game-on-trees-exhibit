import DoubleCentreP4ZeroTransport
import DoubleCentreP4Geometry

/-! SOURCE_ONLY. A fixed Staller centre action is paid once. Positive opposite
pools supply a genuine nonterminal right component; its zero axis is handled
with terminal value zero. Strong induction on all p+q then covers every actual
ordinary action through the accepted TwoPool assembly. -/
namespace IsolationGame.DoubleCentreP4.Zero
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

private theorem sum_empty {V U : Type} [DecidableEq V] [DecidableEq U] :
    MarkedSum.combine (∅ : Finset V) (∅ : Finset U) = ∅ := by
  simp [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight]

/-- A complete ordinary copy keeps its local 1--2 edge White under centre-only
marking. This proves the nonterminal premise rather than inferring it from q. -/
theorem pure_marked_nonterminal (q : Nat) (hq : 0<q) :
    ¬Marked.Terminal (GeneralP4Receiver.graph 0 q) (GeneralP4Receiver.marks 0 q) ∅ := by
  let i : Fin q := ⟨0,hq⟩
  have hu (r : Fin 7) : Marked.Undominated (GeneralP4Receiver.graph 0 q)
      (GeneralP4Receiver.marks 0 q) ∅ (GeneralP4Receiver.ordinary 0 q i r) := by
    simp [Marked.Undominated,IsolationGame.Undominated,IsolationGame.Dominated,
      GeneralP4Receiver.marks,GeneralP4Receiver.ordinary,TwoPool.marks,TwoPool.ordinaryLeft]
  intro ht
  apply ht (GeneralP4Receiver.ordinary 0 q i 1)
  exact ⟨hu 1,GeneralP4Receiver.ordinary 0 q i 2,⟨rfl,by decide +kernel⟩,hu 2⟩

/-- The opposite component at q=0 is a marked original singleton. -/
theorem pure_zero_terminal :
    Marked.Terminal (GeneralP4Receiver.graph 0 0) (GeneralP4Receiver.marks 0 0) ∅ := by
  decide +kernel

theorem pure_zero_S :
    Marked.gameValue (GeneralP4Receiver.graph 0 0) (GeneralP4Receiver.marks 0 0) .staller ∅ = 0 :=
  (Marked.value_zero_iff_terminal _ _ _ _).mpr pure_zero_terminal

/-- Exact paid-centre follower budget, for all p,q including both zero axes. -/
theorem left_follower_D (p q : Nat) :
    Marked.gameValue (DoubleCentreP4.graph 0 0 p q) ∅ .dominator
      {DoubleCentreP4.left 0 0 p q} ≤ 3*(p+q) := by
  rw [DoubleCentreP4.left_follower_split]
  have hG := Marked.forest_no_minus (GeneralP4Receiver.graph 0 p)
    (GeneralP4Receiver.graph_acyclic 0 p)
  have hH := Marked.forest_no_minus (GeneralP4Receiver.graph 0 q)
    (GeneralP4Receiver.graph_acyclic 0 q)
  have hleft := GeneralP4Receiver.root_played_S_strong 0 p
  simp [GeneralP4Receiver.cBudget] at hleft
  by_cases hq : 0<q
  · have hsum := MarkedSum.D_upper_right_value
      (GeneralP4Receiver.graph 0 p) (GeneralP4Receiver.graph 0 q) hG hH
      (SelectedVertex.playedMarks (GeneralP4Receiver.graph 0 p)
        (GeneralP4Receiver.marks 0 p) (GeneralP4Receiver.centre 0 p)) ∅
      (GeneralP4Receiver.marks 0 q) ∅ (pure_marked_nonterminal q hq)
    rw [sum_empty] at hsum
    have hright := GeneralP4Receiver.D_upper_strong 0 q
    simp at hright
    have htotal :
        Marked.gameValue (GeneralP4Receiver.graph 0 p)
          (SelectedVertex.playedMarks (GeneralP4Receiver.graph 0 p)
            (GeneralP4Receiver.marks 0 p) (GeneralP4Receiver.centre 0 p)) .staller ∅ +
        Marked.gameValue (GeneralP4Receiver.graph 0 q) (GeneralP4Receiver.marks 0 q) .dominator ∅ ≤
          3*(p+q) := by omega
    convert hsum.trans htotal using 1 <;> congr 1 <;> apply Subsingleton.elim
  · have hz : q=0 := by omega
    subst q
    have hds := MarkedSum.sum_d_le_s
      (GeneralP4Receiver.graph 0 p) (GeneralP4Receiver.graph 0 0) hG hH
      (SelectedVertex.playedMarks (GeneralP4Receiver.graph 0 p)
        (GeneralP4Receiver.marks 0 p) (GeneralP4Receiver.centre 0 p)) ∅
      (GeneralP4Receiver.marks 0 0) ∅
    have hss := MarkedSum.S_upper_value
      (GeneralP4Receiver.graph 0 p) (GeneralP4Receiver.graph 0 0) hG hH
      (SelectedVertex.playedMarks (GeneralP4Receiver.graph 0 p)
        (GeneralP4Receiver.marks 0 p) (GeneralP4Receiver.centre 0 p)) ∅
      (GeneralP4Receiver.marks 0 0) ∅
    rw [sum_empty] at hds hss
    have hr := pure_zero_S
    have htotal :
        Marked.gameValue (GeneralP4Receiver.graph 0 p)
          (SelectedVertex.playedMarks (GeneralP4Receiver.graph 0 p)
            (GeneralP4Receiver.marks 0 p) (GeneralP4Receiver.centre 0 p)) .staller ∅ +
        Marked.gameValue (GeneralP4Receiver.graph 0 0) (GeneralP4Receiver.marks 0 0) .staller ∅ ≤
          3*(p+0) := by omega
    convert hds.trans (hss.trans htotal) using 1 <;> congr 1 <;> apply Subsingleton.elim

theorem left_centre_paid (p q : Nat) :
    1+Marked.gameValue (DoubleCentreP4.graph 0 0 p q) ∅ .dominator
      {DoubleCentreP4.left 0 0 p q} ≤ 3*(p+q)+1 := by
  have h := left_follower_D p q
  omega

theorem right_centre_paid (p q : Nat) :
    1+Marked.gameValue (DoubleCentreP4.graph 0 0 p q) ∅ .dominator
      {DoubleCentreP4.right 0 0 p q} ≤ 3*(p+q)+1 := by
  have h := left_centre_paid q p
  have he := DoubleCentreP4.value_swap 0 0 p q .dominator {DoubleCentreP4.right 0 0 p q}
  have hs : ({DoubleCentreP4.right 0 0 p q} : Finset (DoubleCentreP4.Vertex 0 0 p q)).image
      (DoubleCentreP4.swapEquiv 0 0 p q) = {DoubleCentreP4.left 0 0 q p} := by
    simp [DoubleCentreP4.swapEquiv,DoubleCentreP4.left,DoubleCentreP4.right]
  rw [hs] at he
  omega

/-- Only the two literal fixed spine vertices need separately supplied rows. -/
theorem fixed_paid (p q : Nat) (v : Bool) :
    1+Marked.gameValue (TwoPool.graph spine false true p q)
      (TwoPool.marks (∅ : Finset Bool) p q) .dominator {TwoPool.fixed p q v} ≤
      3*(p+q)+(0+1) := by
  cases v
  · rw [pool_value]
    simpa only [Finset.image_singleton,pool_left] using left_centre_paid p q
  · rw [pool_value]
    simpa only [Finset.image_singleton,pool_right] using right_centre_paid p q

/-- The accepted all-Nat total-pool induction supplies every ordinary first row. -/
theorem S_upper (p q : Nat) :
    Marked.gameValue (DoubleCentreP4.graph 0 0 p q) ∅ .staller ∅ ≤ 3*(p+q)+1 := by
  have h := TwoPool.S_upper_of_fixed spine spine_acyclic false true ∅ 0 fixed_paid p q
  rw [pool_value] at h
  simpa only [Finset.image_empty] using h

theorem D_upper (p q : Nat) :
    Marked.gameValue (DoubleCentreP4.graph 0 0 p q) ∅ .dominator ∅ ≤ 3*(p+q)+1 :=
  (Marked.forest_no_minus _ (DoubleCentreP4.graph_acyclic 0 0 p q) ∅ ∅).trans (S_upper p q)

/-- Every original first action is supplied, with no white-only restriction.
Arbitrary marked/blue follower actions are preserved by pool_legal separately. -/
theorem all_first_paid (p q : Nat) (v : DoubleCentreP4.Vertex 0 0 p q) :
    1+Marked.gameValue (DoubleCentreP4.graph 0 0 p q) ∅ .dominator {v} ≤ 3*(p+q)+1 := by
  have h := TwoPool.all_first_bounds_of_fixed spine spine_acyclic false true ∅ 0 fixed_paid
    p q ((poolEquiv p q).symm v)
  rw [pool_value] at h
  simpa only [Finset.image_singleton,Equiv.apply_symm_apply] using h

#print axioms pure_marked_nonterminal
#print axioms pure_zero_terminal
#print axioms left_follower_D
#print axioms left_centre_paid
#print axioms right_centre_paid
#print axioms fixed_paid
#print axioms S_upper
#print axioms D_upper
#print axioms all_first_paid
end IsolationGame.DoubleCentreP4.Zero
