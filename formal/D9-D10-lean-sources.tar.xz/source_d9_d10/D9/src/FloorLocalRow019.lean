import FloorLocalBase
import FloorLocalRow001
set_option maxRecDepth 4096
set_option maxHeartbeats 1000000
namespace IsolationGame.FloorLocal
def marks_019 : Finset (Fin 7) := {0,1,2,3,4}
theorem normalized_019 : ∀v : Fin 7, Marked.White original_02 marks_019 ∅ v ↔ v∈({5,6} : Finset (Fin 7)) := by decide +kernel
theorem after_019_4 : Marked.gameValue original_02 marks_019 .dominator {4}=0 ∧ Marked.gameValue original_02 marks_019 .staller {4}=0 :=
  LocalProfile.DAG.transport original_02 marks_019 marks_001 4 0 0 (by decide +kernel) row_001
theorem after_019_5 : Marked.gameValue original_02 marks_019 .dominator {5}=0 ∧ Marked.gameValue original_02 marks_019 .staller {5}=0 :=
  LocalProfile.DAG.transport original_02 marks_019 marks_001 5 0 0 (by decide +kernel) row_001
theorem after_019_6 : Marked.gameValue original_02 marks_019 .dominator {6}=0 ∧ Marked.gameValue original_02 marks_019 .staller {6}=0 :=
  LocalProfile.DAG.transport original_02 marks_019 marks_001 6 0 0 (by decide +kernel) row_001
theorem row_019 : Marked.gameValue original_02 marks_019 .dominator ∅=1 ∧ Marked.gameValue original_02 marks_019 .staller ∅=1 := by
  apply LocalProfile.DAG.bellman original_02 marks_019 1 1 4 4 (by decide +kernel) (by decide +kernel)
  · rw [after_019_4.2]
  · rw [after_019_4.1]
  · intro v hv
    fin_cases v
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_019 ∅ 0) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_019 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_019 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_019 ∅ 3) hv)
    · have h := after_019_4
      change 1≤1+Marked.gameValue original_02 marks_019 .staller {4} ∧ 1+Marked.gameValue original_02 marks_019 .dominator {4}≤1
      omega
    · have h := after_019_5
      change 1≤1+Marked.gameValue original_02 marks_019 .staller {5} ∧ 1+Marked.gameValue original_02 marks_019 .dominator {5}≤1
      omega
    · have h := after_019_6
      change 1≤1+Marked.gameValue original_02 marks_019 .staller {6} ∧ 1+Marked.gameValue original_02 marks_019 .dominator {6}≤1
      omega
#print axioms row_019
end IsolationGame.FloorLocal
