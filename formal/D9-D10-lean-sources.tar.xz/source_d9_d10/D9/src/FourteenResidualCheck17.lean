import FourteenResidualData

/-! Finite kernel arithmetic only: first profile fixed to t17.
All arithmetic is checked by kernel reduction; no graph or history search. -/
namespace IsolationGame.FourteenResidual
open CanonicalLocal
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

theorem check11_t17 (b : Index) :
    NumericResidual [.t17] [b] → MatchesFourteen [.t17] [b] := by
  cases b <;> decide +kernel

theorem check12_t17 (b c : Index) :
    NumericResidual [.t17] [b, c] → MatchesFourteen [.t17] [b, c] := by
  cases b <;> cases c <;> decide +kernel

#print axioms check11_t17
#print axioms check12_t17
end IsolationGame.FourteenResidual
