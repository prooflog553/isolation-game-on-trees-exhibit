import AttachmentGraph

namespace IsolationGame.Attachment
open Isolation.Graph
variable {V U : Type} [Fintype V] [DecidableEq V] [Fintype U] [DecidableEq U]
  (G : SimpleGraph V) (H : SimpleGraph U) (z : V) (b : U)

variable (M X : Finset V) (N Y : Finset U)

theorem left_normalized
    (hi : ¬Marked.Legal (original G H z b) (MarkedSum.combine M N) (MarkedSum.combine X Y) (.inr b)) :
    (GuardedEdge.view G).noniso (leftWhite G H z b M X N Y)=leftWhite G H z b M X N Y := by
  funext v
  apply propext
  constructor
  · exact fun h=>h.1
  · intro hv
    obtain ⟨w,ha,hw⟩ := Marked.white_neighbor (original G H z b) hv
    cases w with
    | inl w => exact ⟨hv,w,hw,ha⟩
    | inr w =>
      have hwEq : w=b := ha.2
      subst w
      exact False.elim ((inactive_endpoints G H z b M X N Y hi).2 hw)

theorem right_normalized
    (hi : ¬Marked.Legal (original G H z b) (MarkedSum.combine M N) (MarkedSum.combine X Y) (.inr b)) :
    (GuardedEdge.view H).noniso (rightWhite G H z b M X N Y)=rightWhite G H z b M X N Y := by
  funext v
  apply propext
  constructor
  · exact fun h=>h.1
  · intro hv
    obtain ⟨w,ha,hw⟩ := Marked.white_neighbor (original G H z b) hv
    cases w with
    | inl w =>
      have hvEq : v=b := ha.1
      subst v
      exact False.elim ((inactive_endpoints G H z b M X N Y hi).2 hv)
    | inr w => exact ⟨hv,w,hw,ha⟩

theorem left_white_subset
    (hi : ¬Marked.Legal (original G H z b) (MarkedSum.combine M N) (MarkedSum.combine X Y) (.inr b)) :
    ∀v,leftWhite G H z b M X N Y v→Marked.White G M X v := by
  intro v hv
  have hn : (GuardedEdge.view G).noniso (leftWhite G H z b M X N Y) v := by
    rwa [left_normalized G H z b M X N Y hi]
  obtain ⟨_,w,hw,ha⟩ := hn
  exact ⟨undominated_left G H z b M X N Y v hv.1,w,ha,
    undominated_left G H z b M X N Y w hw.1⟩

theorem right_white_subset
    (hi : ¬Marked.Legal (original G H z b) (MarkedSum.combine M N) (MarkedSum.combine X Y) (.inr b)) :
    ∀v,rightWhite G H z b M X N Y v→Marked.White H N Y v := by
  intro v hv
  have hn : (GuardedEdge.view H).noniso (rightWhite G H z b M X N Y) v := by
    rwa [right_normalized G H z b M X N Y hi]
  obtain ⟨_,w,hw,ha⟩ := hn
  exact ⟨undominated_right G H z b M X N Y v hv.1,w,ha,
    undominated_right G H z b M X N Y w hw.1⟩

/-- The bridge edge is genuinely inert once the attachment root is illegal. -/
theorem inactive_agree
    (hi : ¬Marked.Legal (original G H z b) (MarkedSum.combine M N) (MarkedSum.combine X Y) (.inr b)) :
    (GuardedEdge.view (original G H z b)).AgreeOnWhite (MarkedSum.graph G H) (fullWhite G H z b M X N Y) := by
  have hz := (inactive_endpoints G H z b M X N Y hi).1
  have hb := (inactive_endpoints G H z b M X N Y hi).2
  intro u v hv
  cases u with
  | inl u => cases v with
    | inl v => simp [Isolation.Graph.closed,GuardedEdge.view,original,MarkedSum.graph,disjointSum]
    | inr v =>
      change (Sum.inl u=Sum.inr v ∨ (u=z ∧ v=b)) ↔ (Sum.inl u=Sum.inr v ∨ False)
      simp only [Sum.inl_ne_inr,false_or,or_false,iff_false]
      intro h
      have he : v=b := h.2
      subst v
      exact hb hv
  | inr u => cases v with
    | inl v =>
      change (Sum.inr u=Sum.inl v ∨ (u=b ∧ v=z)) ↔ (Sum.inr u=Sum.inl v ∨ False)
      simp only [Sum.inr_ne_inl,false_or,or_false,iff_false]
      intro h
      have he : v=z := h.2
      subst v
      exact hz hv
    | inr v => simp [Isolation.Graph.closed,GuardedEdge.view,original,MarkedSum.graph,disjointSum]

theorem inactive_split_horizon
    (hi : ¬Marked.Legal (original G H z b) (MarkedSum.combine M N) (MarkedSum.combine X Y) (.inr b))
    (n : Nat) (p : Player) :
    Marked.WinsWithin (original G H z b) (MarkedSum.combine M N) n p (MarkedSum.combine X Y) ↔
      Marked.WinsWithin (MarkedSum.original G H)
        (MarkedSum.combine (ForestFoundation.canonicalMarks (leftWhite G H z b M X N Y))
          (ForestFoundation.canonicalMarks (rightWhite G H z b M X N Y))) n p ∅ := by
  rw [←ForestFoundation.white_horizon]
  change (GuardedEdge.view (original G H z b)).WinsWhite n (GuardedEdge.turn p) (fullWhite G H z b M X N Y) ↔ _
  rw [(GuardedEdge.view (original G H z b)).winsWhite_congr (MarkedSum.graph G H) n (GuardedEdge.turn p) _
    (inactive_agree G H z b M X N Y hi),full_white_split]
  have heG : Marked.White G (ForestFoundation.canonicalMarks (leftWhite G H z b M X N Y)) ∅=
      leftWhite G H z b M X N Y := by
    funext v
    exact propext (ForestFoundation.canonical_white G _ (left_normalized G H z b M X N Y hi) v)
  have heH : Marked.White H (ForestFoundation.canonicalMarks (rightWhite G H z b M X N Y)) ∅=
      rightWhite G H z b M X N Y := by
    funext v
    exact propext (ForestFoundation.canonical_white H _ (right_normalized G H z b M X N Y hi) v)
  have h := MarkedSum.original_horizon G H
    (ForestFoundation.canonicalMarks (leftWhite G H z b M X N Y)) ∅
    (ForestFoundation.canonicalMarks (rightWhite G H z b M X N Y)) ∅ n p
  simp only [MarkedSum.white,heG,heH,MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight,
    Finset.map_empty,Finset.union_empty] at h
  exact h.symm

theorem inactive_split_value
    (hi : ¬Marked.Legal (original G H z b) (MarkedSum.combine M N) (MarkedSum.combine X Y) (.inr b))
    (p : Player) :
    Marked.gameValue (original G H z b) (MarkedSum.combine M N) p (MarkedSum.combine X Y) =
      Marked.gameValue (MarkedSum.original G H)
        (MarkedSum.combine (ForestFoundation.canonicalMarks (leftWhite G H z b M X N Y))
          (ForestFoundation.canonicalMarks (rightWhite G H z b M X N Y))) p ∅ := by
  have he := inactive_split_horizon G H z b M X N Y hi
  apply Nat.le_antisymm
  · exact (Marked.gameValue_le_iff _ _ _ _ _).mpr ((he _ p).mpr
      ((Marked.gameValue_le_iff _ _ _ _ _).mp (Nat.le_refl _)))
  · exact (Marked.gameValue_le_iff _ _ _ _ _).mpr ((he _ p).mp
      ((Marked.gameValue_le_iff _ _ _ _ _).mp (Nat.le_refl _)))

#print axioms inactive_split_horizon
#print axioms inactive_split_value
end IsolationGame.Attachment
