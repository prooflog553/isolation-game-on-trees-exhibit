import FullCanonical08
import Profile_08
import ReplyStrictPairing
import PrivateSwitchAttachment

/-! SOURCE-ONLY. No native/Lean execution. All local values come from accepted
full08 and root-marked08 DAG rows, with true capacity interfaces separated. -/
namespace IsolationGame.Core08ForkLocalFacts
open FullCanonical.T08
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

/-- Computable finite closed-neighbourhood marks, extensionally identical to
playedMarks. Use this definition for finite kernel geometry checks. -/
def N (a : Fin 11) : Finset (Fin 11) :=
  marks_31 ∪ Finset.univ.filter (fun w => Closed original a w)

theorem N_actual (a : Fin 11) : N a=SelectedVertex.playedMarks original marks_31 a := by
  ext w
  simp [N,SelectedVertex.mem_playedMarks]

private theorem absorb_S (a : Fin 11) :
    Marked.gameValue original (N a) .staller ∅ =
      Marked.gameValue original marks_31 .staller {a} := by
  rw [N_actual]
  symm
  apply Marked.value_eq_of_white_eq
  intro w
  change Marked.White _ _ (insert a ∅) w ↔ _
  rw [SelectedVertex.absorb_white]

/-- Any forest S≤3 supplies a RELAXED genuine strict capacity4, by no-minus
and continuation for every original legal follower. It is not Strict3. -/
private theorem relaxed_four {V : Type} [Fintype V] [DecidableEq V]
    (G : SimpleGraph V) (hG : G.IsAcyclic) (M : Finset V)
    (hs : Marked.gameValue G M .staller ∅ ≤ 3) :
    MarkedSum.StrictCapacity G M ∅ 4 := by
  constructor
  · have hd := Marked.forest_no_minus G hG M ∅
    omega
  · intro v _
    have hh := Marked.value_of_white_subset G M M (insert v ∅) ∅ .staller
      (Marked.white_after_subset G v)
    omega

/-- Row25 has an original blue fork-root7 with follower3; all other legal
followers have S2. Thus it is genuinely Strict4, not inferred from D3/S4. -/
theorem row25_strict : MarkedSum.StrictCapacity original marks_25 ∅ 4 := by
  constructor
  · rw [row_25.1] <;> omega
  · intro v hv
    fin_cases v
    · change Marked.gameValue original marks_25 .staller {0}+1≤4
      rw [after_25_0.2] <;> omega
    · change Marked.gameValue original marks_25 .staller {1}+1≤4
      rw [after_25_1.2] <;> omega
    · change Marked.gameValue original marks_25 .staller {2}+1≤4
      rw [after_25_2.2] <;> omega
    · change Marked.gameValue original marks_25 .staller {3}+1≤4
      rw [after_25_3.2] <;> omega
    · change Marked.gameValue original marks_25 .staller {4}+1≤4
      rw [after_25_4.2] <;> omega
    · change Marked.gameValue original marks_25 .staller {5}+1≤4
      rw [after_25_5.2] <;> omega
    · change Marked.gameValue original marks_25 .staller {6}+1≤4
      rw [after_25_6.2] <;> omega
    · change Marked.gameValue original marks_25 .staller {7}+1≤4
      rw [after_25_7.2] <;> omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_25 ∅ 8) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_25 ∅ 9) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_25 ∅ 10) hv)

theorem normal_follower_S (a : Fin 11) (h8 : a≠8) (h9 : a≠9) (h10 : a≠10) :
    Marked.gameValue original (N a) .staller ∅ ≤ 3 := by
  rw [absorb_S]
  fin_cases a
  · exact after_31_0.2.le
  · exact after_31_1.2.le
  · exact after_31_2.2.le
  · exact after_31_3.2.le
  · exact after_31_4.2.le
  · exact after_31_5.2.le
  · exact after_31_6.2.le
  · exact after_31_7.2.le
  · exact False.elim (h8 rfl)
  · exact False.elim (h9 rfl)
  · exact False.elim (h10 rfl)

/-- For every root-live legal local first, the real original arm-start or
blue fork-root7 is private. Its support marks persist for all later history. -/
theorem root_live_private (a : Fin 11) (h10 : a≠10) (hr : (0 : Fin 11) ∉ N a) :
    ∃g : Fin 11,original.Adj g 0 ∧
      ∀w,Marked.White original (N a) ∅ w → original.Adj g w → w=0 := by
  have h : ∀a : Fin 11,a≠10 → (0 : Fin 11) ∉ N a →
      ∃g : Fin 11,original.Adj g 0 ∧
        ∀w,Marked.White original (N a) ∅ w → original.Adj g w → w=0 := by
    decide +kernel
  exact h a h10 hr

theorem root_live_strict (a : Fin 11) (h10 : a≠10) :
    MarkedSum.StrictCapacity original (N a) ∅ 4 := by
  by_cases h8 : a=8
  · subst a
    have he : N 8=marks_25 := by ext w; fin_cases w <;> decide +kernel
    rw [he]; exact row25_strict
  by_cases h9 : a=9
  · subst a
    have he : N 9=marks_25 := by ext w; fin_cases w <;> decide +kernel
    rw [he]; exact row25_strict
  have ht : original.IsAcyclic := by
    have h : original.IsTree := CanonicalLocal.tree_of_certificate original 0
      (by unfold CanonicalLocal.ReachThree; decide +kernel) (by decide +kernel)
    exact h.IsAcyclic
  exact relaxed_four original ht (N a) (normal_follower_S a h8 h9 h10)

theorem root_dominated_follower (a : Fin 11) (hr : (0 : Fin 11) ∈ N a) :
    Marked.gameValue original (N a) .staller ∅ ≤ 3 := by
  apply normal_follower_S a
  · intro h; subst a; exact (by decide +kernel : (0 : Fin 11) ∉ N 8) hr
  · intro h; subst a; exact (by decide +kernel : (0 : Fin 11) ∉ N 9) hr
  · intro h; subst a; exact (by decide +kernel : (0 : Fin 11) ∉ N 10) hr

/-- Marking the local root after the actual fork-leaf history gives the
accepted root-marked row19, balanced4. This is marking, not selecting root0. -/
theorem closed_root_S : Marked.gameValue original (insert 0 marks_31) .staller ∅=4 := by
  have he : insert (0 : Fin 11) marks_31=LocalProfile.e0E0D1L2.marks_19 := by
    ext w; fin_cases w <;> decide +kernel
  rw [he]
  exact LocalProfile.e0E0D1L2.row_19.2
end IsolationGame.Core08ForkLocalFacts
