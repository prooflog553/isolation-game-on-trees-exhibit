import FloorLocalBase
import FloorLocalRow001
import FloorLocalRow017
import FloorLocalRow018
import FloorLocalRow064
import FloorLocalRow065
import FloorLocalRow107
set_option maxRecDepth 4096
set_option maxHeartbeats 1000000
namespace IsolationGame.FloorLocal
def marks_158 : Finset (Fin 7) := {5,6}
theorem normalized_158 : ∀v : Fin 7, Marked.White original_02 marks_158 ∅ v ↔ v∈({0,1,2,3,4} : Finset (Fin 7)) := by decide +kernel
theorem after_158_0 : Marked.gameValue original_02 marks_158 .dominator {0}=1 ∧ Marked.gameValue original_02 marks_158 .staller {0}=1 :=
  LocalProfile.DAG.transport original_02 marks_158 marks_017 0 1 1 (by decide +kernel) row_017
theorem after_158_1 : Marked.gameValue original_02 marks_158 .dominator {1}=0 ∧ Marked.gameValue original_02 marks_158 .staller {1}=0 :=
  LocalProfile.DAG.transport original_02 marks_158 marks_001 1 0 0 (by decide +kernel) row_001
theorem after_158_2 : Marked.gameValue original_02 marks_158 .dominator {2}=1 ∧ Marked.gameValue original_02 marks_158 .staller {2}=1 :=
  LocalProfile.DAG.transport original_02 marks_158 marks_018 2 1 1 (by decide +kernel) row_018
theorem after_158_3 : Marked.gameValue original_02 marks_158 .dominator {3}=1 ∧ Marked.gameValue original_02 marks_158 .staller {3}=2 :=
  LocalProfile.DAG.transport original_02 marks_158 marks_065 3 1 2 (by decide +kernel) row_065
theorem after_158_4 : Marked.gameValue original_02 marks_158 .dominator {4}=1 ∧ Marked.gameValue original_02 marks_158 .staller {4}=2 :=
  LocalProfile.DAG.transport original_02 marks_158 marks_064 4 1 2 (by decide +kernel) row_064
theorem after_158_5 : Marked.gameValue original_02 marks_158 .dominator {5}=1 ∧ Marked.gameValue original_02 marks_158 .staller {5}=2 :=
  LocalProfile.DAG.transport original_02 marks_158 marks_107 5 1 2 (by decide +kernel) row_107
theorem row_158 : Marked.gameValue original_02 marks_158 .dominator ∅=1 ∧ Marked.gameValue original_02 marks_158 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original_02 marks_158 1 2 1 0 (by decide +kernel) (by decide +kernel)
  · rw [after_158_1.2]
  · rw [after_158_0.1]
  · intro v hv
    fin_cases v
    · have h := after_158_0
      change 1≤1+Marked.gameValue original_02 marks_158 .staller {0} ∧ 1+Marked.gameValue original_02 marks_158 .dominator {0}≤2
      omega
    · have h := after_158_1
      change 1≤1+Marked.gameValue original_02 marks_158 .staller {1} ∧ 1+Marked.gameValue original_02 marks_158 .dominator {1}≤2
      omega
    · have h := after_158_2
      change 1≤1+Marked.gameValue original_02 marks_158 .staller {2} ∧ 1+Marked.gameValue original_02 marks_158 .dominator {2}≤2
      omega
    · have h := after_158_3
      change 1≤1+Marked.gameValue original_02 marks_158 .staller {3} ∧ 1+Marked.gameValue original_02 marks_158 .dominator {3}≤2
      omega
    · have h := after_158_4
      change 1≤1+Marked.gameValue original_02 marks_158 .staller {4} ∧ 1+Marked.gameValue original_02 marks_158 .dominator {4}≤2
      omega
    · have h := after_158_5
      change 1≤1+Marked.gameValue original_02 marks_158 .staller {5} ∧ 1+Marked.gameValue original_02 marks_158 .dominator {5}≤2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_158 ∅ 6) hv)
#print axioms row_158
end IsolationGame.FloorLocal
