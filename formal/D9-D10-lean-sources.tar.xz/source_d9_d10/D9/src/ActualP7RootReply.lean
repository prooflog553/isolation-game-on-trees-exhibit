import G2CenterSplit
import P7GraftModel
import P7GraftForest
import CentreOrdinary

/-! SOURCE-ONLY. The new root is really selected and paid. It marks the old
port, retains both original K2 tails, and retains every old selected action. -/
namespace IsolationGame.P7Graft
variable {V : Type} [Fintype V] [DecidableEq V]

 theorem actual_root_marks (G : SimpleGraph V) (y : V) (M : Finset V) :
    SelectedVertex.playedMarks (graph G y) (marks M) (.inr (0 : Fin 7)) =
      MarkedSum.combine (insert y M)
        (SelectedVertex.playedMarks CentreOrdinary.graph ∅ 0) := by
  classical
  ext w
  cases w with
  | inl w =>
    simp [SelectedVertex.mem_playedMarks,marks,graph,Attachment.closed_rl,eq_comm,or_comm]
  | inr w => simp [SelectedVertex.mem_playedMarks,marks,graph]

 theorem actual_root_after_history_value (G : SimpleGraph V) (hG : G.IsAcyclic)
    (y : V) (M X : Finset V) (t : Player) :
    Marked.gameValue (graph G y) (marks M) t
      (insert (.inr (0 : Fin 7)) (X.image Sum.inl)) =
      Marked.gameValue G (insert y M) t X + 2 := by
  have ha : Marked.gameValue (graph G y) (marks M) t
      (insert (.inr (0 : Fin 7)) (X.image Sum.inl)) =
      Marked.gameValue (graph G y)
        (SelectedVertex.playedMarks (graph G y) (marks M) (.inr (0 : Fin 7)))
        t (X.image Sum.inl) := by
    apply Marked.value_eq_of_white_eq
    intro w
    rw [SelectedVertex.absorb_white]
  rw [ha,actual_root_marks]
  have hroot : (0 : Fin 7)∈SelectedVertex.playedMarks CentreOrdinary.graph ∅ 0 :=
    (SelectedVertex.mem_playedMarks _ _ _ _).mpr (Or.inr (Or.inl rfl))
  rw [Attachment.marked_endpoints_value G CentreOrdinary.graph y 0
    (insert y M) (SelectedVertex.playedMarks CentreOrdinary.graph ∅ 0)
    (Finset.mem_insert_self _ _) hroot]
  have hr : Marked.gameValue CentreOrdinary.graph
      (SelectedVertex.playedMarks CentreOrdinary.graph ∅ 0) .dominator ∅=2 ∧
      Marked.gameValue CentreOrdinary.graph
        (SelectedVertex.playedMarks CentreOrdinary.graph ∅ 0) .staller ∅=2 := by
    have he (q : Player) : Marked.gameValue CentreOrdinary.graph ∅ q {0} =
        Marked.gameValue CentreOrdinary.graph
          (SelectedVertex.playedMarks CentreOrdinary.graph ∅ 0) q ∅ := by
      apply Marked.value_eq_of_white_eq
      intro w
      change Marked.White _ _ (insert 0 ∅) w ↔ _
      rw [SelectedVertex.absorb_white]
    simpa only [←he .dominator,←he .staller] using CentreOrdinary.unmarked_root_selected_value
  have hx : X.image Sum.inl = MarkedSum.combine X (∅ : Finset (Fin 7)) := by
    ext v
    cases v <;> simp [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight]
  rw [hx]
  have hh := MarkedSum.forest_balanced_right G CentreOrdinary.graph hG
    CentreOrdinary.graph_isTree.IsAcyclic (insert y M) X
    (SelectedVertex.playedMarks CentreOrdinary.graph ∅ 0) ∅ 2 hr.1 hr.2
  cases t
  · exact hh.1
  · exact hh.2
end IsolationGame.P7Graft

#print axioms IsolationGame.P7Graft.actual_root_marks
#print axioms IsolationGame.P7Graft.actual_root_after_history_value
run_cmd do
  let env ← Lean.getEnv
  for n in env.header.moduleNames do
    Lean.logInfo m!"PROVIDER_MODULE {n}"
    let path ← Lean.findOLean n
    Lean.logInfo m!"PROVIDER_OBJECT {n} {path}"
