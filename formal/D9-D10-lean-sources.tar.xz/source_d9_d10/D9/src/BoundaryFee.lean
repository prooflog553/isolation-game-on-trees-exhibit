import BoundaryModel

namespace IsolationGame.MarkedBoundary
variable {V : Type} [Fintype V] [DecidableEq V] (G : SimpleGraph V) (z : V)

theorem terminal_unspent (M X : Finset V) (hm : z∈M) (hz : z∉X) :
    Marked.Terminal G M X ↔ Marked.Terminal (isolateVertex G z) M X := by
  unfold Marked.Terminal
  rw [white_eq_unspent G z M X hm hz]

/-- A marked original boundary move costs at most once. Until it is used,
all other original moves coincide; after it is used, continuation applies. -/
theorem S_fee (hA : G.IsAcyclic) (M X : Finset V) (hm : z∈M) :
    Marked.gameValue G M .staller X ≤ 1+Marked.gameValue (isolateVertex G z) M .staller X := by
  let H := isolateVertex G z
  have hHA : H.IsAcyclic := isolate_acyclic G z hA
  have main : ∀n,∀X : Finset V, Marked.gameValue H M .staller X=n →
      Marked.gameValue G M .staller X≤1+Marked.gameValue H M .staller X := by
    intro n
    induction n using Nat.strong_induction_on with
    | h n ih =>
      intro X hrank
      by_cases hz : z∈X
      · have h := spent_value_bound G z M X hm hz .staller
        exact h.trans (Nat.le_add_left _ _)
      by_cases ht : Marked.Terminal H M X
      · have htG := (terminal_unspent G z M X hm hz).mpr ht
        rw [(Marked.value_zero_iff_terminal G M X .staller).mpr htG]
        omega
      have htG : ¬Marked.Terminal G M X := fun h=>ht ((terminal_unspent G z M X hm hz).mp h)
      obtain ⟨v,hv,he⟩ := Marked.exists_optimal_s_move G M X htG
      by_cases hvz : v=z
      · subst v
        have hspent := spent_value_bound G z M (insert z X) hm (Finset.mem_insert_self _ _) .dominator
        rw [isolated_z_value_insert G z M X hm .dominator] at hspent
        have hno := Marked.forest_no_minus H hHA M X
        dsimp [H] at *
        omega
      have hvH : Marked.Legal H M X v := (legal_iff_unspent G z M X hm hz v hvz).mp hv
      have hfirst := Marked.s_move_lower H M X v hvH
      have hzv : z∉insert v X := by simp [hz,Ne.symm hvz]
      by_cases htv : Marked.Terminal H M (insert v X)
      · have htvG := (terminal_unspent G z M (insert v X) hm hzv).mpr htv
        have hzero := (Marked.value_zero_iff_terminal G M (insert v X) .dominator).mpr htvG
        omega
      obtain ⟨w,hw,hwopt⟩ := Marked.exists_optimal_d_move H M (insert v X) htv
      have hwz : w≠z := by
        intro heq;subst w
        exact isolated_z_illegal G z M (insert v X) hm hw
      have hwG := (legal_iff_unspent G z M (insert v X) hm hzv w hwz).mpr hw
      have hsmall : Marked.gameValue H M .staller (insert w (insert v X))<n := by omega
      have hrec := ih _ hsmall (insert w (insert v X)) rfl
      have hD := Marked.d_move_upper G M (insert v X) w hwG
      omega
  exact main _ X rfl

theorem D_fee (hA : G.IsAcyclic) (M X : Finset V) (hm : z∈M) :
    Marked.gameValue G M .dominator X ≤ 1+Marked.gameValue (isolateVertex G z) M .dominator X := by
  let H := isolateVertex G z
  by_cases hz : z∈X
  · have h := spent_value_bound G z M X hm hz .dominator
    omega
  by_cases ht : Marked.Terminal H M X
  · have htG := (terminal_unspent G z M X hm hz).mpr ht
    rw [(Marked.value_zero_iff_terminal G M X .dominator).mpr htG]
    omega
  obtain ⟨v,hv,he⟩ := Marked.exists_optimal_d_move H M X ht
  have hvz : v≠z := by
    intro heq;subst v
    exact isolated_z_illegal G z M X hm hv
  have hvG := (legal_iff_unspent G z M X hm hz v hvz).mpr hv
  have hS := S_fee G z hA M (insert v X) hm
  have hD := Marked.d_move_upper G M X v hvG
  dsimp [H] at *
  omega

#print axioms S_fee
#print axioms D_fee
end IsolationGame.MarkedBoundary
