import CenterT08ReceiverTransport
import CenterT08ReceiverFinite
import G2CenterSplit
import PureModuleStrict
import StrictCompanionPairing

namespace IsolationGame.CenterT08Receiver
open CoreFamily CanonicalLocal
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

private abbrev P (p : Nat) := CoreFamily.graph [] p
private abbrev T := LocalProfile.e0E0D1L2.original

private theorem p_acyclic (p : Nat) : (P p).IsAcyclic :=
  (CoreFamily.family_tree [] p).IsAcyclic
private theorem t_tree : T.IsTree :=
  CanonicalLocal.tree_of_certificate T 0
    (by unfold CanonicalLocal.ReachThree; decide +kernel)
    (by decide +kernel)
private theorem t_acyclic : T.IsAcyclic := t_tree.IsAcyclic

private theorem t_live : ¬Marked.Terminal T ({0} : Finset (Fin 11)) ∅ := by
  intro h
  have z := (Marked.value_zero_iff_terminal T ({0} : Finset (Fin 11)) ∅ .dominator).mpr h
  rw [Finite.root_D] at z
  omega

private theorem p_root_played_S (p : Nat) :
    Marked.gameValue (P p) (SelectedVertex.playedMarks (P p) {none} none)
      .staller ∅ ≤ 3*p := by
  have h := Marked.value_eq_of_white_eq (P p) ({none} : Finset (PureV p))
    (SelectedVertex.playedMarks (P p) {none} none) {none} ∅ .staller (by
      intro v
      exact Iff.of_eq (congrArg (fun f => f v)
        (SelectedVertex.absorb_white (P p) ({none} : Finset (PureV p)) ∅ none)))
  rw [←h]
  exact PureModuleStrict.follower_S p none

theorem fixed_root_paid (p : Nat) :
    1+Marked.gameValue (graph p) (marks p) .dominator {fixed p 0} ≤ 3*p+5 := by
  rw [value_split]
  have he := Attachment.after_left_root_value (P p) T none 0
    ({none} : Finset (PureV p)) (∅ : Finset (Fin 11)) .dominator
  simp only [Finset.image_singleton] at *
  change Marked.gameValue (splitGraph p)
    (MarkedSum.combine ({none} : Finset (PureV p)) ∅) .dominator
    {Sum.inl none} = _ at he
  change 1+Marked.gameValue (splitGraph p)
    (MarkedSum.combine ({none} : Finset (PureV p)) ∅) .dominator
    {Sum.inl none} ≤ 3*p+5
  rw [he]
  change 1+Marked.gameValue (MarkedSum.original (P p) T)
    (MarkedSum.combine (SelectedVertex.playedMarks (P p) {none} none)
      ({0} : Finset (Fin 11))) .dominator ∅ ≤ 3*p+5
  have hb := MarkedSum.D_upper_right_value (P p) T
    (MarkedSum.forest_no_minus (P p) (p_acyclic p))
    (MarkedSum.forest_no_minus T t_acyclic)
    (SelectedVertex.playedMarks (P p) {none} none) ∅
    ({0} : Finset (Fin 11)) ∅ t_live
  have hp := p_root_played_S p
  have ht : Marked.gameValue T ({0} : Finset (Fin 11)) .dominator ∅ = 4 :=
    Finite.root_D
  simp only [Finset.insert_empty] at hb ⊢
  have hempty : MarkedSum.combine (∅ : Finset (PureV p)) (∅ : Finset (Fin 11)) = ∅ := by
    simp [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight]
  rw [hempty] at hb
  have hb2 : Marked.gameValue (MarkedSum.original (P p) T)
    (MarkedSum.combine (SelectedVertex.playedMarks (P p) {none} none) (insert 0 ∅))
    .dominator ∅ ≤ Marked.gameValue (P p)
      (SelectedVertex.playedMarks (P p) {none} none) .staller ∅ +
      Marked.gameValue T ({0} : Finset (Fin 11)) .dominator ∅ := by
    simpa only [Finset.insert_empty] using hb
  omega


private theorem right_played (p : Nat) (N : Finset (Fin 11)) (a : Fin 11) :
    SelectedVertex.playedMarks (splitGraph p)
      (MarkedSum.combine ({none} : Finset (PureV p)) N) (.inr a) =
    MarkedSum.combine ({none} : Finset (PureV p))
      (SelectedVertex.playedMarks T N a) := by
  classical
  ext v
  cases v with
  | inl v =>
    cases v with
    | none => simp [SelectedVertex.mem_playedMarks,MarkedSum.combine_inl,
                   Attachment.closed_lr,splitGraph]
    | some v => simp [SelectedVertex.mem_playedMarks,MarkedSum.combine_inl,
                     Attachment.closed_lr,splitGraph]
  | inr v =>
    simp [SelectedVertex.mem_playedMarks,MarkedSum.combine_inr,
          Attachment.closed_right,splitGraph]

private theorem two_right_value (p : Nat) (a b : Fin 11) (t : Player) :
    Marked.gameValue (splitGraph p)
      (MarkedSum.combine ({none} : Finset (PureV p)) ∅) t
      ({Sum.inr a, Sum.inr b} : Finset (SplitV p)) =
    Marked.gameValue (splitGraph p)
      (MarkedSum.combine ({none} : Finset (PureV p))
        (SelectedVertex.playedMarks T
          (SelectedVertex.playedMarks T ∅ a) b)) t ∅ := by
  let M := MarkedSum.combine ({none} : Finset (PureV p)) (∅ : Finset (Fin 11))
  let M1 := SelectedVertex.playedMarks (splitGraph p) M (.inr a)
  let M2 := SelectedVertex.playedMarks (splitGraph p) M1 (.inr b)
  have h1 := Marked.value_eq_of_white_eq (splitGraph p) M M1
    ({Sum.inr a, Sum.inr b} : Finset (SplitV p)) {Sum.inr b} t (by
      intro v
      change Marked.White (splitGraph p) M (insert (.inr a) {Sum.inr b}) v ↔ _
      exact Iff.of_eq (congrArg (fun f => f v)
        (SelectedVertex.absorb_white (splitGraph p) M {Sum.inr b} (.inr a))))
  have h2 := Marked.value_eq_of_white_eq (splitGraph p) M1 M2
    {Sum.inr b} ∅ t (by
      intro v
      change Marked.White (splitGraph p) M1 (insert (.inr b) ∅) v ↔ _
      exact Iff.of_eq (congrArg (fun f => f v)
        (SelectedVertex.absorb_white (splitGraph p) M1 ∅ (.inr b))))
  rw [h1,h2]
  dsimp [M1,M2,M]
  rw [right_played,right_played]


def t_reply (a : Fin 11) : Fin 11 :=
  if a=0 ∨ a=10 then 1 else 0

def t_after (a : Fin 11) : Finset (Fin 11) :=
  Finset.univ.filter (fun v => Closed T a v ∨ Closed T (t_reply a) v)

private theorem t_after_eq (a : Fin 11) :
    SelectedVertex.playedMarks T (SelectedVertex.playedMarks T ∅ a) (t_reply a) = t_after a := by
  classical
  ext v
  simp [t_after,SelectedVertex.mem_playedMarks,or_comm,or_left_comm,or_assoc]

private theorem p_S_upper (p : Nat) :
    Marked.gameValue (P p) ({none} : Finset (PureV p)) .staller ∅ ≤ 3*p+1 := by
  have h := Marked.starting_player_inequality (P p) ({none} : Finset (PureV p)) ∅
  rw [PureModuleStrict.D_value] at h
  omega

private theorem t_after_root (a : Fin 11) : 0 ∈ t_after a := by
  fin_cases a <;> decide +kernel

private theorem t_after_hard : t_after 10 = Finite.hardMarks := by decide +kernel

private theorem t_after_0 : t_after 0 = Finite.marks12 := by decide +kernel

private theorem t_after_ordinary (a : Fin 11) (ha : a≠10) :
    Marked.gameValue T (t_after a) .staller ∅ ≤ 2 := by
  fin_cases a
  · change Marked.gameValue T (t_after (0 : Fin 11)) .staller ∅ ≤ 2
    have hm : t_after (0 : Fin 11) = Finite.marks12 := by decide +kernel
    rw [hm]
    exact Finite.row12_S
  · change Marked.gameValue T (t_after (1 : Fin 11)) .staller ∅ ≤ 2
    have hm : t_after (1 : Fin 11) = Finite.marks12 := by decide +kernel
    rw [hm]
    exact Finite.row12_S
  · change Marked.gameValue T (t_after (2 : Fin 11)) .staller ∅ ≤ 2
    have hm : t_after (2 : Fin 11) = Finite.marks34 := by decide +kernel
    rw [hm]
    exact Finite.row34_S
  · change Marked.gameValue T (t_after (3 : Fin 11)) .staller ∅ ≤ 2
    have hm : t_after (3 : Fin 11) = Finite.marks34 := by decide +kernel
    rw [hm]
    exact Finite.row34_S
  · change Marked.gameValue T (t_after (4 : Fin 11)) .staller ∅ ≤ 2
    have hm : t_after (4 : Fin 11) = Finite.marks5 := by decide +kernel
    rw [hm]
    exact Finite.row5_S
  · change Marked.gameValue T (t_after (5 : Fin 11)) .staller ∅ ≤ 2
    have hm : t_after (5 : Fin 11) = Finite.marks67 := by decide +kernel
    rw [hm]
    exact Finite.row67_S
  · change Marked.gameValue T (t_after (6 : Fin 11)) .staller ∅ ≤ 2
    have hm : t_after (6 : Fin 11) = Finite.marks67 := by decide +kernel
    rw [hm]
    exact Finite.row67_S
  · change Marked.gameValue T (t_after (7 : Fin 11)) .staller ∅ ≤ 2
    have hm : t_after (7 : Fin 11) = Finite.marks8 := by decide +kernel
    rw [hm]
    exact Finite.row8_S
  · change Marked.gameValue T (t_after (8 : Fin 11)) .staller ∅ ≤ 2
    have hm : t_after (8 : Fin 11) = Finite.marks910 := by decide +kernel
    rw [hm]
    exact Finite.row910_S
  · change Marked.gameValue T (t_after (9 : Fin 11)) .staller ∅ ≤ 2
    have hm : t_after (9 : Fin 11) = Finite.marks910 := by decide +kernel
    rw [hm]
    exact Finite.row910_S
  · exact False.elim (ha rfl)


private theorem two_right_sum_value (p : Nat) (a : Fin 11) (t : Player) :
    Marked.gameValue (splitGraph p)
      (MarkedSum.combine ({none} : Finset (PureV p)) ∅) t
      ({Sum.inr a, Sum.inr (t_reply a)} : Finset (SplitV p)) =
    Marked.gameValue (MarkedSum.original (P p) T)
      (MarkedSum.combine ({none} : Finset (PureV p)) (t_after a)) t ∅ := by
  rw [two_right_value]
  rw [t_after_eq]
  exact Attachment.marked_endpoints_value (P p) T none 0
    ({none} : Finset (PureV p)) (t_after a) (Finset.mem_singleton_self _)
    (t_after_root a) ∅ t

private theorem t_two_ordinary (p : Nat) (a : Fin 11) (ha : a≠10) :
    Marked.gameValue (splitGraph p)
      (MarkedSum.combine ({none} : Finset (PureV p)) ∅) .staller
      ({Sum.inr a, Sum.inr (t_reply a)} : Finset (SplitV p)) ≤ 3*p+3 := by
  rw [two_right_sum_value]
  have hs := MarkedSum.S_upper_value (P p) T
    (MarkedSum.forest_no_minus (P p) (p_acyclic p))
    (MarkedSum.forest_no_minus T t_acyclic)
    ({none} : Finset (PureV p)) ∅ (t_after a) ∅
  have hempty : MarkedSum.combine (∅ : Finset (PureV p)) (∅ : Finset (Fin 11)) = ∅ := by
    simp [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight]
  rw [hempty] at hs
  have hp := p_S_upper p
  have ht : Marked.gameValue T (t_after a) .staller ∅ ≤ 2 := t_after_ordinary a ha
  omega

private theorem t_two_hard (p : Nat) :
    Marked.gameValue (splitGraph p)
      (MarkedSum.combine ({none} : Finset (PureV p)) ∅) .staller
      ({Sum.inr (10:Fin 11), Sum.inr (t_reply 10)} : Finset (SplitV p)) ≤ 3*p+3 := by
  rw [two_right_sum_value, t_after_hard]
  have h := MarkedSum.forest_strict_pair (P p) T (p_acyclic p) t_acyclic
    ({none} : Finset (PureV p)) ∅ Finite.hardMarks ∅
    (3*p+1) 3 (PureModuleStrict.family_strict p) Finite.hard_strict
  have hempty : MarkedSum.combine (∅ : Finset (PureV p)) (∅ : Finset (Fin 11)) = ∅ := by
    simp [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight]
  rw [hempty] at h
  omega


private theorem right_undominated (p : Nat) (a v : Fin 11) :
    Marked.Undominated (splitGraph p)
      (MarkedSum.combine ({none} : Finset (PureV p)) ∅)
      {Sum.inr a} (.inr v) ↔ Marked.Undominated T ∅ {a} v := by
  simp [Marked.Undominated,IsolationGame.Undominated,IsolationGame.Dominated,
        MarkedSum.combine_inr,Attachment.closed_right,splitGraph]

private theorem right_white (p : Nat) (a v : Fin 11) :
    Marked.White T ∅ {a} v →
    Marked.White (splitGraph p)
      (MarkedSum.combine ({none} : Finset (PureV p)) ∅)
      {Sum.inr a} (.inr v) := by
  rintro ⟨hv,w,haw,hw⟩
  exact ⟨(right_undominated p a v).mpr hv,.inr w,haw,
    (right_undominated p a w).mpr hw⟩

private theorem t_reply_legal (a : Fin 11) :
    Marked.Legal T ∅ {a} (t_reply a) := by
  fin_cases a <;> decide +kernel

private theorem split_reply_legal (p : Nat) (a : Fin 11) :
    Marked.Legal (splitGraph p)
      (MarkedSum.combine ({none} : Finset (PureV p)) ∅)
      {Sum.inr a} (.inr (t_reply a)) := by
  obtain ⟨w,hw,hwhite⟩ := t_reply_legal a
  exact ⟨.inr w,(Attachment.closed_right (P p) T none 0 (t_reply a) w).mpr hw,
    right_white p a w hwhite⟩


private theorem split_t_paid (p : Nat) (a : Fin 11) :
    1+Marked.gameValue (splitGraph p)
      (MarkedSum.combine ({none} : Finset (PureV p)) ∅)
      .dominator {Sum.inr a} ≤ 3*p+5 := by
  have hd := Marked.d_move_upper (splitGraph p)
    (MarkedSum.combine ({none} : Finset (PureV p)) ∅)
    {Sum.inr a} (.inr (t_reply a)) (split_reply_legal p a)
  have hx : insert (Sum.inr (t_reply a)) ({Sum.inr a} : Finset (SplitV p)) =
      {Sum.inr a,Sum.inr (t_reply a)} := by
    ext v; simp [or_comm]
  rw [hx] at hd
  by_cases ha : a=10
  · subst a
    have hs := t_two_hard p
    omega
  · have hs := t_two_ordinary p a ha
    omega

theorem fixed_t_paid (p : Nat) (a : Fin 11) :
    1+Marked.gameValue (graph p) (marks p) .dominator {fixed p a.succ} ≤ 3*p+5 := by
  rw [value_split]
  change 1+Marked.gameValue (splitGraph p)
    (MarkedSum.combine ({none} : Finset (PureV p)) ∅)
    .dominator {Sum.inr a} ≤ 3*p+5
  exact split_t_paid p a


theorem fixed_paid_bound (p : Nat) (a : Fixed) :
    1+Marked.gameValue (graph p) (marks p) .dominator {fixed p a} ≤ 3*p+5 := by
  induction a using Fin.cases with
  | zero => exact fixed_root_paid p
  | succ a => exact fixed_t_paid p a

#print axioms fixed_paid_bound

#print axioms fixed_t_paid

#print axioms split_reply_legal

#print axioms two_right_sum_value
#print axioms t_two_ordinary
#print axioms t_two_hard

#print axioms t_after_ordinary

#print axioms right_played
#print axioms two_right_value

#print axioms fixed_root_paid
end IsolationGame.CenterT08Receiver
