import FourteenDiameterNineSemantics
import Lean.Util.CollectAxioms
set_option maxRecDepth 8192
set_option maxHeartbeats 4000000
set_option pp.universes true

#check IsolationGame.FourteenDiameterNineClosure.fourteen_ceiling_obligations
#print axioms IsolationGame.FourteenDiameterNineClosure.fourteen_ceiling_obligations
#check IsolationGame.FourteenDiameterNineClosure.diameter_nine_ordinary_ceiling
#print axioms IsolationGame.FourteenDiameterNineClosure.diameter_nine_ordinary_ceiling
#check IsolationGame.FourteenDiameterNineClosure.diameter_nine_ordinary_ceil_formula
#print axioms IsolationGame.FourteenDiameterNineClosure.diameter_nine_ordinary_ceil_formula
#check IsolationGame.FourteenDiameterNineClosure.fresh_all_patterns
#print axioms IsolationGame.FourteenDiameterNineClosure.fresh_all_patterns
#check IsolationGame.FourteenDiameterNineClosure.fresh_zero_axes
#print axioms IsolationGame.FourteenDiameterNineClosure.fresh_zero_axes
#check IsolationGame.FourteenDiameterNineClosure.fresh_actual_finite_tree
#print axioms IsolationGame.FourteenDiameterNineClosure.fresh_actual_finite_tree
#check IsolationGame.FourteenDiameterNineClosure.actual_empty_start
#print axioms IsolationGame.FourteenDiameterNineClosure.actual_empty_start
#check IsolationGame.FourteenDiameterNineClosure.actual_empty_marks_and_history
#print axioms IsolationGame.FourteenDiameterNineClosure.actual_empty_marks_and_history
#check IsolationGame.FourteenDiameterNineClosure.actual_strategy_bound
#print axioms IsolationGame.FourteenDiameterNineClosure.actual_strategy_bound
#check IsolationGame.FourteenDiameterNineClosure.fresh_all_patterns_and_zero_axes
#print axioms IsolationGame.FourteenDiameterNineClosure.fresh_all_patterns_and_zero_axes
#check IsolationGame.FourteenDiameterNineClosure.edgeless_actual_value_zero
#print axioms IsolationGame.FourteenDiameterNineClosure.edgeless_actual_value_zero
#check IsolationGame.FourteenDiameterNineClosure.subsingleton_actual_value_zero
#print axioms IsolationGame.FourteenDiameterNineClosure.subsingleton_actual_value_zero

run_cmd do
  let env ← Lean.getEnv
  let batchModules : Array String := #["FourteenDiameterNineClosure","FourteenDiameterNineFresh","FourteenDiameterNineSemantics"]
  let names := env.constants.fold (fun ns n ci =>
    match env.getModuleIdxFor? n with
    | some idx =>
      if batchModules.contains env.header.moduleNames[idx]!.toString && !ci.isUnsafe && !ci.isPartial
      then ns.push n else ns
    | none => ns) (#[] : Array Lean.Name)
  let rec beforeAt : Lean.Name → Lean.Name
    | .anonymous => .anonymous
    | .str p s => if s == "_at" then p else beforeAt p
    | .num p _ => beforeAt p
  for (n, ci) in env.constants do
    if let some idx := env.getModuleIdxFor? n then
      let modName := env.header.moduleNames[idx]!
      if batchModules.contains modName.toString then
        let kind : String := match ci with
          | .thmInfo _ => "theorem"
          | .defnInfo _ => "def"
          | .axiomInfo _ => "axiom"
          | .opaqueInfo _ => "opaque"
          | _ => "generated"
        Lean.logInfo m!"BATCH_DECL {modName} {n} {kind}"
        Lean.logInfo m!"CONST_FLAGS {modName} {n} kind={kind} unsafe={ci.isUnsafe} partial={ci.isPartial}"
        if !Lean.isPrivateName n && !n.isInternal then
          Lean.logInfo m!"ACTUAL_PUBLIC_DECL {modName} {n} {kind} instance={Lean.Meta.isInstanceCore env n} unsafe={ci.isUnsafe} partial={ci.isPartial}"
          if Lean.Meta.isInstanceCore env n && !ci.isUnsafe && !ci.isPartial then
            Lean.logInfo m!"PUBLIC_INSTANCE_TYPE {n} {ci.type}"
            let (_, state) := ((Lean.CollectAxioms.collect n).run env).run {}
            Lean.logInfo m!"PUBLIC_INSTANCE_AXIOMS {n} {state.axioms.qsort Lean.Name.lt |>.toList}"
        if ci.isUnsafe || ci.isPartial then
          Lean.logInfo m!"UNSAFE_RUNTIME_CONST {modName} {n} kind={kind} unsafe={ci.isUnsafe} partial={ci.isPartial}"
          if kind == "axiom" then
            let b := beforeAt n
            let original : Lean.Name := if b == .anonymous then n.getPrefix else b
            match env.getModuleIdxFor? original with
            | some oi =>
              let om := env.header.moduleNames[oi]!
              Lean.logInfo m!"STUB_ORIGINAL {n} {original} {om} exists=true"
            | none => Lean.logInfo m!"STUB_ORIGINAL {n} {original} UNKNOWN exists=false"
  for n in names do
    Lean.logInfo m!"SAFE_KERNEL_CONST {n}"
  let action : Lean.CollectAxioms.M Unit := do
    for n in names do
      Lean.CollectAxioms.collect n
  let (_, state) := (action.run env).run {}
  Lean.logInfo m!"SAFE_KERNEL_AXIOM_UNION {state.axioms.qsort Lean.Name.lt |>.toList}"
  for n in env.header.moduleNames do
    Lean.logInfo m!"PROVIDER_MODULE {n}"
    let path ← Lean.findOLean n
    Lean.logInfo m!"PROVIDER_OBJECT {n} {path}"
