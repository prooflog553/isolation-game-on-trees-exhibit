import FloorLocalBase
import FloorLocalRow001
set_option maxRecDepth 4096
set_option maxHeartbeats 1000000
namespace IsolationGame.FloorLocal
def marks_017 : Finset (Fin 7) := {0,1,4,5,6}
theorem normalized_017 : ∀v : Fin 7, Marked.White original_02 marks_017 ∅ v ↔ v∈({2,3} : Finset (Fin 7)) := by decide +kernel
theorem after_017_1 : Marked.gameValue original_02 marks_017 .dominator {1}=0 ∧ Marked.gameValue original_02 marks_017 .staller {1}=0 :=
  LocalProfile.DAG.transport original_02 marks_017 marks_001 1 0 0 (by decide +kernel) row_001
theorem after_017_2 : Marked.gameValue original_02 marks_017 .dominator {2}=0 ∧ Marked.gameValue original_02 marks_017 .staller {2}=0 :=
  LocalProfile.DAG.transport original_02 marks_017 marks_001 2 0 0 (by decide +kernel) row_001
theorem after_017_3 : Marked.gameValue original_02 marks_017 .dominator {3}=0 ∧ Marked.gameValue original_02 marks_017 .staller {3}=0 :=
  LocalProfile.DAG.transport original_02 marks_017 marks_001 3 0 0 (by decide +kernel) row_001
theorem row_017 : Marked.gameValue original_02 marks_017 .dominator ∅=1 ∧ Marked.gameValue original_02 marks_017 .staller ∅=1 := by
  apply LocalProfile.DAG.bellman original_02 marks_017 1 1 1 1 (by decide +kernel) (by decide +kernel)
  · rw [after_017_1.2]
  · rw [after_017_1.1]
  · intro v hv
    fin_cases v
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_017 ∅ 0) hv)
    · have h := after_017_1
      change 1≤1+Marked.gameValue original_02 marks_017 .staller {1} ∧ 1+Marked.gameValue original_02 marks_017 .dominator {1}≤1
      omega
    · have h := after_017_2
      change 1≤1+Marked.gameValue original_02 marks_017 .staller {2} ∧ 1+Marked.gameValue original_02 marks_017 .dominator {2}≤1
      omega
    · have h := after_017_3
      change 1≤1+Marked.gameValue original_02 marks_017 .staller {3} ∧ 1+Marked.gameValue original_02 marks_017 .dominator {3}≤1
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_017 ∅ 4) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_017 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_017 ∅ 6) hv)
#print axioms row_017
end IsolationGame.FloorLocal
