import CoreForestBounds
import MixedFiniteReplyPairing

namespace IsolationGame.CoreForest
open CanonicalLocal CoreFamily CoreFamilySemantics IsolatedRestriction FiniteForestComponents
variable (xs : List Nat) (p : Nat)

theorem local_reply (W : LocalWhite xs p) (i : Fin (xs.length+p)) (c : Nat)
    (h : MarkedSum.ReplyStrictCapacity (CanonicalLocal.graph (label xs p i))
      (ForestFoundation.canonicalMarks (W i)) ∅ c) :
    MarkedSum.ReplyStrictCapacity (induced (forest xs p) (component xs p i))
      (restrict (component xs p i) (forestMarks xs p W)) ∅ c := by
  have ht := MarkedSum.reply_relabel (CanonicalLocal.graph (label xs p i))
    (induced (forest xs p) (component xs p i)) (localEquiv xs p i)
    (local_adjacency xs p i) (ForestFoundation.canonicalMarks (W i)) ∅ c h
  simpa only [local_marks_image,Finset.image_empty] using ht

/-- Arbitrarily many designated original copies receive a floor(|J|/2) upper-bound discount.
The supplied weak capacities may mix genuine strict and reply-strict copies. -/
theorem reply_mixed_s_upper (hA : (CoreFamily.graph xs p).IsAcyclic) (W : LocalWhite xs p)
    (c : Fin (xs.length+p)→Nat) (J : Finset (Fin (xs.length+p)))
    (hc : ∀i,Marked.gameValue (CanonicalLocal.graph (label xs p i))
      (ForestFoundation.canonicalMarks (W i)) .staller ∅≤c i)
    (hj : ∀i∈J,MarkedSum.ReplyStrictCapacity (CanonicalLocal.graph (label xs p i))
      (ForestFoundation.canonicalMarks (W i)) ∅ (c i)) :
    Marked.gameValue (forest xs p) (forestMarks xs p W) .staller ∅≤(∑i,c i)-J.card/2 := by
  classical
  have hX (i) : restrict (component xs p i) (∅ : Finset (DeletedVertex xs p))=∅ := by
    ext v
    simp
  have hcap : ∀i∈(Finset.univ : Finset (Fin (xs.length+p))),
      valueOn (forest xs p) (component xs p i) (forestMarks xs p W) ∅ .staller≤c i := by
    intro i _
    unfold valueOn
    rw [hX,local_value]
    exact hc i
  have hreply : ∀i∈J,MarkedSum.ReplyStrictCapacity (induced (forest xs p) (component xs p i))
      (restrict (component xs p i) (forestMarks xs p W)) (restrict (component xs p i) ∅) (c i) := by
    intro i hi
    rw [hX]
    exact local_reply xs p W i (c i) (hj i hi)
  have hf := finite_reply_mixed_s_upper (forest xs p) (forest_acyclic xs p hA)
    (component xs p) (components_disjoint xs p) (components_no_cross xs p)
    Finset.univ J (Finset.subset_univ _) (forestMarks xs p W) ∅ c hcap hreply
  rw [components_cover,univ_value] at hf
  exact hf

/-- The existing strict hypotheses enter the new interface without a change. -/
theorem reply_mixed_s_upper_of_strict (hA : (CoreFamily.graph xs p).IsAcyclic) (W : LocalWhite xs p)
    (c : Fin (xs.length+p)→Nat) (J : Finset (Fin (xs.length+p)))
    (hc : ∀i,Marked.gameValue (CanonicalLocal.graph (label xs p i))
      (ForestFoundation.canonicalMarks (W i)) .staller ∅≤c i)
    (hj : ∀i∈J,MarkedSum.StrictCapacity (CanonicalLocal.graph (label xs p i))
      (ForestFoundation.canonicalMarks (W i)) ∅ (c i)) :
    Marked.gameValue (forest xs p) (forestMarks xs p W) .staller ∅≤(∑i,c i)-J.card/2 :=
  reply_mixed_s_upper xs p hA W c J hc (fun i hi=>
    MarkedSum.strict_to_reply _ _ _ _ (hj i hi))

#print axioms local_reply
#print axioms reply_mixed_s_upper
#print axioms reply_mixed_s_upper_of_strict
end IsolationGame.CoreForest
