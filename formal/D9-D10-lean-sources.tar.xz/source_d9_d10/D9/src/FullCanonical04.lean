import FullCanonical04Rows05
namespace IsolationGame.FullCanonical.T04
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
theorem full_values : Marked.gameValue original ∅ .dominator ∅=5 ∧ Marked.gameValue original ∅ .staller ∅=5 := by
  constructor
  · exact (Marked.value_eq_of_white_eq original ∅ marks_21 ∅ ∅ .dominator (by decide +kernel)).trans row_21.1
  · exact (Marked.value_eq_of_white_eq original ∅ marks_21 ∅ ∅ .staller (by decide +kernel)).trans row_21.2
theorem not_strict_full : ¬MarkedSum.StrictCapacity original ∅ ∅ 5 := by
  intro h
  have hd := h.1
  rw [full_values.1] at hd
  omega
#print axioms full_values
#print axioms not_strict_full
end IsolationGame.FullCanonical.T04
