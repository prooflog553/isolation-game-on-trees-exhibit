import FullCanonical15Rows01
namespace IsolationGame.FullCanonical.T15
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_8 : Finset (Fin 8) := {0,7}
theorem after_8_0 : Marked.gameValue original marks_8 .dominator {0}=2 ∧ Marked.gameValue original marks_8 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_5 0 2 2 (by decide +kernel) row_5
theorem after_8_1 : Marked.gameValue original marks_8 .dominator {1}=1 ∧ Marked.gameValue original marks_8 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_3 1 1 2 (by decide +kernel) row_3
theorem after_8_2 : Marked.gameValue original marks_8 .dominator {2}=1 ∧ Marked.gameValue original marks_8 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_3 2 1 2 (by decide +kernel) row_3
theorem after_8_3 : Marked.gameValue original marks_8 .dominator {3}=1 ∧ Marked.gameValue original marks_8 .staller {3}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_3 3 1 2 (by decide +kernel) row_3
theorem after_8_4 : Marked.gameValue original marks_8 .dominator {4}=1 ∧ Marked.gameValue original marks_8 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_8 marks_3 4 1 2 (by decide +kernel) row_3
theorem after_8_5 : Marked.gameValue original marks_8 .dominator {5}=1 ∧ Marked.gameValue original marks_8 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_8 marks_3 5 1 2 (by decide +kernel) row_3
theorem after_8_6 : Marked.gameValue original marks_8 .dominator {6}=1 ∧ Marked.gameValue original marks_8 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_8 marks_3 6 1 2 (by decide +kernel) row_3
theorem row_8 : Marked.gameValue original marks_8 .dominator ∅=3 ∧ Marked.gameValue original marks_8 .staller ∅=3 := by
  apply LocalProfile.DAG.bellman original marks_8 3 3 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_8_0.2]
  · rw [after_8_0.1]
  · intro v hv
    fin_cases v
    · have h := after_8_0
      change 3 ≤ 1+Marked.gameValue original marks_8 .staller {0} ∧ 1+Marked.gameValue original marks_8 .dominator {0} ≤ 3
      omega
    · have h := after_8_1
      change 3 ≤ 1+Marked.gameValue original marks_8 .staller {1} ∧ 1+Marked.gameValue original marks_8 .dominator {1} ≤ 3
      omega
    · have h := after_8_2
      change 3 ≤ 1+Marked.gameValue original marks_8 .staller {2} ∧ 1+Marked.gameValue original marks_8 .dominator {2} ≤ 3
      omega
    · have h := after_8_3
      change 3 ≤ 1+Marked.gameValue original marks_8 .staller {3} ∧ 1+Marked.gameValue original marks_8 .dominator {3} ≤ 3
      omega
    · have h := after_8_4
      change 3 ≤ 1+Marked.gameValue original marks_8 .staller {4} ∧ 1+Marked.gameValue original marks_8 .dominator {4} ≤ 3
      omega
    · have h := after_8_5
      change 3 ≤ 1+Marked.gameValue original marks_8 .staller {5} ∧ 1+Marked.gameValue original marks_8 .dominator {5} ≤ 3
      omega
    · have h := after_8_6
      change 3 ≤ 1+Marked.gameValue original marks_8 .staller {6} ∧ 1+Marked.gameValue original marks_8 .dominator {6} ≤ 3
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_8 ∅ 7) hv)
def marks_9 : Finset (Fin 8) := {2,3}
theorem after_9_0 : Marked.gameValue original marks_9 .dominator {0}=1 ∧ Marked.gameValue original marks_9 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_9 marks_1 0 1 1 (by decide +kernel) row_1
theorem after_9_1 : Marked.gameValue original marks_9 .dominator {1}=1 ∧ Marked.gameValue original marks_9 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_9 marks_3 1 1 2 (by decide +kernel) row_3
theorem after_9_2 : Marked.gameValue original marks_9 .dominator {2}=1 ∧ Marked.gameValue original marks_9 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_9 marks_7 2 1 2 (by decide +kernel) row_7
theorem after_9_4 : Marked.gameValue original marks_9 .dominator {4}=0 ∧ Marked.gameValue original marks_9 .staller {4}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_9 marks_0 4 0 0 (by decide +kernel) row_0
theorem after_9_5 : Marked.gameValue original marks_9 .dominator {5}=1 ∧ Marked.gameValue original marks_9 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_9 marks_4 5 1 2 (by decide +kernel) row_4
theorem after_9_6 : Marked.gameValue original marks_9 .dominator {6}=1 ∧ Marked.gameValue original marks_9 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_9 marks_6 6 1 2 (by decide +kernel) row_6
theorem after_9_7 : Marked.gameValue original marks_9 .dominator {7}=1 ∧ Marked.gameValue original marks_9 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_9 marks_3 7 1 2 (by decide +kernel) row_3
theorem row_9 : Marked.gameValue original marks_9 .dominator ∅=1 ∧ Marked.gameValue original marks_9 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_9 1 2 4 0 (by decide +kernel) (by decide +kernel)
  · rw [after_9_4.2]
  · rw [after_9_0.1]
  · intro v hv
    fin_cases v
    · have h := after_9_0
      change 1 ≤ 1+Marked.gameValue original marks_9 .staller {0} ∧ 1+Marked.gameValue original marks_9 .dominator {0} ≤ 2
      omega
    · have h := after_9_1
      change 1 ≤ 1+Marked.gameValue original marks_9 .staller {1} ∧ 1+Marked.gameValue original marks_9 .dominator {1} ≤ 2
      omega
    · have h := after_9_2
      change 1 ≤ 1+Marked.gameValue original marks_9 .staller {2} ∧ 1+Marked.gameValue original marks_9 .dominator {2} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_9 ∅ 3) hv)
    · have h := after_9_4
      change 1 ≤ 1+Marked.gameValue original marks_9 .staller {4} ∧ 1+Marked.gameValue original marks_9 .dominator {4} ≤ 2
      omega
    · have h := after_9_5
      change 1 ≤ 1+Marked.gameValue original marks_9 .staller {5} ∧ 1+Marked.gameValue original marks_9 .dominator {5} ≤ 2
      omega
    · have h := after_9_6
      change 1 ≤ 1+Marked.gameValue original marks_9 .staller {6} ∧ 1+Marked.gameValue original marks_9 .dominator {6} ≤ 2
      omega
    · have h := after_9_7
      change 1 ≤ 1+Marked.gameValue original marks_9 .staller {7} ∧ 1+Marked.gameValue original marks_9 .dominator {7} ≤ 2
      omega
def marks_10 : Finset (Fin 8) := {}
theorem after_10_0 : Marked.gameValue original marks_10 .dominator {0}=2 ∧ Marked.gameValue original marks_10 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_10 marks_5 0 2 2 (by decide +kernel) row_5
theorem after_10_1 : Marked.gameValue original marks_10 .dominator {1}=1 ∧ Marked.gameValue original marks_10 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_10 marks_3 1 1 2 (by decide +kernel) row_3
theorem after_10_2 : Marked.gameValue original marks_10 .dominator {2}=1 ∧ Marked.gameValue original marks_10 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_10 marks_7 2 1 2 (by decide +kernel) row_7
theorem after_10_3 : Marked.gameValue original marks_10 .dominator {3}=1 ∧ Marked.gameValue original marks_10 .staller {3}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_10 marks_9 3 1 2 (by decide +kernel) row_9
theorem after_10_4 : Marked.gameValue original marks_10 .dominator {4}=1 ∧ Marked.gameValue original marks_10 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_10 marks_3 4 1 2 (by decide +kernel) row_3
theorem after_10_5 : Marked.gameValue original marks_10 .dominator {5}=1 ∧ Marked.gameValue original marks_10 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_10 marks_7 5 1 2 (by decide +kernel) row_7
theorem after_10_6 : Marked.gameValue original marks_10 .dominator {6}=1 ∧ Marked.gameValue original marks_10 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_10 marks_9 6 1 2 (by decide +kernel) row_9
theorem after_10_7 : Marked.gameValue original marks_10 .dominator {7}=3 ∧ Marked.gameValue original marks_10 .staller {7}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_10 marks_8 7 3 3 (by decide +kernel) row_8
theorem row_10 : Marked.gameValue original marks_10 .dominator ∅=3 ∧ Marked.gameValue original marks_10 .staller ∅=4 := by
  apply LocalProfile.DAG.bellman original marks_10 3 4 0 7 (by decide +kernel) (by decide +kernel)
  · rw [after_10_0.2]
  · rw [after_10_7.1]
  · intro v hv
    fin_cases v
    · have h := after_10_0
      change 3 ≤ 1+Marked.gameValue original marks_10 .staller {0} ∧ 1+Marked.gameValue original marks_10 .dominator {0} ≤ 4
      omega
    · have h := after_10_1
      change 3 ≤ 1+Marked.gameValue original marks_10 .staller {1} ∧ 1+Marked.gameValue original marks_10 .dominator {1} ≤ 4
      omega
    · have h := after_10_2
      change 3 ≤ 1+Marked.gameValue original marks_10 .staller {2} ∧ 1+Marked.gameValue original marks_10 .dominator {2} ≤ 4
      omega
    · have h := after_10_3
      change 3 ≤ 1+Marked.gameValue original marks_10 .staller {3} ∧ 1+Marked.gameValue original marks_10 .dominator {3} ≤ 4
      omega
    · have h := after_10_4
      change 3 ≤ 1+Marked.gameValue original marks_10 .staller {4} ∧ 1+Marked.gameValue original marks_10 .dominator {4} ≤ 4
      omega
    · have h := after_10_5
      change 3 ≤ 1+Marked.gameValue original marks_10 .staller {5} ∧ 1+Marked.gameValue original marks_10 .dominator {5} ≤ 4
      omega
    · have h := after_10_6
      change 3 ≤ 1+Marked.gameValue original marks_10 .staller {6} ∧ 1+Marked.gameValue original marks_10 .dominator {6} ≤ 4
      omega
    · have h := after_10_7
      change 3 ≤ 1+Marked.gameValue original marks_10 .staller {7} ∧ 1+Marked.gameValue original marks_10 .dominator {7} ≤ 4
      omega
end IsolationGame.FullCanonical.T15
