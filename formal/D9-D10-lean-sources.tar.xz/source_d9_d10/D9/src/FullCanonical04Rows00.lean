import FullCanonical04Base
namespace IsolationGame.FullCanonical.T04
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_0 : Finset (Fin 13) := {0,1,2,3,4,5,6,7,8,9,10,11,12}
theorem row_0 : Marked.gameValue original marks_0 .dominator ∅=0 ∧ Marked.gameValue original marks_0 .staller ∅=0 := by
  constructor <;> apply (Marked.value_zero_iff_terminal _ _ _ _).mpr <;> decide +kernel
def marks_1 : Finset (Fin 13) := {1,2,3,4,5,6,7,8,9,11,12}
theorem after_1_0 : Marked.gameValue original marks_1 .dominator {0}=0 ∧ Marked.gameValue original marks_1 .staller {0}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_1 marks_0 0 0 0 (by decide +kernel) row_0
theorem after_1_1 : Marked.gameValue original marks_1 .dominator {1}=0 ∧ Marked.gameValue original marks_1 .staller {1}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_1 marks_0 1 0 0 (by decide +kernel) row_0
theorem after_1_4 : Marked.gameValue original marks_1 .dominator {4}=0 ∧ Marked.gameValue original marks_1 .staller {4}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_1 marks_0 4 0 0 (by decide +kernel) row_0
theorem after_1_7 : Marked.gameValue original marks_1 .dominator {7}=0 ∧ Marked.gameValue original marks_1 .staller {7}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_1 marks_0 7 0 0 (by decide +kernel) row_0
theorem after_1_10 : Marked.gameValue original marks_1 .dominator {10}=0 ∧ Marked.gameValue original marks_1 .staller {10}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_1 marks_0 10 0 0 (by decide +kernel) row_0
theorem after_1_11 : Marked.gameValue original marks_1 .dominator {11}=0 ∧ Marked.gameValue original marks_1 .staller {11}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_1 marks_0 11 0 0 (by decide +kernel) row_0
theorem row_1 : Marked.gameValue original marks_1 .dominator ∅=1 ∧ Marked.gameValue original marks_1 .staller ∅=1 := by
  apply LocalProfile.DAG.bellman original marks_1 1 1 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_1_0.2]
  · rw [after_1_0.1]
  · intro v hv
    fin_cases v
    · have h := after_1_0
      change 1 ≤ 1+Marked.gameValue original marks_1 .staller {0} ∧ 1+Marked.gameValue original marks_1 .dominator {0} ≤ 1
      omega
    · have h := after_1_1
      change 1 ≤ 1+Marked.gameValue original marks_1 .staller {1} ∧ 1+Marked.gameValue original marks_1 .dominator {1} ≤ 1
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_1 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_1 ∅ 3) hv)
    · have h := after_1_4
      change 1 ≤ 1+Marked.gameValue original marks_1 .staller {4} ∧ 1+Marked.gameValue original marks_1 .dominator {4} ≤ 1
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_1 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_1 ∅ 6) hv)
    · have h := after_1_7
      change 1 ≤ 1+Marked.gameValue original marks_1 .staller {7} ∧ 1+Marked.gameValue original marks_1 .dominator {7} ≤ 1
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_1 ∅ 8) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_1 ∅ 9) hv)
    · have h := after_1_10
      change 1 ≤ 1+Marked.gameValue original marks_1 .staller {10} ∧ 1+Marked.gameValue original marks_1 .dominator {10} ≤ 1
      omega
    · have h := after_1_11
      change 1 ≤ 1+Marked.gameValue original marks_1 .staller {11} ∧ 1+Marked.gameValue original marks_1 .dominator {11} ≤ 1
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_1 ∅ 12) hv)
def marks_2 : Finset (Fin 13) := {0,1,2,3,4,5,6,7,8,9,10}
theorem after_2_10 : Marked.gameValue original marks_2 .dominator {10}=0 ∧ Marked.gameValue original marks_2 .staller {10}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_2 marks_0 10 0 0 (by decide +kernel) row_0
theorem after_2_11 : Marked.gameValue original marks_2 .dominator {11}=0 ∧ Marked.gameValue original marks_2 .staller {11}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_2 marks_0 11 0 0 (by decide +kernel) row_0
theorem after_2_12 : Marked.gameValue original marks_2 .dominator {12}=0 ∧ Marked.gameValue original marks_2 .staller {12}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_2 marks_0 12 0 0 (by decide +kernel) row_0
theorem row_2 : Marked.gameValue original marks_2 .dominator ∅=1 ∧ Marked.gameValue original marks_2 .staller ∅=1 := by
  apply LocalProfile.DAG.bellman original marks_2 1 1 10 10 (by decide +kernel) (by decide +kernel)
  · rw [after_2_10.2]
  · rw [after_2_10.1]
  · intro v hv
    fin_cases v
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_2 ∅ 0) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_2 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_2 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_2 ∅ 3) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_2 ∅ 4) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_2 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_2 ∅ 6) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_2 ∅ 7) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_2 ∅ 8) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_2 ∅ 9) hv)
    · have h := after_2_10
      change 1 ≤ 1+Marked.gameValue original marks_2 .staller {10} ∧ 1+Marked.gameValue original marks_2 .dominator {10} ≤ 1
      omega
    · have h := after_2_11
      change 1 ≤ 1+Marked.gameValue original marks_2 .staller {11} ∧ 1+Marked.gameValue original marks_2 .dominator {11} ≤ 1
      omega
    · have h := after_2_12
      change 1 ≤ 1+Marked.gameValue original marks_2 .staller {12} ∧ 1+Marked.gameValue original marks_2 .dominator {12} ≤ 1
      omega
def marks_3 : Finset (Fin 13) := {1,2,3,4,5,6,8,9,11,12}
theorem after_3_0 : Marked.gameValue original marks_3 .dominator {0}=0 ∧ Marked.gameValue original marks_3 .staller {0}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_3 marks_0 0 0 0 (by decide +kernel) row_0
theorem after_3_1 : Marked.gameValue original marks_3 .dominator {1}=0 ∧ Marked.gameValue original marks_3 .staller {1}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_3 marks_0 1 0 0 (by decide +kernel) row_0
theorem after_3_4 : Marked.gameValue original marks_3 .dominator {4}=0 ∧ Marked.gameValue original marks_3 .staller {4}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_3 marks_0 4 0 0 (by decide +kernel) row_0
theorem after_3_7 : Marked.gameValue original marks_3 .dominator {7}=0 ∧ Marked.gameValue original marks_3 .staller {7}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_3 marks_0 7 0 0 (by decide +kernel) row_0
theorem after_3_8 : Marked.gameValue original marks_3 .dominator {8}=1 ∧ Marked.gameValue original marks_3 .staller {8}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_3 marks_1 8 1 1 (by decide +kernel) row_1
theorem after_3_10 : Marked.gameValue original marks_3 .dominator {10}=0 ∧ Marked.gameValue original marks_3 .staller {10}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_3 marks_0 10 0 0 (by decide +kernel) row_0
theorem after_3_11 : Marked.gameValue original marks_3 .dominator {11}=1 ∧ Marked.gameValue original marks_3 .staller {11}=1 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_3 marks_1 11 1 1 (by decide +kernel) row_1
theorem row_3 : Marked.gameValue original marks_3 .dominator ∅=1 ∧ Marked.gameValue original marks_3 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_3 1 2 0 8 (by decide +kernel) (by decide +kernel)
  · rw [after_3_0.2]
  · rw [after_3_8.1]
  · intro v hv
    fin_cases v
    · have h := after_3_0
      change 1 ≤ 1+Marked.gameValue original marks_3 .staller {0} ∧ 1+Marked.gameValue original marks_3 .dominator {0} ≤ 2
      omega
    · have h := after_3_1
      change 1 ≤ 1+Marked.gameValue original marks_3 .staller {1} ∧ 1+Marked.gameValue original marks_3 .dominator {1} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_3 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_3 ∅ 3) hv)
    · have h := after_3_4
      change 1 ≤ 1+Marked.gameValue original marks_3 .staller {4} ∧ 1+Marked.gameValue original marks_3 .dominator {4} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_3 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_3 ∅ 6) hv)
    · have h := after_3_7
      change 1 ≤ 1+Marked.gameValue original marks_3 .staller {7} ∧ 1+Marked.gameValue original marks_3 .dominator {7} ≤ 2
      omega
    · have h := after_3_8
      change 1 ≤ 1+Marked.gameValue original marks_3 .staller {8} ∧ 1+Marked.gameValue original marks_3 .dominator {8} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_3 ∅ 9) hv)
    · have h := after_3_10
      change 1 ≤ 1+Marked.gameValue original marks_3 .staller {10} ∧ 1+Marked.gameValue original marks_3 .dominator {10} ≤ 2
      omega
    · have h := after_3_11
      change 1 ≤ 1+Marked.gameValue original marks_3 .staller {11} ∧ 1+Marked.gameValue original marks_3 .dominator {11} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_3 ∅ 12) hv)
end IsolationGame.FullCanonical.T04
