import CanonicalValueNormalization
import ForestSumAlgebra

namespace IsolationGame.Attachment
open Isolation.Graph
variable {V U : Type} [Fintype V] [DecidableEq V] [Fintype U] [DecidableEq U]

/-- A literal bridge edge, with no vertex identification and no erased moves. -/
def original (G : SimpleGraph V) (H : SimpleGraph U) (z : V) (b : U) : SimpleGraph (Sum V U) where
  Adj
    | .inl u,.inl v => G.Adj u v
    | .inr u,.inr v => H.Adj u v
    | .inl u,.inr v => u=z ∧ v=b
    | .inr u,.inl v => u=b ∧ v=z
  symm := by
    intro u v h
    cases u <;> cases v
    · exact h.symm
    · exact h.symm
    · exact h.symm
    · exact h.symm
  loopless := by
    intro v h
    cases v with
    | inl v => exact G.loopless v h
    | inr v => exact H.loopless v h

variable (G : SimpleGraph V) (H : SimpleGraph U) (z : V) (b : U)

@[simp] theorem closed_left (v w : V) :
    Closed (original G H z b) (.inl v) (.inl w) ↔ Closed G v w := by simp [Closed,original]
@[simp] theorem closed_right (v w : U) :
    Closed (original G H z b) (.inr v) (.inr w) ↔ Closed H v w := by simp [Closed,original]
@[simp] theorem closed_lr (v : V) (w : U) :
    Closed (original G H z b) (.inl v) (.inr w) ↔ v=z ∧ w=b := by simp [Closed,original]
@[simp] theorem closed_rl (v : U) (w : V) :
    Closed (original G H z b) (.inr v) (.inl w) ↔ v=b ∧ w=z := by simp [Closed,original]

theorem undominated_left (M X : Finset V) (N Y : Finset U) (v : V)
    (h : Marked.Undominated (original G H z b) (MarkedSum.combine M N) (MarkedSum.combine X Y) (.inl v)) :
    Marked.Undominated G M X v := by
  refine ⟨?_,?_⟩
  · intro hv; exact h.1 ((MarkedSum.combine_inl M N v).mpr hv)
  · rintro ⟨w,hw,hc⟩
    exact h.2 ⟨.inl w,(MarkedSum.combine_inl X Y w).mpr hw,(closed_left G H z b w v).mpr hc⟩

theorem undominated_right (M X : Finset V) (N Y : Finset U) (v : U)
    (h : Marked.Undominated (original G H z b) (MarkedSum.combine M N) (MarkedSum.combine X Y) (.inr v)) :
    Marked.Undominated H N Y v := by
  refine ⟨?_,?_⟩
  · intro hv; exact h.1 ((MarkedSum.combine_inr M N v).mpr hv)
  · rintro ⟨w,hw,hc⟩
    exact h.2 ⟨.inr w,(MarkedSum.combine_inr X Y w).mpr hw,(closed_right G H z b w v).mpr hc⟩

def fullWhite (M X : Finset V) (N Y : Finset U) : Sum V U → Prop :=
  Marked.White (original G H z b) (MarkedSum.combine M N) (MarkedSum.combine X Y)

def leftWhite (M X : Finset V) (N Y : Finset U) (v : V) : Prop := fullWhite G H z b M X N Y (.inl v)
def rightWhite (M X : Finset V) (N Y : Finset U) (v : U) : Prop := fullWhite G H z b M X N Y (.inr v)

theorem full_white_split (M X : Finset V) (N Y : Finset U) :
    fullWhite G H z b M X N Y=whiteSum (leftWhite G H z b M X N Y) (rightWhite G H z b M X N Y) := by
  funext v;cases v <;> rfl

theorem inactive_endpoints (M X : Finset V) (N Y : Finset U)
    (hi : ¬Marked.Legal (original G H z b) (MarkedSum.combine M N) (MarkedSum.combine X Y) (.inr b)) :
    ¬fullWhite G H z b M X N Y (.inl z) ∧ ¬fullWhite G H z b M X N Y (.inr b) := by
  constructor
  · intro h; exact hi ⟨.inl z,(closed_rl G H z b b z).mpr ⟨rfl,rfl⟩,h⟩
  · intro h; exact hi ⟨.inr b,Or.inl rfl,h⟩

#print axioms undominated_left
#print axioms inactive_endpoints
end IsolationGame.Attachment
