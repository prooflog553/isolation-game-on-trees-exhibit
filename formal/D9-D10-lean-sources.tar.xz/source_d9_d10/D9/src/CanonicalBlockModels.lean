import CanonicalBlocks

namespace IsolationGame.CanonicalLocal
open IsolatedRestriction SmallPiece

instance (t : Index) (j : Block t) : DecidableRel (induced (graph t) (blockVertices t j)).Adj :=
  fun u v=>inferInstanceAs (Decidable ((graph t).Adj u.val v.val))

def blockEquiv (t : Index) (j : Block t) : Active (blockVertices t j)≃Fin (order (blockKind t j)) where
  toFun v := ⟨v.val.val-(blockData t j).rootLabel,by
    have hv := (block_range t j v.val).mp v.property
    omega⟩
  invFun v := ⟨⟨(blockData t j).rootLabel+v.val,by
    have hb := block_end_bound t j
    have hv := v.isLt
    omega⟩,by
    rw [block_range]
    have hv := v.isLt
    change (blockData t j).rootLabel≤(blockData t j).rootLabel+v.val ∧
      (blockData t j).rootLabel+v.val<(blockData t j).rootLabel+order (blockKind t j)
    omega⟩
  left_inv v := by
    apply Subtype.ext
    apply Fin.ext
    have hv := (block_range t j v.val).mp v.property
    change (blockData t j).rootLabel+(v.val.val-(blockData t j).rootLabel)=v.val.val
    omega
  right_inv v := by
    apply Fin.ext
    change ((blockData t j).rootLabel+v.val)-(blockData t j).rootLabel=v.val
    omega

theorem block_root_map (t : Index) (j : Block t) :
    blockEquiv t j ⟨blockRoot t j,root_mem_block t j⟩=SmallPiece.root (blockKind t j) := by
  apply Fin.ext
  change (blockData t j).rootLabel-(blockData t j).rootLabel=0
  omega

/-- Full original induced adjacency in every small canonical block. -/
theorem block_model_adjacency (t : Index) : ∀j : Block t,∀u v : Active (blockVertices t j),
    (model (blockKind t j)).Adj (blockEquiv t j u) (blockEquiv t j v) ↔
      (induced (graph t) (blockVertices t j)).Adj u v := by
  cases t <;> decide +kernel

theorem block_spec (t : Index) (j : Block t) :
    Spec (induced (graph t) (blockVertices t j)) ⟨blockRoot t j,root_mem_block t j⟩ :=
  ⟨blockKind t j,blockEquiv t j,block_root_map t j,block_model_adjacency t j⟩

#print axioms block_model_adjacency
#print axioms block_spec
end IsolationGame.CanonicalLocal
