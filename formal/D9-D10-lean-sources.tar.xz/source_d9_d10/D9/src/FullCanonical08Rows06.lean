import FullCanonical08Rows05
namespace IsolationGame.FullCanonical.T08
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_24 : Finset (Fin 11) := {1,2,3,5,6}
theorem after_24_0 : Marked.gameValue original marks_24 .dominator {0}=1 ∧ Marked.gameValue original marks_24 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_24 marks_3 0 1 1 (by decide +kernel) row_3
theorem after_24_1 : Marked.gameValue original marks_24 .dominator {1}=1 ∧ Marked.gameValue original marks_24 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_24 marks_13 1 1 2 (by decide +kernel) row_13
theorem after_24_4 : Marked.gameValue original marks_24 .dominator {4}=1 ∧ Marked.gameValue original marks_24 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_24 marks_13 4 1 2 (by decide +kernel) row_13
theorem after_24_5 : Marked.gameValue original marks_24 .dominator {5}=1 ∧ Marked.gameValue original marks_24 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_24 marks_19 5 1 2 (by decide +kernel) row_19
theorem after_24_7 : Marked.gameValue original marks_24 .dominator {7}=0 ∧ Marked.gameValue original marks_24 .staller {7}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_24 marks_0 7 0 0 (by decide +kernel) row_0
theorem after_24_8 : Marked.gameValue original marks_24 .dominator {8}=1 ∧ Marked.gameValue original marks_24 .staller {8}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_24 marks_1 8 1 1 (by decide +kernel) row_1
theorem after_24_9 : Marked.gameValue original marks_24 .dominator {9}=1 ∧ Marked.gameValue original marks_24 .staller {9}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_24 marks_12 9 1 2 (by decide +kernel) row_12
theorem after_24_10 : Marked.gameValue original marks_24 .dominator {10}=1 ∧ Marked.gameValue original marks_24 .staller {10}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_24 marks_10 10 1 2 (by decide +kernel) row_10
theorem row_24 : Marked.gameValue original marks_24 .dominator ∅=1 ∧ Marked.gameValue original marks_24 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_24 1 2 7 0 (by decide +kernel) (by decide +kernel)
  · rw [after_24_7.2]
  · rw [after_24_0.1]
  · intro v hv
    fin_cases v
    · have h := after_24_0
      change 1 ≤ 1+Marked.gameValue original marks_24 .staller {0} ∧ 1+Marked.gameValue original marks_24 .dominator {0} ≤ 2
      omega
    · have h := after_24_1
      change 1 ≤ 1+Marked.gameValue original marks_24 .staller {1} ∧ 1+Marked.gameValue original marks_24 .dominator {1} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_24 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_24 ∅ 3) hv)
    · have h := after_24_4
      change 1 ≤ 1+Marked.gameValue original marks_24 .staller {4} ∧ 1+Marked.gameValue original marks_24 .dominator {4} ≤ 2
      omega
    · have h := after_24_5
      change 1 ≤ 1+Marked.gameValue original marks_24 .staller {5} ∧ 1+Marked.gameValue original marks_24 .dominator {5} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_24 ∅ 6) hv)
    · have h := after_24_7
      change 1 ≤ 1+Marked.gameValue original marks_24 .staller {7} ∧ 1+Marked.gameValue original marks_24 .dominator {7} ≤ 2
      omega
    · have h := after_24_8
      change 1 ≤ 1+Marked.gameValue original marks_24 .staller {8} ∧ 1+Marked.gameValue original marks_24 .dominator {8} ≤ 2
      omega
    · have h := after_24_9
      change 1 ≤ 1+Marked.gameValue original marks_24 .staller {9} ∧ 1+Marked.gameValue original marks_24 .dominator {9} ≤ 2
      omega
    · have h := after_24_10
      change 1 ≤ 1+Marked.gameValue original marks_24 .staller {10} ∧ 1+Marked.gameValue original marks_24 .dominator {10} ≤ 2
      omega
def marks_25 : Finset (Fin 11) := {7,8,9,10}
theorem after_25_0 : Marked.gameValue original marks_25 .dominator {0}=2 ∧ Marked.gameValue original marks_25 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_25 marks_8 0 2 2 (by decide +kernel) row_8
theorem after_25_1 : Marked.gameValue original marks_25 .dominator {1}=1 ∧ Marked.gameValue original marks_25 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_25 marks_6 1 1 2 (by decide +kernel) row_6
theorem after_25_2 : Marked.gameValue original marks_25 .dominator {2}=1 ∧ Marked.gameValue original marks_25 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_25 marks_9 2 1 2 (by decide +kernel) row_9
theorem after_25_3 : Marked.gameValue original marks_25 .dominator {3}=1 ∧ Marked.gameValue original marks_25 .staller {3}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_25 marks_14 3 1 2 (by decide +kernel) row_14
theorem after_25_4 : Marked.gameValue original marks_25 .dominator {4}=1 ∧ Marked.gameValue original marks_25 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_25 marks_6 4 1 2 (by decide +kernel) row_6
theorem after_25_5 : Marked.gameValue original marks_25 .dominator {5}=1 ∧ Marked.gameValue original marks_25 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_25 marks_9 5 1 2 (by decide +kernel) row_9
theorem after_25_6 : Marked.gameValue original marks_25 .dominator {6}=1 ∧ Marked.gameValue original marks_25 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_25 marks_14 6 1 2 (by decide +kernel) row_14
theorem after_25_7 : Marked.gameValue original marks_25 .dominator {7}=3 ∧ Marked.gameValue original marks_25 .staller {7}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_25 marks_20 7 3 3 (by decide +kernel) row_20
theorem row_25 : Marked.gameValue original marks_25 .dominator ∅=3 ∧ Marked.gameValue original marks_25 .staller ∅=4 := by
  apply LocalProfile.DAG.bellman original marks_25 3 4 0 7 (by decide +kernel) (by decide +kernel)
  · rw [after_25_0.2]
  · rw [after_25_7.1]
  · intro v hv
    fin_cases v
    · have h := after_25_0
      change 3 ≤ 1+Marked.gameValue original marks_25 .staller {0} ∧ 1+Marked.gameValue original marks_25 .dominator {0} ≤ 4
      omega
    · have h := after_25_1
      change 3 ≤ 1+Marked.gameValue original marks_25 .staller {1} ∧ 1+Marked.gameValue original marks_25 .dominator {1} ≤ 4
      omega
    · have h := after_25_2
      change 3 ≤ 1+Marked.gameValue original marks_25 .staller {2} ∧ 1+Marked.gameValue original marks_25 .dominator {2} ≤ 4
      omega
    · have h := after_25_3
      change 3 ≤ 1+Marked.gameValue original marks_25 .staller {3} ∧ 1+Marked.gameValue original marks_25 .dominator {3} ≤ 4
      omega
    · have h := after_25_4
      change 3 ≤ 1+Marked.gameValue original marks_25 .staller {4} ∧ 1+Marked.gameValue original marks_25 .dominator {4} ≤ 4
      omega
    · have h := after_25_5
      change 3 ≤ 1+Marked.gameValue original marks_25 .staller {5} ∧ 1+Marked.gameValue original marks_25 .dominator {5} ≤ 4
      omega
    · have h := after_25_6
      change 3 ≤ 1+Marked.gameValue original marks_25 .staller {6} ∧ 1+Marked.gameValue original marks_25 .dominator {6} ≤ 4
      omega
    · have h := after_25_7
      change 3 ≤ 1+Marked.gameValue original marks_25 .staller {7} ∧ 1+Marked.gameValue original marks_25 .dominator {7} ≤ 4
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_25 ∅ 8) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_25 ∅ 9) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_25 ∅ 10) hv)
def marks_26 : Finset (Fin 11) := {2,3,7,10}
theorem after_26_0 : Marked.gameValue original marks_26 .dominator {0}=2 ∧ Marked.gameValue original marks_26 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_26 marks_11 0 2 2 (by decide +kernel) row_11
theorem after_26_1 : Marked.gameValue original marks_26 .dominator {1}=2 ∧ Marked.gameValue original marks_26 .staller {1}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_26 marks_16 1 2 3 (by decide +kernel) row_16
theorem after_26_2 : Marked.gameValue original marks_26 .dominator {2}=2 ∧ Marked.gameValue original marks_26 .staller {2}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_26 marks_22 2 2 3 (by decide +kernel) row_22
theorem after_26_4 : Marked.gameValue original marks_26 .dominator {4}=1 ∧ Marked.gameValue original marks_26 .staller {4}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_26 marks_3 4 1 1 (by decide +kernel) row_3
theorem after_26_5 : Marked.gameValue original marks_26 .dominator {5}=1 ∧ Marked.gameValue original marks_26 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_26 marks_10 5 1 2 (by decide +kernel) row_10
theorem after_26_6 : Marked.gameValue original marks_26 .dominator {6}=1 ∧ Marked.gameValue original marks_26 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_26 marks_15 6 1 2 (by decide +kernel) row_15
theorem after_26_7 : Marked.gameValue original marks_26 .dominator {7}=1 ∧ Marked.gameValue original marks_26 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_26 marks_6 7 1 2 (by decide +kernel) row_6
theorem after_26_8 : Marked.gameValue original marks_26 .dominator {8}=1 ∧ Marked.gameValue original marks_26 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_26 marks_14 8 1 2 (by decide +kernel) row_14
theorem after_26_9 : Marked.gameValue original marks_26 .dominator {9}=1 ∧ Marked.gameValue original marks_26 .staller {9}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_26 marks_14 9 1 2 (by decide +kernel) row_14
theorem row_26 : Marked.gameValue original marks_26 .dominator ∅=2 ∧ Marked.gameValue original marks_26 .staller ∅=3 := by
  apply LocalProfile.DAG.bellman original marks_26 2 3 4 0 (by decide +kernel) (by decide +kernel)
  · rw [after_26_4.2]
  · rw [after_26_0.1]
  · intro v hv
    fin_cases v
    · have h := after_26_0
      change 2 ≤ 1+Marked.gameValue original marks_26 .staller {0} ∧ 1+Marked.gameValue original marks_26 .dominator {0} ≤ 3
      omega
    · have h := after_26_1
      change 2 ≤ 1+Marked.gameValue original marks_26 .staller {1} ∧ 1+Marked.gameValue original marks_26 .dominator {1} ≤ 3
      omega
    · have h := after_26_2
      change 2 ≤ 1+Marked.gameValue original marks_26 .staller {2} ∧ 1+Marked.gameValue original marks_26 .dominator {2} ≤ 3
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_26 ∅ 3) hv)
    · have h := after_26_4
      change 2 ≤ 1+Marked.gameValue original marks_26 .staller {4} ∧ 1+Marked.gameValue original marks_26 .dominator {4} ≤ 3
      omega
    · have h := after_26_5
      change 2 ≤ 1+Marked.gameValue original marks_26 .staller {5} ∧ 1+Marked.gameValue original marks_26 .dominator {5} ≤ 3
      omega
    · have h := after_26_6
      change 2 ≤ 1+Marked.gameValue original marks_26 .staller {6} ∧ 1+Marked.gameValue original marks_26 .dominator {6} ≤ 3
      omega
    · have h := after_26_7
      change 2 ≤ 1+Marked.gameValue original marks_26 .staller {7} ∧ 1+Marked.gameValue original marks_26 .dominator {7} ≤ 3
      omega
    · have h := after_26_8
      change 2 ≤ 1+Marked.gameValue original marks_26 .staller {8} ∧ 1+Marked.gameValue original marks_26 .dominator {8} ≤ 3
      omega
    · have h := after_26_9
      change 2 ≤ 1+Marked.gameValue original marks_26 .staller {9} ∧ 1+Marked.gameValue original marks_26 .dominator {9} ≤ 3
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_26 ∅ 10) hv)
def marks_27 : Finset (Fin 11) := {2,3,8,9}
theorem after_27_0 : Marked.gameValue original marks_27 .dominator {0}=1 ∧ Marked.gameValue original marks_27 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_27 marks_2 0 1 1 (by decide +kernel) row_2
theorem after_27_1 : Marked.gameValue original marks_27 .dominator {1}=2 ∧ Marked.gameValue original marks_27 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_27 marks_18 1 2 2 (by decide +kernel) row_18
theorem after_27_2 : Marked.gameValue original marks_27 .dominator {2}=2 ∧ Marked.gameValue original marks_27 .staller {2}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_27 marks_23 2 2 3 (by decide +kernel) row_23
theorem after_27_4 : Marked.gameValue original marks_27 .dominator {4}=1 ∧ Marked.gameValue original marks_27 .staller {4}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_27 marks_4 4 1 1 (by decide +kernel) row_4
theorem after_27_5 : Marked.gameValue original marks_27 .dominator {5}=1 ∧ Marked.gameValue original marks_27 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_27 marks_12 5 1 2 (by decide +kernel) row_12
theorem after_27_6 : Marked.gameValue original marks_27 .dominator {6}=1 ∧ Marked.gameValue original marks_27 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_27 marks_17 6 1 2 (by decide +kernel) row_17
theorem after_27_7 : Marked.gameValue original marks_27 .dominator {7}=1 ∧ Marked.gameValue original marks_27 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_27 marks_6 7 1 2 (by decide +kernel) row_6
theorem after_27_8 : Marked.gameValue original marks_27 .dominator {8}=1 ∧ Marked.gameValue original marks_27 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_27 marks_14 8 1 2 (by decide +kernel) row_14
theorem after_27_10 : Marked.gameValue original marks_27 .dominator {10}=1 ∧ Marked.gameValue original marks_27 .staller {10}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_27 marks_14 10 1 2 (by decide +kernel) row_14
theorem row_27 : Marked.gameValue original marks_27 .dominator ∅=2 ∧ Marked.gameValue original marks_27 .staller ∅=3 := by
  apply LocalProfile.DAG.bellman original marks_27 2 3 0 1 (by decide +kernel) (by decide +kernel)
  · rw [after_27_0.2]
  · rw [after_27_1.1]
  · intro v hv
    fin_cases v
    · have h := after_27_0
      change 2 ≤ 1+Marked.gameValue original marks_27 .staller {0} ∧ 1+Marked.gameValue original marks_27 .dominator {0} ≤ 3
      omega
    · have h := after_27_1
      change 2 ≤ 1+Marked.gameValue original marks_27 .staller {1} ∧ 1+Marked.gameValue original marks_27 .dominator {1} ≤ 3
      omega
    · have h := after_27_2
      change 2 ≤ 1+Marked.gameValue original marks_27 .staller {2} ∧ 1+Marked.gameValue original marks_27 .dominator {2} ≤ 3
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_27 ∅ 3) hv)
    · have h := after_27_4
      change 2 ≤ 1+Marked.gameValue original marks_27 .staller {4} ∧ 1+Marked.gameValue original marks_27 .dominator {4} ≤ 3
      omega
    · have h := after_27_5
      change 2 ≤ 1+Marked.gameValue original marks_27 .staller {5} ∧ 1+Marked.gameValue original marks_27 .dominator {5} ≤ 3
      omega
    · have h := after_27_6
      change 2 ≤ 1+Marked.gameValue original marks_27 .staller {6} ∧ 1+Marked.gameValue original marks_27 .dominator {6} ≤ 3
      omega
    · have h := after_27_7
      change 2 ≤ 1+Marked.gameValue original marks_27 .staller {7} ∧ 1+Marked.gameValue original marks_27 .dominator {7} ≤ 3
      omega
    · have h := after_27_8
      change 2 ≤ 1+Marked.gameValue original marks_27 .staller {8} ∧ 1+Marked.gameValue original marks_27 .dominator {8} ≤ 3
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_27 ∅ 9) hv)
    · have h := after_27_10
      change 2 ≤ 1+Marked.gameValue original marks_27 .staller {10} ∧ 1+Marked.gameValue original marks_27 .dominator {10} ≤ 3
      omega
end IsolationGame.FullCanonical.T08
