import AttachmentGraph
import Mathlib.Combinatorics.SimpleGraph.Acyclic

/-! SOURCE_ONLY. This file has not been elaborated or compiled.
A literal bridge between two trees is a tree, using connectivity and an
edge-set cover. No vertex identification and no change to the carrier. -/
namespace IsolationGame.Attachment
variable {V U : Type} [Fintype V] [DecidableEq V] [Fintype U] [DecidableEq U]

private def leftEdge (G : SimpleGraph V) (H : SimpleGraph U) (z : V) (b : U)
    (e : G.edgeSet) : (original G H z b).edgeSet := by
  refine ⟨Sym2.map Sum.inl e.val, ?_⟩
  rcases e with ⟨e, he⟩
  induction e using Sym2.inductionOn with
  | _ x y => exact he

private def rightEdge (G : SimpleGraph V) (H : SimpleGraph U) (z : V) (b : U)
    (e : H.edgeSet) : (original G H z b).edgeSet := by
  refine ⟨Sym2.map Sum.inr e.val, ?_⟩
  rcases e with ⟨e, he⟩
  induction e using Sym2.inductionOn with
  | _ x y => exact he

/-- The original edges in both components, plus the single actual bridge,
cover the full edge set. Injectivity is unnecessary for the tree argument. -/
private def edgeCover (G : SimpleGraph V) (H : SimpleGraph U) (z : V) (b : U) :
    G.edgeSet ⊕ (H.edgeSet ⊕ Unit) → (original G H z b).edgeSet
  | .inl e => leftEdge G H z b e
  | .inr (.inl e) => rightEdge G H z b e
  | .inr (.inr _) => ⟨s(Sum.inl z, Sum.inr b), ⟨rfl, rfl⟩⟩

private theorem edgeCover_surjective (G : SimpleGraph V) (H : SimpleGraph U)
    (z : V) (b : U) : Function.Surjective (edgeCover G H z b) := by
  rintro ⟨e, he⟩
  induction e using Sym2.inductionOn with
  | _ x y =>
    cases x with
    | inl x =>
      cases y with
      | inl y => exact ⟨.inl ⟨s(x,y), he⟩, rfl⟩
      | inr y =>
        change x = z ∧ y = b at he
        rcases he with ⟨rfl, rfl⟩
        exact ⟨.inr (.inr ()), rfl⟩
    | inr x =>
      cases y with
      | inl y =>
        change x = b ∧ y = z at he
        rcases he with ⟨rfl, rfl⟩
        refine ⟨.inr (.inr ()), ?_⟩
        exact Subtype.ext (Sym2.eq_swap)
      | inr y => exact ⟨.inr (.inl ⟨s(x,y), he⟩), rfl⟩

theorem original_connected (G : SimpleGraph V) (H : SimpleGraph U)
    (z : V) (b : U) (hG : G.Connected) (hH : H.Connected) :
    (original G H z b).Connected := by
  apply (SimpleGraph.connected_iff_exists_forall_reachable (original G H z b)).mpr
  refine ⟨Sum.inl z, ?_⟩
  intro v
  cases v with
  | inl v =>
    obtain ⟨p⟩ := hG z v
    let f : G →g original G H z b :=
      ⟨Sum.inl, by intro u v h; exact h⟩
    exact (p.map f).reachable
  | inr v =>
    obtain ⟨p⟩ := hH b v
    let f : H →g original G H z b :=
      ⟨Sum.inr, by intro u v h; exact h⟩
    have hb : (original G H z b).Adj (Sum.inl z) (Sum.inr b) := ⟨rfl,rfl⟩
    exact hb.reachable.trans (p.map f).reachable

/-- Joining two finite trees by exactly one edge preserves the actual tree. -/
theorem original_tree (G : SimpleGraph V) (H : SimpleGraph U)
    (z : V) (b : U) (hG : G.IsTree) (hH : H.IsTree) :
    (original G H z b).IsTree := by
  classical
  have hc := original_connected G H z b hG.isConnected hH.isConnected
  have hcover := Fintype.card_le_of_surjective (edgeCover G H z b)
    (edgeCover_surjective G H z b)
  simp only [Fintype.card_sum, Fintype.card_unit] at hcover
  have hGcard : Fintype.card G.edgeSet + 1 = Fintype.card V := by
    simpa only [SimpleGraph.edgeFinset_card] using hG.card_edgeFinset
  have hHcard : Fintype.card H.edgeSet + 1 = Fintype.card U := by
    simpa only [SimpleGraph.edgeFinset_card] using hH.card_edgeFinset
  have hlower : Fintype.card (Sum V U) ≤
      Fintype.card (original G H z b).edgeSet + 1 := by
    simpa only [Nat.card_eq_fintype_card] using hc.card_vert_le_card_edgeSet_add_one
  apply SimpleGraph.isTree_iff_connected_and_card.mpr
  refine ⟨hc, ?_⟩
  simp only [Nat.card_eq_fintype_card, Fintype.card_sum] at hlower ⊢
  omega

#print axioms original_connected
#print axioms original_tree
end IsolationGame.Attachment
