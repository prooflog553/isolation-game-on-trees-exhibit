import CoreForestTransition
import FloorLocalBase

namespace IsolationGame.ForestQueries
open CanonicalLocal CoreFamily CoreFamilySemantics

def bitsState (xs : List Nat) (p : Nat) (masks : List Nat) : LocalWhite xs p :=
  fun i v=>(masks.getD i.val 0).testBit v.val=true

instance (xs : List Nat) (p : Nat) (masks : List Nat) (i) :
    DecidablePred (bitsState xs p masks i) := fun _=>inferInstanceAs (Decidable (_=true))

instance {V : Type} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]
    (W : V→Prop) [DecidablePred W] : DecidablePred ((GuardedEdge.view G).noniso W) :=
  fun v=>inferInstanceAs (Decidable (W v ∧ ∃w,W w ∧ G.Adj v w))

instance {V : Type} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]
    (W : V→Prop) [DecidablePred W] : DecidablePred ((GuardedEdge.view G).legal W) :=
  fun v=>inferInstanceAs (Decidable (∃w,W w ∧ (v=w ∨ G.Adj v w)))

instance {V : Type} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]
    (W : V→Prop) [DecidablePred W] (v) : DecidablePred ((GuardedEdge.view G).step W v) := by
  intro w
  unfold Isolation.Graph.step Isolation.Graph.noniso Isolation.Graph.remove Isolation.Graph.closed GuardedEdge.view
  infer_instance

theorem canonicalMarks_eq {V : Type} [Fintype V] [DecidableEq V] (W : V→Prop) (M : Finset V)
    (h : ∀v,¬W v ↔ v∈M) : ForestFoundation.canonicalMarks W=M := by
  ext v
  simpa only [ForestFoundation.canonicalMarks,Finset.mem_filter,Finset.mem_univ,true_and] using h v

end IsolationGame.ForestQueries
