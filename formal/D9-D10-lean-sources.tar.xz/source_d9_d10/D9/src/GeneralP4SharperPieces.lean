import GeneralP4Bounds
import StrictCompanionPairing

/-! Optional stronger-candidate pieces. These are source-only, unelaborated.
The all-k 3k/2 theorem is deliberately not asserted here: the paired-centre
full-carrier regrouping is still needed. This file supplies the legal clear-P4
D recurrence, the already available strict T01 capacity, and its literal pair.
No nonterminal assumption on the base graph is needed. -/
namespace IsolationGame.GeneralP4Receiver
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

/-- Existing strict capacity theorem, including every original legal action. -/
theorem rootmarked_T01_strict :
    MarkedSum.StrictCapacity P4Receiver.T ({0} : Finset (Fin 4)) ∅ 2 :=
  LocalProfile.e0E0D0L1.strict_profile

/-- A genuine disjoint pair of rootmarked P4s costs at most three for S. -/
theorem rootmarked_T01_pair_S :
    Marked.gameValue (MarkedSum.original P4Receiver.T P4Receiver.T)
      (MarkedSum.combine ({0} : Finset (Fin 4)) ({0} : Finset (Fin 4))) .staller ∅ ≤ 3 := by
  have h := MarkedSum.forest_strict_pair P4Receiver.T P4Receiver.T
    P4Receiver.t_acyclic P4Receiver.t_acyclic
    ({0} : Finset (Fin 4)) ∅ ({0} : Finset (Fin 4)) ∅
    2 2 rootmarked_T01_strict rootmarked_T01_strict
  simpa only [P4Receiver.empty_combine] using h

/-- The internal second vertex has a white neighbour independently of the base. -/
theorem attachment_second_legal {V : Type} [Fintype V] [DecidableEq V]
    (G : SimpleGraph V) (z : V) (M : Finset V) (hz : z∈M) :
    Marked.Legal (P4Receiver.A G z) (P4Receiver.AM M) ∅ (Sum.inr (1 : Fin 4)) := by
  refine ⟨Sum.inr (1 : Fin 4),Or.inl rfl,?_⟩
  exact (P4Receiver.white_right G z M hz ∅ 1).mpr (by decide +kernel)

/-- Dominator selects the second P4 vertex, paying one. The entire P4 then
has no White vertices; exact full-carrier normalization leaves the base on S. -/
theorem attachment_D_clear {V : Type} [Fintype V] [DecidableEq V]
    (G : SimpleGraph V) (z : V) (M : Finset V) (hG : G.IsAcyclic) (hz : z∈M) :
    Marked.gameValue (P4Receiver.A G z) (P4Receiver.AM M) .dominator ∅ ≤
      1+Marked.gameValue G M .staller ∅ := by
  have h := Marked.d_move_upper (P4Receiver.A G z) (P4Receiver.AM M) ∅
    (Sum.inr (1 : Fin 4)) (attachment_second_legal G z M hz)
  simp only [Finset.insert_empty] at h
  rw [P4Receiver.after_right_sum G z M hz 1 (P4Receiver.after_root_mem 1 (Or.inr rfl)),
    P4Receiver.terminal_after G M hG (P4Receiver.after 1)
      P4Receiver.after1_terminal .staller] at h
  exact h

/-- Exact full-carrier branch isolation transfers the legal clear-P4 strategy. -/
theorem D_clear_step (k p : Nat) :
    Marked.gameValue (graph (k+1) p) (marks (k+1) p) .dominator ∅ ≤
      1+Marked.gameValue (graph k p) (marks k p) .staller ∅ := by
  rw [value_split]
  change Marked.gameValue (P4Receiver.A (graph k p) (centre k p))
    (P4Receiver.AM (marks k p)) .dominator ∅ ≤
      1+Marked.gameValue (graph k p) (marks k p) .staller ∅
  exact attachment_D_clear (graph k p) (centre k p) (marks k p)
    (graph_acyclic k p) (root_marked k p)

/-- The sharper recurrence has a valid zero-branch S base, with its +1 intact. -/
theorem pure_S_upper : ∀p : Nat,
    Marked.gameValue (graph 0 p) (marks 0 p) .staller ∅ ≤ 3*p+1 := by
  intro p
  have h := Marked.starting_player_inequality (graph 0 p) (marks 0 p) ∅
  rw [pure_D] at h
  exact h

#print axioms rootmarked_T01_strict
#print axioms rootmarked_T01_pair_S
#print axioms attachment_second_legal
#print axioms attachment_D_clear
#print axioms D_clear_step
#print axioms pure_S_upper
end IsolationGame.GeneralP4Receiver
