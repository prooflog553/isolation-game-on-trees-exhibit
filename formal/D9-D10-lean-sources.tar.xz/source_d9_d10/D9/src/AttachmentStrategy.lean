import AttachmentCapacity

namespace IsolationGame.Attachment
variable {V U : Type} [Fintype V] [DecidableEq V] [Fintype U] [DecidableEq U]
  (G : SimpleGraph V) (H : SimpleGraph U) (z : V) (b : U)

/-- Selecting the actual attachment root is one real move. If it is already
illegal, the exact split theorem supplies the bound without a fictitious pass. -/
theorem D_bound_by_base_S (hG : G.IsAcyclic) (hH : H.IsAcyclic)
    (hLoc : AttachmentGeometry.LocalSpec H b)
    (M X : Finset V) (N Y : Finset U) :
    Marked.gameValue (original G H z b) (MarkedSum.combine M N) .dominator (MarkedSum.combine X Y) ≤
      1+Marked.gameValue G M .staller X+(AttachmentGeometry.longStars H b).card := by
  by_cases hl : Marked.Legal (original G H z b) (MarkedSum.combine M N) (MarkedSum.combine X Y) (.inr b)
  · have hmove := Marked.d_move_upper (original G H z b) (MarkedSum.combine M N) (MarkedSum.combine X Y) (.inr b) hl
    rw [←combine_insert_right X Y b] at hmove
    have hr := root_selected_illegal G H z b M X N (insert b Y) (Finset.mem_insert_self _ _)
    have hb := inactive_capacity G H z b hG hH hLoc M X N (insert b Y) hr .staller
    omega
  · have hb := inactive_capacity G H z b hG hH hLoc M X N Y hl .dominator
    omega

/-- Every actual first S vertex is covered, including new blue actions and
base vertices whose legality was created by the attachment. -/
theorem S_attachment_bound (hG : G.IsAcyclic) (hH : H.IsAcyclic)
    (hLoc : AttachmentGeometry.LocalSpec H b)
    (M X : Finset V) (N Y : Finset U) :
    Marked.gameValue (original G H z b) (MarkedSum.combine M N) .staller (MarkedSum.combine X Y) ≤
      Marked.gameValue G M .staller X+(AttachmentGeometry.longStars H b).card+2 := by
  by_cases ht : Marked.Terminal (original G H z b) (MarkedSum.combine M N) (MarkedSum.combine X Y)
  · rw [(Marked.value_zero_iff_terminal (original G H z b) (MarkedSum.combine M N) (MarkedSum.combine X Y) .staller).mpr ht]
    omega
  obtain ⟨v,hv,he⟩ := Marked.exists_optimal_s_move (original G H z b) (MarkedSum.combine M N) (MarkedSum.combine X Y) ht
  cases v with
  | inl v =>
    rw [←combine_insert_left X Y v] at he
    have hnext := D_bound_by_base_S G H z b hG hH hLoc M (insert v X) N Y
    have hbase := Marked.value_of_white_subset G M M (insert v X) X .staller (Marked.white_after_subset G v)
    omega
  | inr v =>
    rw [←combine_insert_right X Y v] at he
    have hnext := D_bound_by_base_S G H z b hG hH hLoc M X N (insert v Y)
    omega

theorem D_attachment_bound (hG : G.IsAcyclic) (hH : H.IsAcyclic)
    (hLoc : AttachmentGeometry.LocalSpec H b)
    (M X : Finset V) (N Y : Finset U) :
    Marked.gameValue (original G H z b) (MarkedSum.combine M N) .dominator (MarkedSum.combine X Y) ≤
      Marked.gameValue G M .dominator X+(AttachmentGeometry.longStars H b).card+2 := by
  have hd := D_bound_by_base_S G H z b hG hH hLoc M X N Y
  have hs := Marked.starting_player_inequality G M X
  omega

#print axioms D_attachment_bound
#print axioms S_attachment_bound
end IsolationGame.Attachment
