import FloorLocalBase
import FloorLocalRow001
import FloorLocalRow016
import FloorLocalRow017
import FloorLocalRow064
set_option maxRecDepth 4096
set_option maxHeartbeats 1000000
namespace IsolationGame.FloorLocal
def marks_107 : Finset (Fin 7) := {4,5,6}
theorem normalized_107 : ∀v : Fin 7, Marked.White original_02 marks_107 ∅ v ↔ v∈({0,1,2,3} : Finset (Fin 7)) := by decide +kernel
theorem after_107_0 : Marked.gameValue original_02 marks_107 .dominator {0}=1 ∧ Marked.gameValue original_02 marks_107 .staller {0}=1 :=
  LocalProfile.DAG.transport original_02 marks_107 marks_017 0 1 1 (by decide +kernel) row_017
theorem after_107_1 : Marked.gameValue original_02 marks_107 .dominator {1}=0 ∧ Marked.gameValue original_02 marks_107 .staller {1}=0 :=
  LocalProfile.DAG.transport original_02 marks_107 marks_001 1 0 0 (by decide +kernel) row_001
theorem after_107_2 : Marked.gameValue original_02 marks_107 .dominator {2}=0 ∧ Marked.gameValue original_02 marks_107 .staller {2}=0 :=
  LocalProfile.DAG.transport original_02 marks_107 marks_001 2 0 0 (by decide +kernel) row_001
theorem after_107_3 : Marked.gameValue original_02 marks_107 .dominator {3}=1 ∧ Marked.gameValue original_02 marks_107 .staller {3}=1 :=
  LocalProfile.DAG.transport original_02 marks_107 marks_016 3 1 1 (by decide +kernel) row_016
theorem after_107_4 : Marked.gameValue original_02 marks_107 .dominator {4}=1 ∧ Marked.gameValue original_02 marks_107 .staller {4}=2 :=
  LocalProfile.DAG.transport original_02 marks_107 marks_064 4 1 2 (by decide +kernel) row_064
theorem row_107 : Marked.gameValue original_02 marks_107 .dominator ∅=1 ∧ Marked.gameValue original_02 marks_107 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original_02 marks_107 1 2 1 0 (by decide +kernel) (by decide +kernel)
  · rw [after_107_1.2]
  · rw [after_107_0.1]
  · intro v hv
    fin_cases v
    · have h := after_107_0
      change 1≤1+Marked.gameValue original_02 marks_107 .staller {0} ∧ 1+Marked.gameValue original_02 marks_107 .dominator {0}≤2
      omega
    · have h := after_107_1
      change 1≤1+Marked.gameValue original_02 marks_107 .staller {1} ∧ 1+Marked.gameValue original_02 marks_107 .dominator {1}≤2
      omega
    · have h := after_107_2
      change 1≤1+Marked.gameValue original_02 marks_107 .staller {2} ∧ 1+Marked.gameValue original_02 marks_107 .dominator {2}≤2
      omega
    · have h := after_107_3
      change 1≤1+Marked.gameValue original_02 marks_107 .staller {3} ∧ 1+Marked.gameValue original_02 marks_107 .dominator {3}≤2
      omega
    · have h := after_107_4
      change 1≤1+Marked.gameValue original_02 marks_107 .staller {4} ∧ 1+Marked.gameValue original_02 marks_107 .dominator {4}≤2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_107 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_107 ∅ 6) hv)
#print axioms row_107
end IsolationGame.FloorLocal
