import FourteenResidualData

/-! Finite kernel arithmetic only: first profile fixed to t16.
All arithmetic is checked by kernel reduction; no graph or history search. -/
namespace IsolationGame.FourteenResidual
open CanonicalLocal
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

theorem check11_t16 (b : Index) :
    NumericResidual [.t16] [b] → MatchesFourteen [.t16] [b] := by
  cases b <;> decide +kernel

theorem check12_t16 (b c : Index) :
    NumericResidual [.t16] [b, c] → MatchesFourteen [.t16] [b, c] := by
  cases b <;> cases c <;> decide +kernel

#print axioms check11_t16
#print axioms check12_t16
end IsolationGame.FourteenResidual
