import FourteenResidualData

/-! Finite kernel arithmetic only: first profile fixed to t04.
All arithmetic is checked by kernel reduction; no graph or history search. -/
namespace IsolationGame.FourteenResidual
open CanonicalLocal
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

theorem check11_t04 (b : Index) :
    NumericResidual [.t04] [b] → MatchesFourteen [.t04] [b] := by
  cases b <;> decide +kernel

theorem check12_t04 (b c : Index) :
    NumericResidual [.t04] [b, c] → MatchesFourteen [.t04] [b, c] := by
  cases b <;> cases c <;> decide +kernel

#print axioms check11_t04
#print axioms check12_t04
end IsolationGame.FourteenResidual
