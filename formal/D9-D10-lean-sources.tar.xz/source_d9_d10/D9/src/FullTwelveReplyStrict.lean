import ReplyStrictPairing
import FullTwelveWeakEvidence
import CanonicalTrees

namespace IsolationGame.FullCanonical.T12
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

/-- t12 stays non-strict at capacity four. This weaker interface retains its
bad original action eight and the legal same-component response one. -/
theorem reply_strict_four : MarkedSum.ReplyStrictCapacity original ∅ ∅ 4 := by
  constructor
  · have h := weak_D_upper
    omega
  · intro v hv
    by_cases hb : v=8
    · subst v
      apply Or.inr
      refine ⟨1,?_,?_⟩
      · simpa only [Finset.insert_empty] using weak_bad_reply_legal
      · simpa only [Finset.insert_empty] using weak_bad_reply_strict
    · apply Or.inl
      have h := weak_normal_follower_S v hb
      simpa only [Finset.insert_empty] using (show Marked.gameValue original ∅ .staller {v}+1≤4 by omega)

/-- A reusable result for any genuine strict forest companion and history. -/
theorem with_any_strict {V : Type} [Fintype V] [DecidableEq V]
    (C : SimpleGraph V) (hC : C.IsAcyclic)
    (M X : Finset V) (c : Nat) (hc : MarkedSum.StrictCapacity C M X c) :
    Marked.gameValue (MarkedSum.original original C) (MarkedSum.combine ∅ M)
      .staller (MarkedSum.combine ∅ X)≤c+3 := by
  have hB : original.IsAcyclic := (CanonicalLocal.canonical_tree .t12).IsAcyclic
  have h := MarkedSum.forest_reply_strict_pair original C hB hC ∅ ∅ M X 4 c reply_strict_four hc
  omega

/-- Two full t12 original carriers save one move as well. -/
theorem two_full_twelve :
    Marked.gameValue (MarkedSum.original original original) (MarkedSum.combine ∅ ∅)
      .staller (MarkedSum.combine ∅ ∅)≤7 :=
  MarkedSum.forest_reply_pair original original
    (CanonicalLocal.canonical_tree .t12).IsAcyclic (CanonicalLocal.canonical_tree .t12).IsAcyclic ∅ ∅ ∅ ∅ 4 4 reply_strict_four reply_strict_four

#print axioms reply_strict_four
#print axioms with_any_strict
#print axioms two_full_twelve
end IsolationGame.FullCanonical.T12
