import TwoPoolForestExhaustion
import FiniteTreeCertificate
import Profile_08_Graph

/-! Fresh reconstruction of the 12-fixed-vertex centre–T08 receiver model.
This is new source, not a recovered historical CenterT08ReceiverModel file.
Pending actual Lean compilation; no proof status is claimed by its presence. -/

namespace IsolationGame.CenterT08Receiver

set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

abbrev Fixed := Fin 12

def fixedGraph : SimpleGraph Fixed := LocalProfile.graph
  [(0,1), (1,2), (2,3), (3,4), (1,5), (5,6), (6,7),
   (1,8), (8,9), (9,10), (8,11)]

instance : DecidableRel fixedGraph.Adj :=
  inferInstanceAs (DecidableRel (LocalProfile.graph _).Adj)

theorem fixed_tree : fixedGraph.IsTree :=
  CanonicalLocal.tree_of_certificate fixedGraph 1
    (by unfold CanonicalLocal.ReachThree fixedGraph; decide +kernel)
    (by decide +kernel)

abbrev Vertex (p : Nat) := TwoPool.Vertex Fixed p 0

def graph (p : Nat) : SimpleGraph (Vertex p) :=
  TwoPool.graph fixedGraph 0 0 p 0

def marks (p : Nat) : Finset (Vertex p) :=
  TwoPool.marks ({0} : Finset Fixed) p 0

def fixed (p : Nat) (v : Fixed) : Vertex p := TwoPool.fixed p 0 v

def ordinary (p : Nat) (i : Fin p) (r : Fin 7) : Vertex p :=
  TwoPool.ordinaryLeft p 0 i r

theorem graph_acyclic (p : Nat) : (graph p).IsAcyclic :=
  TwoPool.graph_acyclic fixedGraph fixed_tree.IsAcyclic 0 0 p 0

theorem order (p : Nat) : Fintype.card (Vertex p) = 12 + 7*p := by
  simpa [Vertex] using (TwoPool.original_order (F := Fixed) p 0)

theorem root_marked (p : Nat) : fixed p 0 ∈ marks p := by
  simp [fixed, marks]

#print axioms fixed_tree
#print axioms graph_acyclic
#print axioms order
#print axioms root_marked

end IsolationGame.CenterT08Receiver
