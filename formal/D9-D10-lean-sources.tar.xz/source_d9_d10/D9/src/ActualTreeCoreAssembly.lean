import ActualRootPartition
import CoreFamilyAdjacency
import RootedAssemblyContract

/-!
Candidate generated 2026-10-19. Verification status is recorded in native receipts.
A structural assembly theorem. Canonical completeness is an explicit premise.
All canonical types, including t00, t02 and t13, may occur with arbitrary
multiplicity. The tail parameter is zero; the list keeps every branch.
-/
namespace IsolationGame.CoreFamily
open CanonicalLocal ActualRootBranches SmallPiece IsolatedRestriction NecessaryCore
variable {V : Type} [Fintype V] [DecidableEq V]

/-- The exact all-branch list, in an arbitrary finite enumeration. -/
def allProfileCodes {n : Nat} (f : Fin n → Index) : List Nat :=
  List.ofFn (fun i => code (f i))

@[simp] theorem allProfileCodes_length {n : Nat} (f : Fin n → Index) :
    (allProfileCodes f).length = n := by simp [allProfileCodes]

private def castFinEquiv {m n : Nat} (h : m = n) : Fin m ≃ Fin n where
  toFun := Fin.cast h
  invFun := Fin.cast h.symm
  left_inv := by intro i; cases h; rfl
  right_inv := by intro i; cases h; rfl

/-- Reindex Fin n into the literal family's branch-index type. -/
def allProfileIndex {n : Nat} (f : Fin n → Index) :
    Fin n ≃ Fin ((allProfileCodes f).length+0) :=
  castFinEquiv (by simp)

@[simp] theorem allProfileIndex_val {n : Nat} (f : Fin n → Index) (i : Fin n) :
    (allProfileIndex f i).val = i.val := rfl

/-- List enumeration recovers the full canonical label, not just its size. -/
theorem allProfileIndex_label {n : Nat} (f : Fin n → Index) (i : Fin n) :
    label (allProfileCodes f) 0 (allProfileIndex f i) = f i := by
  have hi : (allProfileIndex f i).val < (allProfileCodes f).length := by
    simpa only [Nat.add_zero] using (allProfileIndex f i).isLt
  simp only [label, dif_pos hi]
  change decode ((List.ofFn (fun j : Fin n => code (f j)))[i.val]'hi) = f i
  simp only [List.getElem_ofFn]
  have he : (⟨i.val, by simpa [allProfileCodes] using hi⟩ : Fin n) = i := by
    apply Fin.ext
    rfl
  simpa only [he, decode_code]

/-- Glue complete branch isomorphisms into a complete original-graph
isomorphism. The target need not separately be assumed to be a tree. -/
theorem assemble_core_family_indexed (G : SimpleGraph V) (hG : G.IsTree) (r : V)
    (xs : List Nat) (e : Child G r ≃ Fin (xs.length+0))
    (hf : ∀a : Child G r,
      RootedAssembly.RootedIso (outerGraph G r a) (outerRoot G r a)
        (CanonicalLocal.graph (label xs 0 (e a))) (root (label xs 0 (e a)))) :
    AssemblySpec G r xs 0 := by
  classical
  choose f hfroot hfadj using hf
  let c : ActualRootPartition.Code G r ≃ Vertex xs 0 :=
    Equiv.optionCongr (Equiv.sigmaCongr e f)
  let g := ActualRootPartition.realizeEquiv G hG r
  let t := g.symm.trans c
  have ht (x : ActualRootPartition.Code G r) : t (g x) = c x := by
    simp [t]
  have hcroot : c none = none := rfl
  have hcsome (a : Child G r) (u : Outer G r a) :
      c (some ⟨a,u⟩) = some ⟨e a,f a u⟩ := rfl
  have hgroot : g none = r := rfl
  have hroot (a : Child G r) (u : Outer G r a) :
      (CoreFamily.graph xs 0).Adj none (some ⟨e a,f a u⟩) ↔ G.Adj r u.val := by
    rw [CoreFamilySemantics.root_adj, ActualRootPartition.root_adj G hG r]
    constructor
    · intro he
      have hu : u = outerRoot G r a := (f a).injective (he.trans (hfroot a).symm)
      exact congrArg Subtype.val hu
    · intro he
      have hu : u = outerRoot G r a := Subtype.ext he
      rw [hu,hfroot]
  refine ⟨t, ?_, ?_⟩
  · rw [←hgroot,ht,hcroot]
  · intro u v
    obtain ⟨x,rfl⟩ := g.surjective u
    obtain ⟨y,rfl⟩ := g.surjective v
    rw [ht,ht]
    cases x with
    | none =>
      cases y with
      | none => exact iff_of_false (CoreFamily.graph xs 0).irrefl G.irrefl
      | some y =>
        obtain ⟨a,v⟩ := y
        rw [hcroot,hcsome]
        exact hroot a v
    | some x =>
      obtain ⟨a,u⟩ := x
      cases y with
      | none =>
        rw [hcsome,hcroot]
        change (CoreFamily.graph xs 0).Adj (some ⟨e a,f a u⟩) none ↔ G.Adj u.val r
        rw [(CoreFamily.graph xs 0).adj_comm,G.adj_comm]
        exact hroot a u
      | some y =>
        obtain ⟨b,v⟩ := y
        rw [hcsome,hcsome]
        change (CoreFamily.graph xs 0).Adj (some ⟨e a,f a u⟩) (some ⟨e b,f b v⟩) ↔
          G.Adj u.val v.val
        by_cases hab : a = b
        · subst b
          exact (CoreFamilySemantics.same_adj xs 0 (e a) (f a u) (f a v)).trans
            (hfadj a u v)
        · have heab : e a ≠ e b := fun he => hab (e.injective he)
          exact iff_of_false
            (CoreFamilySemantics.distinct_no_adj xs 0 (e a) (e b) heab (f a u) (f b v))
            (ActualRootPartition.no_cross G hG r a b hab u v)

/-- Assemble from any explicitly given canonical branch labels. No sorting,
exceptional-code filter, multiplicity bound, or game hypothesis is used. -/
theorem assemble_core_family_of_labels (G : SimpleGraph V) (hG : G.IsTree) (r : V)
    (f : Child G r → Index)
    (hf : ∀a : Child G r, RootedAssembly.RootedIso
      (outerGraph G r a) (outerRoot G r a) (CanonicalLocal.graph (f a)) (root (f a))) :
    ∃xs : List Nat, xs.length = Fintype.card (Child G r) ∧ AssemblySpec G r xs 0 := by
  classical
  let d : Child G r ≃ Fin (Fintype.card (Child G r)) := Fintype.equivFin _
  let labels : Fin (Fintype.card (Child G r)) → Index := fun i => f (d.symm i)
  let xs := allProfileCodes labels
  let e : Child G r ≃ Fin (xs.length+0) := d.trans (allProfileIndex labels)
  have he (a : Child G r) : label xs 0 (e a) = f a := by
    change label (allProfileCodes labels) 0 (allProfileIndex labels (d a)) = f a
    rw [allProfileIndex_label]
    simp only [labels,Equiv.symm_apply_apply]
  refine ⟨xs,by simp [xs],assemble_core_family_indexed G hG r xs e ?_⟩
  intro a
  rw [he a]
  exact hf a

/-- The minimal structural bridge: each actual component is fully rooted-iso
to some canonical profile, hence the whole actual tree is a literal core. -/
theorem assemble_core_family (G : SimpleGraph V) (hG : G.IsTree) (r : V)
    (hcanonical : ∀a : Child G r, ∃t : Index, RootedAssembly.RootedIso
      (outerGraph G r a) (outerRoot G r a) (CanonicalLocal.graph t) (root t)) :
    ∃xs : List Nat, xs.length = Fintype.card (Child G r) ∧ AssemblySpec G r xs 0 := by
  classical
  choose f hf using hcanonical
  exact assemble_core_family_of_labels G hG r f hf

/-- Standard graph-isomorphism form of the same all-carrier assembly. -/
theorem exists_core_family_iso (G : SimpleGraph V) (hG : G.IsTree) (r : V)
    (hcanonical : ∀a : Child G r, ∃t : Index, RootedAssembly.RootedIso
      (outerGraph G r a) (outerRoot G r a) (CanonicalLocal.graph t) (root t)) :
    ∃xs : List Nat, ∃e : G ≃g CoreFamily.graph xs 0, e r = none := by
  obtain ⟨xs,_,e,her,hea⟩ := assemble_core_family G hG r hcanonical
  exact ⟨xs,{ toEquiv := e, map_rel_iff' := fun {u v} => hea u v },her⟩

#print axioms assemble_core_family_indexed
#print axioms assemble_core_family_of_labels
#print axioms assemble_core_family
#print axioms exists_core_family_iso
end IsolationGame.CoreFamily
