import LiteralBWSemantics
import Mathlib.Tactic.FinCases
namespace IsolationGame.LiteralBW
set_option maxHeartbeats 3000000

 theorem node_ne_port (p q : Nat) (i j : Fin (p+q)) (k : Fin 7) :
    node p q i k ≠ port p q j := by
  unfold port; split_ifs <;> simp

 theorem x_adj (p q : Nat) (v : Vertex p q) :
    (graph p q).Adj (x p q) v ↔
      v=y p q ∨ ∃ j : Fin (p+q), j.val<p ∧ v=node p q j 0 := by
  have hn (j : Fin (p+q)) (k : Fin 7) : x p q ≠ node p q j k := Ne.symm (node_ne_x p q j k)
  have hp (j : Fin (p+q)) : x p q=port p q j ↔ j.val<p := by
    simp only [port]; split_ifs with h
    · simp [h]
    · simp [h]
  change (x p q ≠ v ∧ (forward p q (x p q) v ∨ forward p q v (x p q))) ↔ _
  simp only [forward,hp,hn,x_ne_y,false_and,and_false,or_false,false_or,exists_false,and_true,true_and]
  constructor
  · exact fun h=>h.2
  · intro h
    refine ⟨?_,h⟩
    rcases h with rfl|⟨j,_,rfl⟩
    · exact x_ne_y p q
    · exact hn j 0

 theorem x_adj_node (p q : Nat) (j : Fin (p+q)) (k : Fin 7) :
    (graph p q).Adj (x p q) (node p q j k) ↔ j.val<p ∧ k=0 := by
  rw [x_adj]
  simp only [node_ne_y,false_or,node_eq_node]
  constructor
  · rintro ⟨i,hi,hji,hk⟩; subst i; exact ⟨hi,hk⟩
  · rintro ⟨hj,hk⟩; exact ⟨j,hj,rfl,hk⟩

 theorem y_adj_node (p q : Nat) (j : Fin (p+q)) (k : Fin 7) :
    (graph p q).Adj (y p q) (node p q j k) ↔ p≤j.val ∧ k=0 := by
  rw [y_adj]
  simp only [node_ne_x,false_or,node_eq_node]
  constructor
  · rintro ⟨i,hi,hji,hk⟩; subst i; exact ⟨hi,hk⟩
  · rintro ⟨hj,hk⟩; exact ⟨j,hj,rfl,hk⟩

 def localForward (a b : Fin 7) : Prop :=
    (a=0∧b=1)∨(a=1∧b=2)∨(a=2∧b=3)∨(a=0∧b=4)∨(a=4∧b=5)∨(a=5∧b=6)
 def localAdj (a b : Fin 7) : Prop := localForward a b ∨ localForward b a

 theorem nodes_adj (p q : Nat) (i j : Fin (p+q)) (a b : Fin 7) :
    (graph p q).Adj (node p q i a) (node p q j b) ↔ i=j ∧ localAdj a b := by
  fin_cases a <;> fin_cases b <;>
    simp [graph,forward,node_ne_x,node_ne_y,node_ne_port,node_eq_node,
      localAdj,localForward,and_assoc,eq_comm]

#print axioms nodes_adj
end IsolationGame.LiteralBW
