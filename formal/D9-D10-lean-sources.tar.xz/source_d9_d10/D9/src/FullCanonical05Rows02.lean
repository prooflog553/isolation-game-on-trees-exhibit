import FullCanonical05Rows01
namespace IsolationGame.FullCanonical.T05
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_8 : Finset (Fin 16) := {1,2,3,5,6,8,9,11,12,14,15}
theorem after_8_0 : Marked.gameValue original marks_8 .dominator {0}=0 ∧ Marked.gameValue original marks_8 .staller {0}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_0 0 0 0 (by decide +kernel) row_0
theorem after_8_1 : Marked.gameValue original marks_8 .dominator {1}=0 ∧ Marked.gameValue original marks_8 .staller {1}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_0 1 0 0 (by decide +kernel) row_0
theorem after_8_4 : Marked.gameValue original marks_8 .dominator {4}=0 ∧ Marked.gameValue original marks_8 .staller {4}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_0 4 0 0 (by decide +kernel) row_0
theorem after_8_5 : Marked.gameValue original marks_8 .dominator {5}=1 ∧ Marked.gameValue original marks_8 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_5 5 1 2 (by decide +kernel) row_5
theorem after_8_7 : Marked.gameValue original marks_8 .dominator {7}=0 ∧ Marked.gameValue original marks_8 .staller {7}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_0 7 0 0 (by decide +kernel) row_0
theorem after_8_8 : Marked.gameValue original marks_8 .dominator {8}=1 ∧ Marked.gameValue original marks_8 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_4 adjacency_4 marks_8 marks_5 8 1 2 (by decide +kernel) row_5
theorem after_8_10 : Marked.gameValue original marks_8 .dominator {10}=0 ∧ Marked.gameValue original marks_8 .staller {10}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_0 10 0 0 (by decide +kernel) row_0
theorem after_8_11 : Marked.gameValue original marks_8 .dominator {11}=1 ∧ Marked.gameValue original marks_8 .staller {11}=2 :=
  FullCanonicalDAG.transport_perm original perm_5 adjacency_5 marks_8 marks_5 11 1 2 (by decide +kernel) row_5
theorem after_8_13 : Marked.gameValue original marks_8 .dominator {13}=0 ∧ Marked.gameValue original marks_8 .staller {13}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_0 13 0 0 (by decide +kernel) row_0
theorem after_8_14 : Marked.gameValue original marks_8 .dominator {14}=1 ∧ Marked.gameValue original marks_8 .staller {14}=2 :=
  FullCanonicalDAG.transport_perm original perm_6 adjacency_6 marks_8 marks_5 14 1 2 (by decide +kernel) row_5
theorem row_8 : Marked.gameValue original marks_8 .dominator ∅=1 ∧ Marked.gameValue original marks_8 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_8 1 2 0 5 (by decide +kernel) (by decide +kernel)
  · rw [after_8_0.2]
  · rw [after_8_5.1]
  · intro v hv
    fin_cases v
    · have h := after_8_0
      change 1 ≤ 1+Marked.gameValue original marks_8 .staller {0} ∧ 1+Marked.gameValue original marks_8 .dominator {0} ≤ 2
      omega
    · have h := after_8_1
      change 1 ≤ 1+Marked.gameValue original marks_8 .staller {1} ∧ 1+Marked.gameValue original marks_8 .dominator {1} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_8 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_8 ∅ 3) hv)
    · have h := after_8_4
      change 1 ≤ 1+Marked.gameValue original marks_8 .staller {4} ∧ 1+Marked.gameValue original marks_8 .dominator {4} ≤ 2
      omega
    · have h := after_8_5
      change 1 ≤ 1+Marked.gameValue original marks_8 .staller {5} ∧ 1+Marked.gameValue original marks_8 .dominator {5} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_8 ∅ 6) hv)
    · have h := after_8_7
      change 1 ≤ 1+Marked.gameValue original marks_8 .staller {7} ∧ 1+Marked.gameValue original marks_8 .dominator {7} ≤ 2
      omega
    · have h := after_8_8
      change 1 ≤ 1+Marked.gameValue original marks_8 .staller {8} ∧ 1+Marked.gameValue original marks_8 .dominator {8} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_8 ∅ 9) hv)
    · have h := after_8_10
      change 1 ≤ 1+Marked.gameValue original marks_8 .staller {10} ∧ 1+Marked.gameValue original marks_8 .dominator {10} ≤ 2
      omega
    · have h := after_8_11
      change 1 ≤ 1+Marked.gameValue original marks_8 .staller {11} ∧ 1+Marked.gameValue original marks_8 .dominator {11} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_8 ∅ 12) hv)
    · have h := after_8_13
      change 1 ≤ 1+Marked.gameValue original marks_8 .staller {13} ∧ 1+Marked.gameValue original marks_8 .dominator {13} ≤ 2
      omega
    · have h := after_8_14
      change 1 ≤ 1+Marked.gameValue original marks_8 .staller {14} ∧ 1+Marked.gameValue original marks_8 .dominator {14} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_8 ∅ 15) hv)
def marks_9 : Finset (Fin 16) := {1,2,3,4,5,6,7,8,9,11,12}
theorem after_9_0 : Marked.gameValue original marks_9 .dominator {0}=1 ∧ Marked.gameValue original marks_9 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_9 marks_2 0 1 1 (by decide +kernel) row_2
theorem after_9_1 : Marked.gameValue original marks_9 .dominator {1}=1 ∧ Marked.gameValue original marks_9 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_9 marks_4 1 1 2 (by decide +kernel) row_4
theorem after_9_4 : Marked.gameValue original marks_9 .dominator {4}=1 ∧ Marked.gameValue original marks_9 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_9 marks_4 4 1 2 (by decide +kernel) row_4
theorem after_9_7 : Marked.gameValue original marks_9 .dominator {7}=1 ∧ Marked.gameValue original marks_9 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_9 marks_4 7 1 2 (by decide +kernel) row_4
theorem after_9_10 : Marked.gameValue original marks_9 .dominator {10}=1 ∧ Marked.gameValue original marks_9 .staller {10}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_9 marks_4 10 1 2 (by decide +kernel) row_4
theorem after_9_11 : Marked.gameValue original marks_9 .dominator {11}=1 ∧ Marked.gameValue original marks_9 .staller {11}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_9 marks_7 11 1 2 (by decide +kernel) row_7
theorem after_9_13 : Marked.gameValue original marks_9 .dominator {13}=0 ∧ Marked.gameValue original marks_9 .staller {13}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_9 marks_0 13 0 0 (by decide +kernel) row_0
theorem after_9_14 : Marked.gameValue original marks_9 .dominator {14}=1 ∧ Marked.gameValue original marks_9 .staller {14}=1 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_9 marks_1 14 1 1 (by decide +kernel) row_1
theorem after_9_15 : Marked.gameValue original marks_9 .dominator {15}=1 ∧ Marked.gameValue original marks_9 .staller {15}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_9 marks_3 15 1 2 (by decide +kernel) row_3
theorem row_9 : Marked.gameValue original marks_9 .dominator ∅=1 ∧ Marked.gameValue original marks_9 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_9 1 2 13 0 (by decide +kernel) (by decide +kernel)
  · rw [after_9_13.2]
  · rw [after_9_0.1]
  · intro v hv
    fin_cases v
    · have h := after_9_0
      change 1 ≤ 1+Marked.gameValue original marks_9 .staller {0} ∧ 1+Marked.gameValue original marks_9 .dominator {0} ≤ 2
      omega
    · have h := after_9_1
      change 1 ≤ 1+Marked.gameValue original marks_9 .staller {1} ∧ 1+Marked.gameValue original marks_9 .dominator {1} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_9 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_9 ∅ 3) hv)
    · have h := after_9_4
      change 1 ≤ 1+Marked.gameValue original marks_9 .staller {4} ∧ 1+Marked.gameValue original marks_9 .dominator {4} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_9 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_9 ∅ 6) hv)
    · have h := after_9_7
      change 1 ≤ 1+Marked.gameValue original marks_9 .staller {7} ∧ 1+Marked.gameValue original marks_9 .dominator {7} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_9 ∅ 8) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_9 ∅ 9) hv)
    · have h := after_9_10
      change 1 ≤ 1+Marked.gameValue original marks_9 .staller {10} ∧ 1+Marked.gameValue original marks_9 .dominator {10} ≤ 2
      omega
    · have h := after_9_11
      change 1 ≤ 1+Marked.gameValue original marks_9 .staller {11} ∧ 1+Marked.gameValue original marks_9 .dominator {11} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_9 ∅ 12) hv)
    · have h := after_9_13
      change 1 ≤ 1+Marked.gameValue original marks_9 .staller {13} ∧ 1+Marked.gameValue original marks_9 .dominator {13} ≤ 2
      omega
    · have h := after_9_14
      change 1 ≤ 1+Marked.gameValue original marks_9 .staller {14} ∧ 1+Marked.gameValue original marks_9 .dominator {14} ≤ 2
      omega
    · have h := after_9_15
      change 1 ≤ 1+Marked.gameValue original marks_9 .staller {15} ∧ 1+Marked.gameValue original marks_9 .dominator {15} ≤ 2
      omega
def marks_10 : Finset (Fin 16) := {2,3,5,6,8,9,11,12,14,15}
theorem after_10_0 : Marked.gameValue original marks_10 .dominator {0}=0 ∧ Marked.gameValue original marks_10 .staller {0}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_10 marks_0 0 0 0 (by decide +kernel) row_0
theorem after_10_1 : Marked.gameValue original marks_10 .dominator {1}=0 ∧ Marked.gameValue original marks_10 .staller {1}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_10 marks_0 1 0 0 (by decide +kernel) row_0
theorem after_10_2 : Marked.gameValue original marks_10 .dominator {2}=1 ∧ Marked.gameValue original marks_10 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_10 marks_8 2 1 2 (by decide +kernel) row_8
theorem after_10_4 : Marked.gameValue original marks_10 .dominator {4}=0 ∧ Marked.gameValue original marks_10 .staller {4}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_10 marks_0 4 0 0 (by decide +kernel) row_0
theorem after_10_5 : Marked.gameValue original marks_10 .dominator {5}=1 ∧ Marked.gameValue original marks_10 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_7 adjacency_7 marks_10 marks_8 5 1 2 (by decide +kernel) row_8
theorem after_10_7 : Marked.gameValue original marks_10 .dominator {7}=0 ∧ Marked.gameValue original marks_10 .staller {7}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_10 marks_0 7 0 0 (by decide +kernel) row_0
theorem after_10_8 : Marked.gameValue original marks_10 .dominator {8}=1 ∧ Marked.gameValue original marks_10 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_8 adjacency_8 marks_10 marks_8 8 1 2 (by decide +kernel) row_8
theorem after_10_10 : Marked.gameValue original marks_10 .dominator {10}=0 ∧ Marked.gameValue original marks_10 .staller {10}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_10 marks_0 10 0 0 (by decide +kernel) row_0
theorem after_10_11 : Marked.gameValue original marks_10 .dominator {11}=1 ∧ Marked.gameValue original marks_10 .staller {11}=2 :=
  FullCanonicalDAG.transport_perm original perm_9 adjacency_9 marks_10 marks_8 11 1 2 (by decide +kernel) row_8
theorem after_10_13 : Marked.gameValue original marks_10 .dominator {13}=0 ∧ Marked.gameValue original marks_10 .staller {13}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_10 marks_0 13 0 0 (by decide +kernel) row_0
theorem after_10_14 : Marked.gameValue original marks_10 .dominator {14}=1 ∧ Marked.gameValue original marks_10 .staller {14}=2 :=
  FullCanonicalDAG.transport_perm original perm_10 adjacency_10 marks_10 marks_8 14 1 2 (by decide +kernel) row_8
theorem row_10 : Marked.gameValue original marks_10 .dominator ∅=1 ∧ Marked.gameValue original marks_10 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_10 1 2 0 2 (by decide +kernel) (by decide +kernel)
  · rw [after_10_0.2]
  · rw [after_10_2.1]
  · intro v hv
    fin_cases v
    · have h := after_10_0
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {0} ∧ 1+Marked.gameValue original marks_10 .dominator {0} ≤ 2
      omega
    · have h := after_10_1
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {1} ∧ 1+Marked.gameValue original marks_10 .dominator {1} ≤ 2
      omega
    · have h := after_10_2
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {2} ∧ 1+Marked.gameValue original marks_10 .dominator {2} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_10 ∅ 3) hv)
    · have h := after_10_4
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {4} ∧ 1+Marked.gameValue original marks_10 .dominator {4} ≤ 2
      omega
    · have h := after_10_5
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {5} ∧ 1+Marked.gameValue original marks_10 .dominator {5} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_10 ∅ 6) hv)
    · have h := after_10_7
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {7} ∧ 1+Marked.gameValue original marks_10 .dominator {7} ≤ 2
      omega
    · have h := after_10_8
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {8} ∧ 1+Marked.gameValue original marks_10 .dominator {8} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_10 ∅ 9) hv)
    · have h := after_10_10
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {10} ∧ 1+Marked.gameValue original marks_10 .dominator {10} ≤ 2
      omega
    · have h := after_10_11
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {11} ∧ 1+Marked.gameValue original marks_10 .dominator {11} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_10 ∅ 12) hv)
    · have h := after_10_13
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {13} ∧ 1+Marked.gameValue original marks_10 .dominator {13} ≤ 2
      omega
    · have h := after_10_14
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {14} ∧ 1+Marked.gameValue original marks_10 .dominator {14} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_10 ∅ 15) hv)
def marks_11 : Finset (Fin 16) := {0,1,2,3,4,5,6,7,10,13}
theorem after_11_7 : Marked.gameValue original marks_11 .dominator {7}=2 ∧ Marked.gameValue original marks_11 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_11 marks_6 7 2 2 (by decide +kernel) row_6
theorem after_11_8 : Marked.gameValue original marks_11 .dominator {8}=2 ∧ Marked.gameValue original marks_11 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_11 marks_6 8 2 2 (by decide +kernel) row_6
theorem after_11_9 : Marked.gameValue original marks_11 .dominator {9}=2 ∧ Marked.gameValue original marks_11 .staller {9}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_11 marks_6 9 2 2 (by decide +kernel) row_6
theorem after_11_10 : Marked.gameValue original marks_11 .dominator {10}=2 ∧ Marked.gameValue original marks_11 .staller {10}=2 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_11 marks_6 10 2 2 (by decide +kernel) row_6
theorem after_11_11 : Marked.gameValue original marks_11 .dominator {11}=2 ∧ Marked.gameValue original marks_11 .staller {11}=2 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_11 marks_6 11 2 2 (by decide +kernel) row_6
theorem after_11_12 : Marked.gameValue original marks_11 .dominator {12}=2 ∧ Marked.gameValue original marks_11 .staller {12}=2 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_11 marks_6 12 2 2 (by decide +kernel) row_6
theorem after_11_13 : Marked.gameValue original marks_11 .dominator {13}=2 ∧ Marked.gameValue original marks_11 .staller {13}=2 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_11 marks_6 13 2 2 (by decide +kernel) row_6
theorem after_11_14 : Marked.gameValue original marks_11 .dominator {14}=2 ∧ Marked.gameValue original marks_11 .staller {14}=2 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_11 marks_6 14 2 2 (by decide +kernel) row_6
theorem after_11_15 : Marked.gameValue original marks_11 .dominator {15}=2 ∧ Marked.gameValue original marks_11 .staller {15}=2 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_11 marks_6 15 2 2 (by decide +kernel) row_6
theorem row_11 : Marked.gameValue original marks_11 .dominator ∅=3 ∧ Marked.gameValue original marks_11 .staller ∅=3 := by
  apply LocalProfile.DAG.bellman original marks_11 3 3 7 7 (by decide +kernel) (by decide +kernel)
  · rw [after_11_7.2]
  · rw [after_11_7.1]
  · intro v hv
    fin_cases v
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_11 ∅ 0) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_11 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_11 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_11 ∅ 3) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_11 ∅ 4) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_11 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_11 ∅ 6) hv)
    · have h := after_11_7
      change 3 ≤ 1+Marked.gameValue original marks_11 .staller {7} ∧ 1+Marked.gameValue original marks_11 .dominator {7} ≤ 3
      omega
    · have h := after_11_8
      change 3 ≤ 1+Marked.gameValue original marks_11 .staller {8} ∧ 1+Marked.gameValue original marks_11 .dominator {8} ≤ 3
      omega
    · have h := after_11_9
      change 3 ≤ 1+Marked.gameValue original marks_11 .staller {9} ∧ 1+Marked.gameValue original marks_11 .dominator {9} ≤ 3
      omega
    · have h := after_11_10
      change 3 ≤ 1+Marked.gameValue original marks_11 .staller {10} ∧ 1+Marked.gameValue original marks_11 .dominator {10} ≤ 3
      omega
    · have h := after_11_11
      change 3 ≤ 1+Marked.gameValue original marks_11 .staller {11} ∧ 1+Marked.gameValue original marks_11 .dominator {11} ≤ 3
      omega
    · have h := after_11_12
      change 3 ≤ 1+Marked.gameValue original marks_11 .staller {12} ∧ 1+Marked.gameValue original marks_11 .dominator {12} ≤ 3
      omega
    · have h := after_11_13
      change 3 ≤ 1+Marked.gameValue original marks_11 .staller {13} ∧ 1+Marked.gameValue original marks_11 .dominator {13} ≤ 3
      omega
    · have h := after_11_14
      change 3 ≤ 1+Marked.gameValue original marks_11 .staller {14} ∧ 1+Marked.gameValue original marks_11 .dominator {14} ≤ 3
      omega
    · have h := after_11_15
      change 3 ≤ 1+Marked.gameValue original marks_11 .staller {15} ∧ 1+Marked.gameValue original marks_11 .dominator {15} ≤ 3
      omega
end IsolationGame.FullCanonical.T05
