import AllProfileCoreCard
import CoreRootOpening

namespace IsolationGame.AllProfileCore
open CanonicalLocal CoreFamily CoreFamilySemantics CoreForest

/-- Root-only initial marks have exactly this normalized local white set. -/
theorem root_only_white (t : Index) :
    Marked.White (CanonicalLocal.graph t) {root t} ∅ =
      (GuardedEdge.view (CanonicalLocal.graph t)).noniso (fun v => True ∧ v ≠ root t) := by
  funext v
  apply propext
  rw [←GuardedEdge.white_agree]
  simp [Isolation.Graph.noniso,Isolation.Graph.raw]

/-- Reuse the accepted full-profile certificate, including t00 and t13. -/
theorem closed_profile_S (t : Index) :
    Marked.gameValue (CanonicalLocal.graph t)
      (ForestFoundation.canonicalMarks
        ((GuardedEdge.view (CanonicalLocal.graph t)).noniso (fun v => True ∧ v ≠ root t)))
      .staller ∅ = expectedS t := by
  have h := Marked.canonical_mark_value (CanonicalLocal.graph t) {root t} ∅ .staller
  rw [root_only_white] at h
  rw [←h]
  exact S_value t

/-- Normalizing all-white first is harmless even for isolated t00. -/
theorem initial_closed_local (xs : List Nat) (q : Nat) (i : Fin (xs.length+q)) :
    closeCentre xs q (initialLocal xs q) i =
      (GuardedEdge.view (CanonicalLocal.graph (CoreFamily.label xs q i))).noniso
        (fun v => True ∧ v ≠ root (CoreFamily.label xs q i)) := by
  funext v
  exact propext ((GuardedEdge.view (CanonicalLocal.graph (CoreFamily.label xs q i))).normalize_restrict
    (fun _ => True) (fun v => v ≠ root (CoreFamily.label xs q i)) v)

/-- Bridge the actual singleton selected history, rather than rewriting only
an empty-history initialization equality. All original vertices are retained. -/
theorem selected_initial_value (xs : List Nat) (q : Nat) (turn : Player) :
    Marked.gameValue (CoreFamily.graph xs q) {none} turn {none} =
      Marked.gameValue (CoreFamily.graph xs q)
        (marks xs q (closeCentre xs q (initialLocal xs q))) turn ∅ := by
  have hi : Marked.White (CoreFamily.graph xs q) {none} ∅ = white xs q (initialLocal xs q) := by
    funext v
    exact propext (initial_original_white xs q v)
  have hs := ForestFoundation.marked_white_step (CoreFamily.graph xs q) {none} ∅ none
  rw [hi] at hs
  change (GuardedEdge.view (CoreFamily.graph xs q)).step (white xs q (initialLocal xs q)) none = _ at hs
  rw [step_eq_next xs q (initialLocal xs q) (initial_normalized xs q)] at hs
  simp only [Finset.insert_empty] at hs
  apply Marked.value_eq_of_white_eq
  intro v
  rw [←hs]
  exact (original_white xs q _ (next_normalized xs q (initialLocal xs q)
    (initial_normalized xs q) none) v).symm

/-- An unconditional bound for every finite list of natural-number codes.
No exclusion of t00, allowed-code list, or local all-white hypothesis occurs. -/
theorem root_selected_S (xs : List Nat) (q : Nat) :
    Marked.gameValue (CoreFamily.graph xs q) {none} .staller {none} ≤ 3*q+cost xs := by
  classical
  rw [selected_initial_value]
  have hn : Normalized xs q (closeCentre xs q (initialLocal xs q)) :=
    next_normalized xs q (initialLocal xs q) (initial_normalized xs q) none
  rw [free_root_value xs q _ hn (closed_roots_nonwhite xs q (initialLocal xs q))]
  have hc : ∀ i : Fin (xs.length+q),
      Marked.gameValue (CanonicalLocal.graph (CoreFamily.label xs q i))
        (ForestFoundation.canonicalMarks (closeCentre xs q (initialLocal xs q) i)) .staller ∅ ≤
        expectedS (CoreFamily.label xs q i) := by
    intro i
    rw [initial_closed_local,closed_profile_S]
  have hf := mixed_s_upper xs q (family_tree xs q).IsAcyclic
    (closeCentre xs q (initialLocal xs q)) (fun i => expectedS (CoreFamily.label xs q i)) ∅ hc (by simp)
  simp only [Finset.card_empty,Nat.zero_div,Nat.sub_zero] at hf
  rw [sum_label] at hf
  simpa [cost,expectedS,Nat.mul_comm,Nat.add_comm] using hf

#print axioms root_only_white
#print axioms closed_profile_S
#print axioms initial_closed_local
#print axioms selected_initial_value
#print axioms root_selected_S
end IsolationGame.AllProfileCore
