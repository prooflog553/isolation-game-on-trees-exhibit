import OriginalReplyGroups
import FiniteStrictPairing

namespace IsolationGame.FiniteForestComponents
open IsolatedRestriction
variable {V Iota : Type} [Fintype V] [DecidableEq V] [DecidableEq Iota]

/-- Every actual disjoint reply-strict pair saves one move, with no bound on
the number of copies. The original carriers and inherited histories remain. -/
theorem finite_reply_s_upper (G : SimpleGraph V) (hG : G.IsAcyclic)
    (C : Iota→Finset V)
    (hdis : ∀i j,i≠j→Disjoint (C i) (C j))
    (hcross : ∀i j,i≠j→∀u∈C i,∀v∈C j,¬G.Adj u v)
    (I : Finset Iota) (M X : Finset V) (c : Iota→Nat)
    (hc : ∀i∈I,MarkedSum.ReplyStrictCapacity (induced G (C i)) (restrict (C i) M) (restrict (C i) X) (c i)) :
    valueOn G (I.biUnion C) M X .staller≤(∑i∈I,c i)-I.card/2 := by
  revert hc
  refine Finset.case_strong_induction_on I ?_ ?_
  · intro _
    simp [empty_value]
  · intro i I hi ih hc
    by_cases hI : I=∅
    · subst I
      have hs := MarkedSum.reply_S_upper (induced G (C i))
        (MarkedSum.forest_no_minus _ (PartitionBridge.induced_acyclic G hG (C i)))
        (restrict (C i) M) (restrict (C i) X) (c i) (hc i (by simp))
      rw [show (insert i (∅ : Finset Iota)).biUnion C=C i from Finset.singleton_biUnion]
      simpa [valueOn] using hs
    · obtain ⟨j,hj⟩ := Finset.nonempty_iff_ne_empty.mpr hI
      let R := I.erase j
      have hRi : i∉R := fun h=>hi (Finset.mem_of_mem_erase h)
      have hRj : j∉R := Finset.not_mem_erase _ _
      have hij : i≠j := by intro he;subst j;exact hi hj
      have hIR : I=insert j R := (Finset.insert_erase hj).symm
      have hpairR : Disjoint ({i,j} : Finset Iota) R := by
        apply Finset.disjoint_left.mpr
        intro k hk hR
        simp only [Finset.mem_insert,Finset.mem_singleton] at hk
        rcases hk with rfl | rfl
        · exact hRi hR
        · exact hRj hR
      have hd := regions_disjoint C hdis {i,j} R hpairR
      have he := regions_noCross G C hcross {i,j} R hpairR
      simp only [Finset.biUnion_insert,Finset.singleton_biUnion] at hd he
      have hsum := union_s_upper G hG (C i∪C j) (R.biUnion C) hd he M X
      have hpair := union_reply_pair G hG (C i) (C j) (hdis i j hij) (by intro u v hu hv;exact hcross i j hij u hu v hv) M X
        (c i) (c j) (hc i (by simp)) (hc j (by simp [hj]))
      have hRcap : ∀k∈R,MarkedSum.ReplyStrictCapacity (induced G (C k)) (restrict (C k) M) (restrict (C k) X) (c k) := by
        intro k hk
        exact hc k (Finset.mem_insert_of_mem (Finset.mem_of_mem_erase hk))
      have hrest := ih R (Finset.erase_subset j I) hRcap
      have hrestpos := sum_ge_card c R (by intro k hk;have h:=(hRcap k hk).1;omega)
      have hcipos : 1≤c i := by have h:=(hc i (by simp)).1;omega
      have hcjpos : 1≤c j := by have h:=(hc j (by simp [hj])).1;omega
      have hfull : (insert i I).biUnion C=(C i∪C j)∪R.biUnion C := by
        rw [hIR,Finset.biUnion_insert,Finset.biUnion_insert]
        exact (Finset.union_assoc _ _ _).symm
      have hcard : (insert i I).card=R.card+2 := by
        rw [Finset.card_insert_of_not_mem hi,hIR,Finset.card_insert_of_not_mem hRj]
      have htotal : (∑k∈insert i I,c k)=c i+c j+∑k∈R,c k := by
        rw [Finset.sum_insert hi,hIR,Finset.sum_insert hRj]
        omega
      rw [hfull,hcard,htotal]
      omega

#print axioms finite_reply_s_upper
end IsolationGame.FiniteForestComponents
