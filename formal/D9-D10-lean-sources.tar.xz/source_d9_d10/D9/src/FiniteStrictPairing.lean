import OriginalStrictGroups

namespace IsolationGame.FiniteForestComponents
open IsolatedRestriction
variable {V Iota : Type} [Fintype V] [DecidableEq V] [DecidableEq Iota]

theorem regions_disjoint (C : Iota→Finset V)
    (hd : ∀i j,i≠j→Disjoint (C i) (C j))
    (I J : Finset Iota) (hIJ : Disjoint I J) : Disjoint (I.biUnion C) (J.biUnion C) := by
  apply Finset.disjoint_left.mpr
  intro v hvI hvJ
  obtain ⟨i,hi,hvi⟩ := Finset.mem_biUnion.mp hvI
  obtain ⟨j,hj,hvj⟩ := Finset.mem_biUnion.mp hvJ
  have hij : i≠j := by intro he;subst j;exact Finset.disjoint_left.mp hIJ hi hj
  exact Finset.disjoint_left.mp (hd i j hij) hvi hvj

theorem regions_noCross (G : SimpleGraph V) (C : Iota→Finset V)
    (hc : ∀i j,i≠j→∀u∈C i,∀v∈C j,¬G.Adj u v)
    (I J : Finset Iota) (hIJ : Disjoint I J) :
    ∀u v,u∈I.biUnion C→v∈J.biUnion C→¬G.Adj u v := by
  intro u v hu hv
  obtain ⟨i,hi,hui⟩ := Finset.mem_biUnion.mp hu
  obtain ⟨j,hj,hvj⟩ := Finset.mem_biUnion.mp hv
  have hij : i≠j := by intro he;subst j;exact Finset.disjoint_left.mp hIJ hi hj
  exact hc i j hij u hui v hvj

theorem sum_ge_card (c : Iota→Nat) (I : Finset Iota) (hc : ∀i∈I,1≤c i) : I.card≤∑i∈I,c i := by
  revert hc
  induction I using Finset.induction_on with
  | empty => simp
  | @insert i I hi ih =>
    intro hc
    rw [Finset.card_insert_of_not_mem hi,Finset.sum_insert hi]
    have hci := hc i (by simp)
    have hI := ih (by intro j hj;exact hc j (by simp [hj]))
    omega

/-- Each pair of strict ORIGINAL components saves one move. The proof pairs
two actual disjoint induced components at a time, then uses the genuine
forest sum bound. No isolated-value substitution across active edges occurs. -/
theorem finite_strict_s_upper (G : SimpleGraph V) (hG : G.IsAcyclic)
    (C : Iota→Finset V)
    (hdis : ∀i j,i≠j→Disjoint (C i) (C j))
    (hcross : ∀i j,i≠j→∀u∈C i,∀v∈C j,¬G.Adj u v)
    (I : Finset Iota) (M X : Finset V) (c : Iota→Nat)
    (hc : ∀i∈I,MarkedSum.StrictCapacity (induced G (C i)) (restrict (C i) M) (restrict (C i) X) (c i)) :
    valueOn G (I.biUnion C) M X .staller≤(∑i∈I,c i)-I.card/2 := by
  revert hc
  refine Finset.case_strong_induction_on I ?_ ?_
  · intro _
    simp [empty_value]
  · intro i I hi ih hc
    by_cases hI : I=∅
    · subst I
      have hs := Marked.starting_player_inequality (induced G (C i)) (restrict (C i) M) (restrict (C i) X)
      have hd := (hc i (by simp)).1
      rw [show (insert i (∅ : Finset Iota)).biUnion C=C i from Finset.singleton_biUnion]
      simpa [valueOn] using hs.trans hd
    · obtain ⟨j,hj⟩ := Finset.nonempty_iff_ne_empty.mpr hI
      let R := I.erase j
      have hRi : i∉R := fun h=>hi (Finset.mem_of_mem_erase h)
      have hRj : j∉R := Finset.not_mem_erase _ _
      have hij : i≠j := by intro he;subst j;exact hi hj
      have hIR : I=insert j R := (Finset.insert_erase hj).symm
      have hpairR : Disjoint ({i,j} : Finset Iota) R := by
        apply Finset.disjoint_left.mpr
        intro k hk hR
        simp only [Finset.mem_insert,Finset.mem_singleton] at hk
        rcases hk with rfl | rfl
        · exact hRi hR
        · exact hRj hR
      have hd := regions_disjoint C hdis {i,j} R hpairR
      have he := regions_noCross G C hcross {i,j} R hpairR
      simp only [Finset.biUnion_insert,Finset.singleton_biUnion] at hd he
      have hsum := union_s_upper G hG (C i∪C j) (R.biUnion C) hd he M X
      have hpair := union_strict_pair G hG (C i) (C j) (hdis i j hij) (by intro u v hu hv;exact hcross i j hij u hu v hv) M X
        (c i) (c j) (hc i (by simp)) (hc j (by simp [hj]))
      have hRcap : ∀k∈R,MarkedSum.StrictCapacity (induced G (C k)) (restrict (C k) M) (restrict (C k) X) (c k) := by
        intro k hk
        exact hc k (Finset.mem_insert_of_mem (Finset.mem_of_mem_erase hk))
      have hrest := ih R (Finset.erase_subset j I) hRcap
      have hrestpos := sum_ge_card c R (by intro k hk;have h:=(hRcap k hk).1;omega)
      have hcipos : 1≤c i := by have h:=(hc i (by simp)).1;omega
      have hcjpos : 1≤c j := by have h:=(hc j (by simp [hj])).1;omega
      have hfull : (insert i I).biUnion C=(C i∪C j)∪R.biUnion C := by
        rw [hIR,Finset.biUnion_insert,Finset.biUnion_insert]
        exact (Finset.union_assoc _ _ _).symm
      have hcard : (insert i I).card=R.card+2 := by
        rw [Finset.card_insert_of_not_mem hi,hIR,Finset.card_insert_of_not_mem hRj]
      have htotal : (∑k∈insert i I,c k)=c i+c j+∑k∈R,c k := by
        rw [Finset.sum_insert hi,hIR,Finset.sum_insert hRj]
        omega
      rw [hfull,hcard,htotal]
      omega

#print axioms finite_strict_s_upper
end IsolationGame.FiniteForestComponents
