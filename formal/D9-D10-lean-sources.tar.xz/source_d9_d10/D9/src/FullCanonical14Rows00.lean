import FullCanonical14Base
namespace IsolationGame.FullCanonical.T14
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_0 : Finset (Fin 5) := {0,1,2,3,4}
theorem row_0 : Marked.gameValue original marks_0 .dominator ∅=0 ∧ Marked.gameValue original marks_0 .staller ∅=0 := by
  constructor <;> apply (Marked.value_zero_iff_terminal _ _ _ _).mpr <;> decide +kernel
def marks_1 : Finset (Fin 5) := {0,1,4}
theorem after_1_1 : Marked.gameValue original marks_1 .dominator {1}=0 ∧ Marked.gameValue original marks_1 .staller {1}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_1 marks_0 1 0 0 (by decide +kernel) row_0
theorem after_1_2 : Marked.gameValue original marks_1 .dominator {2}=0 ∧ Marked.gameValue original marks_1 .staller {2}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_1 marks_0 2 0 0 (by decide +kernel) row_0
theorem after_1_3 : Marked.gameValue original marks_1 .dominator {3}=0 ∧ Marked.gameValue original marks_1 .staller {3}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_1 marks_0 3 0 0 (by decide +kernel) row_0
theorem row_1 : Marked.gameValue original marks_1 .dominator ∅=1 ∧ Marked.gameValue original marks_1 .staller ∅=1 := by
  apply LocalProfile.DAG.bellman original marks_1 1 1 1 1 (by decide +kernel) (by decide +kernel)
  · rw [after_1_1.2]
  · rw [after_1_1.1]
  · intro v hv
    fin_cases v
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_1 ∅ 0) hv)
    · have h := after_1_1
      change 1 ≤ 1+Marked.gameValue original marks_1 .staller {1} ∧ 1+Marked.gameValue original marks_1 .dominator {1} ≤ 1
      omega
    · have h := after_1_2
      change 1 ≤ 1+Marked.gameValue original marks_1 .staller {2} ∧ 1+Marked.gameValue original marks_1 .dominator {2} ≤ 1
      omega
    · have h := after_1_3
      change 1 ≤ 1+Marked.gameValue original marks_1 .staller {3} ∧ 1+Marked.gameValue original marks_1 .dominator {3} ≤ 1
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_1 ∅ 4) hv)
def marks_2 : Finset (Fin 5) := {1,2,3}
theorem after_2_0 : Marked.gameValue original marks_2 .dominator {0}=0 ∧ Marked.gameValue original marks_2 .staller {0}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_2 marks_0 0 0 0 (by decide +kernel) row_0
theorem after_2_1 : Marked.gameValue original marks_2 .dominator {1}=0 ∧ Marked.gameValue original marks_2 .staller {1}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_2 marks_0 1 0 0 (by decide +kernel) row_0
theorem after_2_4 : Marked.gameValue original marks_2 .dominator {4}=0 ∧ Marked.gameValue original marks_2 .staller {4}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_2 marks_0 4 0 0 (by decide +kernel) row_0
theorem row_2 : Marked.gameValue original marks_2 .dominator ∅=1 ∧ Marked.gameValue original marks_2 .staller ∅=1 := by
  apply LocalProfile.DAG.bellman original marks_2 1 1 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_2_0.2]
  · rw [after_2_0.1]
  · intro v hv
    fin_cases v
    · have h := after_2_0
      change 1 ≤ 1+Marked.gameValue original marks_2 .staller {0} ∧ 1+Marked.gameValue original marks_2 .dominator {0} ≤ 1
      omega
    · have h := after_2_1
      change 1 ≤ 1+Marked.gameValue original marks_2 .staller {1} ∧ 1+Marked.gameValue original marks_2 .dominator {1} ≤ 1
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_2 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_2 ∅ 3) hv)
    · have h := after_2_4
      change 1 ≤ 1+Marked.gameValue original marks_2 .staller {4} ∧ 1+Marked.gameValue original marks_2 .dominator {4} ≤ 1
      omega
def marks_3 : Finset (Fin 5) := {0,4}
theorem after_3_0 : Marked.gameValue original marks_3 .dominator {0}=1 ∧ Marked.gameValue original marks_3 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_3 marks_1 0 1 1 (by decide +kernel) row_1
theorem after_3_1 : Marked.gameValue original marks_3 .dominator {1}=0 ∧ Marked.gameValue original marks_3 .staller {1}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_3 marks_0 1 0 0 (by decide +kernel) row_0
theorem after_3_2 : Marked.gameValue original marks_3 .dominator {2}=0 ∧ Marked.gameValue original marks_3 .staller {2}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_3 marks_0 2 0 0 (by decide +kernel) row_0
theorem after_3_3 : Marked.gameValue original marks_3 .dominator {3}=0 ∧ Marked.gameValue original marks_3 .staller {3}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_3 marks_0 3 0 0 (by decide +kernel) row_0
theorem row_3 : Marked.gameValue original marks_3 .dominator ∅=1 ∧ Marked.gameValue original marks_3 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_3 1 2 1 0 (by decide +kernel) (by decide +kernel)
  · rw [after_3_1.2]
  · rw [after_3_0.1]
  · intro v hv
    fin_cases v
    · have h := after_3_0
      change 1 ≤ 1+Marked.gameValue original marks_3 .staller {0} ∧ 1+Marked.gameValue original marks_3 .dominator {0} ≤ 2
      omega
    · have h := after_3_1
      change 1 ≤ 1+Marked.gameValue original marks_3 .staller {1} ∧ 1+Marked.gameValue original marks_3 .dominator {1} ≤ 2
      omega
    · have h := after_3_2
      change 1 ≤ 1+Marked.gameValue original marks_3 .staller {2} ∧ 1+Marked.gameValue original marks_3 .dominator {2} ≤ 2
      omega
    · have h := after_3_3
      change 1 ≤ 1+Marked.gameValue original marks_3 .staller {3} ∧ 1+Marked.gameValue original marks_3 .dominator {3} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_3 ∅ 4) hv)
end IsolationGame.FullCanonical.T14
