import CoreFamilyAdjacency
import CanonicalValueNormalization

namespace IsolationGame.CoreFamilySemantics
open CanonicalLocal CoreFamily Isolation.Graph
variable (xs : List Nat) (p : Nat)

abbrev LocalWhite := ∀i : Fin (xs.length+p), Fin (size (label xs p i))→Prop

def white (W : LocalWhite xs p) : Vertex xs p→Prop
  | none => False
  | some ⟨i,v⟩ => W i v

def Normalized (W : LocalWhite xs p) : Prop :=
  ∀i,(GuardedEdge.view (CanonicalLocal.graph (label xs p i))).noniso (W i)=W i

noncomputable def marks (W : LocalWhite xs p) : Finset (Vertex xs p) :=
  ForestFoundation.canonicalMarks (white xs p W)

theorem noniso_root (W : LocalWhite xs p) :
    ¬(GuardedEdge.view (CoreFamily.graph xs p)).noniso (white xs p W) none :=
  fun h=>h.1

theorem noniso_local (W : LocalWhite xs p) (i : Fin (xs.length+p)) (u : Fin (size (label xs p i))) :
    (GuardedEdge.view (CoreFamily.graph xs p)).noniso (white xs p W) (some ⟨i,u⟩) ↔
      (GuardedEdge.view (CanonicalLocal.graph (label xs p i))).noniso (W i) u := by
  constructor
  · rintro ⟨hu,w,hw,ha⟩
    cases w with
    | none => exact False.elim hw
    | some w =>
      obtain ⟨j,v⟩ := w
      by_cases hij : i=j
      · subst j
        exact ⟨hu,v,hw,(same_adj xs p i u v).mp ha⟩
      · exact False.elim (distinct_no_adj xs p i j hij u v ha)
  · rintro ⟨hu,v,hv,ha⟩
    exact ⟨hu,some ⟨i,v⟩,hv,(same_adj xs p i u v).mpr ha⟩

theorem normalized_white (W : LocalWhite xs p) (hn : Normalized xs p W) :
    (GuardedEdge.view (CoreFamily.graph xs p)).noniso (white xs p W)=white xs p W := by
  funext v
  apply propext
  cases v with
  | none => exact iff_of_false (noniso_root xs p W) id
  | some v =>
    obtain ⟨i,u⟩ := v
    rw [noniso_local,hn i]
    rfl

theorem root_marked (W : LocalWhite xs p) : none∈marks xs p W := by
  simp [marks,ForestFoundation.canonicalMarks,white]

/-- Canonical compact whites denote an actual original marked graph. The
central vertex is genuinely marked, not merely normalized away. -/
theorem original_white (W : LocalWhite xs p) (hn : Normalized xs p W) (v : Vertex xs p) :
    Marked.White (CoreFamily.graph xs p) (marks xs p W) ∅ v ↔ white xs p W v :=
  ForestFoundation.canonical_white (CoreFamily.graph xs p) _ (normalized_white xs p W hn) v

#print axioms noniso_local
#print axioms original_white
end IsolationGame.CoreFamilySemantics
