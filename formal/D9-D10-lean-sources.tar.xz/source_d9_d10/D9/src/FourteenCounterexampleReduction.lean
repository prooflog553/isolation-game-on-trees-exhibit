import FourteenReceiverExclusion
import WeakActualCounterKernel

/-!
SOURCE_ONLY. This is a conditional reduction, not a solution of the fourteen
families. In particular no finite p/q test is substituted for ∀ p q : Nat.
The classifier provider is root-accepted. The weak actual-game import remains
gated pending independent acceptance and explicit native-slot authorization.
-/
namespace IsolationGame.FourteenCounterexample
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
open CanonicalLocal NecessaryCore FourteenResidual
open WeakOneCenterArithmetic

/-- The same literal original graph as the accepted two-core opening model. -/
def LiteralCounter (xs ys : List Nat) (p q : Nat) : Prop :=
  (3*Fintype.card (TwoCoreOpening.Vertex xs ys p q)+6)/7 <
    isolationNumber (TwoCoreOpening.graph xs ys p q)

def PatternCounter (k : Pattern) (p q : Nat) : Prop :=
  (3*Fintype.card (PatternVertex k p q)+6)/7 < isolationNumber (patternGraph k p q)

/-- An actual counter forces failure of both actual weak one-center bounds.
The scalar failure equivalence supplies the two signed classifier premises. -/
theorem literal_counter_signed_failures (xs ys : List Nat) (p q : Nat)
    (hCounter : LiteralCounter xs ys p q) :
    (-1 ≤ signedScore xs ys) ∧ (-1 ≤ signedScore ys xs) := by
  constructor
  · apply (scalar_ceil_failure_iff xs ys p q).mp
    intro hBudget
    exact (Nat.not_lt_of_ge
      ((WeakOneCenterGame.ordinary_weak_one_center_upper xs ys p q).trans hBudget)) hCounter
  · apply (scalar_ceil_failure_iff ys xs q p).mp
    intro hBudget
    rw [carrier_order_exchange xs ys p q] at hBudget
    exact (Nat.not_lt_of_ge
      ((WeakOneCenterGame.ordinary_weak_one_center_right_upper xs ys p q).trans hBudget)) hCounter

/-- Every classifier premise is derived on this same original strict counter.
The all-P4 branches are excluded using the complete rooted receiver bridge. -/
theorem literal_counter_matches_fourteen (xs ys : List Nat) (p q : Nat)
    (hxs : ∀ n ∈ xs, decode n ≠ .t02)
    (hys : ∀ n ∈ ys, decode n ≠ .t02)
    (hLength : xs.length+ys.length ≤ 3)
    (hCounter : LiteralCounter xs ys p q) :
    MatchesFourteen (xs.map decode) (ys.map decode) := by
  have hScores := literal_counter_signed_failures xs ys p q hCounter
  have hNonpure := strict_counter_not_allP4 xs ys p q hCounter
  exact classify_raw xs ys hxs hys hLength hScores.1 hScores.2 hNonpure.1 hNonpure.2

/-- Full literal isomorphism certificate for an explicitly displayed row.
If the classifier exchanges sides, p' is exactly q and q' is exactly p.
The same e supplies both value and order equalities; no card-only transport. -/
theorem literal_counter_yields_pattern_certificate (xs ys : List Nat) (p q : Nat)
    (hxs : ∀ n ∈ xs, decode n ≠ .t02)
    (hys : ∀ n ∈ ys, decode n ≠ .t02)
    (hLength : xs.length+ys.length ≤ 3)
    (hCounter : LiteralCounter xs ys p q) :
    ∃ (k : Pattern) (p' q' : Nat),
      ((p'=p ∧ q'=q) ∨ (p'=q ∧ q'=p)) ∧
      ∃ e : TwoCoreOpening.graph xs ys p q ≃g patternGraph k p' q',
        PatternCounter k p' q' ∧
        Fintype.card (TwoCoreOpening.Vertex xs ys p q) =
          Fintype.card (PatternVertex k p' q') ∧
        isolationNumber (TwoCoreOpening.graph xs ys p q) =
          isolationNumber (patternGraph k p' q') := by
  obtain ⟨k,p',q',hPools,⟨e⟩⟩ := exists_patternIso xs ys p q
    (literal_counter_matches_fourteen xs ys p q hxs hys hLength hCounter)
  exact ⟨k,p',q',hPools,e,strict_counter_transport _ _ e hCounter,
    Fintype.card_congr e.toEquiv,OriginalIsoTransport.isolationNumber_eq _ _ e⟩

/-- Any supplied actual finite diameter-nine ordinary strict counterexample
produces an explicit fourteen-family literal strict counter of no greater order.
This makes no assertion that an actual counterexample exists. -/
theorem actual_counter_yields_fourteen
    {V : Type} [Fintype V] [DecidableEq V]
    (G : SimpleGraph V) (hT : G.IsTree) (hDiam : G.diam ≤ 9)
    (hCounter : MinimalCeil9.ceil3n7 (Fintype.card V) < isolationNumber G) :
    ∃ (k : Pattern) (p q : Nat), PatternCounter k p q ∧
      Fintype.card (PatternVertex k p q) ≤ Fintype.card V := by
  obtain ⟨xs,ys,p,q,hxs,hys,hLength,hLiteral,_,hLe⟩ :=
    MinimalCeil9.exists_normalized_three_core_counterexample_le G hT hDiam hCounter
  change LiteralCounter xs ys p q at hLiteral
  obtain ⟨k,p',q',_,e,hPattern,hCard,_⟩ :=
    literal_counter_yields_pattern_certificate xs ys p q hxs hys hLength hLiteral
  refine ⟨k,p',q',hPattern,?_⟩
  rw [←hCard]
  exact hLe

/-- The precise remaining all-parameter task: fourteen literal families,
with both ordinary multiplicities independently unbounded. -/
def FourteenCeilingObligations : Prop :=
  ∀ (k : Pattern) (p q : Nat), isolationNumber (patternGraph k p q) ≤
    (3*Fintype.card (PatternVertex k p q)+6)/7

/-- Conditional closure only. Its premise is not proved by this module. -/
theorem diameter_nine_ceiling_of_fourteen (hFamilies : FourteenCeilingObligations)
    {V : Type} [Fintype V] [DecidableEq V]
    (G : SimpleGraph V) (hT : G.IsTree) (hDiam : G.diam ≤ 9) :
    isolationNumber G ≤ MinimalCeil9.ceil3n7 (Fintype.card V) := by
  by_contra h
  have hCounter : MinimalCeil9.ceil3n7 (Fintype.card V) < isolationNumber G :=
    Nat.lt_of_not_ge h
  obtain ⟨k,p,q,hPattern,_⟩ := actual_counter_yields_fourteen G hT hDiam hCounter
  exact (Nat.not_lt_of_ge (hFamilies k p q)) hPattern

#print axioms LiteralCounter
#print axioms PatternCounter
#print axioms literal_counter_signed_failures
#print axioms literal_counter_matches_fourteen
#print axioms literal_counter_yields_pattern_certificate
#print axioms actual_counter_yields_fourteen
#print axioms FourteenCeilingObligations
#print axioms diameter_nine_ceiling_of_fourteen
end IsolationGame.FourteenCounterexample
