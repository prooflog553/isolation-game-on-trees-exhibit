import CoreOrdinaryIndexNormalization

/-! SOURCE-ONLY candidate. Literal list permutations act on complete cores.
No raw code, original vertex or selectable move is discarded.
-/
namespace IsolationGame.CoreFamily

private def swapOptionalHeads {A : Type} : Option (Option A) ≃ Option (Option A) where
  toFun
    | none => some none
    | some none => none
    | some (some a) => some (some a)
  invFun
    | none => some none
    | some none => none
    | some (some a) => some (some a)
  left_inv := by intro a; rcases a with _ | (_ | a) <;> rfl
  right_inv := by intro a; rcases a with _ | (_ | a) <;> rfl

private def twoHeadEquiv (n m : Nat) (xs : List Nat) (q : Nat) :
    Option (Option (Fin (xs.length+q))) ≃ Fin ((n::m::xs).length+q) :=
  (Equiv.optionCongr (headTailEquiv m xs q)).trans (headTailEquiv n (m::xs) q)

/-- Interchange two raw list heads by an explicit exact label bijection. -/
def swapHeadReindex (n m : Nat) (xs : List Nat) (q : Nat) :
    LabelReindex (n::m::xs) q (m::n::xs) q where
  indexEquiv := (twoHeadEquiv n m xs q).symm.trans
    (swapOptionalHeads.trans (twoHeadEquiv m n xs q))
  label_eq := by
    intro i
    obtain ⟨a,rfl⟩ := (twoHeadEquiv n m xs q).surjective i
    simp only [Equiv.trans_apply,Equiv.symm_apply_apply]
    cases a with
    | none =>
      change label (n::m::xs) q (headIndex n (m::xs) q) =
        label (m::n::xs) q (tailIndex m (n::xs) q (headIndex n xs q))
      rw [label_headIndex,label_tailIndex,label_headIndex]
    | some a =>
      cases a with
      | none =>
        change label (n::m::xs) q (tailIndex n (m::xs) q (headIndex m xs q)) =
          label (m::n::xs) q (headIndex m (n::xs) q)
        rw [label_tailIndex,label_headIndex,label_headIndex]
      | some a =>
        change label (n::m::xs) q (tailIndex n (m::xs) q (tailIndex m xs q a)) =
          label (m::n::xs) q (tailIndex m (n::xs) q (tailIndex n xs q a))
        rw [label_tailIndex,label_tailIndex,label_tailIndex,label_tailIndex]

/-- Every ordinary list permutation yields full original-carrier reindexing. -/
theorem exists_permLabelReindex {xs ys : List Nat} (h : xs.Perm ys) (q : Nat) :
    Nonempty (LabelReindex xs q ys q) := by
  induction h with
  | nil => exact ⟨LabelReindex.refl [] q⟩
  | cons n h ih => obtain ⟨e⟩ := ih; exact ⟨e.cons n⟩
  | swap n m xs => exact ⟨swapHeadReindex m n xs q⟩
  | trans h₁ h₂ ih₁ ih₂ =>
    obtain ⟨e⟩ := ih₁
    obtain ⟨f⟩ := ih₂
    exact ⟨e.trans f⟩

noncomputable def permLabelReindex {xs ys : List Nat} (h : xs.Perm ys) (q : Nat) :
    LabelReindex xs q ys q := Classical.choice (exists_permLabelReindex h q)

noncomputable def permutationIso {xs ys : List Nat} (h : xs.Perm ys) (q : Nat) :
    graph xs q ≃g graph ys q := (permLabelReindex h q).graphIso

@[simp] theorem permutationIso_root {xs ys : List Nat} (h : xs.Perm ys) (q : Nat) :
    permutationIso h q none = none := rfl

#print axioms exists_permLabelReindex
#print axioms permutationIso
end IsolationGame.CoreFamily
