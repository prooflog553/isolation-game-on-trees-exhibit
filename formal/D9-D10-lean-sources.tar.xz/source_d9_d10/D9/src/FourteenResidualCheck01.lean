import FourteenResidualData

/-! Finite kernel arithmetic only: first profile fixed to t01.
All arithmetic is checked by kernel reduction; no graph or history search. -/
namespace IsolationGame.FourteenResidual
open CanonicalLocal
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

theorem check11_t01 (b : Index) :
    NumericResidual [.t01] [b] → MatchesFourteen [.t01] [b] := by
  cases b <;> decide +kernel

theorem check12_t01 (b c : Index) :
    NumericResidual [.t01] [b, c] → MatchesFourteen [.t01] [b, c] := by
  cases b <;> cases c <;> decide +kernel

#print axioms check11_t01
#print axioms check12_t01
end IsolationGame.FourteenResidual
