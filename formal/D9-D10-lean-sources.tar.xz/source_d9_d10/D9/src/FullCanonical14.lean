import FullCanonical14Rows01
namespace IsolationGame.FullCanonical.T14
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
theorem full_values : Marked.gameValue original ∅ .dominator ∅=1 ∧ Marked.gameValue original ∅ .staller ∅=2 := by
  constructor
  · exact (Marked.value_eq_of_white_eq original ∅ marks_5 ∅ ∅ .dominator (by decide +kernel)).trans row_5.1
  · exact (Marked.value_eq_of_white_eq original ∅ marks_5 ∅ ∅ .staller (by decide +kernel)).trans row_5.2
theorem not_strict_full : ¬MarkedSum.StrictCapacity original ∅ ∅ 2 := by
  intro h
  have hf := h.2 3 (by decide +kernel)
  change Marked.gameValue original marks_5 .staller {3}+1≤2 at hf
  rw [after_5_3.2] at hf
  omega
#print axioms full_values
#print axioms not_strict_full
end IsolationGame.FullCanonical.T14
