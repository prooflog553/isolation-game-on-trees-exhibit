import FullCanonical12Rows03
namespace IsolationGame.FullCanonical.T12
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_16 : Finset (Fin 9) := {2,3}
theorem after_16_0 : Marked.gameValue original marks_16 .dominator {0}=1 ∧ Marked.gameValue original marks_16 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_2 0 1 1 (by decide +kernel) row_2
theorem after_16_1 : Marked.gameValue original marks_16 .dominator {1}=2 ∧ Marked.gameValue original marks_16 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_12 1 2 2 (by decide +kernel) row_12
theorem after_16_2 : Marked.gameValue original marks_16 .dominator {2}=2 ∧ Marked.gameValue original marks_16 .staller {2}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_14 2 2 3 (by decide +kernel) row_14
theorem after_16_4 : Marked.gameValue original marks_16 .dominator {4}=1 ∧ Marked.gameValue original marks_16 .staller {4}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_3 4 1 1 (by decide +kernel) row_3
theorem after_16_5 : Marked.gameValue original marks_16 .dominator {5}=1 ∧ Marked.gameValue original marks_16 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_16 marks_9 5 1 2 (by decide +kernel) row_9
theorem after_16_6 : Marked.gameValue original marks_16 .dominator {6}=1 ∧ Marked.gameValue original marks_16 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_11 6 1 2 (by decide +kernel) row_11
theorem after_16_7 : Marked.gameValue original marks_16 .dominator {7}=1 ∧ Marked.gameValue original marks_16 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_5 7 1 2 (by decide +kernel) row_5
theorem after_16_8 : Marked.gameValue original marks_16 .dominator {8}=1 ∧ Marked.gameValue original marks_16 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_10 8 1 2 (by decide +kernel) row_10
theorem row_16 : Marked.gameValue original marks_16 .dominator ∅=2 ∧ Marked.gameValue original marks_16 .staller ∅=3 := by
  apply LocalProfile.DAG.bellman original marks_16 2 3 0 1 (by decide +kernel) (by decide +kernel)
  · rw [after_16_0.2]
  · rw [after_16_1.1]
  · intro v hv
    fin_cases v
    · have h := after_16_0
      change 2 ≤ 1+Marked.gameValue original marks_16 .staller {0} ∧ 1+Marked.gameValue original marks_16 .dominator {0} ≤ 3
      omega
    · have h := after_16_1
      change 2 ≤ 1+Marked.gameValue original marks_16 .staller {1} ∧ 1+Marked.gameValue original marks_16 .dominator {1} ≤ 3
      omega
    · have h := after_16_2
      change 2 ≤ 1+Marked.gameValue original marks_16 .staller {2} ∧ 1+Marked.gameValue original marks_16 .dominator {2} ≤ 3
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_16 ∅ 3) hv)
    · have h := after_16_4
      change 2 ≤ 1+Marked.gameValue original marks_16 .staller {4} ∧ 1+Marked.gameValue original marks_16 .dominator {4} ≤ 3
      omega
    · have h := after_16_5
      change 2 ≤ 1+Marked.gameValue original marks_16 .staller {5} ∧ 1+Marked.gameValue original marks_16 .dominator {5} ≤ 3
      omega
    · have h := after_16_6
      change 2 ≤ 1+Marked.gameValue original marks_16 .staller {6} ∧ 1+Marked.gameValue original marks_16 .dominator {6} ≤ 3
      omega
    · have h := after_16_7
      change 2 ≤ 1+Marked.gameValue original marks_16 .staller {7} ∧ 1+Marked.gameValue original marks_16 .dominator {7} ≤ 3
      omega
    · have h := after_16_8
      change 2 ≤ 1+Marked.gameValue original marks_16 .staller {8} ∧ 1+Marked.gameValue original marks_16 .dominator {8} ≤ 3
      omega
def marks_17 : Finset (Fin 9) := {}
theorem after_17_0 : Marked.gameValue original marks_17 .dominator {0}=2 ∧ Marked.gameValue original marks_17 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_7 0 2 2 (by decide +kernel) row_7
theorem after_17_1 : Marked.gameValue original marks_17 .dominator {1}=2 ∧ Marked.gameValue original marks_17 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_12 1 2 2 (by decide +kernel) row_12
theorem after_17_2 : Marked.gameValue original marks_17 .dominator {2}=2 ∧ Marked.gameValue original marks_17 .staller {2}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_14 2 2 3 (by decide +kernel) row_14
theorem after_17_3 : Marked.gameValue original marks_17 .dominator {3}=2 ∧ Marked.gameValue original marks_17 .staller {3}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_16 3 2 3 (by decide +kernel) row_16
theorem after_17_4 : Marked.gameValue original marks_17 .dominator {4}=2 ∧ Marked.gameValue original marks_17 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_17 marks_12 4 2 2 (by decide +kernel) row_12
theorem after_17_5 : Marked.gameValue original marks_17 .dominator {5}=2 ∧ Marked.gameValue original marks_17 .staller {5}=3 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_17 marks_14 5 2 3 (by decide +kernel) row_14
theorem after_17_6 : Marked.gameValue original marks_17 .dominator {6}=2 ∧ Marked.gameValue original marks_17 .staller {6}=3 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_17 marks_16 6 2 3 (by decide +kernel) row_16
theorem after_17_7 : Marked.gameValue original marks_17 .dominator {7}=3 ∧ Marked.gameValue original marks_17 .staller {7}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_13 7 3 3 (by decide +kernel) row_13
theorem after_17_8 : Marked.gameValue original marks_17 .dominator {8}=3 ∧ Marked.gameValue original marks_17 .staller {8}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_15 8 3 4 (by decide +kernel) row_15
theorem row_17 : Marked.gameValue original marks_17 .dominator ∅=3 ∧ Marked.gameValue original marks_17 .staller ∅=4 := by
  apply LocalProfile.DAG.bellman original marks_17 3 4 0 7 (by decide +kernel) (by decide +kernel)
  · rw [after_17_0.2]
  · rw [after_17_7.1]
  · intro v hv
    fin_cases v
    · have h := after_17_0
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {0} ∧ 1+Marked.gameValue original marks_17 .dominator {0} ≤ 4
      omega
    · have h := after_17_1
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {1} ∧ 1+Marked.gameValue original marks_17 .dominator {1} ≤ 4
      omega
    · have h := after_17_2
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {2} ∧ 1+Marked.gameValue original marks_17 .dominator {2} ≤ 4
      omega
    · have h := after_17_3
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {3} ∧ 1+Marked.gameValue original marks_17 .dominator {3} ≤ 4
      omega
    · have h := after_17_4
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {4} ∧ 1+Marked.gameValue original marks_17 .dominator {4} ≤ 4
      omega
    · have h := after_17_5
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {5} ∧ 1+Marked.gameValue original marks_17 .dominator {5} ≤ 4
      omega
    · have h := after_17_6
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {6} ∧ 1+Marked.gameValue original marks_17 .dominator {6} ≤ 4
      omega
    · have h := after_17_7
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {7} ∧ 1+Marked.gameValue original marks_17 .dominator {7} ≤ 4
      omega
    · have h := after_17_8
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {8} ∧ 1+Marked.gameValue original marks_17 .dominator {8} ≤ 4
      omega
end IsolationGame.FullCanonical.T12
