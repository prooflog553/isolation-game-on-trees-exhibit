import ZeroReceiverCeiling
import PureProfileReceiverTransport
import CompletePositiveReceiver

namespace IsolationGame.FullReceiverCeiling
open CanonicalLocal AllProfileCore PairableProfileCore ReceiverBudgetExceptions
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

abbrev Vertex (xs : List Nat) (q k p : Nat) := UniversalReceiverThresholds.Vertex xs q k p
abbrev graph (xs : List Nat) (q k p : Nat) := UniversalReceiverThresholds.graph xs q k p

/-- All zero-receiver cases on the literal original graph. The sole
zero-pair small-slack class is transported by a complete carrier isomorphism. -/
theorem ordinary_k0_ceil (xs : List Nat) (q p : Nat) :
    isolationNumber (graph xs q 0 p) ≤ (3*Fintype.card (Vertex xs q 0 p)+6)/7 := by
  by_cases hp : pairCount xs=0
  · by_cases hs : slackSum xs≤1
    · have hxs := ZeroReceiverCeiling.no_pair_small_slack_all02 xs hp hs
      have h := PureProfileReceiverTransport.ordinary_ceil xs q p hxs
      convert h using 1 <;> congr 1 <;> apply Subsingleton.elim
    · exact ZeroReceiverCeiling.ordinary_ceil_of_slack xs q p hp (by omega)
  · exact ZeroReceiverCeiling.ordinary_ceil_of_positive_pair xs q p (by omega)

/-- Every natural receiver parameter, every finite raw-code list, and every
ordinary multiplicity. This is an explicit-family theorem only. -/
theorem ordinary_ceil (xs : List Nat) (q k p : Nat) :
    isolationNumber (graph xs q k p) ≤ (3*Fintype.card (Vertex xs q k p)+6)/7 := by
  cases k with
  | zero => exact ordinary_k0_ceil xs q p
  | succ k => exact CompletePositiveReceiver.ordinary_ceil_of_positive_k xs q (k+1) p (by omega)

/-- Geometry, exact full carrier order and the ordinary empty-start bound
refer to one and the same explicitly defined receiver graph. -/
theorem family_tree_diameter_order_ceil (xs : List Nat) (q k p : Nat) :
    (graph xs q k p).IsTree ∧ (graph xs q k p).diam≤9 ∧
    Fintype.card (Vertex xs q k p)=coreOrder xs+1+4*k+7*(p+q) ∧
    isolationNumber (graph xs q k p)≤(3*Fintype.card (Vertex xs q k p)+6)/7 :=
  ⟨UniversalReceiverThresholds.graph_tree xs q k p,
    UniversalReceiverThresholds.diam_le_nine xs q k p,
    UniversalReceiverThresholds.order xs q k p,ordinary_ceil xs q k p⟩

#print axioms ordinary_k0_ceil
#print axioms ordinary_ceil
#print axioms family_tree_diameter_order_ceil
end IsolationGame.FullReceiverCeiling
