import FullCanonical05Rows04
namespace IsolationGame.FullCanonical.T05
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_20 : Finset (Fin 16) := {0,1,2,3,4,5,6}
theorem after_20_0 : Marked.gameValue original marks_20 .dominator {0}=3 ∧ Marked.gameValue original marks_20 .staller {0}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_20 marks_11 0 3 3 (by decide +kernel) row_11
theorem after_20_7 : Marked.gameValue original marks_20 .dominator {7}=3 ∧ Marked.gameValue original marks_20 .staller {7}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_20 marks_13 7 3 3 (by decide +kernel) row_13
theorem after_20_8 : Marked.gameValue original marks_20 .dominator {8}=3 ∧ Marked.gameValue original marks_20 .staller {8}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_20 marks_13 8 3 3 (by decide +kernel) row_13
theorem after_20_9 : Marked.gameValue original marks_20 .dominator {9}=3 ∧ Marked.gameValue original marks_20 .staller {9}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_20 marks_13 9 3 3 (by decide +kernel) row_13
theorem after_20_10 : Marked.gameValue original marks_20 .dominator {10}=3 ∧ Marked.gameValue original marks_20 .staller {10}=3 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_20 marks_13 10 3 3 (by decide +kernel) row_13
theorem after_20_11 : Marked.gameValue original marks_20 .dominator {11}=3 ∧ Marked.gameValue original marks_20 .staller {11}=3 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_20 marks_13 11 3 3 (by decide +kernel) row_13
theorem after_20_12 : Marked.gameValue original marks_20 .dominator {12}=3 ∧ Marked.gameValue original marks_20 .staller {12}=3 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_20 marks_13 12 3 3 (by decide +kernel) row_13
theorem after_20_13 : Marked.gameValue original marks_20 .dominator {13}=3 ∧ Marked.gameValue original marks_20 .staller {13}=3 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_20 marks_13 13 3 3 (by decide +kernel) row_13
theorem after_20_14 : Marked.gameValue original marks_20 .dominator {14}=3 ∧ Marked.gameValue original marks_20 .staller {14}=3 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_20 marks_13 14 3 3 (by decide +kernel) row_13
theorem after_20_15 : Marked.gameValue original marks_20 .dominator {15}=3 ∧ Marked.gameValue original marks_20 .staller {15}=3 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_20 marks_13 15 3 3 (by decide +kernel) row_13
theorem row_20 : Marked.gameValue original marks_20 .dominator ∅=4 ∧ Marked.gameValue original marks_20 .staller ∅=4 := by
  apply LocalProfile.DAG.bellman original marks_20 4 4 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_20_0.2]
  · rw [after_20_0.1]
  · intro v hv
    fin_cases v
    · have h := after_20_0
      change 4 ≤ 1+Marked.gameValue original marks_20 .staller {0} ∧ 1+Marked.gameValue original marks_20 .dominator {0} ≤ 4
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_20 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_20 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_20 ∅ 3) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_20 ∅ 4) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_20 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_20 ∅ 6) hv)
    · have h := after_20_7
      change 4 ≤ 1+Marked.gameValue original marks_20 .staller {7} ∧ 1+Marked.gameValue original marks_20 .dominator {7} ≤ 4
      omega
    · have h := after_20_8
      change 4 ≤ 1+Marked.gameValue original marks_20 .staller {8} ∧ 1+Marked.gameValue original marks_20 .dominator {8} ≤ 4
      omega
    · have h := after_20_9
      change 4 ≤ 1+Marked.gameValue original marks_20 .staller {9} ∧ 1+Marked.gameValue original marks_20 .dominator {9} ≤ 4
      omega
    · have h := after_20_10
      change 4 ≤ 1+Marked.gameValue original marks_20 .staller {10} ∧ 1+Marked.gameValue original marks_20 .dominator {10} ≤ 4
      omega
    · have h := after_20_11
      change 4 ≤ 1+Marked.gameValue original marks_20 .staller {11} ∧ 1+Marked.gameValue original marks_20 .dominator {11} ≤ 4
      omega
    · have h := after_20_12
      change 4 ≤ 1+Marked.gameValue original marks_20 .staller {12} ∧ 1+Marked.gameValue original marks_20 .dominator {12} ≤ 4
      omega
    · have h := after_20_13
      change 4 ≤ 1+Marked.gameValue original marks_20 .staller {13} ∧ 1+Marked.gameValue original marks_20 .dominator {13} ≤ 4
      omega
    · have h := after_20_14
      change 4 ≤ 1+Marked.gameValue original marks_20 .staller {14} ∧ 1+Marked.gameValue original marks_20 .dominator {14} ≤ 4
      omega
    · have h := after_20_15
      change 4 ≤ 1+Marked.gameValue original marks_20 .staller {15} ∧ 1+Marked.gameValue original marks_20 .dominator {15} ≤ 4
      omega
def marks_21 : Finset (Fin 16) := {0,1,4,7,10,13}
theorem after_21_1 : Marked.gameValue original marks_21 .dominator {1}=4 ∧ Marked.gameValue original marks_21 .staller {1}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_21 marks_16 1 4 4 (by decide +kernel) row_16
theorem after_21_2 : Marked.gameValue original marks_21 .dominator {2}=4 ∧ Marked.gameValue original marks_21 .staller {2}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_21 marks_16 2 4 4 (by decide +kernel) row_16
theorem after_21_3 : Marked.gameValue original marks_21 .dominator {3}=4 ∧ Marked.gameValue original marks_21 .staller {3}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_21 marks_16 3 4 4 (by decide +kernel) row_16
theorem after_21_4 : Marked.gameValue original marks_21 .dominator {4}=4 ∧ Marked.gameValue original marks_21 .staller {4}=4 :=
  FullCanonicalDAG.transport_perm original perm_7 adjacency_7 marks_21 marks_16 4 4 4 (by decide +kernel) row_16
theorem after_21_5 : Marked.gameValue original marks_21 .dominator {5}=4 ∧ Marked.gameValue original marks_21 .staller {5}=4 :=
  FullCanonicalDAG.transport_perm original perm_7 adjacency_7 marks_21 marks_16 5 4 4 (by decide +kernel) row_16
theorem after_21_6 : Marked.gameValue original marks_21 .dominator {6}=4 ∧ Marked.gameValue original marks_21 .staller {6}=4 :=
  FullCanonicalDAG.transport_perm original perm_7 adjacency_7 marks_21 marks_16 6 4 4 (by decide +kernel) row_16
theorem after_21_7 : Marked.gameValue original marks_21 .dominator {7}=4 ∧ Marked.gameValue original marks_21 .staller {7}=4 :=
  FullCanonicalDAG.transport_perm original perm_8 adjacency_8 marks_21 marks_16 7 4 4 (by decide +kernel) row_16
theorem after_21_8 : Marked.gameValue original marks_21 .dominator {8}=4 ∧ Marked.gameValue original marks_21 .staller {8}=4 :=
  FullCanonicalDAG.transport_perm original perm_8 adjacency_8 marks_21 marks_16 8 4 4 (by decide +kernel) row_16
theorem after_21_9 : Marked.gameValue original marks_21 .dominator {9}=4 ∧ Marked.gameValue original marks_21 .staller {9}=4 :=
  FullCanonicalDAG.transport_perm original perm_8 adjacency_8 marks_21 marks_16 9 4 4 (by decide +kernel) row_16
theorem after_21_10 : Marked.gameValue original marks_21 .dominator {10}=4 ∧ Marked.gameValue original marks_21 .staller {10}=4 :=
  FullCanonicalDAG.transport_perm original perm_9 adjacency_9 marks_21 marks_16 10 4 4 (by decide +kernel) row_16
theorem after_21_11 : Marked.gameValue original marks_21 .dominator {11}=4 ∧ Marked.gameValue original marks_21 .staller {11}=4 :=
  FullCanonicalDAG.transport_perm original perm_9 adjacency_9 marks_21 marks_16 11 4 4 (by decide +kernel) row_16
theorem after_21_12 : Marked.gameValue original marks_21 .dominator {12}=4 ∧ Marked.gameValue original marks_21 .staller {12}=4 :=
  FullCanonicalDAG.transport_perm original perm_9 adjacency_9 marks_21 marks_16 12 4 4 (by decide +kernel) row_16
theorem after_21_13 : Marked.gameValue original marks_21 .dominator {13}=4 ∧ Marked.gameValue original marks_21 .staller {13}=4 :=
  FullCanonicalDAG.transport_perm original perm_10 adjacency_10 marks_21 marks_16 13 4 4 (by decide +kernel) row_16
theorem after_21_14 : Marked.gameValue original marks_21 .dominator {14}=4 ∧ Marked.gameValue original marks_21 .staller {14}=4 :=
  FullCanonicalDAG.transport_perm original perm_10 adjacency_10 marks_21 marks_16 14 4 4 (by decide +kernel) row_16
theorem after_21_15 : Marked.gameValue original marks_21 .dominator {15}=4 ∧ Marked.gameValue original marks_21 .staller {15}=4 :=
  FullCanonicalDAG.transport_perm original perm_10 adjacency_10 marks_21 marks_16 15 4 4 (by decide +kernel) row_16
theorem row_21 : Marked.gameValue original marks_21 .dominator ∅=5 ∧ Marked.gameValue original marks_21 .staller ∅=5 := by
  apply LocalProfile.DAG.bellman original marks_21 5 5 1 1 (by decide +kernel) (by decide +kernel)
  · rw [after_21_1.2]
  · rw [after_21_1.1]
  · intro v hv
    fin_cases v
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_21 ∅ 0) hv)
    · have h := after_21_1
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {1} ∧ 1+Marked.gameValue original marks_21 .dominator {1} ≤ 5
      omega
    · have h := after_21_2
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {2} ∧ 1+Marked.gameValue original marks_21 .dominator {2} ≤ 5
      omega
    · have h := after_21_3
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {3} ∧ 1+Marked.gameValue original marks_21 .dominator {3} ≤ 5
      omega
    · have h := after_21_4
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {4} ∧ 1+Marked.gameValue original marks_21 .dominator {4} ≤ 5
      omega
    · have h := after_21_5
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {5} ∧ 1+Marked.gameValue original marks_21 .dominator {5} ≤ 5
      omega
    · have h := after_21_6
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {6} ∧ 1+Marked.gameValue original marks_21 .dominator {6} ≤ 5
      omega
    · have h := after_21_7
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {7} ∧ 1+Marked.gameValue original marks_21 .dominator {7} ≤ 5
      omega
    · have h := after_21_8
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {8} ∧ 1+Marked.gameValue original marks_21 .dominator {8} ≤ 5
      omega
    · have h := after_21_9
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {9} ∧ 1+Marked.gameValue original marks_21 .dominator {9} ≤ 5
      omega
    · have h := after_21_10
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {10} ∧ 1+Marked.gameValue original marks_21 .dominator {10} ≤ 5
      omega
    · have h := after_21_11
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {11} ∧ 1+Marked.gameValue original marks_21 .dominator {11} ≤ 5
      omega
    · have h := after_21_12
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {12} ∧ 1+Marked.gameValue original marks_21 .dominator {12} ≤ 5
      omega
    · have h := after_21_13
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {13} ∧ 1+Marked.gameValue original marks_21 .dominator {13} ≤ 5
      omega
    · have h := after_21_14
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {14} ∧ 1+Marked.gameValue original marks_21 .dominator {14} ≤ 5
      omega
    · have h := after_21_15
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {15} ∧ 1+Marked.gameValue original marks_21 .dominator {15} ≤ 5
      omega
def marks_22 : Finset (Fin 16) := {2,3,5,6,8,9}
theorem after_22_0 : Marked.gameValue original marks_22 .dominator {0}=2 ∧ Marked.gameValue original marks_22 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_22 marks_6 0 2 2 (by decide +kernel) row_6
theorem after_22_1 : Marked.gameValue original marks_22 .dominator {1}=3 ∧ Marked.gameValue original marks_22 .staller {1}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_22 marks_13 1 3 3 (by decide +kernel) row_13
theorem after_22_2 : Marked.gameValue original marks_22 .dominator {2}=3 ∧ Marked.gameValue original marks_22 .staller {2}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_22 marks_19 2 3 4 (by decide +kernel) row_19
theorem after_22_4 : Marked.gameValue original marks_22 .dominator {4}=3 ∧ Marked.gameValue original marks_22 .staller {4}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_22 marks_13 4 3 3 (by decide +kernel) row_13
theorem after_22_5 : Marked.gameValue original marks_22 .dominator {5}=3 ∧ Marked.gameValue original marks_22 .staller {5}=4 :=
  FullCanonicalDAG.transport_perm original perm_7 adjacency_7 marks_22 marks_19 5 3 4 (by decide +kernel) row_19
theorem after_22_7 : Marked.gameValue original marks_22 .dominator {7}=3 ∧ Marked.gameValue original marks_22 .staller {7}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_22 marks_13 7 3 3 (by decide +kernel) row_13
theorem after_22_8 : Marked.gameValue original marks_22 .dominator {8}=3 ∧ Marked.gameValue original marks_22 .staller {8}=4 :=
  FullCanonicalDAG.transport_perm original perm_8 adjacency_8 marks_22 marks_19 8 3 4 (by decide +kernel) row_19
theorem after_22_10 : Marked.gameValue original marks_22 .dominator {10}=1 ∧ Marked.gameValue original marks_22 .staller {10}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_22 marks_4 10 1 2 (by decide +kernel) row_4
theorem after_22_11 : Marked.gameValue original marks_22 .dominator {11}=1 ∧ Marked.gameValue original marks_22 .staller {11}=2 :=
  FullCanonicalDAG.transport_perm original perm_9 adjacency_9 marks_22 marks_14 11 1 2 (by decide +kernel) row_14
theorem after_22_12 : Marked.gameValue original marks_22 .dominator {12}=1 ∧ Marked.gameValue original marks_22 .staller {12}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_22 marks_17 12 1 2 (by decide +kernel) row_17
theorem after_22_13 : Marked.gameValue original marks_22 .dominator {13}=1 ∧ Marked.gameValue original marks_22 .staller {13}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_22 marks_4 13 1 2 (by decide +kernel) row_4
theorem after_22_14 : Marked.gameValue original marks_22 .dominator {14}=1 ∧ Marked.gameValue original marks_22 .staller {14}=2 :=
  FullCanonicalDAG.transport_perm original perm_10 adjacency_10 marks_22 marks_14 14 1 2 (by decide +kernel) row_14
theorem after_22_15 : Marked.gameValue original marks_22 .dominator {15}=1 ∧ Marked.gameValue original marks_22 .staller {15}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_22 marks_17 15 1 2 (by decide +kernel) row_17
theorem row_22 : Marked.gameValue original marks_22 .dominator ∅=3 ∧ Marked.gameValue original marks_22 .staller ∅=4 := by
  apply LocalProfile.DAG.bellman original marks_22 3 4 0 1 (by decide +kernel) (by decide +kernel)
  · rw [after_22_0.2]
  · rw [after_22_1.1]
  · intro v hv
    fin_cases v
    · have h := after_22_0
      change 3 ≤ 1+Marked.gameValue original marks_22 .staller {0} ∧ 1+Marked.gameValue original marks_22 .dominator {0} ≤ 4
      omega
    · have h := after_22_1
      change 3 ≤ 1+Marked.gameValue original marks_22 .staller {1} ∧ 1+Marked.gameValue original marks_22 .dominator {1} ≤ 4
      omega
    · have h := after_22_2
      change 3 ≤ 1+Marked.gameValue original marks_22 .staller {2} ∧ 1+Marked.gameValue original marks_22 .dominator {2} ≤ 4
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_22 ∅ 3) hv)
    · have h := after_22_4
      change 3 ≤ 1+Marked.gameValue original marks_22 .staller {4} ∧ 1+Marked.gameValue original marks_22 .dominator {4} ≤ 4
      omega
    · have h := after_22_5
      change 3 ≤ 1+Marked.gameValue original marks_22 .staller {5} ∧ 1+Marked.gameValue original marks_22 .dominator {5} ≤ 4
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_22 ∅ 6) hv)
    · have h := after_22_7
      change 3 ≤ 1+Marked.gameValue original marks_22 .staller {7} ∧ 1+Marked.gameValue original marks_22 .dominator {7} ≤ 4
      omega
    · have h := after_22_8
      change 3 ≤ 1+Marked.gameValue original marks_22 .staller {8} ∧ 1+Marked.gameValue original marks_22 .dominator {8} ≤ 4
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_22 ∅ 9) hv)
    · have h := after_22_10
      change 3 ≤ 1+Marked.gameValue original marks_22 .staller {10} ∧ 1+Marked.gameValue original marks_22 .dominator {10} ≤ 4
      omega
    · have h := after_22_11
      change 3 ≤ 1+Marked.gameValue original marks_22 .staller {11} ∧ 1+Marked.gameValue original marks_22 .dominator {11} ≤ 4
      omega
    · have h := after_22_12
      change 3 ≤ 1+Marked.gameValue original marks_22 .staller {12} ∧ 1+Marked.gameValue original marks_22 .dominator {12} ≤ 4
      omega
    · have h := after_22_13
      change 3 ≤ 1+Marked.gameValue original marks_22 .staller {13} ∧ 1+Marked.gameValue original marks_22 .dominator {13} ≤ 4
      omega
    · have h := after_22_14
      change 3 ≤ 1+Marked.gameValue original marks_22 .staller {14} ∧ 1+Marked.gameValue original marks_22 .dominator {14} ≤ 4
      omega
    · have h := after_22_15
      change 3 ≤ 1+Marked.gameValue original marks_22 .staller {15} ∧ 1+Marked.gameValue original marks_22 .dominator {15} ≤ 4
      omega
def marks_23 : Finset (Fin 16) := {1,2,3,4,5,6}
theorem after_23_0 : Marked.gameValue original marks_23 .dominator {0}=3 ∧ Marked.gameValue original marks_23 .staller {0}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_23 marks_11 0 3 3 (by decide +kernel) row_11
theorem after_23_1 : Marked.gameValue original marks_23 .dominator {1}=4 ∧ Marked.gameValue original marks_23 .staller {1}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_23 marks_20 1 4 4 (by decide +kernel) row_20
theorem after_23_4 : Marked.gameValue original marks_23 .dominator {4}=4 ∧ Marked.gameValue original marks_23 .staller {4}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_23 marks_20 4 4 4 (by decide +kernel) row_20
theorem after_23_7 : Marked.gameValue original marks_23 .dominator {7}=3 ∧ Marked.gameValue original marks_23 .staller {7}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_23 marks_13 7 3 3 (by decide +kernel) row_13
theorem after_23_8 : Marked.gameValue original marks_23 .dominator {8}=3 ∧ Marked.gameValue original marks_23 .staller {8}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_23 marks_15 8 3 4 (by decide +kernel) row_15
theorem after_23_9 : Marked.gameValue original marks_23 .dominator {9}=3 ∧ Marked.gameValue original marks_23 .staller {9}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_23 marks_18 9 3 4 (by decide +kernel) row_18
theorem after_23_10 : Marked.gameValue original marks_23 .dominator {10}=3 ∧ Marked.gameValue original marks_23 .staller {10}=3 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_23 marks_13 10 3 3 (by decide +kernel) row_13
theorem after_23_11 : Marked.gameValue original marks_23 .dominator {11}=3 ∧ Marked.gameValue original marks_23 .staller {11}=4 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_23 marks_15 11 3 4 (by decide +kernel) row_15
theorem after_23_12 : Marked.gameValue original marks_23 .dominator {12}=3 ∧ Marked.gameValue original marks_23 .staller {12}=4 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_23 marks_18 12 3 4 (by decide +kernel) row_18
theorem after_23_13 : Marked.gameValue original marks_23 .dominator {13}=3 ∧ Marked.gameValue original marks_23 .staller {13}=3 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_23 marks_13 13 3 3 (by decide +kernel) row_13
theorem after_23_14 : Marked.gameValue original marks_23 .dominator {14}=3 ∧ Marked.gameValue original marks_23 .staller {14}=4 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_23 marks_15 14 3 4 (by decide +kernel) row_15
theorem after_23_15 : Marked.gameValue original marks_23 .dominator {15}=3 ∧ Marked.gameValue original marks_23 .staller {15}=4 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_23 marks_18 15 3 4 (by decide +kernel) row_18
theorem row_23 : Marked.gameValue original marks_23 .dominator ∅=4 ∧ Marked.gameValue original marks_23 .staller ∅=5 := by
  apply LocalProfile.DAG.bellman original marks_23 4 5 0 1 (by decide +kernel) (by decide +kernel)
  · rw [after_23_0.2]
  · rw [after_23_1.1]
  · intro v hv
    fin_cases v
    · have h := after_23_0
      change 4 ≤ 1+Marked.gameValue original marks_23 .staller {0} ∧ 1+Marked.gameValue original marks_23 .dominator {0} ≤ 5
      omega
    · have h := after_23_1
      change 4 ≤ 1+Marked.gameValue original marks_23 .staller {1} ∧ 1+Marked.gameValue original marks_23 .dominator {1} ≤ 5
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_23 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_23 ∅ 3) hv)
    · have h := after_23_4
      change 4 ≤ 1+Marked.gameValue original marks_23 .staller {4} ∧ 1+Marked.gameValue original marks_23 .dominator {4} ≤ 5
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_23 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_23 ∅ 6) hv)
    · have h := after_23_7
      change 4 ≤ 1+Marked.gameValue original marks_23 .staller {7} ∧ 1+Marked.gameValue original marks_23 .dominator {7} ≤ 5
      omega
    · have h := after_23_8
      change 4 ≤ 1+Marked.gameValue original marks_23 .staller {8} ∧ 1+Marked.gameValue original marks_23 .dominator {8} ≤ 5
      omega
    · have h := after_23_9
      change 4 ≤ 1+Marked.gameValue original marks_23 .staller {9} ∧ 1+Marked.gameValue original marks_23 .dominator {9} ≤ 5
      omega
    · have h := after_23_10
      change 4 ≤ 1+Marked.gameValue original marks_23 .staller {10} ∧ 1+Marked.gameValue original marks_23 .dominator {10} ≤ 5
      omega
    · have h := after_23_11
      change 4 ≤ 1+Marked.gameValue original marks_23 .staller {11} ∧ 1+Marked.gameValue original marks_23 .dominator {11} ≤ 5
      omega
    · have h := after_23_12
      change 4 ≤ 1+Marked.gameValue original marks_23 .staller {12} ∧ 1+Marked.gameValue original marks_23 .dominator {12} ≤ 5
      omega
    · have h := after_23_13
      change 4 ≤ 1+Marked.gameValue original marks_23 .staller {13} ∧ 1+Marked.gameValue original marks_23 .dominator {13} ≤ 5
      omega
    · have h := after_23_14
      change 4 ≤ 1+Marked.gameValue original marks_23 .staller {14} ∧ 1+Marked.gameValue original marks_23 .dominator {14} ≤ 5
      omega
    · have h := after_23_15
      change 4 ≤ 1+Marked.gameValue original marks_23 .staller {15} ∧ 1+Marked.gameValue original marks_23 .dominator {15} ≤ 5
      omega
end IsolationGame.FullCanonical.T05
