import FullTwelveReplyStrict
import OneCenterMixedBudget
import CoreForestReplyBounds
import WeakBudgetConditionalBridge

/-!
The full-profile imports are pending independent acceptance at source creation.
No native result is claimed here. The actual t12 proof is included in this
module sequence and must receive this package's full byte-exact audit.
-/
namespace IsolationGame.FullProfileCore
open CanonicalLocal

/-- Full strict types plus the genuinely reply-strict full t12. -/
def fullWeakPairable : Index → Bool
  | .t01 | .t06 | .t08 | .t12 | .t15 | .t16 | .t18 | .t19 => true
  | _ => false

theorem fullWeakPairable_iff (t : Index) :
    fullWeakPairable t = true ↔ fullPairable t = true ∨ t = .t12 := by
  cases t <;> decide

theorem full_weak_reply (t : Index) (h : fullWeakPairable t = true) :
    MarkedSum.ReplyStrictCapacity (graph t) ∅ ∅ (fullS t) := by
  rcases (fullWeakPairable_iff t).mp h with hs | ht
  · exact MarkedSum.strict_to_reply _ _ _ _ ((full_strict_exact t).mpr hs)
  · subst t
    exact FullCanonical.T12.reply_strict_four

/-- Align the independently established full S values with the accepted
numerical table; the table itself was never a game-capacity premise. -/
theorem fullS_eq_numericFullS (t : Index) :
    fullS t = WeakOneCenterArithmetic.numericFullS t := by
  cases t <;> decide

theorem fullCost_eq_numericFullCost (xs : List Nat) :
    fullCost xs = WeakOneCenterArithmetic.numericFullCost xs :=
  WeakOneCenterArithmetic.align_numericFullCost fullS fullS_eq_numericFullS xs

theorem fullWeakPairable_flag (t : Index) :
    (if fullWeakPairable t = true then 1 else 0) =
      WeakOneCenterArithmetic.fullWeakPairFlag t := by
  cases t <;> decide

/-- The unrestricted ordinary t02 pool has no designated reply-pair flag. -/
theorem ordinary_pool_not_weak_pairable : fullWeakPairable .t02 = false := rfl

/-- t12 is reply-strict, while the established full table excludes Strict4. -/
theorem full_twelve_reply_but_not_strict :
    MarkedSum.ReplyStrictCapacity (graph .t12) ∅ ∅ 4 ∧
      ¬MarkedSum.StrictCapacity (graph .t12) ∅ ∅ 4 :=
  ⟨FullCanonical.T12.reply_strict_four,FullCanonical.T12.not_strict_full⟩

#print axioms fullWeakPairable_iff
#print axioms full_weak_reply
#print axioms fullS_eq_numericFullS
#print axioms fullCost_eq_numericFullCost
#print axioms fullWeakPairable_flag
#print axioms ordinary_pool_not_weak_pairable
#print axioms full_twelve_reply_but_not_strict
end IsolationGame.FullProfileCore
