import GeneralP4PureTransport
import TwoPoolStrongInduction

/-! Candidate all-k receiver upper bounds, prepared without native elaboration.
The dependency order is acyclic:
  pure_D / pure_root_follower_S -> independent root_played_S ->
  fixed-paid assuming the previous k's D -> one-pool p induction -> D_all.
The k=0 case is used only for D and centre-played S. Its initial S need not be 3p.
All paid first actions are quantified, even when a first action is weakly illegal.
The initially marked centre remains selectable throughout.
No equality, optimality, catalogue recovery, or novelty claim is asserted. -/
namespace IsolationGame.GeneralP4Receiver
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

/-- Independent of every initial S/D bound at positive k. -/
theorem root_played_S (k p : Nat) :
    Marked.gameValue (graph k p)
      (SelectedVertex.playedMarks (graph k p) (marks k p) (centre k p)) .staller ∅ ≤
      3*p+2*k := by
  induction k with
  | zero =>
    rw [←root_absorb]
    simpa using pure_root_follower_S p
  | succ k ih =>
    rw [←root_absorb,value_split]
    change Marked.gameValue (P4Receiver.A (graph k p) (centre k p))
      (P4Receiver.AM (marks k p)) .staller {Sum.inl (centre k p)} ≤ 3*p+2*(k+1)
    have h := P4Receiver.center_S (graph k p) (centre k p) (marks k p)
      (graph_acyclic k p) (3*p+2*k) ih
    omega

theorem root_follower_S (k p : Nat) :
    Marked.gameValue (graph k p) (marks k p) .staller {centre k p} ≤ 3*p+2*k := by
  rw [root_absorb]
  exact root_played_S k p

theorem centre_paid (k p : Nat) :
    1+Marked.gameValue (graph (k+1) p) (marks (k+1) p) .dominator
      {centre (k+1) p} ≤ 3*p+2*(k+1) := by
  rw [value_split]
  change 1+Marked.gameValue (P4Receiver.A (graph k p) (centre k p))
    (P4Receiver.AM (marks k p)) .dominator {Sum.inl (centre k p)} ≤ 3*p+2*(k+1)
  have h := P4Receiver.center_paid (graph k p) (centre k p) (marks k p)
    (graph_acyclic k p) (3*p+2*k) (root_played_S k p)
  omega

/-- Only the previous k's D bound is needed for the newly isolated P4. -/
theorem zero_branch_paid_of_D (k p : Nat)
    (hd : Marked.gameValue (graph k p) (marks k p) .dominator ∅ ≤ 3*p+2*k)
    (r : Fin 4) :
    1+Marked.gameValue (graph (k+1) p) (marks (k+1) p) .dominator
      {branch (k+1) p 0 r} ≤ 3*p+2*(k+1) := by
  rw [value_split]
  change 1+Marked.gameValue (P4Receiver.A (graph k p) (centre k p))
    (P4Receiver.AM (marks k p)) .dominator {Sum.inr r} ≤ 3*p+2*(k+1)
  have h := P4Receiver.right_paid (graph k p) (centre k p) (marks k p)
    (graph_acyclic k p) (root_marked k p) (3*p+2*k) hd (root_played_S k p) r
  omega

/-- A real graph automorphism sends the selected branch to index zero. -/
theorem branch_paid_of_D (k p : Nat)
    (hd : Marked.gameValue (graph k p) (marks k p) .dominator ∅ ≤ 3*p+2*k)
    (i : Fin (k+1)) (r : Fin 4) :
    1+Marked.gameValue (graph (k+1) p) (marks (k+1) p) .dominator
      {branch (k+1) p i r} ≤ 3*p+2*(k+1) := by
  rw [value_permute (k+1) p (Equiv.swap i 0)]
  simpa only [Finset.image_singleton,permute_branch,Equiv.swap_apply_left] using
    zero_branch_paid_of_D k p hd r

theorem fixed_paid_of_D (k p : Nat)
    (hd : Marked.gameValue (graph k p) (marks k p) .dominator ∅ ≤ 3*p+2*k)
    (v : Fixed (k+1)) :
    1+Marked.gameValue (graph (k+1) p) (marks (k+1) p) .dominator
      {fixed (k+1) p v} ≤ 3*p+2*(k+1) := by
  cases v with
  | none => exact centre_paid k p
  | some v =>
    rcases v with ⟨i,r⟩
    exact branch_paid_of_D k p hd i r

section OnePoolAssembly
variable {F : Type} [Fintype F] [DecidableEq F]

/-- One-pool assembly with a genuinely positive fixed budget. All p>=0 are
covered; the second pool is literally Fin0 and never receives an extra IH. -/
theorem onePool_bounds_of_fixed (H : SimpleGraph F) (hH : H.IsAcyclic)
    (z : F) (M : Finset F) (b : Nat)
    (hfixed : ∀ p : Nat, ∀ v : F,
      1+Marked.gameValue (TwoPool.graph H z z p 0) (TwoPool.marks M p 0) .dominator
        {TwoPool.fixed p 0 v} ≤ 3*p+(b+1)) (p : Nat) :
    Marked.gameValue (TwoPool.graph H z z p 0) (TwoPool.marks M p 0) .staller ∅ ≤
      3*p+(b+1) ∧
    ∀v : TwoPool.Vertex F p 0,
      1+Marked.gameValue (TwoPool.graph H z z p 0) (TwoPool.marks M p 0) .dominator
        {v} ≤ 3*p+(b+1) := by
  induction p using Nat.strong_induction_on with
  | h p hin =>
    have hf (v : TwoPool.Vertex F p 0) :
        1+Marked.gameValue (TwoPool.graph H z z p 0) (TwoPool.marks M p 0) .dominator
          {v} ≤ 3*p+(b+1) := by
      rcases TwoPool.vertex_exhaustion p 0 v with
        ⟨a,rfl⟩ | ⟨i,r,rfl⟩ | ⟨i,r,rfl⟩
      · exact hfixed p a
      · cases p with
        | zero => exact Fin.elim0 i
        | succ p =>
          have hc := TwoPool.ordinaryLeft_first_bound H hH z z M p 0 i r
          have hs := (hin p (by omega)).1
          omega
      · exact Fin.elim0 i
    refine ⟨?_,hf⟩
    apply (Marked.gameValue_le_iff _ _ _ _ _).mpr
    apply Or.inr
    intro v _
    apply (Marked.gameValue_le_iff _ _ .dominator (insert v ∅) (3*p+b)).mp
    have hh := hf v
    simpa only [Finset.insert_empty] using (by omega :
      Marked.gameValue (TwoPool.graph H z z p 0) (TwoPool.marks M p 0) .dominator
        {v} ≤ 3*p+b)
end OnePoolAssembly

/-- The sole outer induction. At k=0 its assertion is pure D, not pure S. -/
theorem D_all (k : Nat) : ∀p : Nat,
    Marked.gameValue (graph k p) (marks k p) .dominator ∅ ≤ 3*p+2*k := by
  induction k with
  | zero =>
    intro p
    simpa using (pure_D p).le
  | succ k ih =>
    intro p
    have hfixed : ∀q : Nat, ∀v : Fixed (k+1),
        1+Marked.gameValue (graph (k+1) q) (marks (k+1) q) .dominator
          {fixed (k+1) q v} ≤ 3*q+((2*k+1)+1) := by
      intro q v
      have h := fixed_paid_of_D k q (ih q) v
      omega
    have hs := (onePool_bounds_of_fixed (fixedGraph (k+1)) (fixed_acyclic (k+1))
      (root (k+1)) ({root (k+1)} : Finset (Fixed (k+1))) (2*k+1) hfixed p).1
    have hn := Marked.forest_no_minus (graph (k+1) p) (graph_acyclic (k+1) p)
      (marks (k+1) p) ∅
    change Marked.gameValue (graph (k+1) p) (marks (k+1) p) .staller ∅ ≤
      3*p+((2*k+1)+1) at hs
    omega

private theorem successor_bounds (k p : Nat) :
    Marked.gameValue (graph (k+1) p) (marks (k+1) p) .staller ∅ ≤ 3*p+2*(k+1) ∧
    ∀v : Vertex (k+1) p,
      1+Marked.gameValue (graph (k+1) p) (marks (k+1) p) .dominator {v} ≤
        3*p+2*(k+1) := by
  have hfixed : ∀q : Nat, ∀v : Fixed (k+1),
      1+Marked.gameValue (graph (k+1) q) (marks (k+1) q) .dominator
        {fixed (k+1) q v} ≤ 3*q+((2*k+1)+1) := by
    intro q v
    have h := fixed_paid_of_D k q (D_all k q) v
    omega
  have h := onePool_bounds_of_fixed (fixedGraph (k+1)) (fixed_acyclic (k+1))
    (root (k+1)) ({root (k+1)} : Finset (Fixed (k+1))) (2*k+1) hfixed p
  change Marked.gameValue (graph (k+1) p) (marks (k+1) p) .staller ∅ ≤
      3*p+((2*k+1)+1) ∧
    ∀v : Vertex (k+1) p,
      1+Marked.gameValue (graph (k+1) p) (marks (k+1) p) .dominator {v} ≤
        3*p+((2*k+1)+1) at h
  constructor
  · have hs := h.1
    omega
  · intro v
    have hv := h.2 v
    omega

/-- Initial S upper bound for every positive number of P4 receiver branches. -/
theorem S_upper (k p : Nat) (hk : 1≤k) :
    Marked.gameValue (graph k p) (marks k p) .staller ∅ ≤ 3*p+2*k := by
  cases k with
  | zero => omega
  | succ k => exact (successor_bounds k p).1

/-- D also has the pure zero-branch base. -/
theorem D_upper (k p : Nat) :
    Marked.gameValue (graph k p) (marks k p) .dominator ∅ ≤ 3*p+2*k := D_all k p

/-- Every original prescribed first action, including the marked centre. -/
theorem all_first_bound (k p : Nat) (hk : 1≤k) (v : Vertex k p) :
    1+Marked.gameValue (graph k p) (marks k p) .dominator {v} ≤ 3*p+2*k := by
  cases k with
  | zero => omega
  | succ k => exact (successor_bounds k p).2 v

#print axioms root_played_S
#print axioms centre_paid
#print axioms branch_paid_of_D
#print axioms fixed_paid_of_D
#print axioms onePool_bounds_of_fixed
#print axioms D_all
#print axioms S_upper
#print axioms D_upper
#print axioms all_first_bound
end IsolationGame.GeneralP4Receiver
