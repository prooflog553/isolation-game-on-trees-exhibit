import G2CopyCoordinates

namespace IsolationGame.G2Family
open BWCoordinates
set_option maxHeartbeats 3000000

def localInsert {n : Nat} (i : Fin (n+1)) : Sum (Local n) (Fin 7) ≃ Local (n+1) where
  toFun
    | .inl none => none
    | .inl (some (j,a)) => some (i.succAbove j,a)
    | .inr a => some (i,a)
  invFun
    | none => .inl none
    | some (j,a) => match finSuccEquiv' i j with
      | none => .inr a
      | some t => .inl (some (t,a))
  left_inv := by
    intro u
    rcases u with (_|⟨j,a⟩)|a
    · rfl
    · simp
    · simp
  right_inv := by
    intro u
    rcases u with _|⟨j,a⟩
    · rfl
    · cases he : finSuccEquiv' i j with
      | none =>
        have hj : j=i := by simpa using congrArg (finSuccEquiv' i).symm he
        simp [he,hj]
      | some t =>
        have hj : j=i.succAbove t := by simpa using congrArg (finSuccEquiv' i).symm he
        simp [he,hj]

def shuffleRight (A B C : Type) : Sum (Sum A B) C ≃ Sum (Sum A C) B where
  toFun
    | .inl (.inl a) => .inl (.inl a)
    | .inl (.inr b) => .inr b
    | .inr c => .inl (.inr c)
  invFun
    | .inl (.inl a) => .inl (.inl a)
    | .inl (.inr c) => .inr c
    | .inr b => .inl (.inr b)
  left_inv := by intro u; rcases u with (a|b)|c <;> rfl
  right_inv := by intro u; rcases u with (a|c)|b <;> rfl

def insertXEquiv (p q k : Nat) (i : Fin (p+1)) :
    Sum (CVertex p q k) (Fin 7) ≃ CVertex (p+1) q k :=
  (shuffleRight _ _ _).trans
    (Equiv.sumCongr
      ((Equiv.sumAssoc _ _ _).trans (Equiv.sumCongr (Equiv.refl _) (localInsert i)))
      (Equiv.refl _))

def insertYEquiv (p q k : Nat) (i : Fin (q+1)) :
    Sum (CVertex p q k) (Fin 7) ≃ CVertex p (q+1) k :=
  (shuffleRight _ _ _).trans
    (Equiv.sumCongr
      ((shuffleRight _ _ _).trans (Equiv.sumCongr (localInsert i) (Equiv.refl _)))
      (Equiv.refl _))

def cx (p q k : Nat) : CVertex p q k := .inl (.inr none)
def cy (p q k : Nat) : CVertex p q k := .inl (.inl none)

theorem insertX_adj (p q k : Nat) (i : Fin (p+1))
    (u v : Sum (CVertex p q k) (Fin 7)) :
    (cGraph (p+1) q k).Adj (insertXEquiv p q k i u) (insertXEquiv p q k i v) ↔
      (P7Graft.graph (cGraph p q k) (cx p q k)).Adj u v := by
  have hn (j : Fin p) : i.succAbove j ≠ i := Fin.succAbove_ne i j
  have he (j l : Fin p) : i.succAbove j = i.succAbove l ↔ j=l :=
    by constructor <;> intro h
       · simpa using congrArg (finSuccEquiv' i) h
       · rw [h]
  rcases u with ((u|u)|u)|u <;> rcases v with ((v|v)|v)|v
  all_goals try (cases u <;> cases v)
  all_goals simp [insertXEquiv,shuffleRight,localInsert,cGraph,localGraph,
    P7Graft.graph,Attachment.original,cx,hn,Ne.symm (hn _),he]

theorem insertY_adj (p q k : Nat) (i : Fin (q+1))
    (u v : Sum (CVertex p q k) (Fin 7)) :
    (cGraph p (q+1) k).Adj (insertYEquiv p q k i u) (insertYEquiv p q k i v) ↔
      (P7Graft.graph (cGraph p q k) (cy p q k)).Adj u v := by
  have hn (j : Fin q) : i.succAbove j ≠ i := Fin.succAbove_ne i j
  have he (j l : Fin q) : i.succAbove j = i.succAbove l ↔ j=l :=
    by constructor <;> intro h
       · simpa using congrArg (finSuccEquiv' i) h
       · rw [h]
  rcases u with ((u|u)|u)|u <;> rcases v with ((v|v)|v)|v
  all_goals try (cases u <;> cases v)
  all_goals simp [insertYEquiv,shuffleRight,localInsert,cGraph,localGraph,
    P7Graft.graph,Attachment.original,cy,hn,Ne.symm (hn _),he]

theorem insertX_marks (p q k : Nat) (i : Fin (p+1)) :
    (P7Graft.marks (cMarks p q k)).image (insertXEquiv p q k i) = cMarks (p+1) q k := by
  simp [P7Graft.marks,MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight,
    cMarks,insertXEquiv,shuffleRight,localInsert]

theorem insertY_marks (p q k : Nat) (i : Fin (q+1)) :
    (P7Graft.marks (cMarks p q k)).image (insertYEquiv p q k i) = cMarks p (q+1) k := by
  simp [P7Graft.marks,MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight,
    cMarks,insertYEquiv,shuffleRight,localInsert]

theorem insertX_first_bound (p q k : Nat) (i : Fin (p+1)) (a : Fin 7)
    (hA : (cGraph p q k).IsAcyclic) :
    1 + Marked.gameValue (cGraph (p+1) q k) (cMarks (p+1) q k) .dominator
      {.inl (.inr (some (i,a)))} ≤
      3 + Marked.gameValue (cGraph p q k) (cMarks p q k) .staller ∅ := by
  letI : DecidableEq (P7Graft.Vertex (CVertex p q k)) := Sum.instDecidableEq
  have h := P7Graft.first_move_bound (cGraph p q k) hA (cx p q k) (cMarks p q k) a
  have he := Marked.gameValue_relabel
    (P7Graft.graph (cGraph p q k) (cx p q k)) (cGraph (p+1) q k)
    (insertXEquiv p q k i) (insertX_adj p q k i)
    (P7Graft.marks (cMarks p q k)) {.inr a} .dominator
  rw [insertX_marks] at he
  have he' : Marked.gameValue (cGraph (p+1) q k) (cMarks (p+1) q k) .dominator
      {.inl (.inr (some (i,a)))} =
      Marked.gameValue (P7Graft.graph (cGraph p q k) (cx p q k))
        (P7Graft.marks (cMarks p q k)) .dominator {.inr a} := by
    simpa [insertXEquiv,shuffleRight,localInsert] using he
  rw [he']
  exact h

theorem insertY_first_bound (p q k : Nat) (i : Fin (q+1)) (a : Fin 7)
    (hA : (cGraph p q k).IsAcyclic) :
    1 + Marked.gameValue (cGraph p (q+1) k) (cMarks p (q+1) k) .dominator
      {.inl (.inl (some (i,a)))} ≤
      3 + Marked.gameValue (cGraph p q k) (cMarks p q k) .staller ∅ := by
  letI : DecidableEq (P7Graft.Vertex (CVertex p q k)) := Sum.instDecidableEq
  have h := P7Graft.first_move_bound (cGraph p q k) hA (cy p q k) (cMarks p q k) a
  have he := Marked.gameValue_relabel
    (P7Graft.graph (cGraph p q k) (cy p q k)) (cGraph p (q+1) k)
    (insertYEquiv p q k i) (insertY_adj p q k i)
    (P7Graft.marks (cMarks p q k)) {.inr a} .dominator
  rw [insertY_marks] at he
  have he' : Marked.gameValue (cGraph p (q+1) k) (cMarks p (q+1) k) .dominator
      {.inl (.inl (some (i,a)))} =
      Marked.gameValue (P7Graft.graph (cGraph p q k) (cy p q k))
        (P7Graft.marks (cMarks p q k)) .dominator {.inr a} := by
    simpa [insertYEquiv,shuffleRight,localInsert] using he
  rw [he']
  exact h

end IsolationGame.G2Family
