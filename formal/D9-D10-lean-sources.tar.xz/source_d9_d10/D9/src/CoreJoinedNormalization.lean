import CoreAllP4ReceiverTransport
import CoreFamilyPermutation

/-! SOURCE-ONLY candidate. Normalize both original halves through the actual
bridge edge, retaining both root images and all original selectable vertices.
-/
namespace IsolationGame.CoreFamily

noncomputable def joinedOrdinaryNormalizationIso (xs ys : List Nat) (p q : Nat) :
    Attachment.original (graph xs p) (graph ys q) none none ≃g
      Attachment.original
        (graph (nonordinaryCodes xs) (p+ordinaryCount xs))
        (graph (nonordinaryCodes ys) (q+ordinaryCount ys)) none none :=
  OriginalIsoTransport.attachmentIso _ _ _ _ none none none none
    (ordinaryNormalizationIso xs p) (ordinaryNormalizationIso ys q) rfl rfl

@[simp] theorem joinedOrdinaryNormalizationIso_leftRoot (xs ys : List Nat) (p q : Nat) :
    joinedOrdinaryNormalizationIso xs ys p q (.inl none) = .inl none := rfl

@[simp] theorem joinedOrdinaryNormalizationIso_rightRoot (xs ys : List Nat) (p q : Nat) :
    joinedOrdinaryNormalizationIso xs ys p q (.inr none) = .inr none := rfl

#print axioms joinedOrdinaryNormalizationIso
end IsolationGame.CoreFamily
