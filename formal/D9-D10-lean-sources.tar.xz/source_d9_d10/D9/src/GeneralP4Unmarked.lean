import GeneralP4StrongBounds

/-! Original unmarked P4/P7 star trees, with every original vertex and weak
legal action retained. The singleton k=p=0 tree is handled as terminal; the
centre move is used only when an actual branch makes it legal. -/
namespace IsolationGame.GeneralP4Receiver
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

instance graphDecidable (k p : Nat) : DecidableRel (graph k p).Adj :=
  TwoPool.graphDecidable (fixedGraph k) (root k) (root k) p 0

theorem marks_singleton (k p : Nat) : marks k p = {centre k p} := by
  simp [marks,TwoPool.marks,centre,fixed,TwoPool.fixed]

private theorem centre_reaches_branch (k p : Nat) (i : Fin k) (r : Fin 4) :
    (graph k p).Reachable (centre k p) (branch k p i r) := by
  have hroot : (graph k p).Adj (centre k p) (branch k p i 0) := rfl
  have he (r s : Fin 4) (h : P4Receiver.T.Adj r s) :
      (graph k p).Adj (branch k p i r) (branch k p i s) := ⟨rfl,h⟩
  have h01 := he 0 1 (by decide +kernel)
  have h12 := he 1 2 (by decide +kernel)
  have h23 := he 2 3 (by decide +kernel)
  fin_cases r
  · exact hroot.reachable
  · exact hroot.reachable.trans h01.reachable
  · exact (hroot.reachable.trans h01.reachable).trans h12.reachable
  · exact ((hroot.reachable.trans h01.reachable).trans h12.reachable).trans h23.reachable

private theorem centre_reaches_ordinary (k p : Nat) (i : Fin p) (r : Fin 7) :
    (graph k p).Reachable (centre k p) (ordinary k p i r) := by
  have hroot : (graph k p).Adj (centre k p) (ordinary k p i 0) := ⟨rfl,rfl⟩
  have he (r s : Fin 7) (h : CentreOrdinary.graph.Adj r s) :
      (graph k p).Adj (ordinary k p i r) (ordinary k p i s) := ⟨rfl,h⟩
  have h01 := he 0 1 (by decide +kernel)
  have h12 := he 1 2 (by decide +kernel)
  have h23 := he 2 3 (by decide +kernel)
  have h04 := he 0 4 (by decide +kernel)
  have h45 := he 4 5 (by decide +kernel)
  have h56 := he 5 6 (by decide +kernel)
  fin_cases r
  · exact hroot.reachable
  · exact hroot.reachable.trans h01.reachable
  · exact (hroot.reachable.trans h01.reachable).trans h12.reachable
  · exact ((hroot.reachable.trans h01.reachable).trans h12.reachable).trans h23.reachable
  · exact hroot.reachable.trans h04.reachable
  · exact (hroot.reachable.trans h04.reachable).trans h45.reachable
  · exact ((hroot.reachable.trans h04.reachable).trans h45.reachable).trans h56.reachable

theorem graph_connected (k p : Nat) : (graph k p).Connected := by
  apply (SimpleGraph.connected_iff_exists_forall_reachable (graph k p)).mpr
  refine ⟨centre k p,?_⟩
  intro v
  rcases TwoPool.vertex_exhaustion p 0 v with
    ⟨a,rfl⟩ | ⟨i,r,rfl⟩ | ⟨i,r,rfl⟩
  · cases a with
    | none => exact SimpleGraph.Reachable.refl _
    | some a =>
      rcases a with ⟨i,r⟩
      exact centre_reaches_branch k p i r
  · exact centre_reaches_ordinary k p i r
  · exact Fin.elim0 i

theorem graph_tree (k p : Nat) : (graph k p).IsTree :=
  ⟨graph_connected k p,graph_acyclic k p⟩

private theorem empty_undominated {V : Type} [Fintype V] [DecidableEq V]
    (G : SimpleGraph V) (v : V) : Marked.Undominated G ∅ ∅ v := by
  simp [Marked.Undominated,IsolationGame.Undominated,IsolationGame.Dominated]

/-- No centre-legal assertion is made for the edgeless singleton. -/
theorem unmarked_centre_legal (k p : Nat) (h : 0<k+p) :
    Marked.Legal (graph k p) ∅ ∅ (centre k p) := by
  cases k with
  | succ k =>
    refine ⟨branch (k+1) p 0 0,Or.inr ?_,?_,branch (k+1) p 0 1,?_,?_⟩
    · rfl
    · exact empty_undominated _ _
    · exact ⟨rfl,by decide +kernel⟩
    · exact empty_undominated _ _
  | zero =>
    cases p with
    | zero => omega
    | succ p =>
      refine ⟨ordinary 0 (p+1) 0 0,Or.inr ?_,?_,ordinary 0 (p+1) 0 1,?_,?_⟩
      · exact ⟨rfl,rfl⟩
      · exact empty_undominated _ _
      · exact ⟨rfl,by decide +kernel⟩
      · exact empty_undominated _ _

/-- Adding the selected centre as an initial mark changes no played state. -/
theorem played_empty_eq (k p : Nat) :
    SelectedVertex.playedMarks (graph k p) ∅ (centre k p) =
      SelectedVertex.playedMarks (graph k p) (marks k p) (centre k p) := by
  rw [marks_singleton]
  ext v
  simp only [SelectedVertex.mem_playedMarks,Finset.not_mem_empty,false_or,
    Finset.mem_singleton]
  constructor
  · intro h
    exact Or.inr h
  · rintro (h|h)
    · subst v
      exact Or.inl rfl
    · exact h

theorem unmarked_centre_follower_S (k p : Nat) :
    Marked.gameValue (graph k p) ∅ .staller {centre k p} ≤ 3*p+(3*k+1)/2 := by
  have he : Marked.gameValue (graph k p) ∅ .staller {centre k p} =
      Marked.gameValue (graph k p)
        (SelectedVertex.playedMarks (graph k p) ∅ (centre k p)) .staller ∅ := by
    apply Marked.value_eq_of_white_eq
    intro v
    change Marked.White _ _ (insert (centre k p) ∅) v ↔ _
    rw [SelectedVertex.absorb_white]
  rw [he,played_empty_eq]
  exact root_played_S_strong k p

theorem unmarked_D_opening (k p : Nat) (h : 0<k+p) :
    Marked.gameValue (graph k p) ∅ .dominator ∅ ≤ 3*p+(3*k+1)/2+1 := by
  have hd := Marked.d_move_upper (graph k p) ∅ ∅ (centre k p)
    (unmarked_centre_legal k p h)
  simp only [Finset.insert_empty] at hd
  have hs := unmarked_centre_follower_S k p
  omega

/-- The original unmarked star family satisfies ceil(3n/7), including the
single-vertex terminal case. This is a uniform upper bound, not a sharpness claim. -/
theorem unmarked_D_ceil (k p : Nat) :
    Marked.gameValue (graph k p) ∅ .dominator ∅ ≤ (3*(1+4*k+7*p)+6)/7 := by
  by_cases h : k+p=0
  · have hk : k=0 := by omega
    have hp : p=0 := by omega
    subst k
    subst p
    have ht : Marked.Terminal (graph 0 0) ∅ ∅ := by decide +kernel
    have hv := (Marked.value_zero_iff_terminal (graph 0 0) ∅ ∅ .dominator).mpr ht
    rw [hv]
    omega
  · have hd := unmarked_D_opening k p (by omega)
    have ha : 3*p+(3*k+1)/2+1 ≤ (3*(1+4*k+7*p)+6)/7 := by
      by_cases hk : k≤4
      · interval_cases k <;> omega
      · omega
    exact hd.trans ha

theorem unmarked_D_order_bound (k p : Nat) :
    Marked.gameValue (graph k p) ∅ .dominator ∅ ≤
      (3*Fintype.card (Vertex k p)+6)/7 := by
  rw [order]
  exact unmarked_D_ceil k p

#print axioms graph_tree
#print axioms unmarked_centre_legal
#print axioms played_empty_eq
#print axioms unmarked_centre_follower_S
#print axioms unmarked_D_ceil
#print axioms unmarked_D_order_bound
end IsolationGame.GeneralP4Receiver
