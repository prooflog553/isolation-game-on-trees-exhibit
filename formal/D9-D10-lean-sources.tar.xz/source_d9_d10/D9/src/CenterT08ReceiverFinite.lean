import Profile_08
import Mathlib.Tactic.FinCases

/-! Fresh kernel-checkable finite goals for the centre–T08 fixed rows.
This file is a NEW reconstruction, not a recovered historical source. It has
not yet been compiled; `decide +kernel` is intended to produce proof terms. -/

namespace IsolationGame.CenterT08Receiver.Finite

set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

private abbrev F := LocalProfile.e0E0D1L2.original

def hardMarks : Finset (Fin 11) := {0,1,2,7,10}

/-- The reply-to-11 state needs a strict capacity, not merely an S-bound. -/
theorem hard_strict : MarkedSum.StrictCapacity F hardMarks ∅ 3 := by
  have hD : Marked.WinsWithin F hardMarks 2 .dominator ∅ := by decide +kernel
  have hS : ∀ v : Fin 11, Marked.Legal F hardMarks ∅ v →
      Marked.WinsWithin F hardMarks 2 .staller {v} := by decide +kernel
  constructor
  · have h := (Marked.gameValue_le_iff F hardMarks .dominator ∅ 2).mpr hD
    omega
  · intro v hv
    have h := (Marked.gameValue_le_iff F hardMarks .staller {v} 2).mpr (hS v hv)
    simp only [Finset.insert_empty] at h ⊢
    omega

def marks12 : Finset (Fin 11) := {0,1,2,4,7}
def marks34 : Finset (Fin 11) := {0,1,2,3,4,7}
def marks5  : Finset (Fin 11) := {0,1,4,5,7}
def marks67 : Finset (Fin 11) := {0,1,4,5,6,7}
def marks8  : Finset (Fin 11) := {0,1,4,7,8,10}
def marks910 : Finset (Fin 11) := {0,1,4,7,8,9}

theorem row12_S : Marked.gameValue F marks12 .staller ∅ ≤ 2 := by
  apply (Marked.gameValue_le_iff F marks12 .staller ∅ 2).mpr
  decide +kernel

theorem row34_S : Marked.gameValue F marks34 .staller ∅ ≤ 2 := by
  apply (Marked.gameValue_le_iff F marks34 .staller ∅ 2).mpr
  decide +kernel

theorem row5_S : Marked.gameValue F marks5 .staller ∅ ≤ 2 := by
  apply (Marked.gameValue_le_iff F marks5 .staller ∅ 2).mpr
  decide +kernel

theorem row67_S : Marked.gameValue F marks67 .staller ∅ ≤ 2 := by
  apply (Marked.gameValue_le_iff F marks67 .staller ∅ 2).mpr
  decide +kernel

theorem row8_S : Marked.gameValue F marks8 .staller ∅ ≤ 2 := by
  apply (Marked.gameValue_le_iff F marks8 .staller ∅ 2).mpr
  decide +kernel

theorem row910_S : Marked.gameValue F marks910 .staller ∅ ≤ 2 := by
  apply (Marked.gameValue_le_iff F marks910 .staller ∅ 2).mpr
  decide +kernel

theorem root_D : Marked.gameValue F ({0} : Finset (Fin 11)) .dominator ∅ = 4 :=
  LocalProfile.e0E0D1L2.D_value

theorem root_S : Marked.gameValue F ({0} : Finset (Fin 11)) .staller ∅ = 5 :=
  LocalProfile.e0E0D1L2.S_value

#print axioms hard_strict
#print axioms row12_S
#print axioms row34_S
#print axioms row5_S
#print axioms row67_S
#print axioms row8_S
#print axioms row910_S
#print axioms root_D
#print axioms root_S

end IsolationGame.CenterT08Receiver.Finite
