import FullCanonicalDAG
namespace IsolationGame.FullCanonical.T00
abbrev original : SimpleGraph (Fin 1) := CanonicalLocal.graph CanonicalLocal.Index.t00
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
end IsolationGame.FullCanonical.T00
