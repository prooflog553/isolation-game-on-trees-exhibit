import FourteenResidualData

/-! Finite kernel arithmetic only: first profile fixed to t19.
All arithmetic is checked by kernel reduction; no graph or history search. -/
namespace IsolationGame.FourteenResidual
open CanonicalLocal
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

theorem check11_t19 (b : Index) :
    NumericResidual [.t19] [b] → MatchesFourteen [.t19] [b] := by
  cases b <;> decide +kernel

theorem check12_t19 (b c : Index) :
    NumericResidual [.t19] [b, c] → MatchesFourteen [.t19] [b, c] := by
  cases b <;> cases c <;> decide +kernel

#print axioms check11_t19
#print axioms check12_t19
end IsolationGame.FourteenResidual
