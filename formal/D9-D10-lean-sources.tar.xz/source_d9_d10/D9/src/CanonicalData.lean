import FiniteTreeCertificate
import BranchModels

namespace IsolationGame.CanonicalLocal
open SmallPiece

inductive Index where
  | t00
  | t01
  | t02
  | t03
  | t04
  | t05
  | t06
  | t07
  | t08
  | t09
  | t10
  | t11
  | t12
  | t13
  | t14
  | t15
  | t16
  | t17
  | t18
  | t19
  deriving DecidableEq

instance : Fintype Index := ⟨{.t00,.t01,.t02,.t03,.t04,.t05,.t06,.t07,.t08,.t09,.t10,.t11,.t12,.t13,.t14,.t15,.t16,.t17,.t18,.t19},by intro t;cases t <;> simp⟩

def size : Index→Nat
  | .t00=>1
  | .t01=>4
  | .t02=>7
  | .t03=>10
  | .t04=>13
  | .t05=>16
  | .t06=>5
  | .t07=>8
  | .t08=>11
  | .t09=>9
  | .t10=>3
  | .t11=>6
  | .t12=>9
  | .t13=>2
  | .t14=>5
  | .t15=>8
  | .t16=>11
  | .t17=>6
  | .t18=>9
  | .t19=>4

def edges : Index→List (Nat×Nat)
  | .t00=>[]
  | .t01=>[(0,1),(1,2),(2,3)]
  | .t02=>[(0,1),(1,2),(2,3),(0,4),(4,5),(5,6)]
  | .t03=>[(0,1),(1,2),(2,3),(0,4),(4,5),(5,6),(0,7),(7,8),(8,9)]
  | .t04=>[(0,1),(1,2),(2,3),(0,4),(4,5),(5,6),(0,7),(7,8),(8,9),(0,10),(10,11),(11,12)]
  | .t05=>[(0,1),(1,2),(2,3),(0,4),(4,5),(5,6),(0,7),(7,8),(8,9),(0,10),(10,11),(11,12),(0,13),(13,14),(14,15)]
  | .t06=>[(0,1),(1,2),(2,3),(1,4)]
  | .t07=>[(0,1),(1,2),(2,3),(0,4),(4,5),(5,6),(4,7)]
  | .t08=>[(0,1),(1,2),(2,3),(0,4),(4,5),(5,6),(0,7),(7,8),(8,9),(7,10)]
  | .t09=>[(0,1),(1,2),(2,3),(1,4),(0,5),(5,6),(6,7),(5,8)]
  | .t10=>[(0,1),(1,2)]
  | .t11=>[(0,1),(1,2),(2,3),(0,4),(4,5)]
  | .t12=>[(0,1),(1,2),(2,3),(0,4),(4,5),(5,6),(0,7),(7,8)]
  | .t13=>[(0,1)]
  | .t14=>[(0,1),(1,2),(2,3),(0,4)]
  | .t15=>[(0,1),(1,2),(2,3),(0,4),(4,5),(5,6),(0,7)]
  | .t16=>[(0,1),(1,2),(2,3),(0,4),(4,5),(5,6),(0,7),(7,8),(8,9),(0,10)]
  | .t17=>[(0,1),(1,2),(2,3),(1,4),(0,5)]
  | .t18=>[(0,1),(1,2),(2,3),(0,4),(4,5),(5,6),(4,7),(0,8)]
  | .t19=>[(0,1),(1,2),(0,3)]

def graph (t : Index) : SimpleGraph (Fin (size t)) := LocalProfile.graph (edges t)
instance (t : Index) : DecidableRel (graph t).Adj := inferInstanceAs (DecidableRel (LocalProfile.graph _).Adj)

def root (t : Index) : Fin (size t) := ⟨0,by cases t <;> decide⟩

def parameters : Index→Nat×Nat×Nat×Nat
  | .t00=>(0,0,0,0)
  | .t01=>(0,0,0,1)
  | .t02=>(0,0,0,2)
  | .t03=>(0,0,0,3)
  | .t04=>(0,0,0,4)
  | .t05=>(0,0,0,5)
  | .t06=>(0,0,1,0)
  | .t07=>(0,0,1,1)
  | .t08=>(0,0,1,2)
  | .t09=>(0,0,2,0)
  | .t10=>(0,1,0,0)
  | .t11=>(0,1,0,1)
  | .t12=>(0,1,0,2)
  | .t13=>(1,0,0,0)
  | .t14=>(1,0,0,1)
  | .t15=>(1,0,0,2)
  | .t16=>(1,0,0,3)
  | .t17=>(1,0,1,0)
  | .t18=>(1,0,1,1)
  | .t19=>(1,1,0,0)

structure BlockData where
  kind : Kind
  rootLabel : Nat
  vertices : List Nat

def blocks : Index→List BlockData
  | .t00=>[]
  | .t01=>[⟨.long,1,[1,2,3]⟩]
  | .t02=>[⟨.long,1,[1,2,3]⟩,⟨.long,4,[4,5,6]⟩]
  | .t03=>[⟨.long,1,[1,2,3]⟩,⟨.long,4,[4,5,6]⟩,⟨.long,7,[7,8,9]⟩]
  | .t04=>[⟨.long,1,[1,2,3]⟩,⟨.long,4,[4,5,6]⟩,⟨.long,7,[7,8,9]⟩,⟨.long,10,[10,11,12]⟩]
  | .t05=>[⟨.long,1,[1,2,3]⟩,⟨.long,4,[4,5,6]⟩,⟨.long,7,[7,8,9]⟩,⟨.long,10,[10,11,12]⟩,⟨.long,13,[13,14,15]⟩]
  | .t06=>[⟨.fork,1,[1,2,3,4]⟩]
  | .t07=>[⟨.long,1,[1,2,3]⟩,⟨.fork,4,[4,5,6,7]⟩]
  | .t08=>[⟨.long,1,[1,2,3]⟩,⟨.long,4,[4,5,6]⟩,⟨.fork,7,[7,8,9,10]⟩]
  | .t09=>[⟨.fork,1,[1,2,3,4]⟩,⟨.fork,5,[5,6,7,8]⟩]
  | .t10=>[⟨.edge,1,[1,2]⟩]
  | .t11=>[⟨.long,1,[1,2,3]⟩,⟨.edge,4,[4,5]⟩]
  | .t12=>[⟨.long,1,[1,2,3]⟩,⟨.long,4,[4,5,6]⟩,⟨.edge,7,[7,8]⟩]
  | .t13=>[⟨.leaf,1,[1]⟩]
  | .t14=>[⟨.long,1,[1,2,3]⟩,⟨.leaf,4,[4]⟩]
  | .t15=>[⟨.long,1,[1,2,3]⟩,⟨.long,4,[4,5,6]⟩,⟨.leaf,7,[7]⟩]
  | .t16=>[⟨.long,1,[1,2,3]⟩,⟨.long,4,[4,5,6]⟩,⟨.long,7,[7,8,9]⟩,⟨.leaf,10,[10]⟩]
  | .t17=>[⟨.fork,1,[1,2,3,4]⟩,⟨.leaf,5,[5]⟩]
  | .t18=>[⟨.long,1,[1,2,3]⟩,⟨.fork,4,[4,5,6,7]⟩,⟨.leaf,8,[8]⟩]
  | .t19=>[⟨.edge,1,[1,2]⟩,⟨.leaf,3,[3]⟩]

abbrev Block (t : Index) := Fin ((blocks t).length)
def blockData (t : Index) (j : Block t) : BlockData := (blocks t).get j
def blockKind (t : Index) (j : Block t) : Kind := (blockData t j).kind
def blockVertices (t : Index) (j : Block t) : Finset (Fin (size t)) :=
  Finset.univ.filter (fun v=>v.val∈(blockData t j).vertices)

end IsolationGame.CanonicalLocal
