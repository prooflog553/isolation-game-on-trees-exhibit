import ForestNoMinus
import SumValueBounds

namespace IsolationGame.MarkedSum
variable {V U : Type} [Fintype V] [DecidableEq V] [Fintype U] [DecidableEq U]
  (G : SimpleGraph V) (H : SimpleGraph U)

theorem forest_no_minus (hG : G.IsAcyclic) : NoMinus G :=
  Marked.forest_no_minus G hG

/-- The complete ordinary sandwich on a literal disjoint pair of partially
marked original forests. Histories and initial marks are inherited exactly. -/
theorem forest_sum_bounds (hG : G.IsAcyclic) (hH : H.IsAcyclic)
    (M X : Finset V) (N Y : Finset U) :
    Marked.gameValue G M .dominator X+Marked.gameValue H N .dominator Y ≤
      Marked.gameValue (original G H) (combine M N) .dominator (combine X Y) ∧
    Marked.gameValue (original G H) (combine M N) .dominator (combine X Y) ≤
      Marked.gameValue (original G H) (combine M N) .staller (combine X Y) ∧
    Marked.gameValue (original G H) (combine M N) .staller (combine X Y) ≤
      Marked.gameValue G M .staller X+Marked.gameValue H N .staller Y :=
  ⟨D_lower_value G H (forest_no_minus G hG) (forest_no_minus H hH) M X N Y,
   sum_d_le_s G H (forest_no_minus G hG) (forest_no_minus H hH) M X N Y,
   S_upper_value G H (forest_no_minus G hG) (forest_no_minus H hH) M X N Y⟩

theorem forest_mixed_start_bounds (hG : G.IsAcyclic) (hH : H.IsAcyclic)
    (M X : Finset V) (N Y : Finset U) (hLive : ¬Marked.Terminal G M X) :
    Marked.gameValue (original G H) (combine M N) .dominator (combine X Y) ≤
      Marked.gameValue G M .dominator X+Marked.gameValue H N .staller Y ∧
    Marked.gameValue G M .staller X+Marked.gameValue H N .dominator Y ≤
      Marked.gameValue (original G H) (combine M N) .staller (combine X Y) :=
  ⟨D_upper_left_value G H (forest_no_minus G hG) (forest_no_minus H hH) M X N Y hLive,
   (S_lower_values G H (forest_no_minus G hG) (forest_no_minus H hH) M X N Y).1⟩

/-- Balanced-component removal is proved for arbitrary disjoint forest
contexts; it is not a rule for grafting across an active boundary vertex. -/
theorem forest_balanced_right (hG : G.IsAcyclic) (hH : H.IsAcyclic)
    (M X : Finset V) (N Y : Finset U) (k : Nat)
    (hd : Marked.gameValue H N .dominator Y=k) (hs : Marked.gameValue H N .staller Y=k) :
    Marked.gameValue (original G H) (combine M N) .dominator (combine X Y)=
      Marked.gameValue G M .dominator X+k ∧
    Marked.gameValue (original G H) (combine M N) .staller (combine X Y)=
      Marked.gameValue G M .staller X+k :=
  balanced_right G H (forest_no_minus G hG) (forest_no_minus H hH) M X N Y k hd hs

#print axioms forest_sum_bounds
#print axioms forest_mixed_start_bounds
#print axioms forest_balanced_right
end IsolationGame.MarkedSum
