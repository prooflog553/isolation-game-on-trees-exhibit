import BoundaryFee
import IsolatedRestriction

namespace IsolationGame.MarkedBoundary
variable {V : Type} [Fintype V] [DecidableEq V] (G : SimpleGraph V) (z : V)

def retained : Finset V := Finset.univ.erase z

def deleted : SimpleGraph (IsolatedRestriction.Active (retained z)) :=
  IsolatedRestriction.induced G (retained z)

theorem edges_inside : IsolatedRestriction.EdgesInside (isolateVertex G z) (retained z) := by
  intro v w h
  exact ⟨by simp [retained,h.2.1],by simp [retained,h.2.2]⟩

theorem induced_isolated_eq :
    IsolatedRestriction.induced (isolateVertex G z) (retained z)=deleted G z := by
  ext v w
  have hv : v.val≠z := (Finset.mem_erase.mp v.property).1
  have hw : w.val≠z := (Finset.mem_erase.mp w.property).1
  change (G.Adj v.val w.val ∧ v.val≠z ∧ w.val≠z) ↔ G.Adj v.val w.val
  simp [hv,hw]

theorem isolated_value_eq_deleted (M X : Finset V) (p : Player) :
    Marked.gameValue (isolateVertex G z) M p X =
      Marked.gameValue (deleted G z) (IsolatedRestriction.restrict (retained z) M) p
        (IsolatedRestriction.restrict (retained z) X) := by
  rw [IsolatedRestriction.gameValue_eq (isolateVertex G z) (retained z) (edges_inside G z) M X p,
    induced_isolated_eq]

/-- Paid deletion of one genuinely initially marked original vertex, for
both players and all inherited selected histories. No active blue vertex is
deleted for free. -/
theorem marked_vertex_fee (hA : G.IsAcyclic) (M X : Finset V) (hm : z∈M) :
    Marked.gameValue G M .dominator X ≤
      1+Marked.gameValue (deleted G z) (IsolatedRestriction.restrict (retained z) M) .dominator
        (IsolatedRestriction.restrict (retained z) X) ∧
    Marked.gameValue G M .staller X ≤
      1+Marked.gameValue (deleted G z) (IsolatedRestriction.restrict (retained z) M) .staller
        (IsolatedRestriction.restrict (retained z) X) := by
  rw [←isolated_value_eq_deleted G z M X .dominator,←isolated_value_eq_deleted G z M X .staller]
  exact ⟨D_fee G z hA M X hm,S_fee G z hA M X hm⟩

#print marked_vertex_fee
#print axioms marked_vertex_fee
end IsolationGame.MarkedBoundary
