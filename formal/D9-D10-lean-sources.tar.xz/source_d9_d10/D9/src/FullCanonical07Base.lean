import FullCanonicalDAG
namespace IsolationGame.FullCanonical.T07
abbrev original : SimpleGraph (Fin 8) := CanonicalLocal.graph CanonicalLocal.Index.t07
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
noncomputable def perm_0 : Fin 8 ≃ Fin 8 :=
  Equiv.ofBijective (fun v => ![0,1,2,3,4,5,6,7] v) (by decide +kernel)
theorem adjacency_0 : ∀u v,original.Adj (perm_0 u) (perm_0 v) ↔ original.Adj u v := by decide +kernel
end IsolationGame.FullCanonical.T07
