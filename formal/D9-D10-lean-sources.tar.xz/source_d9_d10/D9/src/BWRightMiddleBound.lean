import BWLocalFollowers
import BWCenterBounds
namespace IsolationGame.BWBridge
open MarkedModule

 theorem opened_middle_counts (q : Nat) (i : Fin q) :
    U (set (whole q) i (.opened true true))+1=q ∧
    H (set (whole q) i (.opened true true))=0 ∧
    E (set (whole q) i (.opened true true))=2 := by
  have hu := U_update_add (whole q) i (.opened true true)
  have hh := H_update_add (whole q) i (.opened true true)
  have he := E_update_add (whole q) i (.opened true true)
  change U (set (whole q) i (.opened true true))+1=U (whole q)+0 at hu
  change H (set (whole q) i (.opened true true))+0=H (whole q)+0 at hh
  change E (set (whole q) i (.opened true true))+0=E (whole q)+(1+1) at he
  have hc := whole_counts q

  omega

 theorem opened_middle_S_bound (q : Nat) (i : Fin q) :
    Marked.gameValue MarkedModule.original (MarkedModule.stateMarks (set (whole q) i (.opened true true)))
      .staller ∅ ≤ 3*q := by
  obtain ⟨hu,hh,he⟩ := opened_middle_counts q i
  rw [no_reserve_S_value _ hh _ _ (MarkedModule.stateMarks_white _)]
  split_ifs <;> omega

 theorem right_middle_D_bound (p q : Nat) (hp : 1≤p) (hq : 1≤q) (i : Fin q) :
    Marked.gameValue (original p q) (marks p q) .dominator {.inr (.gate (some i))}≤3*(p+q) := by
  rw [right_middle_value p q hq i]
  have h := (MarkedSum.forest_mixed_start_bounds
    (MarkedModule.original (B:=Fin p)) (MarkedModule.original (B:=Fin q))
    (module_acyclic p) (module_acyclic q)
    MarkedModule.initialMarks ∅ (MarkedModule.stateMarks (set (whole q) i (.opened true true))) ∅
    (pure_live p hp)).1
  have he : MarkedSum.combine (∅ : Finset (Side p)) (∅ : Finset (Side q))=∅ := by
    simp [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight]
  rw [he,pure_D] at h
  have hs := opened_middle_S_bound q i
  omega

/-- q=1 leaves exactly two edge units on this entire original side. No
move in a fictitious M_0 is used; the D bound starts in the positive left module. -/
 theorem one_opened_middle_value (t : Player) :
    Marked.gameValue MarkedModule.original
      (MarkedModule.stateMarks (set (whole 1) 0 (.opened true true))) t ∅=2 := by
  obtain ⟨hu,hh,he⟩ := opened_middle_counts 1 0
  have hz : U (set (whole 1) 0 (.opened true true))=0 := by omega
  rw [no_whole_no_reserve_value _ hz hh _ _ (MarkedModule.stateMarks_white _),he]

#print axioms right_middle_D_bound
#print axioms one_opened_middle_value
end IsolationGame.BWBridge
