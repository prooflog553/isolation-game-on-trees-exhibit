import G2CopyCoordinates

namespace IsolationGame.G2Family
set_option maxHeartbeats 3000000
set_option maxRecDepth 4096

instance localGraphDecidable (n : Nat) : DecidableRel (localGraph n).Adj := by
  intro u v
  cases u <;> cases v <;> dsimp [localGraph] <;> infer_instance

instance cGraphDecidable (p q k : Nat) : DecidableRel (cGraph p q k).Adj := by
  intro u v
  rcases u with (u|u)|u <;> rcases v with (v|v)|v
  all_goals dsimp [cGraph]; infer_instance

/-- A finite reachability certificate permitting the actual distance-four P4 ends. -/
def ReachFour {V : Type} (G : SimpleGraph V) (r : V) : Prop := ∀v,
  v=r ∨ G.Adj r v ∨ (∃a,G.Adj r a ∧ G.Adj a v) ∨
    (∃a b,G.Adj r a ∧ G.Adj a b ∧ G.Adj b v) ∨
    ∃a b c,G.Adj r a ∧ G.Adj a b ∧ G.Adj b c ∧ G.Adj c v

theorem connected_of_reachFour {V : Type} (G : SimpleGraph V) (r : V)
    (h : ReachFour G r) : G.Connected := by
  apply (SimpleGraph.connected_iff_exists_forall_reachable G).mpr
  refine ⟨r,?_⟩
  intro v
  rcases h v with rfl | hv | ⟨a,ha,hv⟩ | ⟨a,b,ha,hab,hbv⟩ | ⟨a,b,c,ha,hab,hbc,hcv⟩
  · exact SimpleGraph.Reachable.refl _
  · exact hv.reachable
  · exact ha.reachable.trans hv.reachable
  · exact (ha.reachable.trans hab.reachable).trans hbv.reachable
  · exact ((ha.reachable.trans hab.reachable).trans hbc.reachable).trans hcv.reachable

theorem cBase_reachFour (k : Nat) : ReachFour (cGraph 0 0 k) (.inl (.inl none)) := by
  intro v
  rcases v with (v|v)|v
  · cases v with
    | none => exact Or.inl rfl
    | some v => exact Fin.elim0 v.1
  · cases v with
    | none => exact Or.inr (Or.inl ⟨rfl,rfl⟩)
    | some v => exact Fin.elim0 v.1
  · obtain ⟨i,t⟩ := v
    fin_cases t
    · exact Or.inr (Or.inl ⟨rfl,rfl⟩)
    · refine Or.inr (Or.inr (Or.inl ⟨.inr (i,0),?_,?_⟩)) <;>
        simp [cGraph,pathGraph] <;> decide +kernel
    · refine Or.inr (Or.inr (Or.inr (Or.inl ⟨.inr (i,0),.inr (i,1),?_,?_,?_⟩))) <;>
        simp [cGraph,pathGraph] <;> decide +kernel
    · refine Or.inr (Or.inr (Or.inr (Or.inr ⟨.inr (i,0),.inr (i,1),.inr (i,2),?_,?_,?_,?_⟩))) <;>
        simp [cGraph,pathGraph] <;> decide +kernel

theorem cBase_tree_0 : (cGraph 0 0 0).IsTree := by
  apply SimpleGraph.isTree_iff_connected_and_card.mpr
  refine ⟨connected_of_reachFour _ (.inl (.inl none)) (cBase_reachFour _),?_⟩
  rw [Nat.card_eq_fintype_card,Nat.card_eq_fintype_card,←SimpleGraph.edgeFinset_card]
  decide +kernel

theorem cBase_tree_1 : (cGraph 0 0 1).IsTree := by
  apply SimpleGraph.isTree_iff_connected_and_card.mpr
  refine ⟨connected_of_reachFour _ (.inl (.inl none)) (cBase_reachFour _),?_⟩
  rw [Nat.card_eq_fintype_card,Nat.card_eq_fintype_card,←SimpleGraph.edgeFinset_card]
  decide +kernel

theorem cBase_tree_2 : (cGraph 0 0 2).IsTree := by
  apply SimpleGraph.isTree_iff_connected_and_card.mpr
  refine ⟨connected_of_reachFour _ (.inl (.inl none)) (cBase_reachFour _),?_⟩
  rw [Nat.card_eq_fintype_card,Nat.card_eq_fintype_card,←SimpleGraph.edgeFinset_card]
  decide +kernel

/-- The three exact fixed graphs used as the ordinary-copy induction bases. -/
theorem cGraph_base_acyclic (k : Nat) (hk : k ≤ 2) : (cGraph 0 0 k).IsAcyclic := by
  interval_cases k
  · exact cBase_tree_0.2
  · exact cBase_tree_1.2
  · exact cBase_tree_2.2

#print axioms cGraph_base_acyclic
end IsolationGame.G2Family
