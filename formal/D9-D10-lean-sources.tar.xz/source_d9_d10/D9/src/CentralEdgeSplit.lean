import CentralEdgeMetric
import Mathlib.Data.Finset.Max
import Mathlib.Combinatorics.SimpleGraph.Diam

namespace IsolationGame.DiameterNineCentralSplit
open PartitionBridge
variable {V : Type} [Fintype V] [DecidableEq V]

/-- Cut at any genuine edge of a diametral path. The radius statements concern
all vertices of each induced half, including branches off that path. -/
theorem diametral_edge_split (G : SimpleGraph V) (hT : G.IsTree)
    (x y : V) (hmax : ∀ u v, G.dist u v ≤ G.dist x y)
    (p : G.Walk x y) (hp : p.IsPath) (i : Nat) (hi : i < p.length) :
    SplitWithin G (DescendantGeometry.retained G x (p.getVert (i + 1)))
      (p.getVert i) (p.getVert (i + 1)) i (p.length - (i + 1)) := by
  let a := p.getVert i
  let b := p.getVert (i + 1)
  have hab : G.Adj a b := p.adj_getVert_succ hi
  have hposA := path_getVert_distances G hT p hp i (by omega)
  have hposB := path_getVert_distances G hT p hp (i + 1) (by omega)
  have hlen := tree_path_length_eq_dist hT p hp
  have hdepth : G.dist x b = G.dist x a + 1 := by
    change G.dist x (p.getVert (i + 1)) = G.dist x (p.getVert i) + 1
    omega
  let A := DescendantGeometry.retained G x b
  obtain ⟨ha, hx, hb, hcut, hTB, _⟩ :=
    DescendantGeometry.descendant_partition_spec G hT x a b hab hdepth
  change a ∈ A at ha
  change x ∈ A at hx
  change b ∉ A at hb
  change OneBridge G A a b at hcut
  have hy : y ∉ A := by
    intro hyA
    have hne : G.dist x y ≠ G.dist x b + G.dist b y := by
      simpa only [A, DescendantGeometry.retained, Finset.mem_filter,
        Finset.mem_univ, true_and] using hyA
    apply hne
    change G.dist x y = G.dist x (p.getVert (i + 1)) +
      G.dist (p.getVert (i + 1)) y
    omega
  have hreverse : OneBridge G (outside A) b a := outside_oneBridge G A a b hcut
  have hbB : b ∈ outside A := by simp [outside, hb]
  have hxB : x ∉ outside A := by simp [outside, hx]
  have hTA := retained_tree G hT A a b ha hcut
  refine ⟨ha, hb, hab, hcut, hTA, hTB, ?_, ?_⟩
  · intro v
    have hthrough := distance_through_left G hT A a b hcut v.val y v.property hy
    have hbound := hmax v.val y
    have hradius : G.dist a v.val ≤ i := by
      rw [G.dist_comm (u := v.val) (v := a)] at hthrough
      change G.dist (p.getVert i) v.val ≤ i
      change G.dist v.val y = G.dist (p.getVert i) v.val +
        G.dist (p.getVert i) y at hthrough
      omega
    exact (retained_distance_le G hT.isConnected A a b hcut a ha v).trans hradius
  · intro v
    have hthrough := distance_through_left G hT (outside A) b a hreverse
      v.val x v.property hxB
    have hbound := hmax v.val x
    have hbx : G.dist b x = i + 1 := by
      rw [G.dist_comm]
      exact hposB.1
    have hradius : G.dist b v.val ≤ p.length - (i + 1) := by
      rw [G.dist_comm (u := v.val) (v := b)] at hthrough
      omega
    exact (retained_distance_le G hT.isConnected (outside A) b a hreverse
      b hbB v).trans hradius

/-- Existential packaging of the exact prescribed diametral-edge cut. -/
theorem split_at_diametral_path (G : SimpleGraph V) (hT : G.IsTree)
    (x y : V) (hmax : ∀ u v, G.dist u v ≤ G.dist x y)
    (p : G.Walk x y) (hp : p.IsPath) (i : Nat) (hi : i < p.length) :
    ∃ (A : Finset V) (a b : V), SplitWithin G A a b i (p.length - (i + 1)) :=
  ⟨DescendantGeometry.retained G x (p.getVert (i + 1)), p.getVert i,
    p.getVert (i + 1), diametral_edge_split G hT x y hmax p hp i hi⟩

/-- A finite nontrivial tree has distinct diametral endpoints. This uses a
finite maximum of actual distances and needs no canonical-family assumption. -/
theorem exists_distinct_diametral_pair (G : SimpleGraph V) (hT : G.IsTree)
    (hN : ∃ x y : V, x ≠ y) :
    ∃ x y : V, 0 < G.dist x y ∧ ∀ u v, G.dist u v ≤ G.dist x y := by
  obtain ⟨x₀, y₀, hne⟩ := hN
  let s : Finset (V × V) := Finset.univ
  have hs : s.Nonempty := ⟨(x₀, y₀), by simp [s]⟩
  obtain ⟨xy, _, hmax⟩ := s.exists_max_image (fun z => G.dist z.1 z.2) hs
  have hb (u v : V) : G.dist u v ≤ G.dist xy.1 xy.2 :=
    hmax (u, v) (by simp [s])
  refine ⟨xy.1, xy.2, ?_, hb⟩
  exact (hT.isConnected.pos_dist_of_ne hne).trans_le (hb x₀ y₀)

/-- Arbitrary finite nontrivial actual trees with pairwise distances at most
nine admit a genuine central edge and radius-four induced halves. -/
theorem exists_central_edge_of_pairwise_dist_le_nine (G : SimpleGraph V)
    (hT : G.IsTree) (hN : ∃ x y : V, x ≠ y)
    (h9 : ∀ u v, G.dist u v ≤ 9) :
    ∃ (A : Finset V) (a b : V), SplitWithin G A a b 4 4 := by
  obtain ⟨x, y, hpos, hmax⟩ := exists_distinct_diametral_pair G hT hN
  obtain ⟨p, hp, hlen⟩ := hT.isConnected.exists_path_of_dist x y
  let i := (p.length - 1) / 2
  have h9len : p.length ≤ 9 := by rw [hlen]; exact h9 x y
  have hi : i < p.length := by dsimp [i]; omega
  have hleft : i ≤ 4 := by dsimp [i]; omega
  have hright : p.length - (i + 1) ≤ 4 := by dsimp [i]; omega
  obtain ⟨A, a, b, ha, hb, hab, hcut, hTA, hTB, hLA, hRB⟩ :=
    split_at_diametral_path G hT x y hmax p hp i hi
  exact ⟨A, a, b, ha, hb, hab, hcut, hTA, hTB,
    fun v => (hLA v).trans hleft, fun v => (hRB v).trans hright⟩

/-- The public diameter formulation. Connectedness is used when comparing
natural-number distances with diameter; disconnected-distance zero is irrelevant. -/
theorem exists_central_edge_of_diam_le_nine (G : SimpleGraph V)
    (hT : G.IsTree) (hN : ∃ x y : V, x ≠ y) (h9 : G.diam ≤ 9) :
    ∃ (A : Finset V) (a b : V), SplitWithin G A a b 4 4 := by
  obtain ⟨x, y, hxy⟩ := hN
  letI : Nonempty V := ⟨x⟩
  apply exists_central_edge_of_pairwise_dist_le_nine G hT ⟨x, y, hxy⟩
  intro u v
  exact (SimpleGraph.dist_le_diam
    (SimpleGraph.connected_iff_ediam_ne_top.mp hT.isConnected) (u := u) (v := v)).trans h9

/-- A singleton is handled by its one actual root. The second disjunct alone
contains an edge; no edge or second vertex is manufactured for a singleton. -/
theorem singleton_or_central_edge (G : SimpleGraph V) (hT : G.IsTree)
    (h9 : G.diam ≤ 9) :
    (∃ r : V, ∀ v : V, v = r) ∨
      ∃ (A : Finset V) (a b : V), SplitWithin G A a b 4 4 := by
  classical
  by_cases hN : ∃ x y : V, x ≠ y
  · exact Or.inr (exists_central_edge_of_diam_le_nine G hT hN h9)
  · left
    obtain ⟨r, _⟩ :=
      (SimpleGraph.connected_iff_exists_forall_reachable G).mp hT.isConnected
    refine ⟨r, ?_⟩
    intro v
    by_contra hv
    exact hN ⟨v, r, hv⟩

#print axioms diametral_edge_split
#print axioms split_at_diametral_path
#print axioms exists_distinct_diametral_pair
#print axioms exists_central_edge_of_pairwise_dist_le_nine
#print axioms exists_central_edge_of_diam_le_nine
#print axioms singleton_or_central_edge

end IsolationGame.DiameterNineCentralSplit
