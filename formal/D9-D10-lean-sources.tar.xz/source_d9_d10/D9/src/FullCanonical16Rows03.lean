import FullCanonical16Rows02
namespace IsolationGame.FullCanonical.T16
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_12 : Finset (Fin 11) := {2,3,5,6}
theorem after_12_0 : Marked.gameValue original marks_12 .dominator {0}=1 ∧ Marked.gameValue original marks_12 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_1 0 1 1 (by decide +kernel) row_1
theorem after_12_1 : Marked.gameValue original marks_12 .dominator {1}=1 ∧ Marked.gameValue original marks_12 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_3 1 1 2 (by decide +kernel) row_3
theorem after_12_2 : Marked.gameValue original marks_12 .dominator {2}=1 ∧ Marked.gameValue original marks_12 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_11 2 1 2 (by decide +kernel) row_11
theorem after_12_4 : Marked.gameValue original marks_12 .dominator {4}=1 ∧ Marked.gameValue original marks_12 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_3 4 1 2 (by decide +kernel) row_3
theorem after_12_5 : Marked.gameValue original marks_12 .dominator {5}=1 ∧ Marked.gameValue original marks_12 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_12 marks_11 5 1 2 (by decide +kernel) row_11
theorem after_12_7 : Marked.gameValue original marks_12 .dominator {7}=0 ∧ Marked.gameValue original marks_12 .staller {7}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_0 7 0 0 (by decide +kernel) row_0
theorem after_12_8 : Marked.gameValue original marks_12 .dominator {8}=1 ∧ Marked.gameValue original marks_12 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_12 marks_6 8 1 2 (by decide +kernel) row_6
theorem after_12_9 : Marked.gameValue original marks_12 .dominator {9}=1 ∧ Marked.gameValue original marks_12 .staller {9}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_7 9 1 2 (by decide +kernel) row_7
theorem after_12_10 : Marked.gameValue original marks_12 .dominator {10}=1 ∧ Marked.gameValue original marks_12 .staller {10}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_3 10 1 2 (by decide +kernel) row_3
theorem row_12 : Marked.gameValue original marks_12 .dominator ∅=1 ∧ Marked.gameValue original marks_12 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_12 1 2 7 0 (by decide +kernel) (by decide +kernel)
  · rw [after_12_7.2]
  · rw [after_12_0.1]
  · intro v hv
    fin_cases v
    · have h := after_12_0
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {0} ∧ 1+Marked.gameValue original marks_12 .dominator {0} ≤ 2
      omega
    · have h := after_12_1
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {1} ∧ 1+Marked.gameValue original marks_12 .dominator {1} ≤ 2
      omega
    · have h := after_12_2
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {2} ∧ 1+Marked.gameValue original marks_12 .dominator {2} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_12 ∅ 3) hv)
    · have h := after_12_4
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {4} ∧ 1+Marked.gameValue original marks_12 .dominator {4} ≤ 2
      omega
    · have h := after_12_5
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {5} ∧ 1+Marked.gameValue original marks_12 .dominator {5} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_12 ∅ 6) hv)
    · have h := after_12_7
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {7} ∧ 1+Marked.gameValue original marks_12 .dominator {7} ≤ 2
      omega
    · have h := after_12_8
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {8} ∧ 1+Marked.gameValue original marks_12 .dominator {8} ≤ 2
      omega
    · have h := after_12_9
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {9} ∧ 1+Marked.gameValue original marks_12 .dominator {9} ≤ 2
      omega
    · have h := after_12_10
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {10} ∧ 1+Marked.gameValue original marks_12 .dominator {10} ≤ 2
      omega
def marks_13 : Finset (Fin 11) := {1,2,3}
theorem after_13_0 : Marked.gameValue original marks_13 .dominator {0}=2 ∧ Marked.gameValue original marks_13 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_5 0 2 2 (by decide +kernel) row_5
theorem after_13_1 : Marked.gameValue original marks_13 .dominator {1}=3 ∧ Marked.gameValue original marks_13 .staller {1}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_10 1 3 3 (by decide +kernel) row_10
theorem after_13_4 : Marked.gameValue original marks_13 .dominator {4}=1 ∧ Marked.gameValue original marks_13 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_3 4 1 2 (by decide +kernel) row_3
theorem after_13_5 : Marked.gameValue original marks_13 .dominator {5}=1 ∧ Marked.gameValue original marks_13 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_8 5 1 2 (by decide +kernel) row_8
theorem after_13_6 : Marked.gameValue original marks_13 .dominator {6}=1 ∧ Marked.gameValue original marks_13 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_11 6 1 2 (by decide +kernel) row_11
theorem after_13_7 : Marked.gameValue original marks_13 .dominator {7}=1 ∧ Marked.gameValue original marks_13 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_13 marks_3 7 1 2 (by decide +kernel) row_3
theorem after_13_8 : Marked.gameValue original marks_13 .dominator {8}=1 ∧ Marked.gameValue original marks_13 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_13 marks_8 8 1 2 (by decide +kernel) row_8
theorem after_13_9 : Marked.gameValue original marks_13 .dominator {9}=1 ∧ Marked.gameValue original marks_13 .staller {9}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_13 marks_11 9 1 2 (by decide +kernel) row_11
theorem after_13_10 : Marked.gameValue original marks_13 .dominator {10}=3 ∧ Marked.gameValue original marks_13 .staller {10}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_10 10 3 3 (by decide +kernel) row_10
theorem row_13 : Marked.gameValue original marks_13 .dominator ∅=3 ∧ Marked.gameValue original marks_13 .staller ∅=4 := by
  apply LocalProfile.DAG.bellman original marks_13 3 4 0 1 (by decide +kernel) (by decide +kernel)
  · rw [after_13_0.2]
  · rw [after_13_1.1]
  · intro v hv
    fin_cases v
    · have h := after_13_0
      change 3 ≤ 1+Marked.gameValue original marks_13 .staller {0} ∧ 1+Marked.gameValue original marks_13 .dominator {0} ≤ 4
      omega
    · have h := after_13_1
      change 3 ≤ 1+Marked.gameValue original marks_13 .staller {1} ∧ 1+Marked.gameValue original marks_13 .dominator {1} ≤ 4
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_13 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_13 ∅ 3) hv)
    · have h := after_13_4
      change 3 ≤ 1+Marked.gameValue original marks_13 .staller {4} ∧ 1+Marked.gameValue original marks_13 .dominator {4} ≤ 4
      omega
    · have h := after_13_5
      change 3 ≤ 1+Marked.gameValue original marks_13 .staller {5} ∧ 1+Marked.gameValue original marks_13 .dominator {5} ≤ 4
      omega
    · have h := after_13_6
      change 3 ≤ 1+Marked.gameValue original marks_13 .staller {6} ∧ 1+Marked.gameValue original marks_13 .dominator {6} ≤ 4
      omega
    · have h := after_13_7
      change 3 ≤ 1+Marked.gameValue original marks_13 .staller {7} ∧ 1+Marked.gameValue original marks_13 .dominator {7} ≤ 4
      omega
    · have h := after_13_8
      change 3 ≤ 1+Marked.gameValue original marks_13 .staller {8} ∧ 1+Marked.gameValue original marks_13 .dominator {8} ≤ 4
      omega
    · have h := after_13_9
      change 3 ≤ 1+Marked.gameValue original marks_13 .staller {9} ∧ 1+Marked.gameValue original marks_13 .dominator {9} ≤ 4
      omega
    · have h := after_13_10
      change 3 ≤ 1+Marked.gameValue original marks_13 .staller {10} ∧ 1+Marked.gameValue original marks_13 .dominator {10} ≤ 4
      omega
def marks_14 : Finset (Fin 11) := {0,10}
theorem after_14_0 : Marked.gameValue original marks_14 .dominator {0}=3 ∧ Marked.gameValue original marks_14 .staller {0}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_9 0 3 3 (by decide +kernel) row_9
theorem after_14_1 : Marked.gameValue original marks_14 .dominator {1}=3 ∧ Marked.gameValue original marks_14 .staller {1}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_10 1 3 3 (by decide +kernel) row_10
theorem after_14_2 : Marked.gameValue original marks_14 .dominator {2}=3 ∧ Marked.gameValue original marks_14 .staller {2}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_10 2 3 3 (by decide +kernel) row_10
theorem after_14_3 : Marked.gameValue original marks_14 .dominator {3}=3 ∧ Marked.gameValue original marks_14 .staller {3}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_10 3 3 3 (by decide +kernel) row_10
theorem after_14_4 : Marked.gameValue original marks_14 .dominator {4}=3 ∧ Marked.gameValue original marks_14 .staller {4}=3 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_14 marks_10 4 3 3 (by decide +kernel) row_10
theorem after_14_5 : Marked.gameValue original marks_14 .dominator {5}=3 ∧ Marked.gameValue original marks_14 .staller {5}=3 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_14 marks_10 5 3 3 (by decide +kernel) row_10
theorem after_14_6 : Marked.gameValue original marks_14 .dominator {6}=3 ∧ Marked.gameValue original marks_14 .staller {6}=3 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_14 marks_10 6 3 3 (by decide +kernel) row_10
theorem after_14_7 : Marked.gameValue original marks_14 .dominator {7}=3 ∧ Marked.gameValue original marks_14 .staller {7}=3 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_14 marks_10 7 3 3 (by decide +kernel) row_10
theorem after_14_8 : Marked.gameValue original marks_14 .dominator {8}=3 ∧ Marked.gameValue original marks_14 .staller {8}=3 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_14 marks_10 8 3 3 (by decide +kernel) row_10
theorem after_14_9 : Marked.gameValue original marks_14 .dominator {9}=3 ∧ Marked.gameValue original marks_14 .staller {9}=3 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_14 marks_10 9 3 3 (by decide +kernel) row_10
theorem row_14 : Marked.gameValue original marks_14 .dominator ∅=4 ∧ Marked.gameValue original marks_14 .staller ∅=4 := by
  apply LocalProfile.DAG.bellman original marks_14 4 4 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_14_0.2]
  · rw [after_14_0.1]
  · intro v hv
    fin_cases v
    · have h := after_14_0
      change 4 ≤ 1+Marked.gameValue original marks_14 .staller {0} ∧ 1+Marked.gameValue original marks_14 .dominator {0} ≤ 4
      omega
    · have h := after_14_1
      change 4 ≤ 1+Marked.gameValue original marks_14 .staller {1} ∧ 1+Marked.gameValue original marks_14 .dominator {1} ≤ 4
      omega
    · have h := after_14_2
      change 4 ≤ 1+Marked.gameValue original marks_14 .staller {2} ∧ 1+Marked.gameValue original marks_14 .dominator {2} ≤ 4
      omega
    · have h := after_14_3
      change 4 ≤ 1+Marked.gameValue original marks_14 .staller {3} ∧ 1+Marked.gameValue original marks_14 .dominator {3} ≤ 4
      omega
    · have h := after_14_4
      change 4 ≤ 1+Marked.gameValue original marks_14 .staller {4} ∧ 1+Marked.gameValue original marks_14 .dominator {4} ≤ 4
      omega
    · have h := after_14_5
      change 4 ≤ 1+Marked.gameValue original marks_14 .staller {5} ∧ 1+Marked.gameValue original marks_14 .dominator {5} ≤ 4
      omega
    · have h := after_14_6
      change 4 ≤ 1+Marked.gameValue original marks_14 .staller {6} ∧ 1+Marked.gameValue original marks_14 .dominator {6} ≤ 4
      omega
    · have h := after_14_7
      change 4 ≤ 1+Marked.gameValue original marks_14 .staller {7} ∧ 1+Marked.gameValue original marks_14 .dominator {7} ≤ 4
      omega
    · have h := after_14_8
      change 4 ≤ 1+Marked.gameValue original marks_14 .staller {8} ∧ 1+Marked.gameValue original marks_14 .dominator {8} ≤ 4
      omega
    · have h := after_14_9
      change 4 ≤ 1+Marked.gameValue original marks_14 .staller {9} ∧ 1+Marked.gameValue original marks_14 .dominator {9} ≤ 4
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_14 ∅ 10) hv)
def marks_15 : Finset (Fin 11) := {2,3}
theorem after_15_0 : Marked.gameValue original marks_15 .dominator {0}=2 ∧ Marked.gameValue original marks_15 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_5 0 2 2 (by decide +kernel) row_5
theorem after_15_1 : Marked.gameValue original marks_15 .dominator {1}=3 ∧ Marked.gameValue original marks_15 .staller {1}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_10 1 3 3 (by decide +kernel) row_10
theorem after_15_2 : Marked.gameValue original marks_15 .dominator {2}=3 ∧ Marked.gameValue original marks_15 .staller {2}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_13 2 3 4 (by decide +kernel) row_13
theorem after_15_4 : Marked.gameValue original marks_15 .dominator {4}=1 ∧ Marked.gameValue original marks_15 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_3 4 1 2 (by decide +kernel) row_3
theorem after_15_5 : Marked.gameValue original marks_15 .dominator {5}=1 ∧ Marked.gameValue original marks_15 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_15 marks_11 5 1 2 (by decide +kernel) row_11
theorem after_15_6 : Marked.gameValue original marks_15 .dominator {6}=1 ∧ Marked.gameValue original marks_15 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_12 6 1 2 (by decide +kernel) row_12
theorem after_15_7 : Marked.gameValue original marks_15 .dominator {7}=1 ∧ Marked.gameValue original marks_15 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_15 marks_3 7 1 2 (by decide +kernel) row_3
theorem after_15_8 : Marked.gameValue original marks_15 .dominator {8}=1 ∧ Marked.gameValue original marks_15 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_15 marks_11 8 1 2 (by decide +kernel) row_11
theorem after_15_9 : Marked.gameValue original marks_15 .dominator {9}=1 ∧ Marked.gameValue original marks_15 .staller {9}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_15 marks_12 9 1 2 (by decide +kernel) row_12
theorem after_15_10 : Marked.gameValue original marks_15 .dominator {10}=3 ∧ Marked.gameValue original marks_15 .staller {10}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_10 10 3 3 (by decide +kernel) row_10
theorem row_15 : Marked.gameValue original marks_15 .dominator ∅=3 ∧ Marked.gameValue original marks_15 .staller ∅=4 := by
  apply LocalProfile.DAG.bellman original marks_15 3 4 0 1 (by decide +kernel) (by decide +kernel)
  · rw [after_15_0.2]
  · rw [after_15_1.1]
  · intro v hv
    fin_cases v
    · have h := after_15_0
      change 3 ≤ 1+Marked.gameValue original marks_15 .staller {0} ∧ 1+Marked.gameValue original marks_15 .dominator {0} ≤ 4
      omega
    · have h := after_15_1
      change 3 ≤ 1+Marked.gameValue original marks_15 .staller {1} ∧ 1+Marked.gameValue original marks_15 .dominator {1} ≤ 4
      omega
    · have h := after_15_2
      change 3 ≤ 1+Marked.gameValue original marks_15 .staller {2} ∧ 1+Marked.gameValue original marks_15 .dominator {2} ≤ 4
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_15 ∅ 3) hv)
    · have h := after_15_4
      change 3 ≤ 1+Marked.gameValue original marks_15 .staller {4} ∧ 1+Marked.gameValue original marks_15 .dominator {4} ≤ 4
      omega
    · have h := after_15_5
      change 3 ≤ 1+Marked.gameValue original marks_15 .staller {5} ∧ 1+Marked.gameValue original marks_15 .dominator {5} ≤ 4
      omega
    · have h := after_15_6
      change 3 ≤ 1+Marked.gameValue original marks_15 .staller {6} ∧ 1+Marked.gameValue original marks_15 .dominator {6} ≤ 4
      omega
    · have h := after_15_7
      change 3 ≤ 1+Marked.gameValue original marks_15 .staller {7} ∧ 1+Marked.gameValue original marks_15 .dominator {7} ≤ 4
      omega
    · have h := after_15_8
      change 3 ≤ 1+Marked.gameValue original marks_15 .staller {8} ∧ 1+Marked.gameValue original marks_15 .dominator {8} ≤ 4
      omega
    · have h := after_15_9
      change 3 ≤ 1+Marked.gameValue original marks_15 .staller {9} ∧ 1+Marked.gameValue original marks_15 .dominator {9} ≤ 4
      omega
    · have h := after_15_10
      change 3 ≤ 1+Marked.gameValue original marks_15 .staller {10} ∧ 1+Marked.gameValue original marks_15 .dominator {10} ≤ 4
      omega
end IsolationGame.FullCanonical.T16
