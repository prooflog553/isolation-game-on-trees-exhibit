import PartitionGeometry

namespace IsolationGame.DescendantGeometry
open PartitionBridge
variable {V : Type} [Fintype V] [DecidableEq V]

/-- The original vertices NOT below b relative to the designated root r.
The distance equation describes the original r-to-v geodesic passing b. -/
noncomputable def retained (G : SimpleGraph V) (r b : V) : Finset V :=
  Finset.univ.filter (fun v=>G.dist r v≠G.dist r b+G.dist b v)

/-- Pure original-tree geometry target. This is a proposition definition,
not an assumption added to a game theorem and not an asserted axiom. -/
def Spec (G : SimpleGraph V) (r z b : V) : Prop :=
  ∃hz : z∈retained G r b, ∃hr : r∈retained G r b, ∃hb : b∉retained G r b,
    OneBridge G (retained G r b) z b ∧
    (IsolatedRestriction.induced G (outside (retained G r b))).IsTree ∧
    ∀v : Side (outside (retained G r b)),
      (IsolatedRestriction.induced G (outside (retained G r b))).dist
        ⟨b,by simp [outside,hb]⟩ v=G.dist b v.val

end IsolationGame.DescendantGeometry
