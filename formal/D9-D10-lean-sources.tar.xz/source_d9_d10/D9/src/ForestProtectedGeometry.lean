import GeometryContract
import IsolationGame.TreeLevels
import Mathlib.Data.Finset.Max

namespace IsolationGame.ForestGeometry
variable {V : Type} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V}

lemma forest_path_length (hA : G.IsAcyclic) {u v : V}
    (p : G.Walk u v) (hp : p.IsPath) : p.length = G.dist u v := by
  obtain ⟨q, hq, hlen⟩ := p.reachable.exists_path_of_dist
  have heq := hA.path_unique ⟨p, hp⟩ ⟨q, hq⟩
  have hpq : p = q := congrArg Subtype.val heq
  exact hpq ▸ hlen

lemma forest_adj_levels (hA : G.IsAcyclic) (r : V) {u v : V}
    (hu : G.Reachable u r) (h : G.Adj u v) :
    G.dist u r = G.dist v r + 1 ∨ G.dist v r = G.dist u r + 1 := by
  classical
  obtain ⟨p, hp, hlen⟩ := hu.exists_path_of_dist
  by_cases hv : v ∈ p.support
  · have hpre := forest_path_length hA (p.takeUntil v hv) (hp.takeUntil hv)
    have hpost := forest_path_length hA (p.dropUntil v hv) (hp.dropUntil hv)
    have hadj := SimpleGraph.dist_eq_one_iff_adj.mpr h
    have hsplit := congrArg SimpleGraph.Walk.length (p.take_spec hv)
    simp only [SimpleGraph.Walk.length_append] at hsplit
    exact Or.inl (by omega)
  · have hnew := forest_path_length hA (p.cons h.symm) (hp.cons hv)
    simp only [SimpleGraph.Walk.length_cons] at hnew
    exact Or.inr (by omega)

lemma forest_unique_lower (hA : G.IsAcyclic) (r : V) {u v w : V}
    (hu : G.Reachable u r) (hv : G.Adj u v) (hw : G.Adj u w)
    (hdv : G.dist v r + 1 = G.dist u r)
    (hdw : G.dist w r + 1 = G.dist u r) : v = w := by
  classical
  obtain ⟨p, hp, hplen⟩ := (hv.symm.reachable.trans hu).exists_path_of_dist
  obtain ⟨q, hq, hqlen⟩ := (hw.symm.reachable.trans hu).exists_path_of_dist
  have hpu : u ∉ p.support := by
    intro hu
    have h₁ := SimpleGraph.dist_le (p.dropUntil u hu)
    have h₂ := p.length_dropUntil_le hu
    omega
  have hqu : u ∉ q.support := by
    intro hu
    have h₁ := SimpleGraph.dist_le (q.dropUntil u hu)
    have h₂ := q.length_dropUntil_le hu
    omega
  have heq := hA.path_unique ⟨p.cons hv, hp.cons hpu⟩ ⟨q.cons hw, hq.cons hqu⟩
  have heq' := congrArg (fun z : G.Path u r => z.val.getVert 1) heq
  simpa using heq'

lemma forest_parent (hA : G.IsAcyclic) (r : V) {u : V}
    (hur : G.Reachable u r) (hu : u ≠ r) :
    ∃ v, G.Adj u v ∧ G.dist v r + 1 = G.dist u r := by
  obtain ⟨p, hp, hlen⟩ := hur.exists_path_of_dist
  cases p with
  | nil => exact False.elim (hu rfl)
  | @cons u v r huv p =>
    have ht := forest_path_length hA p hp.of_cons
    simp only [SimpleGraph.Walk.length_cons] at hlen
    exact ⟨v, huv, by omega⟩

lemma closed_reachable {v w : V} (h : (GuardedEdge.view G).closed v w) :
    G.Reachable v w := by
  rcases h with h | h
  · subst w; exact SimpleGraph.Reachable.refl _
  · exact h.reachable

/-- The geometry is stated in the fixed original forest. Vertices outside W
remain present and are included in every legality quantifier. -/
theorem forest_protected_edge_spec (G : SimpleGraph V) (hA : G.IsAcyclic) : Spec G := by
  classical
  intro W hnorm hne
  obtain ⟨r, hrW⟩ := hne
  let s : Finset V := Finset.univ.filter (fun u => W u ∧ G.Reachable u r)
  have hs : s.Nonempty := ⟨r, by simp [s, hrW, SimpleGraph.Reachable.refl]⟩
  obtain ⟨y, hy, hmax⟩ := s.exists_max_image (fun u => G.dist u r) hs
  have hy' : W y ∧ G.Reachable y r := (Finset.mem_filter.mp hy).2
  obtain ⟨hyW, hyr⟩ := hy'
  have hmax' (u : V) (hu : W u) (hur : G.Reachable u r) :
      G.dist u r ≤ G.dist y r := hmax u (by simp [s, hu, hur])
  have hyn : (GuardedEdge.view G).noniso W y := by rw [hnorm]; exact hyW
  obtain ⟨_, x, hxW, hyx⟩ := hyn
  have hyx' : G.Adj y x := hyx
  have hxy : G.Adj x y := hyx'.symm
  have hxr : G.Reachable x r := hxy.reachable.trans hyr
  have hdxy : G.dist x r + 1 = G.dist y r := by
    have hlev := forest_adj_levels hA r hyr hyx'
    have hm := hmax' x hxW hxr
    omega
  by_cases hroot : x = r
  · subst x
    let Z := (GuardedEdge.view G).noniso ((GuardedEdge.view G).remove W r)
    have hdy : G.dist y r = 1 := by
      have hz : G.dist r r = 0 := SimpleGraph.dist_self
      omega
    have hgone (u : V) (hur : G.Reachable u r) : ¬ Z u := by
      intro hu
      have hm := hmax' u hu.1.1 hur
      apply hu.1.2
      by_cases hzero : G.dist u r = 0
      · have he := hur.dist_eq_zero_iff.mp hzero
        exact Or.inl he.symm
      · have hone : G.dist u r = 1 := by omega
        exact Or.inr (SimpleGraph.dist_eq_one_iff_adj.mp hone).symm
    refine ⟨r, y, r, hxW, hyW, hxy, ⟨r, hxW, Or.inl rfl⟩, ?_⟩
    intro v hv ⟨u, hu, hvu⟩
    have hvr : G.Reachable v r := by
      rcases hv with hv | hv
      · exact closed_reachable hv
      · exact (closed_reachable hv).trans hyr
    exact hgone u ((closed_reachable hvu).symm.trans hvr) hu
  · obtain ⟨z, hxz, hdz⟩ := forest_parent hA r hxr hroot
    let Z := (GuardedEdge.view G).noniso ((GuardedEdge.view G).remove W z)
    have hnX : ¬ Z x := fun h => h.1.2 (Or.inr hxz.symm)
    have hnZ : ¬ Z z := fun h => h.1.2 (Or.inl rfl)
    have child_neighbor (u : V) (hxu : G.Adj x u)
        (hdu : G.dist u r = G.dist x r + 1)
        (t : V) (ht : W t) (hut : G.Adj u t) : t = x := by
      have hur := hxu.symm.reachable.trans hxr
      have htr := hut.symm.reachable.trans hur
      have hm := hmax' t ht htr
      have hl := forest_adj_levels hA r hur hut
      exact forest_unique_lower hA r hur hut hxu.symm (by omega) (by omega)
    have child_gone (u : V) (hxu : G.Adj x u)
        (hdu : G.dist u r = G.dist x r + 1) : ¬ Z u := by
      rintro ⟨_, t, ht, hut⟩
      have he := child_neighbor u hxu hdu t ht.1 hut
      subst t
      exact ht.2 (Or.inr hxz.symm)
    have illegal_z : ¬ (GuardedEdge.view G).legal Z z := by
      rintro ⟨u, hu, hzu⟩
      exact hu.1.2 hzu
    have illegal_child (u : V) (hxu : G.Adj x u)
        (hdu : G.dist u r = G.dist x r + 1) :
        ¬ (GuardedEdge.view G).legal Z u := by
      rintro ⟨t, ht, hut | hut⟩
      · subst t; exact child_gone u hxu hdu ht
      · have he := child_neighbor u hxu hdu t ht.1.1 hut
        subst t; exact hnX ht
    have illegal_x : ¬ (GuardedEdge.view G).legal Z x := by
      rintro ⟨u, hu, hxu | hxu⟩
      · subst u; exact hnX hu
      · have hl := forest_adj_levels hA r hxr hxu
        rcases hl with hl | hl
        · have he := forest_unique_lower hA r hxr hxu hxz (by omega) hdz
          subst u; exact hnZ hu
        · exact child_gone u hxu hl hu
    have touch_x (v : V) (hv : (GuardedEdge.view G).closed v x) :
        ¬ (GuardedEdge.view G).legal Z v := by
      rcases hv with hv | hv
      · subst v; exact illegal_x
      · have hvx : G.Adj v x := hv
        have hl := forest_adj_levels hA r hxr hvx.symm
        rcases hl with hl | hl
        · have he := forest_unique_lower hA r hxr hvx.symm hxz (by omega) hdz
          subst v; exact illegal_z
        · exact illegal_child v hvx.symm hl
    have touch_y (v : V) (hv : (GuardedEdge.view G).closed v y) :
        ¬ (GuardedEdge.view G).legal Z v := by
      rcases hv with hv | hv
      · subst v; exact illegal_child y hxy hdxy.symm
      · have hvy : G.Adj v y := hv
        have hvr := hvy.reachable.trans hyr
        have hl := forest_adj_levels hA r hyr hvy.symm
        rcases hl with hl | hl
        · have he := forest_unique_lower hA r hyr hvy.symm hyx' (by omega) hdxy
          subst v; exact illegal_x
        · rintro ⟨u, hu, hvu | hvu⟩
          · subst u
            have hm := hmax' v hu.1.1 hvr
            omega
          · have hvu' : G.Adj v u := hvu
            have hur := hvu'.symm.reachable.trans hvr
            have hm := hmax' u hu.1.1 hur
            have hul := forest_adj_levels hA r hvr hvu'
            have he := forest_unique_lower hA r hvr hvu' hvy (by omega) (by omega)
            subst u
            exact child_gone y hxy hdxy.symm hu
    refine ⟨x, y, z, hxW, hyW, hxy, ⟨x, hxW, Or.inr hxz.symm⟩, ?_⟩
    intro v hv
    exact hv.elim (touch_x v) (touch_y v)

#check @forest_protected_edge_spec
#print axioms forest_protected_edge_spec

end IsolationGame.ForestGeometry
