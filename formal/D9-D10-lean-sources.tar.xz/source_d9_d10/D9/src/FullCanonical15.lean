import FullCanonical15Rows02
namespace IsolationGame.FullCanonical.T15
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
theorem full_values : Marked.gameValue original ∅ .dominator ∅=3 ∧ Marked.gameValue original ∅ .staller ∅=4 := by
  constructor
  · exact (Marked.value_eq_of_white_eq original ∅ marks_10 ∅ ∅ .dominator (by decide +kernel)).trans row_10.1
  · exact (Marked.value_eq_of_white_eq original ∅ marks_10 ∅ ∅ .staller (by decide +kernel)).trans row_10.2
theorem strict_full : MarkedSum.StrictCapacity original ∅ ∅ 4 := by
  constructor
  · rw [full_values.1] <;> decide +kernel
  · intro v hv
    fin_cases v
    · change Marked.gameValue original marks_10 .staller {0}+1≤4
      rw [after_10_0.2] <;> decide +kernel
    · change Marked.gameValue original marks_10 .staller {1}+1≤4
      rw [after_10_1.2] <;> decide +kernel
    · change Marked.gameValue original marks_10 .staller {2}+1≤4
      rw [after_10_2.2] <;> decide +kernel
    · change Marked.gameValue original marks_10 .staller {3}+1≤4
      rw [after_10_3.2] <;> decide +kernel
    · change Marked.gameValue original marks_10 .staller {4}+1≤4
      rw [after_10_4.2] <;> decide +kernel
    · change Marked.gameValue original marks_10 .staller {5}+1≤4
      rw [after_10_5.2] <;> decide +kernel
    · change Marked.gameValue original marks_10 .staller {6}+1≤4
      rw [after_10_6.2] <;> decide +kernel
    · change Marked.gameValue original marks_10 .staller {7}+1≤4
      rw [after_10_7.2] <;> decide +kernel
#print axioms full_values
#print axioms strict_full
end IsolationGame.FullCanonical.T15
