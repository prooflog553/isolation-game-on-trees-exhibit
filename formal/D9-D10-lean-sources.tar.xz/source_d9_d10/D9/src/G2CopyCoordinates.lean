import G2Model
import Mathlib.Logic.Equiv.Fin.Basic

namespace IsolationGame.G2Family
open BWCoordinates
set_option maxHeartbeats 3000000

def localGraph (n : Nat) : SimpleGraph (Local n) where
  Adj
    | none, none => False
    | none, some (_,a) => a=0
    | some (_,a), none => a=0
    | some (i,a), some (j,b) => i=j ∧ CentreOrdinary.graph.Adj a b
  symm := by
    intro u v h
    cases u <;> cases v
    · exact h
    · exact h
    · exact h
    · exact ⟨h.1.symm,h.2.symm⟩
  loopless := by
    intro u h
    cases u with
    | none => exact h
    | some u => exact CentreOrdinary.graph.loopless u.2 h.2

theorem local_decode_adj (n : Nat) (u v : Local n) :
    MarkedModule.original.Adj (decode n u) (decode n v) ↔ (localGraph n).Adj u v := by
  cases u with
  | none =>
    cases v with
    | none => simp [decode,localGraph,MarkedModule.original,GatedGraph.connected,
        GatedGraph.original,GatedGraph.adj,GatedGraph.gateGraph,MarkedModule.star]
    | some v =>
      obtain ⟨j,b⟩ := v
      fin_cases b <;> simp [decode,localGraph,MarkedModule.original,GatedGraph.connected,
        GatedGraph.original,GatedGraph.adj,GatedGraph.gateGraph,MarkedModule.star,MarkedModule.owner]
  | some u =>
    obtain ⟨i,a⟩ := u
    cases v with
    | none =>
      fin_cases a <;> simp [decode,localGraph,MarkedModule.original,GatedGraph.connected,
        GatedGraph.original,GatedGraph.adj,GatedGraph.gateGraph,MarkedModule.star,MarkedModule.owner]
    | some v =>
      obtain ⟨j,b⟩ := v
      fin_cases a <;> fin_cases b <;>
        simp [decode,localGraph,MarkedModule.original,GatedGraph.connected,GatedGraph.original,
          GatedGraph.adj,GatedGraph.gateGraph,MarkedModule.star,MarkedModule.owner,CentreOrdinary.graph,eq_comm]

abbrev CVertex (p q k : Nat) := Sum (Sum (Local q) (Local p)) (Fin k × Fin 4)
def cEquiv (p q k : Nat) : CVertex p q k ≃ Vertex p q k :=
  Equiv.sumCongr (sides q p) (Equiv.refl _)

def cGraph (p q k : Nat) : SimpleGraph (CVertex p q k) where
  Adj
    | .inl (.inl u), .inl (.inl v) => (localGraph q).Adj u v
    | .inl (.inr u), .inl (.inr v) => (localGraph p).Adj u v
    | .inl (.inl u), .inl (.inr v) => u=none ∧ v=none
    | .inl (.inr u), .inl (.inl v) => u=none ∧ v=none
    | .inl (.inl u), .inr (_,a) => u=none ∧ a=0
    | .inr (_,a), .inl (.inl u) => a=0 ∧ u=none
    | .inr (i,a), .inr (j,b) => i=j ∧ pathGraph.Adj a b
    | _, _ => False
  symm := by
    intro u v h
    rcases u with (u|u)|u <;> rcases v with (v|v)|v
    all_goals first | exact h | exact h.symm | exact ⟨h.1.symm,h.2.symm⟩
  loopless := by
    intro u h
    rcases u with (u|u)|u
    · exact (localGraph q).loopless u h
    · exact (localGraph p).loopless u h
    · exact pathGraph.loopless u.2 h.2

theorem cEquiv_adj (p q k : Nat) (u v : CVertex p q k) :
    (graph p q k).Adj (cEquiv p q k u) (cEquiv p q k v) ↔ (cGraph p q k).Adj u v := by
  have hr (n : Nat) (u : Local n) : decode n u = BWBridge.root n ↔ u=none := by
    change sideEquiv n u = sideEquiv n none ↔ _
    exact (sideEquiv n).injective.eq_iff
  rcases u with (u|u)|u <;> rcases v with (v|v)|v
  all_goals simp [cEquiv,sides,sideEquiv,graph,cGraph,BWBridge.original,Attachment.original,
    local_decode_adj,hr]

def cMarks (p q k : Nat) : Finset (CVertex p q k) := {.inl (.inl none)}

theorem cMarks_image (p q k : Nat) : (cMarks p q k).image (cEquiv p q k)=marks p q k := by
  simp [cMarks,marks,y,cEquiv,sides,sideEquiv,decode,BWBridge.root]

theorem cValue (p q k : Nat) (M X : Finset (CVertex p q k)) (t : Player) :
    Marked.gameValue (graph p q k) (M.image (cEquiv p q k)) t (X.image (cEquiv p q k)) =
      Marked.gameValue (cGraph p q k) M t X :=
  Marked.gameValue_relabel _ _ _ (cEquiv_adj p q k) M X t

theorem cMarkedValue (p q k : Nat) (X : Finset (CVertex p q k)) (t : Player) :
    Marked.gameValue (graph p q k) (marks p q k) t (X.image (cEquiv p q k)) =
      Marked.gameValue (cGraph p q k) (cMarks p q k) t X := by
  simpa only [cMarks_image] using cValue p q k (cMarks p q k) X t

end IsolationGame.G2Family
