import CoreFamilyContract
import CanonicalTrees

namespace IsolationGame.CoreFamily
open CanonicalLocal
open scoped BigOperators

theorem family_root_adj (xs : List Nat) (p : Nat) (i : Fin (xs.length+p))
    (v : Fin (size (label xs p i))) :
    (graph xs p).Adj none (some ⟨i,v⟩) ↔ v=root (label xs p i) := by
  simp [graph,SimpleGraph.fromRel,eq_comm]

theorem family_same_adj (xs : List Nat) (p : Nat) (i : Fin (xs.length+p))
    (u v : Fin (size (label xs p i))) :
    (graph xs p).Adj (some ⟨i,u⟩) (some ⟨i,v⟩) ↔
      (CanonicalLocal.graph (label xs p i)).Adj u v := by
  simp [graph,SimpleGraph.fromRel]
  constructor
  · rintro ⟨_,h|h⟩
    · obtain ⟨j,a,b,hab,⟨hij,hu⟩,_,hv⟩ := h
      subst j
      cases hu
      cases hv
      exact hab
    · obtain ⟨j,a,b,hab,⟨hij,hv⟩,_,hu⟩ := h
      subst j
      cases hu
      cases hv
      exact hab.symm
  · intro h
    exact ⟨h.ne,Or.inl ⟨i,u,v,h,⟨rfl,HEq.rfl⟩,rfl,HEq.rfl⟩⟩

theorem family_distinct_no_adj (xs : List Nat) (p : Nat) (i j : Fin (xs.length+p))
    (hij : i≠j) (u : Fin (size (label xs p i))) (v : Fin (size (label xs p j))) :
    ¬(graph xs p).Adj (some ⟨i,u⟩) (some ⟨j,v⟩) := by
  simp [graph,SimpleGraph.fromRel,hij,hij.symm]
  constructor
  · intro k a b _ hi _ hj _
    exact hij (hi.trans hj.symm)
  · intro k a b _ hj _ hi _
    exact hij (hi.trans hj.symm)

private def branchHom (xs : List Nat) (p : Nat) (i : Fin (xs.length+p)) :
    CanonicalLocal.graph (label xs p i) →g graph xs p where
  toFun v := some ⟨i,v⟩
  map_rel' h := (family_same_adj xs p i _ _).mpr h

theorem family_connected (xs : List Nat) (p : Nat) : (graph xs p).Connected := by
  apply (SimpleGraph.connected_iff_exists_forall_reachable _).mpr
  refine ⟨none,?_⟩
  intro v
  cases v with
  | none => exact SimpleGraph.Reachable.refl _
  | some v =>
    obtain ⟨i,u⟩ := v
    have hr := ((family_root_adj xs p i _).mpr rfl).reachable
    have hl := (canonical_tree (label xs p i)).isConnected (root _) u
    exact hr.trans (hl.map (branchHom xs p i))

private abbrev EdgeCode (xs : List Nat) (p : Nat) :=
  Σ i : Fin (xs.length+p), Option (CanonicalLocal.graph (label xs p i)).edgeSet

private noncomputable def edgeMap (xs : List Nat) (p : Nat) :
    EdgeCode xs p → (graph xs p).edgeSet
  | ⟨i,none⟩ => ⟨s(none,some ⟨i,root (label xs p i)⟩), (family_root_adj xs p i _).mpr rfl⟩
  | ⟨i,some e⟩ => ⟨e.val.map (fun v=>some ⟨i,v⟩), by
      obtain ⟨e,he⟩ := e
      induction e using Sym2.inductionOn with
      | _ u v => exact (family_same_adj xs p i u v).mpr he⟩

private theorem edgeMap_surjective (xs : List Nat) (p : Nat) :
    Function.Surjective (edgeMap xs p) := by
  rintro ⟨e,he⟩
  induction e using Sym2.inductionOn with
  | _ u v =>
    change (graph xs p).Adj u v at he
    rcases he with ⟨_,h|h⟩
    · rcases h with ⟨i,rfl,rfl⟩ | ⟨i,a,b,hab,rfl,rfl⟩
      · exact ⟨⟨i,none⟩,rfl⟩
      · exact ⟨⟨i,some ⟨s(a,b),hab⟩⟩,rfl⟩
    · rcases h with ⟨i,rfl,rfl⟩ | ⟨i,a,b,hab,rfl,rfl⟩
      · refine ⟨⟨i,none⟩,Subtype.ext ?_⟩
        exact Sym2.eq_swap
      · refine ⟨⟨i,some ⟨s(a,b),hab⟩⟩,Subtype.ext ?_⟩
        exact Sym2.eq_swap

theorem family_tree (xs : List Nat) (p : Nat) : (graph xs p).IsTree := by
  classical
  have hc := family_connected xs p
  have hu := Fintype.card_le_of_surjective (edgeMap xs p) (edgeMap_surjective xs p)
  have hcode : Fintype.card (EdgeCode xs p) = ∑ i : Fin (xs.length+p), size (label xs p i) := by
    rw [Fintype.card_sigma]
    apply Finset.sum_congr rfl
    intro i _
    rw [Fintype.card_option]
    simpa only [SimpleGraph.edgeFinset_card] using edge_count (label xs p i)
  have hv : Fintype.card (Vertex xs p) = (∑ i : Fin (xs.length+p), size (label xs p i))+1 := by
    simp only [Vertex,Fintype.card_option,Fintype.card_sigma,Fintype.card_fin]
  have hl := hc.card_vert_le_card_edgeSet_add_one
  rw [Nat.card_eq_fintype_card,Nat.card_eq_fintype_card] at hl
  apply SimpleGraph.isTree_iff_connected_and_card.mpr
  refine ⟨hc,?_⟩
  rw [Nat.card_eq_fintype_card,Nat.card_eq_fintype_card]
  rw [hcode] at hu
  omega

end IsolationGame.CoreFamily
