import FullCanonical03Rows02
namespace IsolationGame.FullCanonical.T03
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_12 : Finset (Fin 10) := {1,2,3}
theorem after_12_0 : Marked.gameValue original marks_12 .dominator {0}=2 ∧ Marked.gameValue original marks_12 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_6 0 2 2 (by decide +kernel) row_6
theorem after_12_1 : Marked.gameValue original marks_12 .dominator {1}=3 ∧ Marked.gameValue original marks_12 .staller {1}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_11 1 3 3 (by decide +kernel) row_11
theorem after_12_4 : Marked.gameValue original marks_12 .dominator {4}=1 ∧ Marked.gameValue original marks_12 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_4 4 1 2 (by decide +kernel) row_4
theorem after_12_5 : Marked.gameValue original marks_12 .dominator {5}=1 ∧ Marked.gameValue original marks_12 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_7 5 1 2 (by decide +kernel) row_7
theorem after_12_6 : Marked.gameValue original marks_12 .dominator {6}=1 ∧ Marked.gameValue original marks_12 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_8 6 1 2 (by decide +kernel) row_8
theorem after_12_7 : Marked.gameValue original marks_12 .dominator {7}=1 ∧ Marked.gameValue original marks_12 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_12 marks_4 7 1 2 (by decide +kernel) row_4
theorem after_12_8 : Marked.gameValue original marks_12 .dominator {8}=1 ∧ Marked.gameValue original marks_12 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_12 marks_7 8 1 2 (by decide +kernel) row_7
theorem after_12_9 : Marked.gameValue original marks_12 .dominator {9}=1 ∧ Marked.gameValue original marks_12 .staller {9}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_12 marks_8 9 1 2 (by decide +kernel) row_8
theorem row_12 : Marked.gameValue original marks_12 .dominator ∅=3 ∧ Marked.gameValue original marks_12 .staller ∅=4 := by
  apply LocalProfile.DAG.bellman original marks_12 3 4 0 1 (by decide +kernel) (by decide +kernel)
  · rw [after_12_0.2]
  · rw [after_12_1.1]
  · intro v hv
    fin_cases v
    · have h := after_12_0
      change 3 ≤ 1+Marked.gameValue original marks_12 .staller {0} ∧ 1+Marked.gameValue original marks_12 .dominator {0} ≤ 4
      omega
    · have h := after_12_1
      change 3 ≤ 1+Marked.gameValue original marks_12 .staller {1} ∧ 1+Marked.gameValue original marks_12 .dominator {1} ≤ 4
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_12 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_12 ∅ 3) hv)
    · have h := after_12_4
      change 3 ≤ 1+Marked.gameValue original marks_12 .staller {4} ∧ 1+Marked.gameValue original marks_12 .dominator {4} ≤ 4
      omega
    · have h := after_12_5
      change 3 ≤ 1+Marked.gameValue original marks_12 .staller {5} ∧ 1+Marked.gameValue original marks_12 .dominator {5} ≤ 4
      omega
    · have h := after_12_6
      change 3 ≤ 1+Marked.gameValue original marks_12 .staller {6} ∧ 1+Marked.gameValue original marks_12 .dominator {6} ≤ 4
      omega
    · have h := after_12_7
      change 3 ≤ 1+Marked.gameValue original marks_12 .staller {7} ∧ 1+Marked.gameValue original marks_12 .dominator {7} ≤ 4
      omega
    · have h := after_12_8
      change 3 ≤ 1+Marked.gameValue original marks_12 .staller {8} ∧ 1+Marked.gameValue original marks_12 .dominator {8} ≤ 4
      omega
    · have h := after_12_9
      change 3 ≤ 1+Marked.gameValue original marks_12 .staller {9} ∧ 1+Marked.gameValue original marks_12 .dominator {9} ≤ 4
      omega
def marks_13 : Finset (Fin 10) := {2,3}
theorem after_13_0 : Marked.gameValue original marks_13 .dominator {0}=2 ∧ Marked.gameValue original marks_13 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_6 0 2 2 (by decide +kernel) row_6
theorem after_13_1 : Marked.gameValue original marks_13 .dominator {1}=3 ∧ Marked.gameValue original marks_13 .staller {1}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_11 1 3 3 (by decide +kernel) row_11
theorem after_13_2 : Marked.gameValue original marks_13 .dominator {2}=3 ∧ Marked.gameValue original marks_13 .staller {2}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_12 2 3 4 (by decide +kernel) row_12
theorem after_13_4 : Marked.gameValue original marks_13 .dominator {4}=1 ∧ Marked.gameValue original marks_13 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_4 4 1 2 (by decide +kernel) row_4
theorem after_13_5 : Marked.gameValue original marks_13 .dominator {5}=1 ∧ Marked.gameValue original marks_13 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_13 marks_8 5 1 2 (by decide +kernel) row_8
theorem after_13_6 : Marked.gameValue original marks_13 .dominator {6}=1 ∧ Marked.gameValue original marks_13 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_10 6 1 2 (by decide +kernel) row_10
theorem after_13_7 : Marked.gameValue original marks_13 .dominator {7}=1 ∧ Marked.gameValue original marks_13 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_13 marks_4 7 1 2 (by decide +kernel) row_4
theorem after_13_8 : Marked.gameValue original marks_13 .dominator {8}=1 ∧ Marked.gameValue original marks_13 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_13 marks_8 8 1 2 (by decide +kernel) row_8
theorem after_13_9 : Marked.gameValue original marks_13 .dominator {9}=1 ∧ Marked.gameValue original marks_13 .staller {9}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_13 marks_10 9 1 2 (by decide +kernel) row_10
theorem row_13 : Marked.gameValue original marks_13 .dominator ∅=3 ∧ Marked.gameValue original marks_13 .staller ∅=4 := by
  apply LocalProfile.DAG.bellman original marks_13 3 4 0 1 (by decide +kernel) (by decide +kernel)
  · rw [after_13_0.2]
  · rw [after_13_1.1]
  · intro v hv
    fin_cases v
    · have h := after_13_0
      change 3 ≤ 1+Marked.gameValue original marks_13 .staller {0} ∧ 1+Marked.gameValue original marks_13 .dominator {0} ≤ 4
      omega
    · have h := after_13_1
      change 3 ≤ 1+Marked.gameValue original marks_13 .staller {1} ∧ 1+Marked.gameValue original marks_13 .dominator {1} ≤ 4
      omega
    · have h := after_13_2
      change 3 ≤ 1+Marked.gameValue original marks_13 .staller {2} ∧ 1+Marked.gameValue original marks_13 .dominator {2} ≤ 4
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_13 ∅ 3) hv)
    · have h := after_13_4
      change 3 ≤ 1+Marked.gameValue original marks_13 .staller {4} ∧ 1+Marked.gameValue original marks_13 .dominator {4} ≤ 4
      omega
    · have h := after_13_5
      change 3 ≤ 1+Marked.gameValue original marks_13 .staller {5} ∧ 1+Marked.gameValue original marks_13 .dominator {5} ≤ 4
      omega
    · have h := after_13_6
      change 3 ≤ 1+Marked.gameValue original marks_13 .staller {6} ∧ 1+Marked.gameValue original marks_13 .dominator {6} ≤ 4
      omega
    · have h := after_13_7
      change 3 ≤ 1+Marked.gameValue original marks_13 .staller {7} ∧ 1+Marked.gameValue original marks_13 .dominator {7} ≤ 4
      omega
    · have h := after_13_8
      change 3 ≤ 1+Marked.gameValue original marks_13 .staller {8} ∧ 1+Marked.gameValue original marks_13 .dominator {8} ≤ 4
      omega
    · have h := after_13_9
      change 3 ≤ 1+Marked.gameValue original marks_13 .staller {9} ∧ 1+Marked.gameValue original marks_13 .dominator {9} ≤ 4
      omega
def marks_14 : Finset (Fin 10) := {}
theorem after_14_0 : Marked.gameValue original marks_14 .dominator {0}=3 ∧ Marked.gameValue original marks_14 .staller {0}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_9 0 3 3 (by decide +kernel) row_9
theorem after_14_1 : Marked.gameValue original marks_14 .dominator {1}=3 ∧ Marked.gameValue original marks_14 .staller {1}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_11 1 3 3 (by decide +kernel) row_11
theorem after_14_2 : Marked.gameValue original marks_14 .dominator {2}=3 ∧ Marked.gameValue original marks_14 .staller {2}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_12 2 3 4 (by decide +kernel) row_12
theorem after_14_3 : Marked.gameValue original marks_14 .dominator {3}=3 ∧ Marked.gameValue original marks_14 .staller {3}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_13 3 3 4 (by decide +kernel) row_13
theorem after_14_4 : Marked.gameValue original marks_14 .dominator {4}=3 ∧ Marked.gameValue original marks_14 .staller {4}=3 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_14 marks_11 4 3 3 (by decide +kernel) row_11
theorem after_14_5 : Marked.gameValue original marks_14 .dominator {5}=3 ∧ Marked.gameValue original marks_14 .staller {5}=4 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_14 marks_12 5 3 4 (by decide +kernel) row_12
theorem after_14_6 : Marked.gameValue original marks_14 .dominator {6}=3 ∧ Marked.gameValue original marks_14 .staller {6}=4 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_14 marks_13 6 3 4 (by decide +kernel) row_13
theorem after_14_7 : Marked.gameValue original marks_14 .dominator {7}=3 ∧ Marked.gameValue original marks_14 .staller {7}=3 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_14 marks_11 7 3 3 (by decide +kernel) row_11
theorem after_14_8 : Marked.gameValue original marks_14 .dominator {8}=3 ∧ Marked.gameValue original marks_14 .staller {8}=4 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_14 marks_12 8 3 4 (by decide +kernel) row_12
theorem after_14_9 : Marked.gameValue original marks_14 .dominator {9}=3 ∧ Marked.gameValue original marks_14 .staller {9}=4 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_14 marks_13 9 3 4 (by decide +kernel) row_13
theorem row_14 : Marked.gameValue original marks_14 .dominator ∅=4 ∧ Marked.gameValue original marks_14 .staller ∅=4 := by
  apply LocalProfile.DAG.bellman original marks_14 4 4 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_14_0.2]
  · rw [after_14_0.1]
  · intro v hv
    fin_cases v
    · have h := after_14_0
      change 4 ≤ 1+Marked.gameValue original marks_14 .staller {0} ∧ 1+Marked.gameValue original marks_14 .dominator {0} ≤ 4
      omega
    · have h := after_14_1
      change 4 ≤ 1+Marked.gameValue original marks_14 .staller {1} ∧ 1+Marked.gameValue original marks_14 .dominator {1} ≤ 4
      omega
    · have h := after_14_2
      change 4 ≤ 1+Marked.gameValue original marks_14 .staller {2} ∧ 1+Marked.gameValue original marks_14 .dominator {2} ≤ 4
      omega
    · have h := after_14_3
      change 4 ≤ 1+Marked.gameValue original marks_14 .staller {3} ∧ 1+Marked.gameValue original marks_14 .dominator {3} ≤ 4
      omega
    · have h := after_14_4
      change 4 ≤ 1+Marked.gameValue original marks_14 .staller {4} ∧ 1+Marked.gameValue original marks_14 .dominator {4} ≤ 4
      omega
    · have h := after_14_5
      change 4 ≤ 1+Marked.gameValue original marks_14 .staller {5} ∧ 1+Marked.gameValue original marks_14 .dominator {5} ≤ 4
      omega
    · have h := after_14_6
      change 4 ≤ 1+Marked.gameValue original marks_14 .staller {6} ∧ 1+Marked.gameValue original marks_14 .dominator {6} ≤ 4
      omega
    · have h := after_14_7
      change 4 ≤ 1+Marked.gameValue original marks_14 .staller {7} ∧ 1+Marked.gameValue original marks_14 .dominator {7} ≤ 4
      omega
    · have h := after_14_8
      change 4 ≤ 1+Marked.gameValue original marks_14 .staller {8} ∧ 1+Marked.gameValue original marks_14 .dominator {8} ≤ 4
      omega
    · have h := after_14_9
      change 4 ≤ 1+Marked.gameValue original marks_14 .staller {9} ∧ 1+Marked.gameValue original marks_14 .dominator {9} ≤ 4
      omega
end IsolationGame.FullCanonical.T03
