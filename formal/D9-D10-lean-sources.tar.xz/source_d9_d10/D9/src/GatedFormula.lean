import Std

namespace Gated

inductive Turn where
  | D | S
  deriving DecidableEq, Repr

structure Counts where
  P : Nat
  A : Nat
  sigma : Nat
  deriving DecidableEq, Repr

def Counts.valid (c : Counts) : Prop := c.sigma ≤ c.A ∧ c.A ≤ c.P

def Counts.d (c : Counts) : Nat := c.P + c.A - (c.sigma + 1) / 2

def Counts.s (c : Counts) : Nat := c.P + c.A - c.sigma / 2

def Counts.value (t : Turn) (c : Counts) : Nat :=
  match t with
  | .D => c.d
  | .S => c.s

/-- The complete local move taxonomy. Positivity guards describe actual moves. -/
inductive Step : Counts → Counts → Prop where
  | deleteOpen (p a z : Nat) (hp : 0 < p) :
      Step ⟨p, a, z⟩ ⟨p - 1, a, z⟩
  | deleteSingleton (p a z : Nat) (hz : 0 < z) :
      Step ⟨p, a, z⟩ ⟨p - 1, a - 1, z - 1⟩
  | deletePair (p a z : Nat) (hz : z < a) :
      Step ⟨p, a, z⟩ ⟨p - 1, a, z + 1⟩
  | deleteLarge (p a z : Nat) (hz : z < a) :
      Step ⟨p, a, z⟩ ⟨p - 1, a, z⟩
  | openSingleton (p a z : Nat) (hz : 0 < z) :
      Step ⟨p, a, z⟩ ⟨p, a - 1, z - 1⟩
  | openLarge (p a z : Nat) (hz : z < a) :
      Step ⟨p, a, z⟩ ⟨p, a - 1, z⟩

/-- Concrete transition and move-existence obligations; no game-value assumptions. -/
structure Certificate {State : Type} (Move : State → State → Prop)
    (count : State → Counts) : Prop where
  valid : ∀ q, (count q).valid
  taxonomy : ∀ {q r}, Move q r → Step (count q) (count r)
  delete_singleton : ∀ q, 0 < (count q).sigma →
    ∃ r, Move q r ∧ count r =
      ⟨(count q).P - 1, (count q).A - 1, (count q).sigma - 1⟩
  open_singleton : ∀ q, 0 < (count q).sigma →
    ∃ r, Move q r ∧ count r =
      ⟨(count q).P, (count q).A - 1, (count q).sigma - 1⟩
  delete_unit : ∀ q, 0 < (count q).P →
    ∃ r, Move q r ∧ (count r).P = (count q).P - 1
  open_group : ∀ q, 0 < (count q).A →
    ∃ r, Move q r ∧ (count r).P = (count q).P

/-- D can force termination within this many moves, against all S replies. -/
def winWithin {State : Type} (Move : State → State → Prop) (P : State → Nat) :
    Nat → Turn → State → Prop
  | 0, _, q => P q = 0
  | n + 1, .D, q => P q = 0 ∨ ∃ r, Move q r ∧ winWithin Move P n .S r
  | n + 1, .S, q => P q = 0 ∨ ∀ r, Move q r → winWithin Move P n .D r

theorem step_bounds {c c' : Counts} (hc : c.valid) (hc' : c'.valid)
    (h : Step c c') : c.d ≤ c'.s + 1 ∧ c'.d + 1 ≤ c.s := by
  cases h <;> simp [Counts.valid, Counts.d, Counts.s] at * <;> omega

theorem values_zero {c : Counts} (hc : c.valid) :
    (c.d = 0 ↔ c.P = 0) ∧ (c.s = 0 ↔ c.P = 0) := by
  simp [Counts.valid, Counts.d, Counts.s] at *
  omega

theorem delete_singleton_exact {c : Counts} (hc : c.valid) (hz : 0 < c.sigma) :
    (Counts.mk (c.P - 1) (c.A - 1) (c.sigma - 1)).s + 1 = c.d := by
  simp [Counts.valid, Counts.d, Counts.s] at *
  omega

theorem open_singleton_exact {c : Counts} (hc : c.valid) (hz : 0 < c.sigma) :
    (Counts.mk c.P (c.A - 1) (c.sigma - 1)).d + 1 = c.s := by
  simp [Counts.valid, Counts.d, Counts.s] at *
  omega

theorem delete_zero_exact {c c' : Counts} (hc : c.valid) (hc' : c'.valid)
    (hz : c.sigma = 0) (hp : 0 < c.P) (h : Step c c')
    (hP : c'.P = c.P - 1) : c'.s + 1 = c.d := by
  cases h <;> simp [Counts.valid, Counts.d, Counts.s] at * <;> omega

theorem open_zero_exact {c c' : Counts} (hc : c.valid) (hc' : c'.valid)
    (hz : c.sigma = 0) (hp : 0 < c.P) (h : Step c c')
    (hP : c'.P = c.P) : c'.d + 1 = c.s := by
  cases h <;> simp [Counts.valid, Counts.d, Counts.s] at * <;> omega

theorem no_group_exact {c c' : Counts} (hc : c.valid) (hc' : c'.valid)
    (ha : c.A = 0) (hp : 0 < c.P) (h : Step c c') : c'.d + 1 = c.s := by
  cases h <;> simp [Counts.valid, Counts.d, Counts.s] at * <;> omega

/-- Every legal move strictly lowers the elementary termination rank. -/
theorem step_rank_decreases {c c' : Counts} (hc : c.valid) (h : Step c c') :
    c'.P + c'.A < c.P + c.A := by
  cases h <;> simp [Counts.valid] at * <;> omega

/-- For odd singleton count the two formulas differ by exactly one. -/
theorem odd_values {c : Counts} (hc : c.valid) (hz : c.sigma % 2 = 1) :
    c.d + 1 = c.s := by
  simp [Counts.valid, Counts.d, Counts.s] at *
  omega

/-- Every first move reduces the S-formula when the singleton count is odd. -/
theorem odd_step_s {c c' : Counts} (hc : c.valid) (hc' : c'.valid)
    (hz : c.sigma % 2 = 1) (h : Step c c') : c'.s + 1 ≤ c.s := by
  cases h <;> simp [Counts.valid, Counts.d, Counts.s] at * <;> omega

namespace Certificate

variable {State : Type} {Move : State → State → Prop} {count : State → Counts}

/-- A legal move attaining the D recurrence, proved from local move existence. -/
theorem d_move (C : Certificate Move count) (q : State) (hp : 0 < (count q).P) :
    ∃ r, Move q r ∧ (count r).s + 1 = (count q).d := by
  by_cases hz : 0 < (count q).sigma
  · obtain ⟨r, hm, hr⟩ := C.delete_singleton q hz
    refine ⟨r, hm, ?_⟩
    rw [hr]
    exact delete_singleton_exact (C.valid q) hz
  · have hzero : (count q).sigma = 0 := by omega
    obtain ⟨r, hm, hP⟩ := C.delete_unit q hp
    exact ⟨r, hm, delete_zero_exact (C.valid q) (C.valid r) hzero hp
      (C.taxonomy hm) hP⟩

/-- A legal move attaining the S recurrence, proved from local move existence. -/
theorem s_move (C : Certificate Move count) (q : State) (hp : 0 < (count q).P) :
    ∃ r, Move q r ∧ (count r).d + 1 = (count q).s := by
  by_cases hz : 0 < (count q).sigma
  · obtain ⟨r, hm, hr⟩ := C.open_singleton q hz
    refine ⟨r, hm, ?_⟩
    rw [hr]
    exact open_singleton_exact (C.valid q) hz
  · have hzero : (count q).sigma = 0 := by omega
    by_cases ha : 0 < (count q).A
    · obtain ⟨r, hm, hP⟩ := C.open_group q ha
      exact ⟨r, hm, open_zero_exact (C.valid q) (C.valid r) hzero hp
        (C.taxonomy hm) hP⟩
    · have hA : (count q).A = 0 := by omega
      obtain ⟨r, hm, _⟩ := C.delete_unit q hp
      exact ⟨r, hm, no_group_exact (C.valid q) (C.valid r) hA hp (C.taxonomy hm)⟩

/-- Zero units is exactly the ordinary game-theoretic terminal condition. -/
theorem terminal_iff_no_moves (C : Certificate Move count) (q : State) :
    (count q).P = 0 ↔ ¬ ∃ r, Move q r := by
  constructor
  · intro hp ⟨r, hm⟩
    have hz := (values_zero (C.valid q)).2.mpr hp
    have hb := (step_bounds (C.valid q) (C.valid r) (C.taxonomy hm)).2
    omega
  · intro h
    by_cases hp : (count q).P = 0
    · exact hp
    · have hpos : 0 < (count q).P := by omega
      obtain ⟨r, hm, _⟩ := C.delete_unit q hpos
      exact False.elim (h ⟨r, hm⟩)

/-- Exact minimax formula, expressed without importing or assuming minimax values. -/
theorem formula (C : Certificate Move count) (n : Nat) (t : Turn) (q : State) :
    winWithin Move (fun x => (count x).P) n t q ↔ (count q).value t ≤ n := by
  induction n generalizing t q with
  | zero =>
    have hd := (values_zero (C.valid q)).1
    have hs := (values_zero (C.valid q)).2
    cases t <;> simp [winWithin, Counts.value] <;> omega
  | succ n ih =>
    cases t with
    | D =>
      change ((count q).P = 0 ∨
        ∃ r, Move q r ∧ winWithin Move (fun x => (count x).P) n .S r) ↔
        (count q).d ≤ n + 1
      constructor
      · rintro (hp | ⟨r, hm, hw⟩)
        · have hz := (values_zero (C.valid q)).1.mpr hp
          omega
        · have hr := (ih .S r).mp hw
          change (count r).s ≤ n at hr
          have hb := (step_bounds (C.valid q) (C.valid r) (C.taxonomy hm)).1
          omega
      · intro hd
        by_cases hp : (count q).P = 0
        · exact Or.inl hp
        · have hpos : 0 < (count q).P := by omega
          obtain ⟨r, hm, hr⟩ := C.d_move q hpos
          refine Or.inr ⟨r, hm, (ih .S r).mpr ?_⟩
          change (count r).s ≤ n
          omega
    | S =>
      change ((count q).P = 0 ∨
        ∀ r, Move q r → winWithin Move (fun x => (count x).P) n .D r) ↔
        (count q).s ≤ n + 1
      constructor
      · rintro (hp | hw)
        · have hz := (values_zero (C.valid q)).2.mpr hp
          omega
        · by_cases hp : (count q).P = 0
          · have hz := (values_zero (C.valid q)).2.mpr hp
            omega
          · have hpos : 0 < (count q).P := by omega
            obtain ⟨r, hm, hr⟩ := C.s_move q hpos
            have hd := (ih .D r).mp (hw r hm)
            change (count r).d ≤ n at hd
            omega
      · intro hs
        refine Or.inr ?_
        intro r hm
        apply (ih .D r).mpr
        change (count r).d ≤ n
        have hb := (step_bounds (C.valid q) (C.valid r) (C.taxonomy hm)).2
        omega

/-- The displayed formula is attained and no smaller horizon suffices. -/
theorem exact_horizon (C : Certificate Move count) (t : Turn) (q : State) :
    winWithin Move (fun x => (count x).P) ((count q).value t) t q ∧
    ∀ n, n < (count q).value t →
      ¬ winWithin Move (fun x => (count x).P) n t q := by
  constructor
  · exact (C.formula _ _ _).mpr (Nat.le_refl _)
  · intro n hn hw
    have h := (C.formula n t q).mp hw
    omega

/-- The D-start closed form, with no separate minimax-value definition required. -/
theorem d_formula (C : Certificate Move count) (n : Nat) (q : State) :
    winWithin Move (fun x => (count x).P) n .D q ↔
      (count q).P + (count q).A - ((count q).sigma + 1) / 2 ≤ n :=
  C.formula n .D q

/-- The S-start closed form, with no separate minimax-value definition required. -/
theorem s_formula (C : Certificate Move count) (n : Nat) (q : State) :
    winWithin Move (fun x => (count x).P) n .S q ↔
      (count q).P + (count q).A - (count q).sigma / 2 ≤ n :=
  C.formula n .S q

end Certificate

end Gated

#print axioms Gated.Certificate.formula
#print axioms Gated.Certificate.exact_horizon
#print axioms Gated.odd_step_s
