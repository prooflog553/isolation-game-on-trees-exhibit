import FiniteDefectBound
import ActualRootBudget

namespace IsolationGame.NecessaryCore
open CanonicalLocal ActualRootBranches
variable {A : Type} [DecidableEq A]

def exceptionalCount (f : A→Index) (I : Finset A) : Nat :=
  (I.filter (fun a=>f a≠.t02)).card

theorem exception_partition (f : A→Index) (I : Finset A) :
    exceptionalCount f I=strictCount f I+nonstrictCount f I := by
  induction I using Finset.induction_on with
  | empty => simp [exceptionalCount,strictCount,nonstrictCount]
  | @insert a I ha ih =>
    cases hf : f a <;>
      simp [exceptionalCount,strictCount,nonstrictCount,Finset.filter_insert,ha,hf,pairable] at * <;> omega

variable {V : Type} [Fintype V] [DecidableEq V]

theorem strict_count_matches (G : SimpleGraph V) (hT : G.IsTree)
    (r : V) (hR : ∀v,G.dist r v≤4) (hSmall : RootedReduction.SmallerFloor (Fintype.card V))
    (hCounter : 3*Fintype.card V/7<Marked.gameValue G {r} .dominator ∅) :
    strictCount (branchType G hT r hR hSmall hCounter) Finset.univ=(strictChildren G r).card := by
  classical
  have he : (Finset.univ.filter (fun a=>pairable (branchType G hT r hR hSmall hCounter a)=true))=strictChildren G r := by
    ext a
    simp only [strictChildren,Finset.mem_filter,Finset.mem_univ,true_and]
    exact (branch_type_facts G hT r hR hSmall hCounter a).2.2.2.symm
  exact congrArg Finset.card he

theorem sum_branch_defects (G : SimpleGraph V) (hT : G.IsTree)
    (r : V) (hR : ∀v,G.dist r v≤4) (hSmall : RootedReduction.SmallerFloor (Fintype.card V))
    (hCounter : 3*Fintype.card V/7<Marked.gameValue G {r} .dominator ∅) (I : Finset (Child G r)) :
    (∑a∈I,defect (branchType G hT r hR hSmall hCounter a))=
      7*((∑a∈I,capacity G r a : Nat):Int)-3*((∑a∈I,(piece G r a).card : Nat):Int) := by
  induction I using Finset.induction_on with
  | empty => simp
  | @insert a I ha ih =>
    rw [Finset.sum_insert ha,Finset.sum_insert ha,Finset.sum_insert ha,
      branch_defect G hT r hR hSmall hCounter a,ih]
    omega

/-- At most FOUR nonordinary ORIGINAL root branches in a hypothetical
minimum marked-radius-four floor counterexample. This follows from the real
root game budget and exact local profiles, not from an exploratory search. -/
theorem at_most_four_exceptions (G : SimpleGraph V) (hT : G.IsTree)
    (r : V) (hR : ∀v,G.dist r v≤4) (hSmall : RootedReduction.SmallerFloor (Fintype.card V))
    (hCounter : 3*Fintype.card V/7<Marked.gameValue G {r} .dominator ∅) :
    exceptionalCount (branchType G hT r hR hSmall hCounter) Finset.univ≤4 := by
  let f := branchType G hT r hR hSmall hCounter
  have hb := finite_defect_bound f Finset.univ
  have he := sum_branch_defects G hT r hR hSmall hCounter Finset.univ
  have hg := strict_count_matches G hT r hR hSmall hCounter
  have hn := actual_necessary_defect G hT r hCounter
  have hc := exception_partition f Finset.univ
  rw [he,hg] at hb
  rw [hg] at hc
  change exceptionalCount f Finset.univ≤4
  omega

#print axioms at_most_four_exceptions
end IsolationGame.NecessaryCore
