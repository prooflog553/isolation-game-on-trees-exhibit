import TwoPoolForestExhaustion
import CanonicalData
import MarkedRelabel

/-!
Fresh reconstruction of the five physical fixed blocks. This is new source,
not any historical five-family file. The canonical branch edge lists come
from CanonicalData; the family placements must be checked against the restored
canonical row table before these declarations can be used as ID theorems.
-/

namespace IsolationGame.FiveFamilyNewReconstruction
open CanonicalLocal

inductive Family where
  | id10674 | id8271 | id9423 | id13013 | id8577
  deriving DecidableEq

def branchEdges (offset : Nat) (t : Index) : List (Nat × Nat) :=
  (edges t).map (fun e => (offset + e.1, offset + e.2))

def attachedBranch (centre offset : Nat) (t : Index) : List (Nat × Nat) :=
  (centre, offset) :: branchEdges offset t

def order : Family → Nat
  | .id10674 => 21
  | .id8271 => 35
  | .id9423 => 28
  | .id13013 => 35
  | .id8577 => 28

/-- Labels 0 and 1 are the centres. Every branch retains the exact canonical
    rooted edge list translated to its physical label interval. -/
def fixedEdges : Family → List (Nat × Nat)
  | .id10674 => [(0,1)] ++ attachedBranch 0 2 .t01 ++
      attachedBranch 0 6 .t19 ++ attachedBranch 1 10 .t08
  | .id8271 => [(0,1)] ++ attachedBranch 0 2 .t01 ++
      attachedBranch 0 6 .t03 ++ attachedBranch 0 16 .t15 ++
      attachedBranch 1 24 .t08
  | .id9423 => [(0,1)] ++ attachedBranch 0 2 .t01 ++
      attachedBranch 0 6 .t10 ++ attachedBranch 0 9 .t15 ++
      attachedBranch 1 17 .t08
  | .id13013 => [(0,1)] ++ attachedBranch 0 2 .t08 ++
      attachedBranch 1 13 .t08 ++ attachedBranch 1 24 .t10 ++
      attachedBranch 1 27 .t15
  | .id8577 => [(0,1)] ++ attachedBranch 0 2 .t01 ++
      attachedBranch 0 6 .t08 ++ attachedBranch 1 17 .t08

abbrev Fixed (f : Family) := Fin (order f)

def fixedGraph (f : Family) : SimpleGraph (Fixed f) :=
  LocalProfile.graph (fixedEdges f)

instance (f : Family) : DecidableRel (fixedGraph f).Adj :=
  inferInstanceAs (DecidableRel (LocalProfile.graph (fixedEdges f)).Adj)

def openedCentre : Family → Nat
  | .id13013 => 1
  | _ => 0

def centre (f : Family) : Fixed f :=
  ⟨openedCentre f, by cases f <;> decide⟩

def leftCentre (f : Family) : Fixed f := ⟨0, by cases f <;> decide⟩
def rightCentre (f : Family) : Fixed f := ⟨1, by cases f <;> decide⟩

abbrev Vertex (f : Family) (p q : Nat) := TwoPool.Vertex (Fixed f) p q

/-- The literal physical graph: all fixed labels, all seven roles in each
    left/right ordinary copy, and their genuine centre attachments. -/
def physical (f : Family) (p q : Nat) : SimpleGraph (Vertex f p q) :=
  TwoPool.graph (fixedGraph f) (leftCentre f) (rightCentre f) p q

def initialMarks (f : Family) (p q : Nat) : Finset (Vertex f p q) :=
  TwoPool.marks ({centre f}) p q

def openedVertex (f : Family) (p q : Nat) : Vertex f p q :=
  TwoPool.fixed p q (centre f)

def postOpeningFixedMarks (f : Family) : Finset (Fixed f) :=
  Finset.univ.filter (fun v => v = centre f ∨ (fixedGraph f).Adj (centre f) v)

/-- The actual fixed labels dominated by the chosen centre. In particular,
    this is computed from adjacency, rather than supplied as a favorable mark
    pattern. -/
theorem postOpeningFixedMarks_exact (f : Family) :
    (postOpeningFixedMarks f).image Fin.val =
      match f with
      | .id10674 => ({0,1,2,6} : Finset Nat)
      | .id8271 => ({0,1,2,6,16} : Finset Nat)
      | .id9423 => ({0,1,2,6,9} : Finset Nat)
      | .id13013 => ({0,1,13,24,27} : Finset Nat)
      | .id8577 => ({0,1,2,6} : Finset Nat) := by
  cases f <;> decide +kernel

theorem vertex_count (f : Family) (p q : Nat) :
    Fintype.card (Vertex f p q) = order f + 7 * (p + q) := by
  simpa [Fixed] using (TwoPool.original_order (F := Fixed f) p q)

theorem original_acyclic (f : Family) (p q : Nat)
    (h : (fixedGraph f).IsAcyclic) : (physical f p q).IsAcyclic :=
  TwoPool.graph_acyclic (fixedGraph f) h (leftCentre f) (rightCentre f) p q

theorem every_vertex (f : Family) (p q : Nat) (v : Vertex f p q) :
    (∃ u : Fixed f, v = TwoPool.fixed p q u) ∨
    (∃ i : Fin p, ∃ r : Fin 7, v = TwoPool.ordinaryLeft p q i r) ∨
    (∃ i : Fin q, ∃ r : Fin 7, v = TwoPool.ordinaryRight p q i r) :=
  TwoPool.vertex_exhaustion p q v

theorem fixed_adjacency (f : Family) (p q : Nat) (u v : Fixed f) :
    (physical f p q).Adj (TwoPool.fixed p q u) (TwoPool.fixed p q v) ↔
      (fixedGraph f).Adj u v :=
  TwoPool.fixed_adj (fixedGraph f) (leftCentre f) (rightCentre f) p q u v

theorem fixed_left_adjacency (f : Family) (p q : Nat) (u : Fixed f)
    (i : Fin p) (r : Fin 7) :
    (physical f p q).Adj (TwoPool.fixed p q u) (TwoPool.ordinaryLeft p q i r) ↔
      u = leftCentre f ∧ r = 0 :=
  TwoPool.fixed_left_adj (fixedGraph f) (leftCentre f) (rightCentre f) p q u i r

theorem fixed_right_adjacency (f : Family) (p q : Nat) (u : Fixed f)
    (i : Fin q) (r : Fin 7) :
    (physical f p q).Adj (TwoPool.fixed p q u) (TwoPool.ordinaryRight p q i r) ↔
      u = rightCentre f ∧ r = 0 :=
  TwoPool.fixed_right_adj (fixedGraph f) (leftCentre f) (rightCentre f) p q u i r

theorem left_adjacency (f : Family) (p q : Nat) (i j : Fin p) (r s : Fin 7) :
    (physical f p q).Adj (TwoPool.ordinaryLeft p q i r) (TwoPool.ordinaryLeft p q j s) ↔
      i = j ∧ CentreOrdinary.graph.Adj r s :=
  TwoPool.left_adj (fixedGraph f) (leftCentre f) (rightCentre f) p q i j r s

theorem right_adjacency (f : Family) (p q : Nat) (i j : Fin q) (r s : Fin 7) :
    (physical f p q).Adj (TwoPool.ordinaryRight p q i r) (TwoPool.ordinaryRight p q j s) ↔
      i = j ∧ CentreOrdinary.graph.Adj r s :=
  TwoPool.right_adj (fixedGraph f) (leftCentre f) (rightCentre f) p q i j r s

theorem cross_pool_nonadjacency (f : Family) (p q : Nat)
    (i : Fin p) (j : Fin q) (r s : Fin 7) :
    ¬(physical f p q).Adj (TwoPool.ordinaryLeft p q i r)
      (TwoPool.ordinaryRight p q j s) :=
  TwoPool.left_right_adj (fixedGraph f) (leftCentre f) (rightCentre f) p q i j r s

theorem initial_fixed_mark (f : Family) (p q : Nat) (v : Fixed f) :
    TwoPool.fixed p q v ∈ initialMarks f p q ↔ v = centre f := by
  simp [initialMarks]

theorem initial_left_unmarked (f : Family) (p q : Nat) (i : Fin p) (r : Fin 7) :
    TwoPool.ordinaryLeft p q i r ∉ initialMarks f p q :=
  TwoPool.left_not_marked {centre f} p q i r

theorem initial_right_unmarked (f : Family) (p q : Nat) (i : Fin q) (r : Fin 7) :
    TwoPool.ordinaryRight p q i r ∉ initialMarks f p q :=
  TwoPool.right_not_marked {centre f} p q i r

end IsolationGame.FiveFamilyNewReconstruction
