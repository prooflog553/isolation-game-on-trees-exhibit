import CanonicalTrees

namespace IsolationGame.CanonicalLocal
open IsolatedRestriction PartitionBridge SmallPiece

theorem block_root_bound (t : Index) : ∀j : Block t,(blockData t j).rootLabel<size t := by
  cases t <;> decide +kernel

theorem block_end_bound (t : Index) : ∀j : Block t,
    (blockData t j).rootLabel+order (blockKind t j)≤size t := by
  cases t <;> decide +kernel

theorem block_root_positive (t : Index) : ∀j : Block t,0<(blockData t j).rootLabel := by
  cases t <;> decide +kernel

theorem block_range (t : Index) : ∀j : Block t,∀v : Fin (size t),
    v∈blockVertices t j ↔ (blockData t j).rootLabel≤v.val ∧ v.val<(blockData t j).rootLabel+order (blockKind t j) := by
  cases t <;> decide +kernel

def blockRoot (t : Index) (j : Block t) : Fin (size t) :=
  ⟨(blockData t j).rootLabel,block_root_bound t j⟩

theorem root_mem_block (t : Index) (j : Block t) : blockRoot t j∈blockVertices t j := by
  rw [block_range]
  have hpos : 0<order (blockKind t j) := (SmallPiece.root (blockKind t j)).isLt
  change (blockData t j).rootLabel≤(blockData t j).rootLabel ∧
    (blockData t j).rootLabel<(blockData t j).rootLabel+order (blockKind t j)
  omega

theorem root_not_block (t : Index) (j : Block t) : root t∉blockVertices t j := by
  rw [block_range]
  have hp := block_root_positive t j
  change ¬((blockData t j).rootLabel≤0 ∧ _)
  omega

theorem block_root_edge (t : Index) : ∀j : Block t,(graph t).Adj (root t) (blockRoot t j) := by
  cases t <;> decide +kernel

theorem block_cut (t : Index) : ∀j : Block t,
    OneBridge (graph t) (Finset.univ\blockVertices t j) (root t) (blockRoot t j) := by
  unfold OneBridge
  cases t <;> decide +kernel

theorem root_candidates (t : Index) : ∀v : Fin (size t),
    (graph t).Adj (root t) v ↔ ∃j : Block t,v=blockRoot t j := by
  cases t <;> decide +kernel

theorem roots_injective (t : Index) : Function.Injective (blockRoot t) := by
  change ∀j k,blockRoot t j=blockRoot t k→j=k
  cases t <;> decide +kernel

#print axioms block_range
#print axioms block_cut
#print axioms root_candidates
end IsolationGame.CanonicalLocal
