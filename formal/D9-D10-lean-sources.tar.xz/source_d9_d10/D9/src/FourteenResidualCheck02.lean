import FourteenResidualData

/-! Finite kernel arithmetic only: first profile fixed to t02.
All arithmetic is checked by kernel reduction; no graph or history search. -/
namespace IsolationGame.FourteenResidual
open CanonicalLocal
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

theorem check11_t02 (b : Index) :
    NumericResidual [.t02] [b] → MatchesFourteen [.t02] [b] := by
  cases b <;> decide +kernel

theorem check12_t02 (b c : Index) :
    NumericResidual [.t02] [b, c] → MatchesFourteen [.t02] [b, c] := by
  cases b <;> cases c <;> decide +kernel

#print axioms check11_t02
#print axioms check12_t02
end IsolationGame.FourteenResidual
