import BWCenterFollowers
namespace IsolationGame.BWBridge
open MarkedModule

 theorem whole_counts (n : Nat) : U (whole n)=n ∧ H (whole n)=0 ∧ E (whole n)=0 := by
  have hu : U (whole n)=Fintype.card (Fin n) := U_whole
  exact ⟨hu.trans (Fintype.card_fin n),H_whole,E_whole⟩

 theorem gated_whole_value (n : Nat) (t : Player) :
    Marked.gameValue MarkedModule.original (gatedMarks (whole n)) t ∅=3*n := by
  have h := GatedGraph.connected_value MarkedModule.owner MarkedModule.star (gatedState (whole n)) t
  change Marked.gameValue MarkedModule.original (gatedMarks (whole n)) t ∅=_ at h
  rw [h]
  cases t <;>
    simp [GatedGraph.playerTurn,Gated.Counts.value,Gated.Counts.d,Gated.Counts.s,Gated.State.counts,
      gated_P,gated_A,gated_sigma,(whole_counts n).1,(whole_counts n).2.1,(whole_counts n).2.2] <;> omega

 theorem pure_D (n : Nat) :
    Marked.gameValue (MarkedModule.original (B:=Fin n)) MarkedModule.initialMarks .dominator ∅=3*n := by
  simpa using MarkedModule.pure_D_value_all (B:=Fin n)

 theorem pure_live (n : Nat) (hn : 1≤n) :
    ¬Marked.Terminal (MarkedModule.original (B:=Fin n)) MarkedModule.initialMarks ∅ := by
  intro h
  have hz := (Marked.value_zero_iff_terminal _ _ _ .dominator).mpr h
  rw [pure_D] at hz; omega

 theorem left_center_D_bound (p q : Nat) (hq : 1≤q) :
    Marked.gameValue (original p q) (marks p q) .dominator {.inl (root p)}≤3*(p+q) := by
  rw [left_center_value p q hq]
  have h := MarkedSum.D_upper_right_value
    (MarkedModule.original (B:=Fin p)) (MarkedModule.original (B:=Fin q))
    (Marked.forest_no_minus _ (module_acyclic p)) (Marked.forest_no_minus _ (module_acyclic q))
    (gatedMarks (whole p)) ∅ MarkedModule.initialMarks ∅ (pure_live q hq)
  have he : MarkedSum.combine (∅ : Finset (Side p)) (∅ : Finset (Side q))=∅ := by
    simp [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight]
  rw [he] at h
  rw [gated_whole_value,pure_D] at h
  omega

 theorem right_center_D_bound (p q : Nat) (hp : 1≤p) (hq : 1≤q) :
    Marked.gameValue (original p q) (marks p q) .dominator {.inr (root q)}≤3*(p+q) := by
  rw [right_center_value p q hq]
  have h := (MarkedSum.forest_mixed_start_bounds
    (MarkedModule.original (B:=Fin p)) (MarkedModule.original (B:=Fin q))
    (module_acyclic p) (module_acyclic q)
    MarkedModule.initialMarks ∅ (gatedMarks (whole q)) ∅ (pure_live p hp)).1
  have he : MarkedSum.combine (∅ : Finset (Side p)) (∅ : Finset (Side q))=∅ := by
    simp [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight]
  rw [he] at h
  rw [gated_whole_value,pure_D] at h
  omega

#print axioms left_center_D_bound
#print axioms right_center_D_bound
end IsolationGame.BWBridge
