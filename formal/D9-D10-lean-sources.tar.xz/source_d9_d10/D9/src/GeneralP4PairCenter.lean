import GeneralP4SharperPieces

/-! Stronger-candidate infrastructure: select the actual shared centre, then
cut only edges whose endpoints are actually marked and regroup the unchanged
full carrier into base + a genuine disjoint pair of rootmarked T01s. -/
namespace IsolationGame.GeneralP4Receiver
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

abbrev pairGraph := MarkedSum.original P4Receiver.T P4Receiver.T
abbrev pairMarks := MarkedSum.combine ({0} : Finset (Fin 4)) ({0} : Finset (Fin 4))

theorem pair_acyclic : pairGraph.IsAcyclic := by
  let f : pairGraph →g P4Receiver.A P4Receiver.T 0 := {
    toFun := id
    map_rel' := by
      intro u v h
      cases u <;> cases v
      · exact h
      · exact False.elim h
      · exact False.elim h
      · exact h }
  intro v c hc
  exact attachment_acyclic P4Receiver.T 0 P4Receiver.t_acyclic
    (c.map f) (hc.map Function.injective_id)

section GenericPair
variable {V : Type} [Fintype V] [DecidableEq V]

abbrev doubleGraph (G : SimpleGraph V) (z : V) :=
  P4Receiver.A (P4Receiver.A G z) (Sum.inl z)
abbrev doubleMarks (M : Finset V) := P4Receiver.AM (P4Receiver.AM M)
abbrev tripleGraph (G : SimpleGraph V) :=
  MarkedSum.original (MarkedSum.original G P4Receiver.T) P4Receiver.T
abbrev tripleMarks (N : Finset V) :=
  MarkedSum.combine (MarkedSum.combine N ({0} : Finset (Fin 4))) ({0} : Finset (Fin 4))

theorem double_played_marks (G : SimpleGraph V) (z : V) (M : Finset V) :
    SelectedVertex.playedMarks (doubleGraph G z) (doubleMarks M) (.inl (.inl z)) =
      tripleMarks (SelectedVertex.playedMarks G M z) := by
  rw [Attachment.left_played_marks,Attachment.left_played_marks]
  simp only [Finset.insert_empty]

/-- Both actual bridge endpoints have been marked by the centre selection. -/
theorem double_center_cut (G : SimpleGraph V) (z : V) (M : Finset V) (t : Player) :
    Marked.gameValue (doubleGraph G z) (doubleMarks M) t {Sum.inl (Sum.inl z)} =
      Marked.gameValue (tripleGraph G)
        (tripleMarks (SelectedVertex.playedMarks G M z)) t ∅ := by
  have hroot : z∈SelectedVertex.playedMarks G M z :=
    (SelectedVertex.mem_playedMarks G M z z).mpr (Or.inr (Or.inl rfl))
  have hnot (v : V) (hv : v∉SelectedVertex.playedMarks G M z) : v≠z := by
    intro he
    exact hv (he.symm ▸ hroot)
  calc
    _ = Marked.gameValue (doubleGraph G z)
        (SelectedVertex.playedMarks (doubleGraph G z) (doubleMarks M) (.inl (.inl z))) t ∅ := by
      apply Marked.value_eq_of_white_eq
      intro v
      change Marked.White _ _ (insert (.inl (.inl z)) ∅) v ↔ _
      rw [SelectedVertex.absorb_white]
    _ = _ := by
      rw [double_played_marks]
      apply Marked.value_eq_of_adj_agree_unmarked
      intro u v hv
      rcases u with (u|u)|u
      all_goals rcases v with (v|v)|v
      all_goals simp only [tripleMarks,MarkedSum.combine_inl,MarkedSum.combine_inr,
        Finset.mem_singleton] at hv
      · rfl
      · simp [doubleGraph,P4Receiver.A,Attachment.original,tripleGraph,
          MarkedSum.original,MarkedSum.graph,Isolation.Graph.disjointSum,GuardedEdge.view,hv]
      · simp [doubleGraph,P4Receiver.A,Attachment.original,tripleGraph,
          MarkedSum.original,MarkedSum.graph,Isolation.Graph.disjointSum,GuardedEdge.view,hv]
      · have hvz := hnot v hv
        simp [doubleGraph,P4Receiver.A,Attachment.original,tripleGraph,
          MarkedSum.original,MarkedSum.graph,Isolation.Graph.disjointSum,GuardedEdge.view,hvz]
      · rfl
      · simp [doubleGraph,P4Receiver.A,Attachment.original,tripleGraph,
          MarkedSum.original,MarkedSum.graph,Isolation.Graph.disjointSum,GuardedEdge.view]
      · have hvz := hnot v hv
        simp [doubleGraph,P4Receiver.A,Attachment.original,tripleGraph,
          MarkedSum.original,MarkedSum.graph,Isolation.Graph.disjointSum,GuardedEdge.view,hvz]
      · simp [doubleGraph,P4Receiver.A,Attachment.original,tripleGraph,
          MarkedSum.original,MarkedSum.graph,Isolation.Graph.disjointSum,GuardedEdge.view]
      · rfl

abbrev tripleAssoc : (V ⊕ Fin 4) ⊕ Fin 4 ≃ V ⊕ (Fin 4 ⊕ Fin 4) :=
  Equiv.sumAssoc V (Fin 4) (Fin 4)

theorem tripleAssoc_adj (G : SimpleGraph V) (u v : (V ⊕ Fin 4) ⊕ Fin 4) :
    (MarkedSum.original G pairGraph).Adj (tripleAssoc u) (tripleAssoc v) ↔
      (tripleGraph G).Adj u v := by
  rcases u with (u|u)|u
  all_goals rcases v with (v|v)|v
  all_goals rfl

theorem image_mem_equiv {A B : Type} [DecidableEq A] [DecidableEq B]
    (e : A ≃ B) (X : Finset A) (v : B) : v∈X.image e ↔ e.symm v∈X := by
  constructor
  · rintro hv
    obtain ⟨u,hu,rfl⟩ := Finset.mem_image.mp hv
    simpa using hu
  · intro hv
    exact Finset.mem_image.mpr ⟨e.symm v,hv,e.apply_symm_apply v⟩

theorem tripleAssoc_marks (N : Finset V) :
    (tripleMarks N).image tripleAssoc = MarkedSum.combine N pairMarks := by
  classical
  ext v
  rw [image_mem_equiv]
  rcases v with v | (r|s)
  all_goals simp [tripleMarks,tripleAssoc,Equiv.sumAssoc,pairMarks]

/-- Two actual P4 attachments add three to the centre-played S bound. -/
theorem double_center_S (G : SimpleGraph V) (z : V) (M : Finset V)
    (hG : G.IsAcyclic) (n : Nat)
    (hp : Marked.gameValue G (SelectedVertex.playedMarks G M z) .staller ∅ ≤ n) :
    Marked.gameValue (doubleGraph G z) (doubleMarks M) .staller
      {Sum.inl (Sum.inl z)} ≤ n+3 := by
  rw [double_center_cut]
  have he := Marked.gameValue_relabel (tripleGraph G) (MarkedSum.original G pairGraph)
    tripleAssoc (tripleAssoc_adj G) (tripleMarks (SelectedVertex.playedMarks G M z)) ∅ .staller
  rw [tripleAssoc_marks,Finset.image_empty] at he
  rw [←he]
  have hsum := MarkedSum.S_upper_value G pairGraph
    (MarkedSum.forest_no_minus G hG) (MarkedSum.forest_no_minus pairGraph pair_acyclic)
    (SelectedVertex.playedMarks G M z) ∅ pairMarks ∅
  have hempty : MarkedSum.combine (∅ : Finset V) (∅ : Finset (Fin 4 ⊕ Fin 4)) = ∅ := by
    simp [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight]
  rw [hempty] at hsum
  have hpair : Marked.gameValue pairGraph pairMarks .staller ∅ ≤ 3 := rootmarked_T01_pair_S
  exact hsum.trans (Nat.add_le_add hp hpair)
end GenericPair

section StarPairTransport

/-- Lift a complete base graph relabeling through one literal P4 attachment. -/
theorem attachment_relabel_adj {V U : Type} [Fintype V] [DecidableEq V]
    [Fintype U] [DecidableEq U] (G : SimpleGraph V) (H : SimpleGraph U)
    (e : V ≃ U) (he : ∀u v,H.Adj (e u) (e v) ↔ G.Adj u v)
    (z : V) (w : U) (hr : e z=w) (u v : V ⊕ Fin 4) :
    (P4Receiver.A H w).Adj ((Equiv.sumCongr e (Equiv.refl _)) u)
      ((Equiv.sumCongr e (Equiv.refl _)) v) ↔ (P4Receiver.A G z).Adj u v := by
  have hroot (x : V) : e x=w ↔ x=z := by
    rw [←hr]
    exact e.injective.eq_iff
  cases u <;> cases v
  all_goals simp [P4Receiver.A,Attachment.original,he,hroot]

def doubleSplitEquiv (k p : Nat) : Vertex (k+2) p ≃
    (Vertex k p ⊕ Fin 4) ⊕ Fin 4 :=
  (splitEquiv (k+1) p).trans (Equiv.sumCongr (splitEquiv k p) (Equiv.refl _))

@[simp] theorem doubleSplit_centre (k p : Nat) :
    doubleSplitEquiv k p (centre (k+2) p) = .inl (.inl (centre k p)) := rfl

theorem doubleSplit_adj (k p : Nat) (u v : Vertex (k+2) p) :
    (doubleGraph (graph k p) (centre k p)).Adj (doubleSplitEquiv k p u)
      (doubleSplitEquiv k p v) ↔ (graph (k+2) p).Adj u v := by
  have h1 := splitEquiv_adj (k+1) p u v
  have h2 := attachment_relabel_adj (graph (k+1) p) (splitGraph k p) (splitEquiv k p)
    (splitEquiv_adj k p) (centre (k+1) p) (Sum.inl (centre k p)) rfl
    (splitEquiv (k+1) p u) (splitEquiv (k+1) p v)
  exact h2.trans h1

theorem doubleSplit_marks (k p : Nat) :
    (marks (k+2) p).image (doubleSplitEquiv k p) = doubleMarks (marks k p) := by
  simp [marks,TwoPool.marks,root,doubleSplitEquiv,splitEquiv,liftFixedEquiv,
    splitFixed,splitFixedTo,reassocEquiv,reassocTo,doubleMarks,P4Receiver.AM,
    MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight]

theorem value_doubleSplit (k p : Nat) (t : Player) (X : Finset (Vertex (k+2) p)) :
    Marked.gameValue (graph (k+2) p) (marks (k+2) p) t X =
      Marked.gameValue (doubleGraph (graph k p) (centre k p)) (doubleMarks (marks k p))
        t (X.image (doubleSplitEquiv k p)) := by
  rw [←doubleSplit_marks]
  exact (Marked.gameValue_relabel _ _ (doubleSplitEquiv k p) (doubleSplit_adj k p)
    (marks (k+2) p) X t).symm

theorem centre_pair_step (k p : Nat) (n : Nat)
    (hp : Marked.gameValue (graph k p)
      (SelectedVertex.playedMarks (graph k p) (marks k p) (centre k p)) .staller ∅ ≤ n) :
    Marked.gameValue (graph (k+2) p)
      (SelectedVertex.playedMarks (graph (k+2) p) (marks (k+2) p) (centre (k+2) p))
      .staller ∅ ≤ n+3 := by
  rw [←root_absorb,value_doubleSplit]
  change Marked.gameValue (doubleGraph (graph k p) (centre k p)) (doubleMarks (marks k p))
    .staller {Sum.inl (Sum.inl (centre k p))} ≤ n+3
  convert double_center_S (graph k p) (centre k p) (marks k p) (graph_acyclic k p) n hp using 1
  congr 1
end StarPairTransport

#print axioms double_center_cut
#print axioms tripleAssoc_adj
#print axioms tripleAssoc_marks
#print axioms double_center_S
#print axioms doubleSplit_adj
#print axioms value_doubleSplit
#print axioms centre_pair_step
end IsolationGame.GeneralP4Receiver
