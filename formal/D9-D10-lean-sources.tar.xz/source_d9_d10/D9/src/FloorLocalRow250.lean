import FloorLocalBase
import FloorLocalRow064
import FloorLocalRow066
import FloorLocalRow107
import FloorLocalRow108
import FloorLocalRow109
import FloorLocalRow158
import FloorLocalRow159
set_option maxRecDepth 4096
set_option maxHeartbeats 1000000
namespace IsolationGame.FloorLocal
def marks_250 : Finset (Fin 7) := {}
theorem normalized_250 : ∀v : Fin 7, Marked.White original_02 marks_250 ∅ v ↔ v∈({0,1,2,3,4,5,6} : Finset (Fin 7)) := by decide +kernel
theorem after_250_0 : Marked.gameValue original_02 marks_250 .dominator {0}=2 ∧ Marked.gameValue original_02 marks_250 .staller {0}=2 :=
  LocalProfile.DAG.transport original_02 marks_250 marks_108 0 2 2 (by decide +kernel) row_108
theorem after_250_1 : Marked.gameValue original_02 marks_250 .dominator {1}=1 ∧ Marked.gameValue original_02 marks_250 .staller {1}=2 :=
  LocalProfile.DAG.transport original_02 marks_250 marks_066 1 1 2 (by decide +kernel) row_066
theorem after_250_2 : Marked.gameValue original_02 marks_250 .dominator {2}=1 ∧ Marked.gameValue original_02 marks_250 .staller {2}=2 :=
  LocalProfile.DAG.transport original_02 marks_250 marks_109 2 1 2 (by decide +kernel) row_109
theorem after_250_3 : Marked.gameValue original_02 marks_250 .dominator {3}=1 ∧ Marked.gameValue original_02 marks_250 .staller {3}=2 :=
  LocalProfile.DAG.transport original_02 marks_250 marks_159 3 1 2 (by decide +kernel) row_159
theorem after_250_4 : Marked.gameValue original_02 marks_250 .dominator {4}=1 ∧ Marked.gameValue original_02 marks_250 .staller {4}=2 :=
  LocalProfile.DAG.transport original_02 marks_250 marks_064 4 1 2 (by decide +kernel) row_064
theorem after_250_5 : Marked.gameValue original_02 marks_250 .dominator {5}=1 ∧ Marked.gameValue original_02 marks_250 .staller {5}=2 :=
  LocalProfile.DAG.transport original_02 marks_250 marks_107 5 1 2 (by decide +kernel) row_107
theorem after_250_6 : Marked.gameValue original_02 marks_250 .dominator {6}=1 ∧ Marked.gameValue original_02 marks_250 .staller {6}=2 :=
  LocalProfile.DAG.transport original_02 marks_250 marks_158 6 1 2 (by decide +kernel) row_158
theorem row_250 : Marked.gameValue original_02 marks_250 .dominator ∅=3 ∧ Marked.gameValue original_02 marks_250 .staller ∅=3 := by
  apply LocalProfile.DAG.bellman original_02 marks_250 3 3 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_250_0.2]
  · rw [after_250_0.1]
  · intro v hv
    fin_cases v
    · have h := after_250_0
      change 3≤1+Marked.gameValue original_02 marks_250 .staller {0} ∧ 1+Marked.gameValue original_02 marks_250 .dominator {0}≤3
      omega
    · have h := after_250_1
      change 3≤1+Marked.gameValue original_02 marks_250 .staller {1} ∧ 1+Marked.gameValue original_02 marks_250 .dominator {1}≤3
      omega
    · have h := after_250_2
      change 3≤1+Marked.gameValue original_02 marks_250 .staller {2} ∧ 1+Marked.gameValue original_02 marks_250 .dominator {2}≤3
      omega
    · have h := after_250_3
      change 3≤1+Marked.gameValue original_02 marks_250 .staller {3} ∧ 1+Marked.gameValue original_02 marks_250 .dominator {3}≤3
      omega
    · have h := after_250_4
      change 3≤1+Marked.gameValue original_02 marks_250 .staller {4} ∧ 1+Marked.gameValue original_02 marks_250 .dominator {4}≤3
      omega
    · have h := after_250_5
      change 3≤1+Marked.gameValue original_02 marks_250 .staller {5} ∧ 1+Marked.gameValue original_02 marks_250 .dominator {5}≤3
      omega
    · have h := after_250_6
      change 3≤1+Marked.gameValue original_02 marks_250 .staller {6} ∧ 1+Marked.gameValue original_02 marks_250 .dominator {6}≤3
      omega
#print axioms row_250
end IsolationGame.FloorLocal
