import AllProfileSelectedBudget
import GenericCoreReceiverBound
import CoreReceiverDiameter
import AttachmentTreeGeometry

namespace IsolationGame.AllProfileReceiver
open AllProfileCore
abbrev Vertex (xs : List Nat) (q k p : Nat) := GenericCoreReceiver.Vertex (CoreFamily.Vertex xs q) k p
abbrev graph (xs : List Nat) (q k p : Nat) := GenericCoreReceiver.graph (CoreFamily.graph xs q) none k p

theorem graph_tree (xs : List Nat) (q k p : Nat) : (graph xs q k p).IsTree :=
  Attachment.original_tree _ _ none (GeneralP4Receiver.centre k p)
    (core_tree xs q) (GeneralP4Receiver.graph_tree k p)

theorem diam_le_nine (xs : List Nat) (q k p : Nat) : (graph xs q k p).diam ≤ 9 :=
  CoreReceiverGeometry.diam_le_nine xs q k p

theorem order (xs : List Nat) (q k p : Nat) :
    Fintype.card (Vertex xs q k p) = coreOrder xs+1+4*k+7*(p+q) :=
  GenericCoreReceiver.carrier_order (CoreFamily.graph xs q) none k p q (coreOrder xs) (core_order xs q)

theorem ordinary_scalar_upper (xs : List Nat) (q k p : Nat) :
    IsolationGame.isolationNumber (graph xs q k p) ≤ 3*(p+q)+(3*k)/2+cost xs+2 := by
  have h := GenericCoreReceiver.ordinary_scalar_upper (CoreFamily.graph xs q) none
    (core_tree xs q).IsAcyclic k p q (cost xs) (root_selected_S xs q)
  convert h using 1 <;> congr 1 <;> apply Subsingleton.elim

theorem ordinary_floor (xs : List Nat) (q k p : Nat)
    (hfloor : 7*((3*k)/2+cost xs+2) ≤ 3*(coreOrder xs+1+4*k)) :
    IsolationGame.isolationNumber (graph xs q k p) ≤ 3*Fintype.card (Vertex xs q k p)/7 := by
  rw [order]
  exact (ordinary_scalar_upper xs q k p).trans
    (GenericCoreReceiver.scalar_floor_condition k p q (coreOrder xs) (cost xs) hfloor)

theorem even_floor_condition (xs : List Nat) (m : Nat) :
    7*((3*(2*m))/2+cost xs+2) ≤ 3*(coreOrder xs+1+4*(2*m)) ↔
      7*cost xs+11 ≤ 3*coreOrder xs+3*m := by omega

theorem odd_floor_condition (xs : List Nat) (m : Nat) :
    7*((3*(2*m+1))/2+cost xs+2) ≤ 3*(coreOrder xs+1+4*(2*m+1)) ↔
      7*cost xs+6 ≤ 3*coreOrder xs+3*m := by omega

theorem family_tree_diameter_order_bounds (xs : List Nat) (q k p : Nat)
    (hfloor : 7*((3*k)/2+cost xs+2) ≤ 3*(coreOrder xs+1+4*k)) :
    (graph xs q k p).IsTree ∧ (graph xs q k p).diam ≤ 9 ∧
    Fintype.card (Vertex xs q k p) = coreOrder xs+1+4*k+7*(p+q) ∧
    IsolationGame.isolationNumber (graph xs q k p) ≤ 3*(p+q)+(3*k)/2+cost xs+2 ∧
    3*(p+q)+(3*k)/2+cost xs+2 ≤ 3*Fintype.card (Vertex xs q k p)/7 := by
  refine ⟨graph_tree xs q k p,diam_le_nine xs q k p,order xs q k p,ordinary_scalar_upper xs q k p,?_⟩
  rw [order]
  exact GenericCoreReceiver.scalar_floor_condition k p q (coreOrder xs) (cost xs) hfloor

#print axioms graph_tree
#print axioms diam_le_nine
#print axioms order
#print axioms ordinary_scalar_upper
#print axioms ordinary_floor
#print axioms even_floor_condition
#print axioms odd_floor_condition
#print axioms family_tree_diameter_order_bounds
end IsolationGame.AllProfileReceiver
