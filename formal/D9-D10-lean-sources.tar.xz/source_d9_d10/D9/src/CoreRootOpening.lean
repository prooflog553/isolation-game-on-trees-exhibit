import CoreForestBounds

namespace IsolationGame.CoreForest
open CanonicalLocal CoreFamily CoreFamilySemantics IsolatedRestriction
variable (xs : List Nat) (p : Nat)

theorem closed_roots_nonwhite (W : LocalWhite xs p) :
    ∀i,¬closeCentre xs p W i (root (label xs p i)) :=
  fun _ h=>h.1.2 rfl

/-- An ACTUAL legal centre opening, followed by an actual separated-forest
bound. The neighbours marked by that selection are retained in closeCentre;
no naive deletion of the selected centre/history is used. -/
theorem root_opening_upper (W : LocalWhite xs p) (hn : Normalized xs p W)
    (hl : ∃i,W i (root (label xs p i))) (k : Nat)
    (hk : Marked.gameValue (forest xs p) (forestMarks xs p (closeCentre xs p W)) .staller ∅≤k) :
    Marked.gameValue (CoreFamily.graph xs p) (marks xs p W) .dominator ∅≤1+k := by
  have hlegal := (actual_legal_root xs p W hn).mpr hl
  have hm := Marked.d_move_upper (CoreFamily.graph xs p) (marks xs p W) ∅ none hlegal
  have hn' : Normalized xs p (closeCentre xs p W) := next_normalized xs p W hn none
  have he := original_next_value xs p W hn none .staller
  change Marked.gameValue (CoreFamily.graph xs p) (marks xs p W) .staller {none}=
    Marked.gameValue (CoreFamily.graph xs p) (marks xs p (closeCentre xs p W)) .staller ∅ at he
  rw [free_root_value xs p _ hn' (closed_roots_nonwhite xs p W)] at he
  simp only [Finset.insert_empty] at hm
  rw [he] at hm
  omega

theorem terminal_value (W : LocalWhite xs p) (hn : Normalized xs p W)
    (hw : ∀i u,¬W i u) (turn : Player) :
    Marked.gameValue (CoreFamily.graph xs p) (marks xs p W) turn ∅=0 := by
  apply (Marked.value_zero_iff_terminal _ _ _ _).mpr
  intro v hv
  have h := (original_white xs p W hn v).mp hv
  cases v with
  | none => exact h
  | some v => obtain ⟨i,u⟩ := v;exact hw i u h

/-- Forest no-minus is used only after genuine separation. -/
theorem forest_d_of_s (hA : (CoreFamily.graph xs p).IsAcyclic) (W : LocalWhite xs p)
    (k : Nat) (hk : Marked.gameValue (forest xs p) (forestMarks xs p W) .staller ∅≤k) :
    Marked.gameValue (forest xs p) (forestMarks xs p W) .dominator ∅≤k :=
  (Marked.forest_no_minus (forest xs p) (forest_acyclic xs p hA) (forestMarks xs p W) ∅).trans hk

#print axioms root_opening_upper
#print axioms terminal_value
#print axioms forest_d_of_s
end IsolationGame.CoreForest
