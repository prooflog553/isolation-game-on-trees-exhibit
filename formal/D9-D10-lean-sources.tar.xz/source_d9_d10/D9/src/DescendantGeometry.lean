import DescendantContract

namespace IsolationGame.DescendantGeometry
open PartitionBridge
variable {V : Type} [Fintype V] [DecidableEq V]

/-- A cross edge into the distance-defined descendants must reach b itself. -/
theorem crossing_child (G : SimpleGraph V) (hT : G.IsTree) (r b a c : V)
    (ha : G.dist r a≠G.dist r b+G.dist b a)
    (hc : G.dist r c=G.dist r b+G.dist b c) (hac : G.Adj a c) : c=b := by
  have hrlevels := tree_adj_levels hT r hac
  have hblevels := tree_adj_levels hT b hac
  rw [G.dist_comm (u:=a) (v:=r),G.dist_comm (u:=c) (v:=r)] at hrlevels
  rw [G.dist_comm (u:=a) (v:=b),G.dist_comm (u:=c) (v:=b)] at hblevels
  have htri := hT.isConnected.dist_triangle (u:=r) (v:=b) (w:=a)
  have hparent : G.dist r a+1=G.dist r c := by omega
  by_contra hcb
  obtain ⟨w,hw,_⟩ := exists_unique_parent hT b hcb
  have hcw := hw.1
  have hdw := hw.2
  rw [G.dist_comm (u:=w) (v:=b),G.dist_comm (u:=c) (v:=b)] at hdw
  have hwtri := hT.isConnected.dist_triangle (u:=r) (v:=b) (w:=w)
  have hwlevels := tree_adj_levels hT r hcw
  rw [G.dist_comm (u:=c) (v:=r),G.dist_comm (u:=w) (v:=r)] at hwlevels
  have hwparent : G.dist w r+1=G.dist c r := by
    rw [G.dist_comm (u:=w) (v:=r),G.dist_comm (u:=c) (v:=r)]
    omega
  have haparent : G.dist a r+1=G.dist c r := by
    rw [G.dist_comm (u:=a) (v:=r),G.dist_comm (u:=c) (v:=r)]
    exact hparent
  have he : a=w := unique_lower_neighbor hT r hac.symm hcw haparent hwparent
  subst w
  omega

theorem descendant_partition_spec (G : SimpleGraph V) (hT : G.IsTree)
    (r z b : V) (hzb : G.Adj z b)
    (hdepth : G.dist r b=G.dist r z+1) : Spec G r z b := by
  have hz : z∈retained G r b := by
    simp only [retained,Finset.mem_filter,Finset.mem_univ,true_and]
    omega
  have hr : r∈retained G r b := by
    simp only [retained,Finset.mem_filter,Finset.mem_univ,true_and,G.dist_self]
    omega
  have hb : b∉retained G r b := by simp [retained]
  have hcross : OneBridge G (retained G r b) z b := by
    intro a c ha hc
    have ha' : G.dist r a≠G.dist r b+G.dist b a := by simpa [retained] using ha
    have hc' : G.dist r c=G.dist r b+G.dist b c := by simpa [retained] using hc
    constructor
    · intro hac
      have hec := crossing_child G hT r b a c ha' hc' hac
      subst c
      have hl := tree_adj_levels hT r hac
      rw [G.dist_comm (u:=a) (v:=r),G.dist_comm (u:=b) (v:=r)] at hl
      have hab := SimpleGraph.dist_eq_one_iff_adj.mpr hac.symm
      have hap : G.dist a r+1=G.dist b r := by
        rw [G.dist_comm (u:=a) (v:=r),G.dist_comm (u:=b) (v:=r)]
        omega
      have hzp : G.dist z r+1=G.dist b r := by
        rw [G.dist_comm (u:=z) (v:=r),G.dist_comm (u:=b) (v:=r)]
        omega
      exact ⟨unique_lower_neighbor hT r hac.symm hzb.symm hap hzp,rfl⟩
    · rintro ⟨rfl,rfl⟩;exact hzb
  let B := outside (retained G r b)
  have hbB : b∈B := by simp [B,outside,hb]
  have hreverse : OneBridge G B b z := by
    intro a c ha hc
    have ha' : a∉retained G r b := by simpa [B,outside] using ha
    have hc' : c∈retained G r b := by simpa [B,outside] using hc
    constructor
    · intro hac
      have he := (hcross c a hc' ha').mp hac.symm
      exact he.symm
    · rintro ⟨rfl,rfl⟩;exact hzb.symm
  have htB := retained_tree G hT B b z hbB hreverse
  refine ⟨hz,hr,hb,hcross,htB,?_⟩
  intro v
  apply Nat.le_antisymm
  · exact retained_distance_le G hT.isConnected B b z hreverse b hbB v
  · obtain ⟨q,hq,hlen⟩ := htB.isConnected.exists_path_of_dist (⟨b,hbB⟩ : Side B) v
    let f : IsolatedRestriction.induced G B →g G := ⟨Subtype.val,by intro u v h;exact h⟩
    have hh := SimpleGraph.dist_le (q.map f)
    rw [SimpleGraph.Walk.length_map,hlen] at hh
    exact hh

#check @descendant_partition_spec
#print descendant_partition_spec
#print axioms descendant_partition_spec
end IsolationGame.DescendantGeometry
