import FullCanonical03Rows01
namespace IsolationGame.FullCanonical.T03
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_8 : Finset (Fin 10) := {1,2,3,5,6}
theorem after_8_0 : Marked.gameValue original marks_8 .dominator {0}=1 ∧ Marked.gameValue original marks_8 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_2 0 1 1 (by decide +kernel) row_2
theorem after_8_1 : Marked.gameValue original marks_8 .dominator {1}=1 ∧ Marked.gameValue original marks_8 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_4 1 1 2 (by decide +kernel) row_4
theorem after_8_4 : Marked.gameValue original marks_8 .dominator {4}=1 ∧ Marked.gameValue original marks_8 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_4 4 1 2 (by decide +kernel) row_4
theorem after_8_5 : Marked.gameValue original marks_8 .dominator {5}=1 ∧ Marked.gameValue original marks_8 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_7 5 1 2 (by decide +kernel) row_7
theorem after_8_7 : Marked.gameValue original marks_8 .dominator {7}=0 ∧ Marked.gameValue original marks_8 .staller {7}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_0 7 0 0 (by decide +kernel) row_0
theorem after_8_8 : Marked.gameValue original marks_8 .dominator {8}=1 ∧ Marked.gameValue original marks_8 .staller {8}=1 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_8 marks_1 8 1 1 (by decide +kernel) row_1
theorem after_8_9 : Marked.gameValue original marks_8 .dominator {9}=1 ∧ Marked.gameValue original marks_8 .staller {9}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_3 9 1 2 (by decide +kernel) row_3
theorem row_8 : Marked.gameValue original marks_8 .dominator ∅=1 ∧ Marked.gameValue original marks_8 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_8 1 2 7 0 (by decide +kernel) (by decide +kernel)
  · rw [after_8_7.2]
  · rw [after_8_0.1]
  · intro v hv
    fin_cases v
    · have h := after_8_0
      change 1 ≤ 1+Marked.gameValue original marks_8 .staller {0} ∧ 1+Marked.gameValue original marks_8 .dominator {0} ≤ 2
      omega
    · have h := after_8_1
      change 1 ≤ 1+Marked.gameValue original marks_8 .staller {1} ∧ 1+Marked.gameValue original marks_8 .dominator {1} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_8 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_8 ∅ 3) hv)
    · have h := after_8_4
      change 1 ≤ 1+Marked.gameValue original marks_8 .staller {4} ∧ 1+Marked.gameValue original marks_8 .dominator {4} ≤ 2
      omega
    · have h := after_8_5
      change 1 ≤ 1+Marked.gameValue original marks_8 .staller {5} ∧ 1+Marked.gameValue original marks_8 .dominator {5} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_8 ∅ 6) hv)
    · have h := after_8_7
      change 1 ≤ 1+Marked.gameValue original marks_8 .staller {7} ∧ 1+Marked.gameValue original marks_8 .dominator {7} ≤ 2
      omega
    · have h := after_8_8
      change 1 ≤ 1+Marked.gameValue original marks_8 .staller {8} ∧ 1+Marked.gameValue original marks_8 .dominator {8} ≤ 2
      omega
    · have h := after_8_9
      change 1 ≤ 1+Marked.gameValue original marks_8 .staller {9} ∧ 1+Marked.gameValue original marks_8 .dominator {9} ≤ 2
      omega
def marks_9 : Finset (Fin 10) := {0,1,4,7}
theorem after_9_1 : Marked.gameValue original marks_9 .dominator {1}=2 ∧ Marked.gameValue original marks_9 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_9 marks_6 1 2 2 (by decide +kernel) row_6
theorem after_9_2 : Marked.gameValue original marks_9 .dominator {2}=2 ∧ Marked.gameValue original marks_9 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_9 marks_6 2 2 2 (by decide +kernel) row_6
theorem after_9_3 : Marked.gameValue original marks_9 .dominator {3}=2 ∧ Marked.gameValue original marks_9 .staller {3}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_9 marks_6 3 2 2 (by decide +kernel) row_6
theorem after_9_4 : Marked.gameValue original marks_9 .dominator {4}=2 ∧ Marked.gameValue original marks_9 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_9 marks_6 4 2 2 (by decide +kernel) row_6
theorem after_9_5 : Marked.gameValue original marks_9 .dominator {5}=2 ∧ Marked.gameValue original marks_9 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_9 marks_6 5 2 2 (by decide +kernel) row_6
theorem after_9_6 : Marked.gameValue original marks_9 .dominator {6}=2 ∧ Marked.gameValue original marks_9 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_9 marks_6 6 2 2 (by decide +kernel) row_6
theorem after_9_7 : Marked.gameValue original marks_9 .dominator {7}=2 ∧ Marked.gameValue original marks_9 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_9 marks_6 7 2 2 (by decide +kernel) row_6
theorem after_9_8 : Marked.gameValue original marks_9 .dominator {8}=2 ∧ Marked.gameValue original marks_9 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_9 marks_6 8 2 2 (by decide +kernel) row_6
theorem after_9_9 : Marked.gameValue original marks_9 .dominator {9}=2 ∧ Marked.gameValue original marks_9 .staller {9}=2 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_9 marks_6 9 2 2 (by decide +kernel) row_6
theorem row_9 : Marked.gameValue original marks_9 .dominator ∅=3 ∧ Marked.gameValue original marks_9 .staller ∅=3 := by
  apply LocalProfile.DAG.bellman original marks_9 3 3 1 1 (by decide +kernel) (by decide +kernel)
  · rw [after_9_1.2]
  · rw [after_9_1.1]
  · intro v hv
    fin_cases v
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_9 ∅ 0) hv)
    · have h := after_9_1
      change 3 ≤ 1+Marked.gameValue original marks_9 .staller {1} ∧ 1+Marked.gameValue original marks_9 .dominator {1} ≤ 3
      omega
    · have h := after_9_2
      change 3 ≤ 1+Marked.gameValue original marks_9 .staller {2} ∧ 1+Marked.gameValue original marks_9 .dominator {2} ≤ 3
      omega
    · have h := after_9_3
      change 3 ≤ 1+Marked.gameValue original marks_9 .staller {3} ∧ 1+Marked.gameValue original marks_9 .dominator {3} ≤ 3
      omega
    · have h := after_9_4
      change 3 ≤ 1+Marked.gameValue original marks_9 .staller {4} ∧ 1+Marked.gameValue original marks_9 .dominator {4} ≤ 3
      omega
    · have h := after_9_5
      change 3 ≤ 1+Marked.gameValue original marks_9 .staller {5} ∧ 1+Marked.gameValue original marks_9 .dominator {5} ≤ 3
      omega
    · have h := after_9_6
      change 3 ≤ 1+Marked.gameValue original marks_9 .staller {6} ∧ 1+Marked.gameValue original marks_9 .dominator {6} ≤ 3
      omega
    · have h := after_9_7
      change 3 ≤ 1+Marked.gameValue original marks_9 .staller {7} ∧ 1+Marked.gameValue original marks_9 .dominator {7} ≤ 3
      omega
    · have h := after_9_8
      change 3 ≤ 1+Marked.gameValue original marks_9 .staller {8} ∧ 1+Marked.gameValue original marks_9 .dominator {8} ≤ 3
      omega
    · have h := after_9_9
      change 3 ≤ 1+Marked.gameValue original marks_9 .staller {9} ∧ 1+Marked.gameValue original marks_9 .dominator {9} ≤ 3
      omega
def marks_10 : Finset (Fin 10) := {2,3,5,6}
theorem after_10_0 : Marked.gameValue original marks_10 .dominator {0}=1 ∧ Marked.gameValue original marks_10 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_10 marks_2 0 1 1 (by decide +kernel) row_2
theorem after_10_1 : Marked.gameValue original marks_10 .dominator {1}=1 ∧ Marked.gameValue original marks_10 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_10 marks_4 1 1 2 (by decide +kernel) row_4
theorem after_10_2 : Marked.gameValue original marks_10 .dominator {2}=1 ∧ Marked.gameValue original marks_10 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_10 marks_8 2 1 2 (by decide +kernel) row_8
theorem after_10_4 : Marked.gameValue original marks_10 .dominator {4}=1 ∧ Marked.gameValue original marks_10 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_10 marks_4 4 1 2 (by decide +kernel) row_4
theorem after_10_5 : Marked.gameValue original marks_10 .dominator {5}=1 ∧ Marked.gameValue original marks_10 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_10 marks_8 5 1 2 (by decide +kernel) row_8
theorem after_10_7 : Marked.gameValue original marks_10 .dominator {7}=0 ∧ Marked.gameValue original marks_10 .staller {7}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_10 marks_0 7 0 0 (by decide +kernel) row_0
theorem after_10_8 : Marked.gameValue original marks_10 .dominator {8}=1 ∧ Marked.gameValue original marks_10 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_10 marks_3 8 1 2 (by decide +kernel) row_3
theorem after_10_9 : Marked.gameValue original marks_10 .dominator {9}=1 ∧ Marked.gameValue original marks_10 .staller {9}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_10 marks_5 9 1 2 (by decide +kernel) row_5
theorem row_10 : Marked.gameValue original marks_10 .dominator ∅=1 ∧ Marked.gameValue original marks_10 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_10 1 2 7 0 (by decide +kernel) (by decide +kernel)
  · rw [after_10_7.2]
  · rw [after_10_0.1]
  · intro v hv
    fin_cases v
    · have h := after_10_0
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {0} ∧ 1+Marked.gameValue original marks_10 .dominator {0} ≤ 2
      omega
    · have h := after_10_1
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {1} ∧ 1+Marked.gameValue original marks_10 .dominator {1} ≤ 2
      omega
    · have h := after_10_2
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {2} ∧ 1+Marked.gameValue original marks_10 .dominator {2} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_10 ∅ 3) hv)
    · have h := after_10_4
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {4} ∧ 1+Marked.gameValue original marks_10 .dominator {4} ≤ 2
      omega
    · have h := after_10_5
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {5} ∧ 1+Marked.gameValue original marks_10 .dominator {5} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_10 ∅ 6) hv)
    · have h := after_10_7
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {7} ∧ 1+Marked.gameValue original marks_10 .dominator {7} ≤ 2
      omega
    · have h := after_10_8
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {8} ∧ 1+Marked.gameValue original marks_10 .dominator {8} ≤ 2
      omega
    · have h := after_10_9
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {9} ∧ 1+Marked.gameValue original marks_10 .dominator {9} ≤ 2
      omega
def marks_11 : Finset (Fin 10) := {0,1,2,3}
theorem after_11_0 : Marked.gameValue original marks_11 .dominator {0}=2 ∧ Marked.gameValue original marks_11 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_11 marks_6 0 2 2 (by decide +kernel) row_6
theorem after_11_4 : Marked.gameValue original marks_11 .dominator {4}=1 ∧ Marked.gameValue original marks_11 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_11 marks_4 4 1 2 (by decide +kernel) row_4
theorem after_11_5 : Marked.gameValue original marks_11 .dominator {5}=1 ∧ Marked.gameValue original marks_11 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_11 marks_4 5 1 2 (by decide +kernel) row_4
theorem after_11_6 : Marked.gameValue original marks_11 .dominator {6}=1 ∧ Marked.gameValue original marks_11 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_11 marks_4 6 1 2 (by decide +kernel) row_4
theorem after_11_7 : Marked.gameValue original marks_11 .dominator {7}=1 ∧ Marked.gameValue original marks_11 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_11 marks_4 7 1 2 (by decide +kernel) row_4
theorem after_11_8 : Marked.gameValue original marks_11 .dominator {8}=1 ∧ Marked.gameValue original marks_11 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_11 marks_4 8 1 2 (by decide +kernel) row_4
theorem after_11_9 : Marked.gameValue original marks_11 .dominator {9}=1 ∧ Marked.gameValue original marks_11 .staller {9}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_11 marks_4 9 1 2 (by decide +kernel) row_4
theorem row_11 : Marked.gameValue original marks_11 .dominator ∅=3 ∧ Marked.gameValue original marks_11 .staller ∅=3 := by
  apply LocalProfile.DAG.bellman original marks_11 3 3 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_11_0.2]
  · rw [after_11_0.1]
  · intro v hv
    fin_cases v
    · have h := after_11_0
      change 3 ≤ 1+Marked.gameValue original marks_11 .staller {0} ∧ 1+Marked.gameValue original marks_11 .dominator {0} ≤ 3
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_11 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_11 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_11 ∅ 3) hv)
    · have h := after_11_4
      change 3 ≤ 1+Marked.gameValue original marks_11 .staller {4} ∧ 1+Marked.gameValue original marks_11 .dominator {4} ≤ 3
      omega
    · have h := after_11_5
      change 3 ≤ 1+Marked.gameValue original marks_11 .staller {5} ∧ 1+Marked.gameValue original marks_11 .dominator {5} ≤ 3
      omega
    · have h := after_11_6
      change 3 ≤ 1+Marked.gameValue original marks_11 .staller {6} ∧ 1+Marked.gameValue original marks_11 .dominator {6} ≤ 3
      omega
    · have h := after_11_7
      change 3 ≤ 1+Marked.gameValue original marks_11 .staller {7} ∧ 1+Marked.gameValue original marks_11 .dominator {7} ≤ 3
      omega
    · have h := after_11_8
      change 3 ≤ 1+Marked.gameValue original marks_11 .staller {8} ∧ 1+Marked.gameValue original marks_11 .dominator {8} ≤ 3
      omega
    · have h := after_11_9
      change 3 ≤ 1+Marked.gameValue original marks_11 .staller {9} ∧ 1+Marked.gameValue original marks_11 .dominator {9} ≤ 3
      omega
end IsolationGame.FullCanonical.T03
