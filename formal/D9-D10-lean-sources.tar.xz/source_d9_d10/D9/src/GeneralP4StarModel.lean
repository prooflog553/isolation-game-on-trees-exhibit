import GeneralP4AttachmentForest
import TwoPoolForestExhaustion
import FiniteTreeCertificate

/-! Explicit full carrier for k P4 branches and a one-pool ordinary P7 family.
Branch index 0 is peeled off by an actual bijection, with all other indices
shifted by Fin.succ. The marked centre remains an original selectable vertex.
Source preparation only; no native elaboration or all-k proof claim yet. -/
namespace IsolationGame.GeneralP4Receiver
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

abbrev Fixed (k : Nat) := Option (Fin k × Fin 4)
def root (k : Nat) : Fixed k := none

def fixedGraph (k : Nat) : SimpleGraph (Fixed k) where
  Adj
    | none, none => False
    | none, some (_,r) => r=0
    | some (_,r), none => r=0
    | some (i,r), some (j,s) => i=j ∧ P4Receiver.T.Adj r s
  symm := by
    intro u v h
    cases u with
    | none => cases v <;> exact h
    | some u =>
      rcases u with ⟨i,r⟩
      cases v with
      | none => exact h
      | some v =>
        rcases v with ⟨j,s⟩
        exact ⟨h.1.symm, P4Receiver.T.symm h.2⟩
  loopless := by
    intro u h
    cases u with
    | none => exact h
    | some u =>
      rcases u with ⟨i,r⟩
      exact P4Receiver.T.loopless r h.2

instance fixedGraphDecidable (k : Nat) : DecidableRel (fixedGraph k).Adj := by
  intro u v
  rcases u with _ | ⟨i,r⟩
  all_goals rcases v with _ | ⟨j,s⟩
  all_goals (dsimp [fixedGraph]; infer_instance)

def splitFixedTo (k : Nat) : Fixed (k+1) → Fixed k ⊕ Fin 4
  | none => .inl none
  | some (i,r) => Fin.cases (.inr r) (fun j => .inl (some (j,r))) i

def splitFixedFrom (k : Nat) : Fixed k ⊕ Fin 4 → Fixed (k+1)
  | .inl none => none
  | .inl (some (i,r)) => some (i.succ,r)
  | .inr r => some (0,r)

def splitFixed (k : Nat) : Fixed (k+1) ≃ Fixed k ⊕ Fin 4 where
  toFun := splitFixedTo k
  invFun := splitFixedFrom k
  left_inv := by
    intro v
    cases v with
    | none => rfl
    | some v =>
      rcases v with ⟨i,r⟩
      induction i using Fin.cases with
      | zero => rfl
      | succ i => rfl
  right_inv := by
    intro v
    cases v with
    | inl v => cases v <;> rfl
    | inr r => rfl

@[simp] theorem splitFixed_root (k : Nat) :
    splitFixed k (root (k+1)) = .inl (root k) := rfl
@[simp] theorem splitFixed_zero (k : Nat) (r : Fin 4) :
    splitFixed k (some (0,r)) = .inr r := rfl
@[simp] theorem splitFixed_succ (k : Nat) (i : Fin k) (r : Fin 4) :
    splitFixed k (some (i.succ,r)) = .inl (some (i,r)) := rfl

/-- Full adjacency equivalence, including the literal centre-to-P4 bridge. -/
theorem splitFixed_adj (k : Nat) (u v : Fixed (k+1)) :
    (Attachment.original (fixedGraph k) P4Receiver.T (root k) 0).Adj
      (splitFixed k u) (splitFixed k v) ↔ (fixedGraph (k+1)).Adj u v := by
  cases u with
  | none =>
    cases v with
    | none => rfl
    | some v =>
      rcases v with ⟨j,s⟩
      induction j using Fin.cases with
      | zero => simp [splitFixed,splitFixedTo,Attachment.original,fixedGraph,root]
      | succ j => simp [splitFixed,splitFixedTo,Attachment.original,fixedGraph,root]
  | some u =>
    rcases u with ⟨i,r⟩
    cases v with
    | none =>
      induction i using Fin.cases with
      | zero => simp [splitFixed,splitFixedTo,Attachment.original,fixedGraph,root]
      | succ i => simp [splitFixed,splitFixedTo,Attachment.original,fixedGraph,root]
    | some v =>
      rcases v with ⟨j,s⟩
      induction i using Fin.cases with
      | zero =>
        induction j using Fin.cases with
        | zero => simp [splitFixed,splitFixedTo,Attachment.original,fixedGraph,root]
        | succ j =>
          have hj : (0 : Fin (k+1)) ≠ j.succ := fun h => Fin.succ_ne_zero j h.symm
          simp [splitFixed,splitFixedTo,Attachment.original,fixedGraph,root,hj]
      | succ i =>
        induction j using Fin.cases with
        | zero => simp [splitFixed,splitFixedTo,Attachment.original,fixedGraph,root]
        | succ j => simp [splitFixed,splitFixedTo,Attachment.original,fixedGraph,root]

private theorem fixed_zero_tree : (fixedGraph 0).IsTree :=
  CanonicalLocal.tree_of_certificate (fixedGraph 0) (root 0)
    (by unfold CanonicalLocal.ReachThree; decide +kernel) (by decide +kernel)

theorem fixed_acyclic (k : Nat) : (fixedGraph k).IsAcyclic := by
  induction k with
  | zero => exact fixed_zero_tree.IsAcyclic
  | succ k ih =>
    apply G2Family.acyclic_transport
      (Attachment.original (fixedGraph k) P4Receiver.T (root k) 0)
      (fixedGraph (k+1)) (splitFixed k).symm
    · intro u v
      simpa using (splitFixed_adj k ((splitFixed k).symm u) ((splitFixed k).symm v)).symm
    · exact attachment_acyclic (fixedGraph k) (root k) ih

abbrev Vertex (k p : Nat) := TwoPool.Vertex (Fixed k) p 0
def graph (k p : Nat) : SimpleGraph (Vertex k p) :=
  TwoPool.graph (fixedGraph k) (root k) (root k) p 0
def marks (k p : Nat) : Finset (Vertex k p) :=
  TwoPool.marks ({root k} : Finset (Fixed k)) p 0
def fixed (k p : Nat) (v : Fixed k) : Vertex k p := TwoPool.fixed p 0 v
def centre (k p : Nat) : Vertex k p := fixed k p (root k)
def branch (k p : Nat) (i : Fin k) (r : Fin 4) : Vertex k p := fixed k p (some (i,r))
def ordinary (k p : Nat) (i : Fin p) (r : Fin 7) : Vertex k p :=
  TwoPool.ordinaryLeft p 0 i r

theorem graph_acyclic (k p : Nat) : (graph k p).IsAcyclic :=
  TwoPool.graph_acyclic (fixedGraph k) (fixed_acyclic k) (root k) (root k) p 0

theorem root_marked (k p : Nat) : centre k p ∈ marks k p := by
  simp [centre,fixed,marks]

theorem order (k p : Nat) : Fintype.card (Vertex k p) = 1+4*k+7*p := by
  have h := TwoPool.original_order (F:=Fixed k) p 0
  simpa [Vertex,Fixed,Nat.mul_comm,Nat.add_comm,Nat.add_left_comm,Nat.add_assoc] using h

#print axioms splitFixed_adj
#print axioms fixed_acyclic
#print axioms graph_acyclic
#print axioms order
end IsolationGame.GeneralP4Receiver
