import CoreFamilyInitial

namespace IsolationGame.CoreFamilySemantics
open CanonicalLocal CoreFamily Isolation.Graph
variable (xs : List Nat) (p : Nat)

def closeCentre (W : LocalWhite xs p) : LocalWhite xs p := fun i=>
  (GuardedEdge.view (CanonicalLocal.graph (label xs p i))).noniso
    (fun v=>W i v ∧ v≠root (label xs p i))

def playLocal (W : LocalWhite xs p) (i : Fin (xs.length+p)) (u : Fin (size (label xs p i))) :
    LocalWhite xs p :=
  Function.update W i ((GuardedEdge.view (CanonicalLocal.graph (label xs p i))).step (W i) u)

def next (W : LocalWhite xs p) : Vertex xs p→LocalWhite xs p
  | none => closeCentre xs p W
  | some ⟨i,u⟩ => playLocal xs p W i u

theorem next_normalized (W : LocalWhite xs p) (hn : Normalized xs p W) (v : Vertex xs p) :
    Normalized xs p (next xs p W v) := by
  cases v with
  | none =>
    intro i
    funext u
    exact propext ((GuardedEdge.view (CanonicalLocal.graph (label xs p i))).normalize_idempotent _ u)
  | some v =>
    obtain ⟨i,u⟩ := v
    intro j
    by_cases h : j=i
    · subst j
      simp only [next,playLocal,Function.update_self]
      funext w
      exact propext ((GuardedEdge.view (CanonicalLocal.graph (label xs p i))).normalize_idempotent _ w)
    · simp only [next,playLocal,Function.update_of_ne h]
      exact hn j

theorem step_eq_next (W : LocalWhite xs p) (hn : Normalized xs p W) (v : Vertex xs p) :
    (GuardedEdge.view (CoreFamily.graph xs p)).step (white xs p W) v=white xs p (next xs p W v) := by
  funext w
  apply propext
  cases w with
  | none => exact iff_of_false (step_root_nonwhite xs p W v) id
  | some w =>
    obtain ⟨j,t⟩ := w
    cases v with
    | none => exact step_centre xs p W j t
    | some v =>
      obtain ⟨i,u⟩ := v
      by_cases h : j=i
      · subst j
        simp only [next,white,playLocal,Function.update_self]
        exact step_same xs p W i u t
      · simp only [next,white,playLocal,Function.update_of_ne h]
        exact step_other xs p W hn i j (Ne.symm h) u t

/-- The deterministic indexed-copy transition is exactly the original marked
one-move follower, for EVERY original action vertex, even if already blue.
No legality hypothesis is necessary for the state identity itself. -/
theorem original_next_white (W : LocalWhite xs p) (hn : Normalized xs p W)
    (v w : Vertex xs p) :
    Marked.White (CoreFamily.graph xs p) (marks xs p W) {v} w ↔
      Marked.White (CoreFamily.graph xs p) (marks xs p (next xs p W v)) ∅ w := by
  rw [actual_follower_white xs p W hn,step_eq_next xs p W hn]
  exact (original_white xs p _ (next_normalized xs p W hn v) w).symm

theorem original_next_value (W : LocalWhite xs p) (hn : Normalized xs p W)
    (v : Vertex xs p) (turn : Player) :
    Marked.gameValue (CoreFamily.graph xs p) (marks xs p W) turn {v}=
      Marked.gameValue (CoreFamily.graph xs p) (marks xs p (next xs p W v)) turn ∅ :=
  Marked.value_eq_of_white_eq _ _ _ _ _ turn (original_next_white xs p W hn v)

#print axioms next_normalized
#print axioms step_eq_next
#print axioms original_next_white
#print axioms original_next_value
end IsolationGame.CoreFamilySemantics
