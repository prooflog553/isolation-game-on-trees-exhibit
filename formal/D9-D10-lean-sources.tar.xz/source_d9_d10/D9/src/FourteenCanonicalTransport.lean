import CoreJoinedNormalization
import FourteenResidualClassifier

/-!
SOURCE_ONLY, not elaborated or accepted. Future compilation is gated by root
acceptance of every pending provider and explicit authorization of a free slot.

The classifier works with decoded Index lists, whereas complete cores use raw
Nat lists. We bridge them by equality of every canonical label, then genuine
List.Perm. Cardinality equality is a consequence of the full graph iso, never
its construction. Invalid raw codes retain their decoded t00 branch.
-/
namespace IsolationGame.FourteenCounterexample
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
open CanonicalLocal NecessaryCore FourteenResidual

/-- Canonical codes of an Index list, with repetitions and order retained. -/
def codes (ts : List Index) : List Nat := ts.map code

/-- Decoding and recoding changes names of raw labels, not branches or vertices. -/
def canonicalCodes (xs : List Nat) : List Nat := codes (xs.map decode)

/-- Extend any exact tail reindexing by heads with equal decoded labels. -/
def decodedHeadReindex {xs ys : List Nat} {p q : Nat}
    (e : CoreFamily.LabelReindex xs p ys q) (n m : Nat)
    (hnm : decode n = decode m) :
    CoreFamily.LabelReindex (n::xs) p (m::ys) q where
  indexEquiv := (CoreFamily.headTailEquiv n xs p).symm.trans
    ((Equiv.optionCongr e.indexEquiv).trans (CoreFamily.headTailEquiv m ys q))
  label_eq := by
    intro i
    obtain ⟨a,rfl⟩ := (CoreFamily.headTailEquiv n xs p).surjective i
    simp only [Equiv.trans_apply,Equiv.symm_apply_apply]
    cases a with
    | none =>
      change CoreFamily.label (n::xs) p (CoreFamily.headIndex n xs p) =
        CoreFamily.label (m::ys) q (CoreFamily.headIndex m ys q)
      rw [CoreFamily.label_headIndex,CoreFamily.label_headIndex]
      exact hnm
    | some a =>
      change CoreFamily.label (n::xs) p (CoreFamily.tailIndex n xs p a) =
        CoreFamily.label (m::ys) q (CoreFamily.tailIndex m ys q (e.indexEquiv a))
      rw [CoreFamily.label_tailIndex,CoreFamily.label_tailIndex]
      exact e.label_eq a

/-- Constructed by exact labels on the complete dependent carrier. -/
def canonicalLabelReindex : (xs : List Nat) → (p : Nat) →
    CoreFamily.LabelReindex xs p (canonicalCodes xs) p
  | [], p => CoreFamily.LabelReindex.refl [] p
  | n::xs, p => decodedHeadReindex (canonicalLabelReindex xs p) n
      (code (decode n)) (decode_code (decode n)).symm

def canonicalIso (xs : List Nat) (p : Nat) :
    CoreFamily.graph xs p ≃g CoreFamily.graph (canonicalCodes xs) p :=
  (canonicalLabelReindex xs p).graphIso

@[simp] theorem canonicalIso_root (xs : List Nat) (p : Nat) :
    canonicalIso xs p none = none := rfl

/-- Consume the classifier's actual permutation, mapped through code. -/
noncomputable def decodedPermutationIso (xs : List Nat) (row : List Index) (p : Nat)
    (h : (xs.map decode).Perm row) :
    CoreFamily.graph xs p ≃g CoreFamily.graph (codes row) p :=
  (canonicalIso xs p).trans (CoreFamily.permutationIso (h.map code) p)

@[simp] theorem decodedPermutationIso_root (xs : List Nat) (row : List Index) (p : Nat)
    (h : (xs.map decode).Perm row) : decodedPermutationIso xs row p h none = none := rfl

/-- Lift both rooted label/permutation isomorphisms through the literal bridge. -/
noncomputable def joinedDecodedPermutationIso (xs ys : List Nat)
    (left right : List Index) (p q : Nat)
    (hl : (xs.map decode).Perm left) (hr : (ys.map decode).Perm right) :
    TwoCoreOpening.graph xs ys p q ≃g
      TwoCoreOpening.graph (codes left) (codes right) p q :=
  OriginalIsoTransport.attachmentIso _ _ _ _ none none none none
    (decodedPermutationIso xs left p hl) (decodedPermutationIso ys right q hr) rfl rfl

@[simp] theorem joinedDecodedPermutationIso_leftRoot (xs ys : List Nat)
    (left right : List Index) (p q : Nat)
    (hl : (xs.map decode).Perm left) (hr : (ys.map decode).Perm right) :
    joinedDecodedPermutationIso xs ys left right p q hl hr (.inl none) = .inl none := rfl

@[simp] theorem joinedDecodedPermutationIso_rightRoot (xs ys : List Nat)
    (left right : List Index) (p q : Nat)
    (hl : (xs.map decode).Perm left) (hr : (ys.map decode).Perm right) :
    joinedDecodedPermutationIso xs ys left right p q hl hr (.inr none) = .inr none := rfl

/-- Side exchange swaps both raw lists and their own ordinary multiplicities. -/
def swapIso (xs ys : List Nat) (p q : Nat) :
    TwoCoreOpening.graph xs ys p q ≃g TwoCoreOpening.graph ys xs q p where
  toEquiv := Equiv.sumComm _ _
  map_rel_iff' := by
    intro u v
    cases u <;> cases v <;> rfl

@[simp] theorem swapIso_leftRoot (xs ys : List Nat) (p q : Nat) :
    swapIso xs ys p q (.inl none) = .inr none := rfl

@[simp] theorem swapIso_rightRoot (xs ys : List Nat) (p q : Nat) :
    swapIso xs ys p q (.inr none) = .inl none := rfl

abbrev PatternVertex (k : Pattern) (p q : Nat) :=
  TwoCoreOpening.Vertex (codes k.left) (codes k.right) p q

abbrev patternGraph (k : Pattern) (p q : Nat) : SimpleGraph (PatternVertex k p q) :=
  TwoCoreOpening.graph (codes k.left) (codes k.right) p q

/-- A complete graph certificate, with the pool transformation explicitly recorded. -/
theorem exists_patternIso (xs ys : List Nat) (p q : Nat)
    (h : MatchesFourteen (xs.map decode) (ys.map decode)) :
    ∃ (k : Pattern) (p' q' : Nat),
      ((p'=p ∧ q'=q) ∨ (p'=q ∧ q'=p)) ∧
      Nonempty (TwoCoreOpening.graph xs ys p q ≃g patternGraph k p' q') := by
  obtain ⟨k,h | h⟩ := matchesFourteen_perms h
  · exact ⟨k,p,q,Or.inl ⟨rfl,rfl⟩,
      ⟨joinedDecodedPermutationIso xs ys k.left k.right p q h.1 h.2⟩⟩
  · exact ⟨k,q,p,Or.inr ⟨rfl,rfl⟩,
      ⟨(swapIso xs ys p q).trans
        (joinedDecodedPermutationIso ys xs k.left k.right q p h.2 h.1)⟩⟩

/-- Card and value are transported by the same original graph isomorphism. -/
theorem strict_counter_transport {V U : Type}
    [Fintype V] [DecidableEq V] [Fintype U] [DecidableEq U]
    (G : SimpleGraph V) (H : SimpleGraph U) (e : G ≃g H)
    (h : (3*Fintype.card V+6)/7 < isolationNumber G) :
    (3*Fintype.card U+6)/7 < isolationNumber H := by
  have hCard := Fintype.card_congr e.toEquiv
  have hValue := OriginalIsoTransport.isolationNumber_eq G H e
  rw [←hCard,←hValue]
  exact h

theorem ceiling_transport {V U : Type}
    [Fintype V] [DecidableEq V] [Fintype U] [DecidableEq U]
    (G : SimpleGraph V) (H : SimpleGraph U) (e : G ≃g H)
    (h : isolationNumber G ≤ (3*Fintype.card V+6)/7) :
    isolationNumber H ≤ (3*Fintype.card U+6)/7 := by
  have hCard := Fintype.card_congr e.toEquiv
  have hValue := OriginalIsoTransport.isolationNumber_eq G H e
  rw [←hCard,←hValue]
  exact h

#print axioms canonicalLabelReindex
#print axioms canonicalIso
#print axioms decodedPermutationIso
#print axioms joinedDecodedPermutationIso
#print axioms swapIso
#print axioms exists_patternIso
#print axioms strict_counter_transport
#print axioms ceiling_transport
end IsolationGame.FourteenCounterexample
