import ForestProtectedGeometry
import GeometryNoMinus

namespace IsolationGame.Marked
variable {V : Type} [Fintype V] [DecidableEq V] (G : SimpleGraph V)

/-- Every partially marked finite ORIGINAL forest has D≤S, for arbitrary
initial marks and selected histories. No geometric/value premise remains. -/
theorem forest_no_minus (hA : G.IsAcyclic) (M X : Finset V) :
    gameValue G M .dominator X ≤ gameValue G M .staller X :=
  ForestFoundation.no_minus_of_geometry G (ForestGeometry.forest_protected_edge_spec G hA) M X

theorem forest_value_sandwich (hA : G.IsAcyclic) (M X : Finset V) :
    gameValue G M .dominator X ≤ gameValue G M .staller X ∧
      gameValue G M .staller X ≤ gameValue G M .dominator X+1 :=
  ⟨forest_no_minus G hA M X,starting_player_inequality G M X⟩

#print forest_no_minus
#print axioms forest_no_minus
#print axioms forest_value_sandwich
end IsolationGame.Marked
