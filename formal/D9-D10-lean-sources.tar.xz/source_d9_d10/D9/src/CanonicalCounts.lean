import CanonicalAssembly
import NineteenParameters

namespace IsolationGame.CanonicalLocal
open SmallPiece

theorem countKind_equiv {A B : Type} [Fintype A] [Fintype B] [DecidableEq A] [DecidableEq B]
    (e : A≃B) (f : A→Kind) (g : B→Kind) (hf : ∀a,f a=g (e a)) (k : Kind) :
    countKind f Finset.univ k=countKind g Finset.univ k := by
  have he : ((Finset.univ.filter (fun a=>f a=k)).image e)=Finset.univ.filter (fun b=>g b=k) := by
    ext b
    simp only [Finset.mem_image,Finset.mem_filter,Finset.mem_univ,true_and]
    constructor
    · rintro ⟨a,ha,rfl⟩
      rw [←hf a]
      exact ha
    · intro hb
      refine ⟨e.symm b,?_,e.apply_symm_apply b⟩
      rw [hf,e.apply_symm_apply]
      exact hb
  have hc := Finset.card_image_of_injective (Finset.univ.filter (fun a=>f a=k)) e.injective
  rw [he] at hc
  exact hc.symm

theorem block_counts (t : Index) :
    (countKind (blockKind t) Finset.univ .leaf,countKind (blockKind t) Finset.univ .edge,
      countKind (blockKind t) Finset.univ .fork,countKind (blockKind t) Finset.univ .long)=parameters t := by
  cases t <;> decide +kernel

/-- Exact actual child-model counts of every canonical ORIGINAL graph. -/
theorem canonical_parameters (t : Index) :
    SmallPiece.parameters (graph t) (root t) (canonical_models t)=parameters t := by
  have hc (k : Kind) : countKind (canonical_models t).kind Finset.univ k=countKind (blockKind t) Finset.univ k :=
    countKind_equiv (childEnum t) (canonical_models t).kind (blockKind t) (by intro a;rfl) k
  change (countKind (canonical_models t).kind Finset.univ .leaf,countKind (canonical_models t).kind Finset.univ .edge,
    countKind (canonical_models t).kind Finset.univ .fork,countKind (canonical_models t).kind Finset.univ .long)=parameters t
  rw [hc,hc,hc,hc]
  exact block_counts t

def allIndices : List Index := [.t00,.t01,.t02,.t03,.t04,.t05,.t06,.t07,.t08,.t09,.t10,.t11,.t12,.t13,.t14,.t15,.t16,.t17,.t18,.t19]

theorem parameter_table : allIndices.map parameters=SmallPiece.allowedParams := by decide +kernel

theorem parameters_injective : Function.Injective parameters := by
  change ∀t u,parameters t=parameters u→t=u
  decide +kernel

theorem canonical_index_exists (p : Nat×Nat×Nat×Nat) (hp : p∈SmallPiece.allowedParams) :
    ∃t : Index,parameters t=p := by
  rw [←parameter_table] at hp
  obtain ⟨t,_,he⟩ := List.mem_map.mp hp
  exact ⟨t,he⟩

#print axioms canonical_parameters
#print axioms canonical_index_exists
end IsolationGame.CanonicalLocal
