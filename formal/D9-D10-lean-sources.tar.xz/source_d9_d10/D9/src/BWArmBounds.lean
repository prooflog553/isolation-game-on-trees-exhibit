import BWArmNormalization
import InertLeaf

namespace IsolationGame.BWBridge
open Isolation.Graph
open MarkedModule

/-- Two insertions are used only to compute the normalized white set.
Legality, and hence whether the second insertion represents an actual move,
is handled separately below. -/
theorem two_selected_white (p q : Nat) (hq : 1 ≤ q) (v w : Vertex p q) :
    Marked.White (original p q) (marks p q) {w,v} =
      (view p q).step ((view p q).step (initialWhite p q) v) w := by
  have h₁ := ForestFoundation.marked_white_step (original p q) (marks p q) ∅ v
  have h₂ := ForestFoundation.marked_white_step (original p q) (marks p q) {v} w
  rw [initial_white p q hq] at h₁
  simp only [Finset.insert_empty] at h₁
  exact h₂.symm.trans (congrArg (fun W => (view p q).step W w) h₁.symm)

theorem left_arm_root_value (p q : Nat) (hq : 1 ≤ q)
    (i : Fin p) (a : Arm) (s : Bool) (t : Player) :
    Marked.gameValue (original p q) (marks p q) t
      {(.inl (root p)),(.inl (arm a i s))} =
      Marked.gameValue (MarkedSum.original MarkedModule.original MarkedModule.original)
        (MarkedSum.combine (gatedMarks (set (whole p) i (.reserve (!s))))
          (MarkedModule.initialMarks (B:=Fin q))) t ∅ := by
  apply split_value p q _ _ _ _
    (gatedWhite (set (whole p) i (.reserve (!s)))) (white (whole q))
  · exact (two_selected_white p q hq _ _).trans (after_left_arm_root p q i a s)
  · exact gated_marks_white _
  · exact pure_white q
  · simp [root,gatedWhite,GatedGraph.stateWhite,GatedGraph.white]
  · simp [root,white]

theorem right_arm_root_value (p q : Nat) (hq : 1 ≤ q)
    (i : Fin q) (a : Arm) (s : Bool) (t : Player) :
    Marked.gameValue (original p q) (marks p q) t
      {(.inr (root q)),(.inr (arm a i s))} =
      Marked.gameValue (MarkedSum.original MarkedModule.original MarkedModule.original)
        (MarkedSum.combine (MarkedModule.initialMarks (B:=Fin p))
          (gatedMarks (set (whole q) i (.reserve (!s))))) t ∅ := by
  apply split_value p q _ _ _ _
    (white (whole p)) (gatedWhite (set (whole q) i (.reserve (!s))))
  · exact (two_selected_white p q hq _ _).trans (after_right_arm_root p q i a s)
  · exact pure_white p
  · exact gated_marks_white _
  · simp [root,white]
  · simp [root,gatedWhite,GatedGraph.stateWhite,GatedGraph.white]

theorem arm_reserve_counts (n : Nat) (i : Fin n) (s : Bool) :
    U (set (whole n) i (.reserve s)) + 1 = n ∧
    H (set (whole n) i (.reserve s)) = 1 ∧
    E (set (whole n) i (.reserve s)) = 0 := by
  have hu := whole_reserve_U (whole n) i s rfl
  have hh := whole_reserve_H (whole n) i s rfl
  have he := whole_reserve_E (whole n) i s rfl
  rw [(whole_counts n).1] at hu
  rw [(whole_counts n).2.1] at hh
  rw [(whole_counts n).2.2] at he
  exact ⟨hu,by simpa using hh,he⟩

theorem left_arm_root_S_bound (p q : Nat) (hq : 1 ≤ q)
    (i : Fin p) (a : Arm) (s : Bool) :
    Marked.gameValue (original p q) (marks p q) .staller
      {(.inl (root p)),(.inl (arm a i s))} ≤ 3*(p+q)-1 := by
  rw [left_arm_root_value p q hq]
  have hc := arm_reserve_counts p i (!s)
  have h := odd_left_module_S_bound p q _ hc.2.1
  omega

theorem right_arm_root_S_bound (p q : Nat) (hq : 1 ≤ q)
    (i : Fin q) (a : Arm) (s : Bool) :
    Marked.gameValue (original p q) (marks p q) .staller
      {(.inr (root q)),(.inr (arm a i s))} ≤ 3*(p+q)-1 := by
  rw [right_arm_root_value p q hq]
  have hc := arm_reserve_counts q i (!s)
  have h := odd_right_module_S_bound p q _ hc.2.1
  omega

theorem split_D_le_S (p q : Nat) (N : Finset (Side p)) (K : Finset (Side q)) :
    Marked.gameValue (MarkedSum.original MarkedModule.original MarkedModule.original)
      (MarkedSum.combine N K) .dominator ∅ ≤
    Marked.gameValue (MarkedSum.original MarkedModule.original MarkedModule.original)
      (MarkedSum.combine N K) .staller ∅ := by
  have h := MarkedSum.sum_d_le_s
    (MarkedModule.original (B:=Fin p)) (MarkedModule.original (B:=Fin q))
    (Marked.forest_no_minus _ (module_acyclic p))
    (Marked.forest_no_minus _ (module_acyclic q)) N ∅ K ∅
  simpa [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight] using h

/-- A legal proposed reply costs one actual move. An illegal proposed reply
costs no move and may only be inserted for white-set equality. -/
theorem response_or_inert_bound {V : Type} [Fintype V] [DecidableEq V]
    (G : SimpleGraph V) (M X : Finset V) (v : V) (k : Nat)
    (hs : Marked.gameValue G M .staller (insert v X) ≤ k)
    (hds : Marked.gameValue G M .dominator (insert v X) ≤
      Marked.gameValue G M .staller (insert v X)) :
    Marked.gameValue G M .dominator X ≤ k+1 := by
  by_cases hv : Marked.Legal G M X v
  · have h := Marked.d_move_upper G M X v hv
    omega
  · have hw := MarkedLeaf.illegal_white_insert G M X v hv
    have he : Marked.gameValue G M .dominator X =
        Marked.gameValue G M .dominator (insert v X) := by
      apply Marked.value_eq_of_white_eq
      intro w
      rw [hw]
    rw [he]
    omega

theorem left_arm_D_bound (p q : Nat) (hp : 1 ≤ p) (hq : 1 ≤ q)
    (i : Fin p) (a : Arm) (s : Bool) :
    Marked.gameValue (original p q) (marks p q) .dominator
      {(.inl (arm a i s))} ≤ 3*(p+q) := by
  have hs := left_arm_root_S_bound p q hq i a s
  have hds : Marked.gameValue (original p q) (marks p q) .dominator
      {(.inl (root p)),(.inl (arm a i s))} ≤
      Marked.gameValue (original p q) (marks p q) .staller
      {(.inl (root p)),(.inl (arm a i s))} := by
    rw [left_arm_root_value p q hq, left_arm_root_value p q hq]
    exact split_D_le_S p q _ _
  have h := response_or_inert_bound (original p q) (marks p q)
    {(.inl (arm a i s))} (.inl (root p)) (3*(p+q)-1) hs hds
  omega

theorem right_arm_D_bound (p q : Nat) (hp : 1 ≤ p) (hq : 1 ≤ q)
    (i : Fin q) (a : Arm) (s : Bool) :
    Marked.gameValue (original p q) (marks p q) .dominator
      {(.inr (arm a i s))} ≤ 3*(p+q) := by
  have hs := right_arm_root_S_bound p q hq i a s
  have hds : Marked.gameValue (original p q) (marks p q) .dominator
      {(.inr (root q)),(.inr (arm a i s))} ≤
      Marked.gameValue (original p q) (marks p q) .staller
      {(.inr (root q)),(.inr (arm a i s))} := by
    rw [right_arm_root_value p q hq, right_arm_root_value p q hq]
    exact split_D_le_S p q _ _
  have h := response_or_inert_bound (original p q) (marks p q)
    {(.inr (arm a i s))} (.inr (root q)) (3*(p+q)-1) hs hds
  omega

#print axioms left_arm_D_bound
#print axioms right_arm_D_bound
end IsolationGame.BWBridge
