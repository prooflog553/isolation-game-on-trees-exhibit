import CanonicalData
import ProfileAudit

namespace IsolationGame.CanonicalLocal

def expectedD : Index→Nat
  | .t00=>0
  | .t01=>1
  | .t02=>3
  | .t03=>4
  | .t04=>5
  | .t05=>6
  | .t06=>1
  | .t07=>3
  | .t08=>4
  | .t09=>3
  | .t10=>1
  | .t11=>2
  | .t12=>3
  | .t13=>0
  | .t14=>1
  | .t15=>3
  | .t16=>4
  | .t17=>1
  | .t18=>3
  | .t19=>1

def expectedS : Index→Nat
  | .t00=>0
  | .t01=>2
  | .t02=>3
  | .t03=>4
  | .t04=>5
  | .t05=>6
  | .t06=>2
  | .t07=>3
  | .t08=>5
  | .t09=>3
  | .t10=>1
  | .t11=>2
  | .t12=>4
  | .t13=>0
  | .t14=>2
  | .t15=>3
  | .t16=>4
  | .t17=>2
  | .t18=>3
  | .t19=>1

def pairable : Index→Bool
  | .t00=>false
  | .t01=>true
  | .t02=>false
  | .t03=>false
  | .t04=>false
  | .t05=>false
  | .t06=>true
  | .t07=>false
  | .t08=>true
  | .t09=>false
  | .t10=>false
  | .t11=>false
  | .t12=>true
  | .t13=>false
  | .t14=>true
  | .t15=>false
  | .t16=>false
  | .t17=>true
  | .t18=>false
  | .t19=>false

theorem D_value (t : Index) : Marked.gameValue (graph t) {root t} .dominator ∅=expectedD t := by
  cases t with
  | t00 => exact LocalProfile.e0E0D0L0.D_value
  | t01 => exact LocalProfile.e0E0D0L1.D_value
  | t02 => exact LocalProfile.e0E0D0L2.D_value
  | t03 => exact LocalProfile.e0E0D0L3.D_value
  | t04 => exact LocalProfile.e0E0D0L4.D_value
  | t05 => exact LocalProfile.e0E0D0L5.D_value
  | t06 => exact LocalProfile.e0E0D1L0.D_value
  | t07 => exact LocalProfile.e0E0D1L1.D_value
  | t08 => exact LocalProfile.e0E0D1L2.D_value
  | t09 => exact LocalProfile.e0E0D2L0.D_value
  | t10 => exact LocalProfile.e0E1D0L0.D_value
  | t11 => exact LocalProfile.e0E1D0L1.D_value
  | t12 => exact LocalProfile.e0E1D0L2.D_value
  | t13 => exact LocalProfile.e1E0D0L0.D_value
  | t14 => exact LocalProfile.e1E0D0L1.D_value
  | t15 => exact LocalProfile.e1E0D0L2.D_value
  | t16 => exact LocalProfile.e1E0D0L3.D_value
  | t17 => exact LocalProfile.e1E0D1L0.D_value
  | t18 => exact LocalProfile.e1E0D1L1.D_value
  | t19 => exact LocalProfile.e1E1D0L0.D_value

theorem S_value (t : Index) : Marked.gameValue (graph t) {root t} .staller ∅=expectedS t := by
  cases t with
  | t00 => exact LocalProfile.e0E0D0L0.S_value
  | t01 => exact LocalProfile.e0E0D0L1.S_value
  | t02 => exact LocalProfile.e0E0D0L2.S_value
  | t03 => exact LocalProfile.e0E0D0L3.S_value
  | t04 => exact LocalProfile.e0E0D0L4.S_value
  | t05 => exact LocalProfile.e0E0D0L5.S_value
  | t06 => exact LocalProfile.e0E0D1L0.S_value
  | t07 => exact LocalProfile.e0E0D1L1.S_value
  | t08 => exact LocalProfile.e0E0D1L2.S_value
  | t09 => exact LocalProfile.e0E0D2L0.S_value
  | t10 => exact LocalProfile.e0E1D0L0.S_value
  | t11 => exact LocalProfile.e0E1D0L1.S_value
  | t12 => exact LocalProfile.e0E1D0L2.S_value
  | t13 => exact LocalProfile.e1E0D0L0.S_value
  | t14 => exact LocalProfile.e1E0D0L1.S_value
  | t15 => exact LocalProfile.e1E0D0L2.S_value
  | t16 => exact LocalProfile.e1E0D0L3.S_value
  | t17 => exact LocalProfile.e1E0D1L0.S_value
  | t18 => exact LocalProfile.e1E0D1L1.S_value
  | t19 => exact LocalProfile.e1E1D0L0.S_value

theorem strict_exact (t : Index) : MarkedSum.StrictCapacity (graph t) {root t} ∅ (expectedS t) ↔ pairable t=true := by
  cases t with
  | t00 =>
    constructor
    · intro h;exact False.elim (LocalProfile.e0E0D0L0.strict_profile h)
    · intro h;cases h
  | t01 =>
    exact ⟨fun _=>rfl,fun _=>LocalProfile.e0E0D0L1.strict_profile⟩
  | t02 =>
    constructor
    · intro h;exact False.elim (LocalProfile.e0E0D0L2.strict_profile h)
    · intro h;cases h
  | t03 =>
    constructor
    · intro h;exact False.elim (LocalProfile.e0E0D0L3.strict_profile h)
    · intro h;cases h
  | t04 =>
    constructor
    · intro h;exact False.elim (LocalProfile.e0E0D0L4.strict_profile h)
    · intro h;cases h
  | t05 =>
    constructor
    · intro h;exact False.elim (LocalProfile.e0E0D0L5.strict_profile h)
    · intro h;cases h
  | t06 =>
    exact ⟨fun _=>rfl,fun _=>LocalProfile.e0E0D1L0.strict_profile⟩
  | t07 =>
    constructor
    · intro h;exact False.elim (LocalProfile.e0E0D1L1.strict_profile h)
    · intro h;cases h
  | t08 =>
    exact ⟨fun _=>rfl,fun _=>LocalProfile.e0E0D1L2.strict_profile⟩
  | t09 =>
    constructor
    · intro h;exact False.elim (LocalProfile.e0E0D2L0.strict_profile h)
    · intro h;cases h
  | t10 =>
    constructor
    · intro h;exact False.elim (LocalProfile.e0E1D0L0.strict_profile h)
    · intro h;cases h
  | t11 =>
    constructor
    · intro h;exact False.elim (LocalProfile.e0E1D0L1.strict_profile h)
    · intro h;cases h
  | t12 =>
    exact ⟨fun _=>rfl,fun _=>LocalProfile.e0E1D0L2.strict_profile⟩
  | t13 =>
    constructor
    · intro h;exact False.elim (LocalProfile.e1E0D0L0.strict_profile h)
    · intro h;cases h
  | t14 =>
    exact ⟨fun _=>rfl,fun _=>LocalProfile.e1E0D0L1.strict_profile⟩
  | t15 =>
    constructor
    · intro h;exact False.elim (LocalProfile.e1E0D0L2.strict_profile h)
    · intro h;cases h
  | t16 =>
    constructor
    · intro h;exact False.elim (LocalProfile.e1E0D0L3.strict_profile h)
    · intro h;cases h
  | t17 =>
    exact ⟨fun _=>rfl,fun _=>LocalProfile.e1E0D1L0.strict_profile⟩
  | t18 =>
    constructor
    · intro h;exact False.elim (LocalProfile.e1E0D1L1.strict_profile h)
    · intro h;cases h
  | t19 =>
    constructor
    · intro h;exact False.elim (LocalProfile.e1E1D0L0.strict_profile h)
    · intro h;cases h

def defect (t : Index) : Int := 7*(expectedS t : Int)-3*(size t : Int)

theorem defect_bounds : ∀t : Index,
    (pairable t=true→defect t≤2) ∧ (t≠.t02→pairable t=false→defect t≤(-2 : Int)) := by decide +kernel

theorem ordinary_data : expectedD .t02=3 ∧ expectedS .t02=3 ∧ size .t02=7 ∧ pairable .t02=false ∧ defect .t02=0 := by decide +kernel

theorem only_ordinary_zero_defect : ∀t : Index,defect t=0 ↔ t=.t02 := by decide +kernel

#print axioms D_value
#print axioms S_value
#print axioms strict_exact
#print axioms defect_bounds
end IsolationGame.CanonicalLocal
