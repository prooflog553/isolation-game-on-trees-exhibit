import FullCanonical04Rows03
namespace IsolationGame.FullCanonical.T04
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_16 : Finset (Fin 13) := {1,2,3,5,6}
theorem after_16_0 : Marked.gameValue original marks_16 .dominator {0}=2 ∧ Marked.gameValue original marks_16 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_6 0 2 2 (by decide +kernel) row_6
theorem after_16_1 : Marked.gameValue original marks_16 .dominator {1}=3 ∧ Marked.gameValue original marks_16 .staller {1}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_12 1 3 3 (by decide +kernel) row_12
theorem after_16_4 : Marked.gameValue original marks_16 .dominator {4}=3 ∧ Marked.gameValue original marks_16 .staller {4}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_12 4 3 3 (by decide +kernel) row_12
theorem after_16_5 : Marked.gameValue original marks_16 .dominator {5}=3 ∧ Marked.gameValue original marks_16 .staller {5}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_14 5 3 4 (by decide +kernel) row_14
theorem after_16_7 : Marked.gameValue original marks_16 .dominator {7}=1 ∧ Marked.gameValue original marks_16 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_4 7 1 2 (by decide +kernel) row_4
theorem after_16_8 : Marked.gameValue original marks_16 .dominator {8}=1 ∧ Marked.gameValue original marks_16 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_16 marks_9 8 1 2 (by decide +kernel) row_9
theorem after_16_9 : Marked.gameValue original marks_16 .dominator {9}=1 ∧ Marked.gameValue original marks_16 .staller {9}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_11 9 1 2 (by decide +kernel) row_11
theorem after_16_10 : Marked.gameValue original marks_16 .dominator {10}=1 ∧ Marked.gameValue original marks_16 .staller {10}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_16 marks_4 10 1 2 (by decide +kernel) row_4
theorem after_16_11 : Marked.gameValue original marks_16 .dominator {11}=1 ∧ Marked.gameValue original marks_16 .staller {11}=2 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_16 marks_9 11 1 2 (by decide +kernel) row_9
theorem after_16_12 : Marked.gameValue original marks_16 .dominator {12}=1 ∧ Marked.gameValue original marks_16 .staller {12}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_16 marks_11 12 1 2 (by decide +kernel) row_11
theorem row_16 : Marked.gameValue original marks_16 .dominator ∅=3 ∧ Marked.gameValue original marks_16 .staller ∅=4 := by
  apply LocalProfile.DAG.bellman original marks_16 3 4 0 1 (by decide +kernel) (by decide +kernel)
  · rw [after_16_0.2]
  · rw [after_16_1.1]
  · intro v hv
    fin_cases v
    · have h := after_16_0
      change 3 ≤ 1+Marked.gameValue original marks_16 .staller {0} ∧ 1+Marked.gameValue original marks_16 .dominator {0} ≤ 4
      omega
    · have h := after_16_1
      change 3 ≤ 1+Marked.gameValue original marks_16 .staller {1} ∧ 1+Marked.gameValue original marks_16 .dominator {1} ≤ 4
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_16 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_16 ∅ 3) hv)
    · have h := after_16_4
      change 3 ≤ 1+Marked.gameValue original marks_16 .staller {4} ∧ 1+Marked.gameValue original marks_16 .dominator {4} ≤ 4
      omega
    · have h := after_16_5
      change 3 ≤ 1+Marked.gameValue original marks_16 .staller {5} ∧ 1+Marked.gameValue original marks_16 .dominator {5} ≤ 4
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_16 ∅ 6) hv)
    · have h := after_16_7
      change 3 ≤ 1+Marked.gameValue original marks_16 .staller {7} ∧ 1+Marked.gameValue original marks_16 .dominator {7} ≤ 4
      omega
    · have h := after_16_8
      change 3 ≤ 1+Marked.gameValue original marks_16 .staller {8} ∧ 1+Marked.gameValue original marks_16 .dominator {8} ≤ 4
      omega
    · have h := after_16_9
      change 3 ≤ 1+Marked.gameValue original marks_16 .staller {9} ∧ 1+Marked.gameValue original marks_16 .dominator {9} ≤ 4
      omega
    · have h := after_16_10
      change 3 ≤ 1+Marked.gameValue original marks_16 .staller {10} ∧ 1+Marked.gameValue original marks_16 .dominator {10} ≤ 4
      omega
    · have h := after_16_11
      change 3 ≤ 1+Marked.gameValue original marks_16 .staller {11} ∧ 1+Marked.gameValue original marks_16 .dominator {11} ≤ 4
      omega
    · have h := after_16_12
      change 3 ≤ 1+Marked.gameValue original marks_16 .staller {12} ∧ 1+Marked.gameValue original marks_16 .dominator {12} ≤ 4
      omega
def marks_17 : Finset (Fin 13) := {2,3,5,6}
theorem after_17_0 : Marked.gameValue original marks_17 .dominator {0}=2 ∧ Marked.gameValue original marks_17 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_6 0 2 2 (by decide +kernel) row_6
theorem after_17_1 : Marked.gameValue original marks_17 .dominator {1}=3 ∧ Marked.gameValue original marks_17 .staller {1}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_12 1 3 3 (by decide +kernel) row_12
theorem after_17_2 : Marked.gameValue original marks_17 .dominator {2}=3 ∧ Marked.gameValue original marks_17 .staller {2}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_16 2 3 4 (by decide +kernel) row_16
theorem after_17_4 : Marked.gameValue original marks_17 .dominator {4}=3 ∧ Marked.gameValue original marks_17 .staller {4}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_12 4 3 3 (by decide +kernel) row_12
theorem after_17_5 : Marked.gameValue original marks_17 .dominator {5}=3 ∧ Marked.gameValue original marks_17 .staller {5}=4 :=
  FullCanonicalDAG.transport_perm original perm_4 adjacency_4 marks_17 marks_16 5 3 4 (by decide +kernel) row_16
theorem after_17_7 : Marked.gameValue original marks_17 .dominator {7}=1 ∧ Marked.gameValue original marks_17 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_4 7 1 2 (by decide +kernel) row_4
theorem after_17_8 : Marked.gameValue original marks_17 .dominator {8}=1 ∧ Marked.gameValue original marks_17 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_5 adjacency_5 marks_17 marks_11 8 1 2 (by decide +kernel) row_11
theorem after_17_9 : Marked.gameValue original marks_17 .dominator {9}=1 ∧ Marked.gameValue original marks_17 .staller {9}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_13 9 1 2 (by decide +kernel) row_13
theorem after_17_10 : Marked.gameValue original marks_17 .dominator {10}=1 ∧ Marked.gameValue original marks_17 .staller {10}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_17 marks_4 10 1 2 (by decide +kernel) row_4
theorem after_17_11 : Marked.gameValue original marks_17 .dominator {11}=1 ∧ Marked.gameValue original marks_17 .staller {11}=2 :=
  FullCanonicalDAG.transport_perm original perm_6 adjacency_6 marks_17 marks_11 11 1 2 (by decide +kernel) row_11
theorem after_17_12 : Marked.gameValue original marks_17 .dominator {12}=1 ∧ Marked.gameValue original marks_17 .staller {12}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_17 marks_13 12 1 2 (by decide +kernel) row_13
theorem row_17 : Marked.gameValue original marks_17 .dominator ∅=3 ∧ Marked.gameValue original marks_17 .staller ∅=4 := by
  apply LocalProfile.DAG.bellman original marks_17 3 4 0 1 (by decide +kernel) (by decide +kernel)
  · rw [after_17_0.2]
  · rw [after_17_1.1]
  · intro v hv
    fin_cases v
    · have h := after_17_0
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {0} ∧ 1+Marked.gameValue original marks_17 .dominator {0} ≤ 4
      omega
    · have h := after_17_1
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {1} ∧ 1+Marked.gameValue original marks_17 .dominator {1} ≤ 4
      omega
    · have h := after_17_2
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {2} ∧ 1+Marked.gameValue original marks_17 .dominator {2} ≤ 4
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_17 ∅ 3) hv)
    · have h := after_17_4
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {4} ∧ 1+Marked.gameValue original marks_17 .dominator {4} ≤ 4
      omega
    · have h := after_17_5
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {5} ∧ 1+Marked.gameValue original marks_17 .dominator {5} ≤ 4
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_17 ∅ 6) hv)
    · have h := after_17_7
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {7} ∧ 1+Marked.gameValue original marks_17 .dominator {7} ≤ 4
      omega
    · have h := after_17_8
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {8} ∧ 1+Marked.gameValue original marks_17 .dominator {8} ≤ 4
      omega
    · have h := after_17_9
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {9} ∧ 1+Marked.gameValue original marks_17 .dominator {9} ≤ 4
      omega
    · have h := after_17_10
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {10} ∧ 1+Marked.gameValue original marks_17 .dominator {10} ≤ 4
      omega
    · have h := after_17_11
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {11} ∧ 1+Marked.gameValue original marks_17 .dominator {11} ≤ 4
      omega
    · have h := after_17_12
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {12} ∧ 1+Marked.gameValue original marks_17 .dominator {12} ≤ 4
      omega
def marks_18 : Finset (Fin 13) := {0,1,2,3}
theorem after_18_0 : Marked.gameValue original marks_18 .dominator {0}=3 ∧ Marked.gameValue original marks_18 .staller {0}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_18 marks_10 0 3 3 (by decide +kernel) row_10
theorem after_18_4 : Marked.gameValue original marks_18 .dominator {4}=3 ∧ Marked.gameValue original marks_18 .staller {4}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_18 marks_12 4 3 3 (by decide +kernel) row_12
theorem after_18_5 : Marked.gameValue original marks_18 .dominator {5}=3 ∧ Marked.gameValue original marks_18 .staller {5}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_18 marks_12 5 3 3 (by decide +kernel) row_12
theorem after_18_6 : Marked.gameValue original marks_18 .dominator {6}=3 ∧ Marked.gameValue original marks_18 .staller {6}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_18 marks_12 6 3 3 (by decide +kernel) row_12
theorem after_18_7 : Marked.gameValue original marks_18 .dominator {7}=3 ∧ Marked.gameValue original marks_18 .staller {7}=3 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_18 marks_12 7 3 3 (by decide +kernel) row_12
theorem after_18_8 : Marked.gameValue original marks_18 .dominator {8}=3 ∧ Marked.gameValue original marks_18 .staller {8}=3 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_18 marks_12 8 3 3 (by decide +kernel) row_12
theorem after_18_9 : Marked.gameValue original marks_18 .dominator {9}=3 ∧ Marked.gameValue original marks_18 .staller {9}=3 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_18 marks_12 9 3 3 (by decide +kernel) row_12
theorem after_18_10 : Marked.gameValue original marks_18 .dominator {10}=3 ∧ Marked.gameValue original marks_18 .staller {10}=3 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_18 marks_12 10 3 3 (by decide +kernel) row_12
theorem after_18_11 : Marked.gameValue original marks_18 .dominator {11}=3 ∧ Marked.gameValue original marks_18 .staller {11}=3 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_18 marks_12 11 3 3 (by decide +kernel) row_12
theorem after_18_12 : Marked.gameValue original marks_18 .dominator {12}=3 ∧ Marked.gameValue original marks_18 .staller {12}=3 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_18 marks_12 12 3 3 (by decide +kernel) row_12
theorem row_18 : Marked.gameValue original marks_18 .dominator ∅=4 ∧ Marked.gameValue original marks_18 .staller ∅=4 := by
  apply LocalProfile.DAG.bellman original marks_18 4 4 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_18_0.2]
  · rw [after_18_0.1]
  · intro v hv
    fin_cases v
    · have h := after_18_0
      change 4 ≤ 1+Marked.gameValue original marks_18 .staller {0} ∧ 1+Marked.gameValue original marks_18 .dominator {0} ≤ 4
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_18 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_18 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_18 ∅ 3) hv)
    · have h := after_18_4
      change 4 ≤ 1+Marked.gameValue original marks_18 .staller {4} ∧ 1+Marked.gameValue original marks_18 .dominator {4} ≤ 4
      omega
    · have h := after_18_5
      change 4 ≤ 1+Marked.gameValue original marks_18 .staller {5} ∧ 1+Marked.gameValue original marks_18 .dominator {5} ≤ 4
      omega
    · have h := after_18_6
      change 4 ≤ 1+Marked.gameValue original marks_18 .staller {6} ∧ 1+Marked.gameValue original marks_18 .dominator {6} ≤ 4
      omega
    · have h := after_18_7
      change 4 ≤ 1+Marked.gameValue original marks_18 .staller {7} ∧ 1+Marked.gameValue original marks_18 .dominator {7} ≤ 4
      omega
    · have h := after_18_8
      change 4 ≤ 1+Marked.gameValue original marks_18 .staller {8} ∧ 1+Marked.gameValue original marks_18 .dominator {8} ≤ 4
      omega
    · have h := after_18_9
      change 4 ≤ 1+Marked.gameValue original marks_18 .staller {9} ∧ 1+Marked.gameValue original marks_18 .dominator {9} ≤ 4
      omega
    · have h := after_18_10
      change 4 ≤ 1+Marked.gameValue original marks_18 .staller {10} ∧ 1+Marked.gameValue original marks_18 .dominator {10} ≤ 4
      omega
    · have h := after_18_11
      change 4 ≤ 1+Marked.gameValue original marks_18 .staller {11} ∧ 1+Marked.gameValue original marks_18 .dominator {11} ≤ 4
      omega
    · have h := after_18_12
      change 4 ≤ 1+Marked.gameValue original marks_18 .staller {12} ∧ 1+Marked.gameValue original marks_18 .dominator {12} ≤ 4
      omega
def marks_19 : Finset (Fin 13) := {1,2,3}
theorem after_19_0 : Marked.gameValue original marks_19 .dominator {0}=3 ∧ Marked.gameValue original marks_19 .staller {0}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_19 marks_10 0 3 3 (by decide +kernel) row_10
theorem after_19_1 : Marked.gameValue original marks_19 .dominator {1}=4 ∧ Marked.gameValue original marks_19 .staller {1}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_19 marks_18 1 4 4 (by decide +kernel) row_18
theorem after_19_4 : Marked.gameValue original marks_19 .dominator {4}=3 ∧ Marked.gameValue original marks_19 .staller {4}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_19 marks_12 4 3 3 (by decide +kernel) row_12
theorem after_19_5 : Marked.gameValue original marks_19 .dominator {5}=3 ∧ Marked.gameValue original marks_19 .staller {5}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_19 marks_14 5 3 4 (by decide +kernel) row_14
theorem after_19_6 : Marked.gameValue original marks_19 .dominator {6}=3 ∧ Marked.gameValue original marks_19 .staller {6}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_19 marks_16 6 3 4 (by decide +kernel) row_16
theorem after_19_7 : Marked.gameValue original marks_19 .dominator {7}=3 ∧ Marked.gameValue original marks_19 .staller {7}=3 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_19 marks_12 7 3 3 (by decide +kernel) row_12
theorem after_19_8 : Marked.gameValue original marks_19 .dominator {8}=3 ∧ Marked.gameValue original marks_19 .staller {8}=4 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_19 marks_14 8 3 4 (by decide +kernel) row_14
theorem after_19_9 : Marked.gameValue original marks_19 .dominator {9}=3 ∧ Marked.gameValue original marks_19 .staller {9}=4 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_19 marks_16 9 3 4 (by decide +kernel) row_16
theorem after_19_10 : Marked.gameValue original marks_19 .dominator {10}=3 ∧ Marked.gameValue original marks_19 .staller {10}=3 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_19 marks_12 10 3 3 (by decide +kernel) row_12
theorem after_19_11 : Marked.gameValue original marks_19 .dominator {11}=3 ∧ Marked.gameValue original marks_19 .staller {11}=4 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_19 marks_14 11 3 4 (by decide +kernel) row_14
theorem after_19_12 : Marked.gameValue original marks_19 .dominator {12}=3 ∧ Marked.gameValue original marks_19 .staller {12}=4 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_19 marks_16 12 3 4 (by decide +kernel) row_16
theorem row_19 : Marked.gameValue original marks_19 .dominator ∅=4 ∧ Marked.gameValue original marks_19 .staller ∅=5 := by
  apply LocalProfile.DAG.bellman original marks_19 4 5 0 1 (by decide +kernel) (by decide +kernel)
  · rw [after_19_0.2]
  · rw [after_19_1.1]
  · intro v hv
    fin_cases v
    · have h := after_19_0
      change 4 ≤ 1+Marked.gameValue original marks_19 .staller {0} ∧ 1+Marked.gameValue original marks_19 .dominator {0} ≤ 5
      omega
    · have h := after_19_1
      change 4 ≤ 1+Marked.gameValue original marks_19 .staller {1} ∧ 1+Marked.gameValue original marks_19 .dominator {1} ≤ 5
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_19 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_19 ∅ 3) hv)
    · have h := after_19_4
      change 4 ≤ 1+Marked.gameValue original marks_19 .staller {4} ∧ 1+Marked.gameValue original marks_19 .dominator {4} ≤ 5
      omega
    · have h := after_19_5
      change 4 ≤ 1+Marked.gameValue original marks_19 .staller {5} ∧ 1+Marked.gameValue original marks_19 .dominator {5} ≤ 5
      omega
    · have h := after_19_6
      change 4 ≤ 1+Marked.gameValue original marks_19 .staller {6} ∧ 1+Marked.gameValue original marks_19 .dominator {6} ≤ 5
      omega
    · have h := after_19_7
      change 4 ≤ 1+Marked.gameValue original marks_19 .staller {7} ∧ 1+Marked.gameValue original marks_19 .dominator {7} ≤ 5
      omega
    · have h := after_19_8
      change 4 ≤ 1+Marked.gameValue original marks_19 .staller {8} ∧ 1+Marked.gameValue original marks_19 .dominator {8} ≤ 5
      omega
    · have h := after_19_9
      change 4 ≤ 1+Marked.gameValue original marks_19 .staller {9} ∧ 1+Marked.gameValue original marks_19 .dominator {9} ≤ 5
      omega
    · have h := after_19_10
      change 4 ≤ 1+Marked.gameValue original marks_19 .staller {10} ∧ 1+Marked.gameValue original marks_19 .dominator {10} ≤ 5
      omega
    · have h := after_19_11
      change 4 ≤ 1+Marked.gameValue original marks_19 .staller {11} ∧ 1+Marked.gameValue original marks_19 .dominator {11} ≤ 5
      omega
    · have h := after_19_12
      change 4 ≤ 1+Marked.gameValue original marks_19 .staller {12} ∧ 1+Marked.gameValue original marks_19 .dominator {12} ≤ 5
      omega
end IsolationGame.FullCanonical.T04
