import ForestNoMinus
import CanonicalValueNormalization

namespace IsolationGame.MarkedBoundary
variable {V : Type} [Fintype V] [DecidableEq V] (G : SimpleGraph V) (z : V)

/-- Remove only edges incident to z; keep the original vertex label. -/
def isolateVertex : SimpleGraph V where
  Adj u v := G.Adj u v ∧ u≠z ∧ v≠z
  symm := by intro u v h;exact ⟨h.1.symm,h.2.2,h.2.1⟩
  loopless := by intro v h;exact G.loopless v h.1

theorem isolate_le : isolateVertex G z≤G := fun _ _ h=>h.1

theorem isolate_acyclic (hA : G.IsAcyclic) : (isolateVertex G z).IsAcyclic := by
  intro v p hp
  exact hA (p.mapLe (isolate_le G z)) (hp.mapLe (isolate_le G z))

theorem closed_sub {v w : V} (h : Closed (isolateVertex G z) v w) : Closed G v w := by
  rcases h with h | h
  · exact Or.inl h
  · exact Or.inr h.1

theorem closed_iff (v w : V) (hv : v≠z) (hw : w≠z) :
    Closed (isolateVertex G z) v w ↔ Closed G v w := by
  simp [Closed,isolateVertex,hv,hw]

theorem dominated_iff_unspent (X : Finset V) (hz : z∉X) (w : V) (hw : w≠z) :
    Dominated (isolateVertex G z) X w ↔ Dominated G X w := by
  constructor
  · rintro ⟨v,hv,hc⟩;exact ⟨v,hv,closed_sub G z hc⟩
  · rintro ⟨v,hv,hc⟩
    have hvz : v≠z := by intro he;subst v;exact hz hv
    exact ⟨v,hv,(closed_iff G z v w hvz hw).mpr hc⟩

theorem undominated_iff_unspent (M X : Finset V) (hm : z∈M) (hz : z∉X) (w : V) :
    Marked.Undominated (isolateVertex G z) M X w ↔ Marked.Undominated G M X w := by
  by_cases hw : w∈M
  · simp [Marked.Undominated,hw]
  · have hwz : w≠z := by intro he;subst w;exact hw hm
    simp only [Marked.Undominated,Undominated,dominated_iff_unspent G z X hz w hwz]

theorem white_subset (M X : Finset V) (hm : z∈M) :
    ∀w,Marked.White G M X w → Marked.White (isolateVertex G z) M X w := by
  have hu (w : V) (hw : Marked.Undominated G M X w) :
      Marked.Undominated (isolateVertex G z) M X w := by
    refine ⟨hw.1,?_⟩
    rintro ⟨v,hv,hc⟩
    exact hw.2 ⟨v,hv,closed_sub G z hc⟩
  intro w hw
  obtain ⟨hw,t,ha,ht⟩ := hw
  have hwz : w≠z := by intro he;subst w;exact hw.1 hm
  have htz : t≠z := by intro he;subst t;exact ht.1 hm
  exact ⟨hu w hw,t,⟨ha,hwz,htz⟩,hu t ht⟩

theorem white_eq_unspent (M X : Finset V) (hm : z∈M) (hz : z∉X) :
    Marked.White G M X=Marked.White (isolateVertex G z) M X := by
  funext w
  apply propext
  constructor
  · exact white_subset G z M X hm w
  · rintro ⟨hw,t,ha,ht⟩
    exact ⟨(undominated_iff_unspent G z M X hm hz w).mp hw,t,ha.1,
      (undominated_iff_unspent G z M X hm hz t).mp ht⟩

theorem isolated_z_illegal (M X : Finset V) (hm : z∈M) :
    ¬Marked.Legal (isolateVertex G z) M X z := by
  rintro ⟨w,hc,hw⟩
  rcases hc with hc | hc
  · subst w;exact hw.1.1 hm
  · exact hc.2.1 rfl

theorem legal_iff_unspent (M X : Finset V) (hm : z∈M) (hz : z∉X) (v : V) (hv : v≠z) :
    Marked.Legal G M X v ↔ Marked.Legal (isolateVertex G z) M X v := by
  constructor
  · rintro ⟨w,hc,hw⟩
    have hwz : w≠z := by intro he;subst w;exact hw.1.1 hm
    exact ⟨w,(closed_iff G z v w hv hwz).mpr hc,white_subset G z M X hm w hw⟩
  · rintro ⟨w,hc,hw⟩
    rw [←white_eq_unspent G z M X hm hz] at hw
    exact ⟨w,closed_sub G z hc,hw⟩

theorem isolated_z_white_insert (M X : Finset V) (hm : z∈M) :
    Marked.White (isolateVertex G z) M (insert z X)=Marked.White (isolateVertex G z) M X := by
  funext w
  apply propext
  constructor
  · exact Marked.white_after_subset _ z w
  · intro hw
    have hl := isolated_z_illegal G z M X hm
    exact Marked.white_survives_imagined_illegal _ (fun _ h=>h) hl w hw

theorem isolated_z_value_insert (M X : Finset V) (hm : z∈M) (p : Player) :
    Marked.gameValue (isolateVertex G z) M p (insert z X)=Marked.gameValue (isolateVertex G z) M p X := by
  apply Marked.value_eq_of_white_eq
  intro w
  rw [isolated_z_white_insert G z M X hm]

/-- Once z has been selected, its original action cannot act on any remaining
white vertex. Removing its incident edges then preserves that state exactly. -/
theorem spent_agree (M X : Finset V) (hm : z∈M) (hz : z∈X) :
    (GuardedEdge.view G).AgreeOnWhite (GuardedEdge.view (isolateVertex G z)) (Marked.White G M X) := by
  intro v w hw
  have hwz : w≠z := by intro he;subst w;exact hw.1.1 hm
  rw [GuardedEdge.closed_agree,GuardedEdge.closed_agree]
  by_cases hv : v=z
  · subst v
    have hfull : ¬Closed G z w := fun hc=>hw.1.2 ⟨z,hz,hc⟩
    have hiso : ¬Closed (isolateVertex G z) z w := fun hc=>hfull (closed_sub G z hc)
    exact iff_of_false hfull hiso
  · exact (closed_iff G z v w hv hwz).symm

theorem spent_normalized (M X : Finset V) (hm : z∈M) :
    (GuardedEdge.view (isolateVertex G z)).noniso (Marked.White G M X)=Marked.White G M X := by
  funext v
  apply propext
  constructor
  · exact fun h=>h.1
  · intro hv
    obtain ⟨w,ha,hw⟩ := Marked.white_neighbor G hv
    have hvz : v≠z := by intro he;subst v;exact hv.1.1 hm
    have hwz : w≠z := by intro he;subst w;exact hw.1.1 hm
    exact ⟨hv,w,hw,ha,hvz,hwz⟩

theorem spent_value_bound (M X : Finset V) (hm : z∈M) (hz : z∈X) (p : Player) :
    Marked.gameValue G M p X≤Marked.gameValue (isolateVertex G z) M p X := by
  let W := Marked.White G M X
  have hn := spent_normalized G z M X hm
  have hsub := white_subset G z M X hm
  have hv : Marked.gameValue (isolateVertex G z) (ForestFoundation.canonicalMarks W) p ∅ ≤
      Marked.gameValue (isolateVertex G z) M p X :=
    Marked.value_of_white_subset _ _ M ∅ X p (fun v h=>hsub v ((ForestFoundation.canonical_white _ W hn v).mp h))
  apply (Marked.gameValue_le_iff G M p X _).mpr
  apply (ForestFoundation.white_horizon G M X _ p).mp
  apply ((GuardedEdge.view G).winsWhite_congr (GuardedEdge.view (isolateVertex G z)) _ _ W (spent_agree G z M X hm hz)).mpr
  apply (ForestFoundation.canonical_horizon _ W hn _ p).mp
  exact (Marked.gameValue_le_iff _ _ _ _ _).mp hv

#print axioms isolate_acyclic
#print axioms white_eq_unspent
#print axioms spent_value_bound
end IsolationGame.MarkedBoundary
