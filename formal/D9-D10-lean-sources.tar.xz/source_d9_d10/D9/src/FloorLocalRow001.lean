import FloorLocalBase
set_option maxRecDepth 4096
set_option maxHeartbeats 1000000
namespace IsolationGame.FloorLocal
def marks_001 : Finset (Fin 7) := {0,1,2,3,4,5,6}
theorem normalized_001 : ∀v : Fin 7, Marked.White original_02 marks_001 ∅ v ↔ v∈({} : Finset (Fin 7)) := by decide +kernel
theorem row_001 : Marked.gameValue original_02 marks_001 .dominator ∅=0 ∧ Marked.gameValue original_02 marks_001 .staller ∅=0 := by
  constructor <;> apply (Marked.value_zero_iff_terminal _ _ _ _).mpr <;> decide +kernel
#print axioms row_001
end IsolationGame.FloorLocal
