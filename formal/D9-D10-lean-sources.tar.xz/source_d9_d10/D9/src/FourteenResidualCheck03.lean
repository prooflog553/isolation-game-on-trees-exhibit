import FourteenResidualData

/-! Finite kernel arithmetic only: first profile fixed to t03.
All arithmetic is checked by kernel reduction; no graph or history search. -/
namespace IsolationGame.FourteenResidual
open CanonicalLocal
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

theorem check11_t03 (b : Index) :
    NumericResidual [.t03] [b] → MatchesFourteen [.t03] [b] := by
  cases b <;> decide +kernel

theorem check12_t03 (b c : Index) :
    NumericResidual [.t03] [b, c] → MatchesFourteen [.t03] [b, c] := by
  cases b <;> cases c <;> decide +kernel

#print axioms check11_t03
#print axioms check12_t03
end IsolationGame.FourteenResidual
