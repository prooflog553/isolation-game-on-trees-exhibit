import GeneralP4Unmarked
import G2CenterSplit

/-! Full original two-centre carrier. This source starts as SOURCE_ONLY;
native status is recorded externally and is never inferred from this header. -/
namespace IsolationGame.DoubleCentreP4
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

abbrev Vertex (k l p q : Nat) := GeneralP4Receiver.Vertex k p ⊕ GeneralP4Receiver.Vertex l q
def graph (k l p q : Nat) : SimpleGraph (Vertex k l p q) :=
  Attachment.original (GeneralP4Receiver.graph k p) (GeneralP4Receiver.graph l q) (GeneralP4Receiver.centre k p) (GeneralP4Receiver.centre l q)
def left (k l p q : Nat) : Vertex k l p q := .inl (GeneralP4Receiver.centre k p)
def right (k l p q : Nat) : Vertex k l p q := .inr (GeneralP4Receiver.centre l q)

instance graphDecidable (k l p q : Nat) : DecidableRel (graph k l p q).Adj := by
  intro u v
  cases u <;> cases v <;> dsimp [graph,Attachment.original] <;> infer_instance

theorem order (k l p q : Nat) :
    Fintype.card (Vertex k l p q) = 2+4*(k+l)+7*(p+q) := by
  change Fintype.card (Sum (GeneralP4Receiver.Vertex k p) (GeneralP4Receiver.Vertex l q)) = _
  rw [Fintype.card_sum,GeneralP4Receiver.order,GeneralP4Receiver.order]
  omega

theorem central_edge (k l p q : Nat) :
    (graph k l p q).Adj (left k l p q) (right k l p q) := ⟨rfl,rfl⟩

private theorem empty_undominated {V : Type} [Fintype V] [DecidableEq V]
    (G : SimpleGraph V) (v : V) : Marked.Undominated G ∅ ∅ v := by
  simp [Marked.Undominated,IsolationGame.Undominated,IsolationGame.Dominated]

/-- The physical centre edge witnesses legality even when all four parameters vanish. -/
theorem left_legal (k l p q : Nat) :
    Marked.Legal (graph k l p q) ∅ ∅ (left k l p q) := by
  exact ⟨left k l p q,Or.inl rfl,empty_undominated _ _,right k l p q,
    central_edge k l p q,empty_undominated _ _⟩

theorem right_legal (k l p q : Nat) :
    Marked.Legal (graph k l p q) ∅ ∅ (right k l p q) := by
  exact ⟨right k l p q,Or.inl rfl,empty_undominated _ _,left k l p q,
    (central_edge k l p q).symm,empty_undominated _ _⟩

private theorem combine_empty {V U : Type} [DecidableEq V] [DecidableEq U] :
    MarkedSum.combine (∅ : Finset V) (∅ : Finset U) = ∅ := by
  simp [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight]

/-- The cut removes just the inert central edge. Both original centres and every
blue original move remain in their exact summands, including singleton summands. -/
theorem left_follower_split (k l p q : Nat) (t : Player) :
    Marked.gameValue (graph k l p q) ∅ t {left k l p q} =
      Marked.gameValue (MarkedSum.original (GeneralP4Receiver.graph k p) (GeneralP4Receiver.graph l q))
        (MarkedSum.combine
          (SelectedVertex.playedMarks (GeneralP4Receiver.graph k p) (GeneralP4Receiver.marks k p) (GeneralP4Receiver.centre k p))
          (GeneralP4Receiver.marks l q)) t ∅ := by
  have h := Attachment.after_left_root_value (GeneralP4Receiver.graph k p) (GeneralP4Receiver.graph l q)
    (GeneralP4Receiver.centre k p) (GeneralP4Receiver.centre l q) ∅ ∅ t
  rw [combine_empty,Finset.insert_empty,GeneralP4Receiver.played_empty_eq,←GeneralP4Receiver.marks_singleton] at h
  convert h using 1 <;> congr 1 <;> apply Subsingleton.elim

def swapEquiv (k l p q : Nat) : Vertex k l p q ≃ Vertex l k q p := Equiv.sumComm _ _

theorem swap_adj (k l p q : Nat) (u v : Vertex k l p q) :
    (graph l k q p).Adj (swapEquiv k l p q u) (swapEquiv k l p q v) ↔
      (graph k l p q).Adj u v := by
  cases u <;> cases v <;> simp [graph,swapEquiv,Attachment.original,and_comm]

theorem value_swap (k l p q : Nat) (t : Player) (X : Finset (Vertex k l p q)) :
    Marked.gameValue (graph k l p q) ∅ t X =
      Marked.gameValue (graph l k q p) ∅ t (X.image (swapEquiv k l p q)) := by
  simpa using (Marked.gameValue_relabel (graph k l p q) (graph l k q p)
    (swapEquiv k l p q) (swap_adj k l p q) ∅ X t).symm

#print axioms order
#print axioms left_legal
#print axioms right_legal
#print axioms left_follower_split
#print axioms value_swap
end IsolationGame.DoubleCentreP4
