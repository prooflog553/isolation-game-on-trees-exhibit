import FloorLocalBase
import FloorLocalRow001
import FloorLocalRow017
set_option maxRecDepth 4096
set_option maxHeartbeats 1000000
namespace IsolationGame.FloorLocal
def marks_064 : Finset (Fin 7) := {0,4,5,6}
theorem normalized_064 : ∀v : Fin 7, Marked.White original_02 marks_064 ∅ v ↔ v∈({1,2,3} : Finset (Fin 7)) := by decide +kernel
theorem after_064_0 : Marked.gameValue original_02 marks_064 .dominator {0}=1 ∧ Marked.gameValue original_02 marks_064 .staller {0}=1 :=
  LocalProfile.DAG.transport original_02 marks_064 marks_017 0 1 1 (by decide +kernel) row_017
theorem after_064_1 : Marked.gameValue original_02 marks_064 .dominator {1}=0 ∧ Marked.gameValue original_02 marks_064 .staller {1}=0 :=
  LocalProfile.DAG.transport original_02 marks_064 marks_001 1 0 0 (by decide +kernel) row_001
theorem after_064_2 : Marked.gameValue original_02 marks_064 .dominator {2}=0 ∧ Marked.gameValue original_02 marks_064 .staller {2}=0 :=
  LocalProfile.DAG.transport original_02 marks_064 marks_001 2 0 0 (by decide +kernel) row_001
theorem after_064_3 : Marked.gameValue original_02 marks_064 .dominator {3}=0 ∧ Marked.gameValue original_02 marks_064 .staller {3}=0 :=
  LocalProfile.DAG.transport original_02 marks_064 marks_001 3 0 0 (by decide +kernel) row_001
theorem row_064 : Marked.gameValue original_02 marks_064 .dominator ∅=1 ∧ Marked.gameValue original_02 marks_064 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original_02 marks_064 1 2 1 0 (by decide +kernel) (by decide +kernel)
  · rw [after_064_1.2]
  · rw [after_064_0.1]
  · intro v hv
    fin_cases v
    · have h := after_064_0
      change 1≤1+Marked.gameValue original_02 marks_064 .staller {0} ∧ 1+Marked.gameValue original_02 marks_064 .dominator {0}≤2
      omega
    · have h := after_064_1
      change 1≤1+Marked.gameValue original_02 marks_064 .staller {1} ∧ 1+Marked.gameValue original_02 marks_064 .dominator {1}≤2
      omega
    · have h := after_064_2
      change 1≤1+Marked.gameValue original_02 marks_064 .staller {2} ∧ 1+Marked.gameValue original_02 marks_064 .dominator {2}≤2
      omega
    · have h := after_064_3
      change 1≤1+Marked.gameValue original_02 marks_064 .staller {3} ∧ 1+Marked.gameValue original_02 marks_064 .dominator {3}≤2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_064 ∅ 4) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_064 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_064 ∅ 6) hv)
#print axioms row_064
end IsolationGame.FloorLocal
