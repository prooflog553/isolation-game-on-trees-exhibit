import FloorLocalBase
import FloorLocalRow001
import FloorLocalRow019
set_option maxRecDepth 4096
set_option maxHeartbeats 1000000
namespace IsolationGame.FloorLocal
def marks_066 : Finset (Fin 7) := {0,1,2,3}
theorem normalized_066 : ∀v : Fin 7, Marked.White original_02 marks_066 ∅ v ↔ v∈({4,5,6} : Finset (Fin 7)) := by decide +kernel
theorem after_066_0 : Marked.gameValue original_02 marks_066 .dominator {0}=1 ∧ Marked.gameValue original_02 marks_066 .staller {0}=1 :=
  LocalProfile.DAG.transport original_02 marks_066 marks_019 0 1 1 (by decide +kernel) row_019
theorem after_066_4 : Marked.gameValue original_02 marks_066 .dominator {4}=0 ∧ Marked.gameValue original_02 marks_066 .staller {4}=0 :=
  LocalProfile.DAG.transport original_02 marks_066 marks_001 4 0 0 (by decide +kernel) row_001
theorem after_066_5 : Marked.gameValue original_02 marks_066 .dominator {5}=0 ∧ Marked.gameValue original_02 marks_066 .staller {5}=0 :=
  LocalProfile.DAG.transport original_02 marks_066 marks_001 5 0 0 (by decide +kernel) row_001
theorem after_066_6 : Marked.gameValue original_02 marks_066 .dominator {6}=0 ∧ Marked.gameValue original_02 marks_066 .staller {6}=0 :=
  LocalProfile.DAG.transport original_02 marks_066 marks_001 6 0 0 (by decide +kernel) row_001
theorem row_066 : Marked.gameValue original_02 marks_066 .dominator ∅=1 ∧ Marked.gameValue original_02 marks_066 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original_02 marks_066 1 2 4 0 (by decide +kernel) (by decide +kernel)
  · rw [after_066_4.2]
  · rw [after_066_0.1]
  · intro v hv
    fin_cases v
    · have h := after_066_0
      change 1≤1+Marked.gameValue original_02 marks_066 .staller {0} ∧ 1+Marked.gameValue original_02 marks_066 .dominator {0}≤2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_066 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_066 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_066 ∅ 3) hv)
    · have h := after_066_4
      change 1≤1+Marked.gameValue original_02 marks_066 .staller {4} ∧ 1+Marked.gameValue original_02 marks_066 .dominator {4}≤2
      omega
    · have h := after_066_5
      change 1≤1+Marked.gameValue original_02 marks_066 .staller {5} ∧ 1+Marked.gameValue original_02 marks_066 .dominator {5}≤2
      omega
    · have h := after_066_6
      change 1≤1+Marked.gameValue original_02 marks_066 .staller {6} ∧ 1+Marked.gameValue original_02 marks_066 .dominator {6}≤2
      omega
#print axioms row_066
end IsolationGame.FloorLocal
