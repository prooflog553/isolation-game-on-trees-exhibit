import FourExceptionalBranches

namespace IsolationGame.NecessaryCore
open CanonicalLocal

def code : Index→Nat
  | .t00=>0
  | .t01=>1
  | .t02=>2
  | .t03=>3
  | .t04=>4
  | .t05=>5
  | .t06=>6
  | .t07=>7
  | .t08=>8
  | .t09=>9
  | .t10=>10
  | .t11=>11
  | .t12=>12
  | .t13=>13
  | .t14=>14
  | .t15=>15
  | .t16=>16
  | .t17=>17
  | .t18=>18
  | .t19=>19

def decode : Nat→Index
  | 0=>.t00
  | 1=>.t01
  | 2=>.t02
  | 3=>.t03
  | 4=>.t04
  | 5=>.t05
  | 6=>.t06
  | 7=>.t07
  | 8=>.t08
  | 9=>.t09
  | 10=>.t10
  | 11=>.t11
  | 12=>.t12
  | 13=>.t13
  | 14=>.t14
  | 15=>.t15
  | 16=>.t16
  | 17=>.t17
  | 18=>.t18
  | 19=>.t19
  | _=>.t00

theorem code_lt (t : Index) : code t<20 := by cases t <;> decide +kernel
theorem decode_code (t : Index) : decode (code t)=t := by cases t <;> rfl

def allowedCode (n : Nat) : Bool := decide (n<20 ∧ n≠0 ∧ n≠2)

theorem allowedCode_iff (n : Nat) : allowedCode n=true ↔ n<20 ∧ n≠0 ∧ n≠2 := by
  simp [allowedCode]

def coreDefect (xs : List Nat) : Int :=
  (xs.map (fun n=>defect (decode n))).sum-7*((xs.countP (fun n=>pairable (decode n))/2 : Nat):Int)

def coreOrder (xs : List Nat) : Nat := 1+(xs.map (fun n=>size (decode n))).sum

def CoreGood (xs : List Nat) : Prop :=
  xs.Pairwise (·≤·) ∧ xs.all allowedCode=true ∧ (-3 : Int)≤coreDefect xs

instance (xs : List Nat) : Decidable (CoreGood xs) := by unfold CoreGood;infer_instance

/-- The candidate list is checked below; this definition alone asserts
neither completeness nor necessity for an original tree. -/
def cores : List (List Nat) :=
  [[],[1],[1,1],[1,1,1],[1,1,1,3],[1,1,1,10],[1,1,3,8],[1,1,8],[1,1,8,10],[1,1,12],[1,3],[1,3,3],[1,3,7],[1,3,8,8],[1,3,10],[1,3,15],[1,4],[1,7],[1,7,10],[1,8],[1,8,8],[1,8,8,10],[1,8,12],[1,10],[1,10,10],[1,10,15],[1,11],[1,12,12],[1,15],[1,16],[1,19],[3],[3,3,8],[3,3,12],[3,6],[3,7,8],[3,8],[3,8,8,8],[3,8,10],[3,8,15],[3,10,12],[3,12],[3,14],[4,8],[4,12],[6],[6,10],[7],[7,8],[7,8,10],[7,12],[8],[8,8],[8,8,8],[8,8,8,10],[8,8,12],[8,10],[8,10,10],[8,10,15],[8,11],[8,12,12],[8,15],[8,16],[8,19],[10],[10,10,12],[10,12],[10,14],[11,12],[12],[12,15],[14],[15]]

theorem core_count : cores.length=73 := by decide +kernel
theorem cores_nodup : cores.Nodup := by decide +kernel

theorem all_core_checks : cores.all (fun xs=>decide (CoreGood xs ∧ xs.length≤4 ∧ coreOrder xs≤44))=true := by
  decide +kernel

theorem maximum_order_attained : ∃xs∈cores,coreOrder xs=44 := by
  refine ⟨[3,8,8,8],?_,?_⟩ <;> decide +kernel

#print axioms all_core_checks
end IsolationGame.NecessaryCore
