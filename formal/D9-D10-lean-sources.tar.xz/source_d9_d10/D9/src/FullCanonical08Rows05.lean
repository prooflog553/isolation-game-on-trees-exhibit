import FullCanonical08Rows04
namespace IsolationGame.FullCanonical.T08
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_20 : Finset (Fin 11) := {0,7,8,9,10}
theorem after_20_0 : Marked.gameValue original marks_20 .dominator {0}=2 ∧ Marked.gameValue original marks_20 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_20 marks_8 0 2 2 (by decide +kernel) row_8
theorem after_20_1 : Marked.gameValue original marks_20 .dominator {1}=1 ∧ Marked.gameValue original marks_20 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_20 marks_6 1 1 2 (by decide +kernel) row_6
theorem after_20_2 : Marked.gameValue original marks_20 .dominator {2}=1 ∧ Marked.gameValue original marks_20 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_20 marks_6 2 1 2 (by decide +kernel) row_6
theorem after_20_3 : Marked.gameValue original marks_20 .dominator {3}=1 ∧ Marked.gameValue original marks_20 .staller {3}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_20 marks_6 3 1 2 (by decide +kernel) row_6
theorem after_20_4 : Marked.gameValue original marks_20 .dominator {4}=1 ∧ Marked.gameValue original marks_20 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_20 marks_6 4 1 2 (by decide +kernel) row_6
theorem after_20_5 : Marked.gameValue original marks_20 .dominator {5}=1 ∧ Marked.gameValue original marks_20 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_20 marks_6 5 1 2 (by decide +kernel) row_6
theorem after_20_6 : Marked.gameValue original marks_20 .dominator {6}=1 ∧ Marked.gameValue original marks_20 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_20 marks_6 6 1 2 (by decide +kernel) row_6
theorem row_20 : Marked.gameValue original marks_20 .dominator ∅=3 ∧ Marked.gameValue original marks_20 .staller ∅=3 := by
  apply LocalProfile.DAG.bellman original marks_20 3 3 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_20_0.2]
  · rw [after_20_0.1]
  · intro v hv
    fin_cases v
    · have h := after_20_0
      change 3 ≤ 1+Marked.gameValue original marks_20 .staller {0} ∧ 1+Marked.gameValue original marks_20 .dominator {0} ≤ 3
      omega
    · have h := after_20_1
      change 3 ≤ 1+Marked.gameValue original marks_20 .staller {1} ∧ 1+Marked.gameValue original marks_20 .dominator {1} ≤ 3
      omega
    · have h := after_20_2
      change 3 ≤ 1+Marked.gameValue original marks_20 .staller {2} ∧ 1+Marked.gameValue original marks_20 .dominator {2} ≤ 3
      omega
    · have h := after_20_3
      change 3 ≤ 1+Marked.gameValue original marks_20 .staller {3} ∧ 1+Marked.gameValue original marks_20 .dominator {3} ≤ 3
      omega
    · have h := after_20_4
      change 3 ≤ 1+Marked.gameValue original marks_20 .staller {4} ∧ 1+Marked.gameValue original marks_20 .dominator {4} ≤ 3
      omega
    · have h := after_20_5
      change 3 ≤ 1+Marked.gameValue original marks_20 .staller {5} ∧ 1+Marked.gameValue original marks_20 .dominator {5} ≤ 3
      omega
    · have h := after_20_6
      change 3 ≤ 1+Marked.gameValue original marks_20 .staller {6} ∧ 1+Marked.gameValue original marks_20 .dominator {6} ≤ 3
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_20 ∅ 7) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_20 ∅ 8) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_20 ∅ 9) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_20 ∅ 10) hv)
def marks_21 : Finset (Fin 11) := {0,1,4,7,10}
theorem after_21_1 : Marked.gameValue original marks_21 .dominator {1}=2 ∧ Marked.gameValue original marks_21 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_21 marks_11 1 2 2 (by decide +kernel) row_11
theorem after_21_2 : Marked.gameValue original marks_21 .dominator {2}=2 ∧ Marked.gameValue original marks_21 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_21 marks_11 2 2 2 (by decide +kernel) row_11
theorem after_21_3 : Marked.gameValue original marks_21 .dominator {3}=2 ∧ Marked.gameValue original marks_21 .staller {3}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_21 marks_11 3 2 2 (by decide +kernel) row_11
theorem after_21_4 : Marked.gameValue original marks_21 .dominator {4}=2 ∧ Marked.gameValue original marks_21 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_21 marks_11 4 2 2 (by decide +kernel) row_11
theorem after_21_5 : Marked.gameValue original marks_21 .dominator {5}=2 ∧ Marked.gameValue original marks_21 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_21 marks_11 5 2 2 (by decide +kernel) row_11
theorem after_21_6 : Marked.gameValue original marks_21 .dominator {6}=2 ∧ Marked.gameValue original marks_21 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_21 marks_11 6 2 2 (by decide +kernel) row_11
theorem after_21_7 : Marked.gameValue original marks_21 .dominator {7}=2 ∧ Marked.gameValue original marks_21 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_21 marks_8 7 2 2 (by decide +kernel) row_8
theorem after_21_8 : Marked.gameValue original marks_21 .dominator {8}=2 ∧ Marked.gameValue original marks_21 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_21 marks_8 8 2 2 (by decide +kernel) row_8
theorem after_21_9 : Marked.gameValue original marks_21 .dominator {9}=2 ∧ Marked.gameValue original marks_21 .staller {9}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_21 marks_8 9 2 2 (by decide +kernel) row_8
theorem row_21 : Marked.gameValue original marks_21 .dominator ∅=3 ∧ Marked.gameValue original marks_21 .staller ∅=3 := by
  apply LocalProfile.DAG.bellman original marks_21 3 3 1 1 (by decide +kernel) (by decide +kernel)
  · rw [after_21_1.2]
  · rw [after_21_1.1]
  · intro v hv
    fin_cases v
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_21 ∅ 0) hv)
    · have h := after_21_1
      change 3 ≤ 1+Marked.gameValue original marks_21 .staller {1} ∧ 1+Marked.gameValue original marks_21 .dominator {1} ≤ 3
      omega
    · have h := after_21_2
      change 3 ≤ 1+Marked.gameValue original marks_21 .staller {2} ∧ 1+Marked.gameValue original marks_21 .dominator {2} ≤ 3
      omega
    · have h := after_21_3
      change 3 ≤ 1+Marked.gameValue original marks_21 .staller {3} ∧ 1+Marked.gameValue original marks_21 .dominator {3} ≤ 3
      omega
    · have h := after_21_4
      change 3 ≤ 1+Marked.gameValue original marks_21 .staller {4} ∧ 1+Marked.gameValue original marks_21 .dominator {4} ≤ 3
      omega
    · have h := after_21_5
      change 3 ≤ 1+Marked.gameValue original marks_21 .staller {5} ∧ 1+Marked.gameValue original marks_21 .dominator {5} ≤ 3
      omega
    · have h := after_21_6
      change 3 ≤ 1+Marked.gameValue original marks_21 .staller {6} ∧ 1+Marked.gameValue original marks_21 .dominator {6} ≤ 3
      omega
    · have h := after_21_7
      change 3 ≤ 1+Marked.gameValue original marks_21 .staller {7} ∧ 1+Marked.gameValue original marks_21 .dominator {7} ≤ 3
      omega
    · have h := after_21_8
      change 3 ≤ 1+Marked.gameValue original marks_21 .staller {8} ∧ 1+Marked.gameValue original marks_21 .dominator {8} ≤ 3
      omega
    · have h := after_21_9
      change 3 ≤ 1+Marked.gameValue original marks_21 .staller {9} ∧ 1+Marked.gameValue original marks_21 .dominator {9} ≤ 3
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_21 ∅ 10) hv)
def marks_22 : Finset (Fin 11) := {1,2,3,7,10}
theorem after_22_0 : Marked.gameValue original marks_22 .dominator {0}=2 ∧ Marked.gameValue original marks_22 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_22 marks_11 0 2 2 (by decide +kernel) row_11
theorem after_22_1 : Marked.gameValue original marks_22 .dominator {1}=2 ∧ Marked.gameValue original marks_22 .staller {1}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_22 marks_16 1 2 3 (by decide +kernel) row_16
theorem after_22_4 : Marked.gameValue original marks_22 .dominator {4}=1 ∧ Marked.gameValue original marks_22 .staller {4}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_22 marks_3 4 1 1 (by decide +kernel) row_3
theorem after_22_5 : Marked.gameValue original marks_22 .dominator {5}=1 ∧ Marked.gameValue original marks_22 .staller {5}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_22 marks_3 5 1 1 (by decide +kernel) row_3
theorem after_22_6 : Marked.gameValue original marks_22 .dominator {6}=1 ∧ Marked.gameValue original marks_22 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_22 marks_10 6 1 2 (by decide +kernel) row_10
theorem after_22_7 : Marked.gameValue original marks_22 .dominator {7}=1 ∧ Marked.gameValue original marks_22 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_22 marks_6 7 1 2 (by decide +kernel) row_6
theorem after_22_8 : Marked.gameValue original marks_22 .dominator {8}=1 ∧ Marked.gameValue original marks_22 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_22 marks_9 8 1 2 (by decide +kernel) row_9
theorem after_22_9 : Marked.gameValue original marks_22 .dominator {9}=1 ∧ Marked.gameValue original marks_22 .staller {9}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_22 marks_9 9 1 2 (by decide +kernel) row_9
theorem row_22 : Marked.gameValue original marks_22 .dominator ∅=2 ∧ Marked.gameValue original marks_22 .staller ∅=3 := by
  apply LocalProfile.DAG.bellman original marks_22 2 3 4 0 (by decide +kernel) (by decide +kernel)
  · rw [after_22_4.2]
  · rw [after_22_0.1]
  · intro v hv
    fin_cases v
    · have h := after_22_0
      change 2 ≤ 1+Marked.gameValue original marks_22 .staller {0} ∧ 1+Marked.gameValue original marks_22 .dominator {0} ≤ 3
      omega
    · have h := after_22_1
      change 2 ≤ 1+Marked.gameValue original marks_22 .staller {1} ∧ 1+Marked.gameValue original marks_22 .dominator {1} ≤ 3
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_22 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_22 ∅ 3) hv)
    · have h := after_22_4
      change 2 ≤ 1+Marked.gameValue original marks_22 .staller {4} ∧ 1+Marked.gameValue original marks_22 .dominator {4} ≤ 3
      omega
    · have h := after_22_5
      change 2 ≤ 1+Marked.gameValue original marks_22 .staller {5} ∧ 1+Marked.gameValue original marks_22 .dominator {5} ≤ 3
      omega
    · have h := after_22_6
      change 2 ≤ 1+Marked.gameValue original marks_22 .staller {6} ∧ 1+Marked.gameValue original marks_22 .dominator {6} ≤ 3
      omega
    · have h := after_22_7
      change 2 ≤ 1+Marked.gameValue original marks_22 .staller {7} ∧ 1+Marked.gameValue original marks_22 .dominator {7} ≤ 3
      omega
    · have h := after_22_8
      change 2 ≤ 1+Marked.gameValue original marks_22 .staller {8} ∧ 1+Marked.gameValue original marks_22 .dominator {8} ≤ 3
      omega
    · have h := after_22_9
      change 2 ≤ 1+Marked.gameValue original marks_22 .staller {9} ∧ 1+Marked.gameValue original marks_22 .dominator {9} ≤ 3
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_22 ∅ 10) hv)
def marks_23 : Finset (Fin 11) := {1,2,3,8,9}
theorem after_23_0 : Marked.gameValue original marks_23 .dominator {0}=1 ∧ Marked.gameValue original marks_23 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_23 marks_2 0 1 1 (by decide +kernel) row_2
theorem after_23_1 : Marked.gameValue original marks_23 .dominator {1}=2 ∧ Marked.gameValue original marks_23 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_23 marks_18 1 2 2 (by decide +kernel) row_18
theorem after_23_4 : Marked.gameValue original marks_23 .dominator {4}=1 ∧ Marked.gameValue original marks_23 .staller {4}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_23 marks_4 4 1 1 (by decide +kernel) row_4
theorem after_23_5 : Marked.gameValue original marks_23 .dominator {5}=1 ∧ Marked.gameValue original marks_23 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_23 marks_7 5 1 2 (by decide +kernel) row_7
theorem after_23_6 : Marked.gameValue original marks_23 .dominator {6}=1 ∧ Marked.gameValue original marks_23 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_23 marks_12 6 1 2 (by decide +kernel) row_12
theorem after_23_7 : Marked.gameValue original marks_23 .dominator {7}=1 ∧ Marked.gameValue original marks_23 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_23 marks_6 7 1 2 (by decide +kernel) row_6
theorem after_23_8 : Marked.gameValue original marks_23 .dominator {8}=1 ∧ Marked.gameValue original marks_23 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_23 marks_9 8 1 2 (by decide +kernel) row_9
theorem after_23_10 : Marked.gameValue original marks_23 .dominator {10}=1 ∧ Marked.gameValue original marks_23 .staller {10}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_23 marks_9 10 1 2 (by decide +kernel) row_9
theorem row_23 : Marked.gameValue original marks_23 .dominator ∅=2 ∧ Marked.gameValue original marks_23 .staller ∅=3 := by
  apply LocalProfile.DAG.bellman original marks_23 2 3 0 1 (by decide +kernel) (by decide +kernel)
  · rw [after_23_0.2]
  · rw [after_23_1.1]
  · intro v hv
    fin_cases v
    · have h := after_23_0
      change 2 ≤ 1+Marked.gameValue original marks_23 .staller {0} ∧ 1+Marked.gameValue original marks_23 .dominator {0} ≤ 3
      omega
    · have h := after_23_1
      change 2 ≤ 1+Marked.gameValue original marks_23 .staller {1} ∧ 1+Marked.gameValue original marks_23 .dominator {1} ≤ 3
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_23 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_23 ∅ 3) hv)
    · have h := after_23_4
      change 2 ≤ 1+Marked.gameValue original marks_23 .staller {4} ∧ 1+Marked.gameValue original marks_23 .dominator {4} ≤ 3
      omega
    · have h := after_23_5
      change 2 ≤ 1+Marked.gameValue original marks_23 .staller {5} ∧ 1+Marked.gameValue original marks_23 .dominator {5} ≤ 3
      omega
    · have h := after_23_6
      change 2 ≤ 1+Marked.gameValue original marks_23 .staller {6} ∧ 1+Marked.gameValue original marks_23 .dominator {6} ≤ 3
      omega
    · have h := after_23_7
      change 2 ≤ 1+Marked.gameValue original marks_23 .staller {7} ∧ 1+Marked.gameValue original marks_23 .dominator {7} ≤ 3
      omega
    · have h := after_23_8
      change 2 ≤ 1+Marked.gameValue original marks_23 .staller {8} ∧ 1+Marked.gameValue original marks_23 .dominator {8} ≤ 3
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_23 ∅ 9) hv)
    · have h := after_23_10
      change 2 ≤ 1+Marked.gameValue original marks_23 .staller {10} ∧ 1+Marked.gameValue original marks_23 .dominator {10} ≤ 3
      omega
end IsolationGame.FullCanonical.T08
