import FullCanonical07Rows00
namespace IsolationGame.FullCanonical.T07
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_4 : Finset (Fin 8) := {0,1,2,3,5,6}
theorem after_4_0 : Marked.gameValue original marks_4 .dominator {0}=0 ∧ Marked.gameValue original marks_4 .staller {0}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_4 marks_0 0 0 0 (by decide +kernel) row_0
theorem after_4_4 : Marked.gameValue original marks_4 .dominator {4}=0 ∧ Marked.gameValue original marks_4 .staller {4}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_4 marks_0 4 0 0 (by decide +kernel) row_0
theorem after_4_5 : Marked.gameValue original marks_4 .dominator {5}=0 ∧ Marked.gameValue original marks_4 .staller {5}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_4 marks_0 5 0 0 (by decide +kernel) row_0
theorem after_4_7 : Marked.gameValue original marks_4 .dominator {7}=0 ∧ Marked.gameValue original marks_4 .staller {7}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_4 marks_0 7 0 0 (by decide +kernel) row_0
theorem row_4 : Marked.gameValue original marks_4 .dominator ∅=1 ∧ Marked.gameValue original marks_4 .staller ∅=1 := by
  apply LocalProfile.DAG.bellman original marks_4 1 1 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_4_0.2]
  · rw [after_4_0.1]
  · intro v hv
    fin_cases v
    · have h := after_4_0
      change 1 ≤ 1+Marked.gameValue original marks_4 .staller {0} ∧ 1+Marked.gameValue original marks_4 .dominator {0} ≤ 1
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 3) hv)
    · have h := after_4_4
      change 1 ≤ 1+Marked.gameValue original marks_4 .staller {4} ∧ 1+Marked.gameValue original marks_4 .dominator {4} ≤ 1
      omega
    · have h := after_4_5
      change 1 ≤ 1+Marked.gameValue original marks_4 .staller {5} ∧ 1+Marked.gameValue original marks_4 .dominator {5} ≤ 1
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 6) hv)
    · have h := after_4_7
      change 1 ≤ 1+Marked.gameValue original marks_4 .staller {7} ∧ 1+Marked.gameValue original marks_4 .dominator {7} ≤ 1
      omega
def marks_5 : Finset (Fin 8) := {0,4,5,6,7}
theorem after_5_0 : Marked.gameValue original marks_5 .dominator {0}=1 ∧ Marked.gameValue original marks_5 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_5 marks_2 0 1 1 (by decide +kernel) row_2
theorem after_5_1 : Marked.gameValue original marks_5 .dominator {1}=0 ∧ Marked.gameValue original marks_5 .staller {1}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_5 marks_0 1 0 0 (by decide +kernel) row_0
theorem after_5_2 : Marked.gameValue original marks_5 .dominator {2}=0 ∧ Marked.gameValue original marks_5 .staller {2}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_5 marks_0 2 0 0 (by decide +kernel) row_0
theorem after_5_3 : Marked.gameValue original marks_5 .dominator {3}=0 ∧ Marked.gameValue original marks_5 .staller {3}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_5 marks_0 3 0 0 (by decide +kernel) row_0
theorem row_5 : Marked.gameValue original marks_5 .dominator ∅=1 ∧ Marked.gameValue original marks_5 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_5 1 2 1 0 (by decide +kernel) (by decide +kernel)
  · rw [after_5_1.2]
  · rw [after_5_0.1]
  · intro v hv
    fin_cases v
    · have h := after_5_0
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {0} ∧ 1+Marked.gameValue original marks_5 .dominator {0} ≤ 2
      omega
    · have h := after_5_1
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {1} ∧ 1+Marked.gameValue original marks_5 .dominator {1} ≤ 2
      omega
    · have h := after_5_2
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {2} ∧ 1+Marked.gameValue original marks_5 .dominator {2} ≤ 2
      omega
    · have h := after_5_3
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {3} ∧ 1+Marked.gameValue original marks_5 .dominator {3} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 4) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 6) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 7) hv)
def marks_6 : Finset (Fin 8) := {1,2,3,5,6}
theorem after_6_0 : Marked.gameValue original marks_6 .dominator {0}=0 ∧ Marked.gameValue original marks_6 .staller {0}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_6 marks_0 0 0 0 (by decide +kernel) row_0
theorem after_6_1 : Marked.gameValue original marks_6 .dominator {1}=1 ∧ Marked.gameValue original marks_6 .staller {1}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_6 marks_4 1 1 1 (by decide +kernel) row_4
theorem after_6_4 : Marked.gameValue original marks_6 .dominator {4}=0 ∧ Marked.gameValue original marks_6 .staller {4}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_6 marks_0 4 0 0 (by decide +kernel) row_0
theorem after_6_5 : Marked.gameValue original marks_6 .dominator {5}=0 ∧ Marked.gameValue original marks_6 .staller {5}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_6 marks_0 5 0 0 (by decide +kernel) row_0
theorem after_6_7 : Marked.gameValue original marks_6 .dominator {7}=0 ∧ Marked.gameValue original marks_6 .staller {7}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_6 marks_0 7 0 0 (by decide +kernel) row_0
theorem row_6 : Marked.gameValue original marks_6 .dominator ∅=1 ∧ Marked.gameValue original marks_6 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_6 1 2 0 1 (by decide +kernel) (by decide +kernel)
  · rw [after_6_0.2]
  · rw [after_6_1.1]
  · intro v hv
    fin_cases v
    · have h := after_6_0
      change 1 ≤ 1+Marked.gameValue original marks_6 .staller {0} ∧ 1+Marked.gameValue original marks_6 .dominator {0} ≤ 2
      omega
    · have h := after_6_1
      change 1 ≤ 1+Marked.gameValue original marks_6 .staller {1} ∧ 1+Marked.gameValue original marks_6 .dominator {1} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_6 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_6 ∅ 3) hv)
    · have h := after_6_4
      change 1 ≤ 1+Marked.gameValue original marks_6 .staller {4} ∧ 1+Marked.gameValue original marks_6 .dominator {4} ≤ 2
      omega
    · have h := after_6_5
      change 1 ≤ 1+Marked.gameValue original marks_6 .staller {5} ∧ 1+Marked.gameValue original marks_6 .dominator {5} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_6 ∅ 6) hv)
    · have h := after_6_7
      change 1 ≤ 1+Marked.gameValue original marks_6 .staller {7} ∧ 1+Marked.gameValue original marks_6 .dominator {7} ≤ 2
      omega
def marks_7 : Finset (Fin 8) := {4,5,6,7}
theorem after_7_0 : Marked.gameValue original marks_7 .dominator {0}=1 ∧ Marked.gameValue original marks_7 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_2 0 1 1 (by decide +kernel) row_2
theorem after_7_1 : Marked.gameValue original marks_7 .dominator {1}=0 ∧ Marked.gameValue original marks_7 .staller {1}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_0 1 0 0 (by decide +kernel) row_0
theorem after_7_2 : Marked.gameValue original marks_7 .dominator {2}=0 ∧ Marked.gameValue original marks_7 .staller {2}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_0 2 0 0 (by decide +kernel) row_0
theorem after_7_3 : Marked.gameValue original marks_7 .dominator {3}=1 ∧ Marked.gameValue original marks_7 .staller {3}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_1 3 1 1 (by decide +kernel) row_1
theorem after_7_4 : Marked.gameValue original marks_7 .dominator {4}=1 ∧ Marked.gameValue original marks_7 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_5 4 1 2 (by decide +kernel) row_5
theorem row_7 : Marked.gameValue original marks_7 .dominator ∅=1 ∧ Marked.gameValue original marks_7 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_7 1 2 1 0 (by decide +kernel) (by decide +kernel)
  · rw [after_7_1.2]
  · rw [after_7_0.1]
  · intro v hv
    fin_cases v
    · have h := after_7_0
      change 1 ≤ 1+Marked.gameValue original marks_7 .staller {0} ∧ 1+Marked.gameValue original marks_7 .dominator {0} ≤ 2
      omega
    · have h := after_7_1
      change 1 ≤ 1+Marked.gameValue original marks_7 .staller {1} ∧ 1+Marked.gameValue original marks_7 .dominator {1} ≤ 2
      omega
    · have h := after_7_2
      change 1 ≤ 1+Marked.gameValue original marks_7 .staller {2} ∧ 1+Marked.gameValue original marks_7 .dominator {2} ≤ 2
      omega
    · have h := after_7_3
      change 1 ≤ 1+Marked.gameValue original marks_7 .staller {3} ∧ 1+Marked.gameValue original marks_7 .dominator {3} ≤ 2
      omega
    · have h := after_7_4
      change 1 ≤ 1+Marked.gameValue original marks_7 .staller {4} ∧ 1+Marked.gameValue original marks_7 .dominator {4} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_7 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_7 ∅ 6) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_7 ∅ 7) hv)
end IsolationGame.FullCanonical.T07
