import FullCanonical18Rows04
namespace IsolationGame.FullCanonical.T18
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_20 : Finset (Fin 9) := {2,3}
theorem after_20_0 : Marked.gameValue original marks_20 .dominator {0}=1 ∧ Marked.gameValue original marks_20 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_20 marks_2 0 1 1 (by decide +kernel) row_2
theorem after_20_1 : Marked.gameValue original marks_20 .dominator {1}=1 ∧ Marked.gameValue original marks_20 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_20 marks_8 1 1 2 (by decide +kernel) row_8
theorem after_20_2 : Marked.gameValue original marks_20 .dominator {2}=1 ∧ Marked.gameValue original marks_20 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_20 marks_16 2 1 2 (by decide +kernel) row_16
theorem after_20_4 : Marked.gameValue original marks_20 .dominator {4}=0 ∧ Marked.gameValue original marks_20 .staller {4}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_20 marks_0 4 0 0 (by decide +kernel) row_0
theorem after_20_5 : Marked.gameValue original marks_20 .dominator {5}=1 ∧ Marked.gameValue original marks_20 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_20 marks_6 5 1 2 (by decide +kernel) row_6
theorem after_20_6 : Marked.gameValue original marks_20 .dominator {6}=1 ∧ Marked.gameValue original marks_20 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_20 marks_15 6 1 2 (by decide +kernel) row_15
theorem after_20_7 : Marked.gameValue original marks_20 .dominator {7}=1 ∧ Marked.gameValue original marks_20 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_20 marks_14 7 1 2 (by decide +kernel) row_14
theorem after_20_8 : Marked.gameValue original marks_20 .dominator {8}=1 ∧ Marked.gameValue original marks_20 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_20 marks_8 8 1 2 (by decide +kernel) row_8
theorem row_20 : Marked.gameValue original marks_20 .dominator ∅=1 ∧ Marked.gameValue original marks_20 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_20 1 2 4 0 (by decide +kernel) (by decide +kernel)
  · rw [after_20_4.2]
  · rw [after_20_0.1]
  · intro v hv
    fin_cases v
    · have h := after_20_0
      change 1 ≤ 1+Marked.gameValue original marks_20 .staller {0} ∧ 1+Marked.gameValue original marks_20 .dominator {0} ≤ 2
      omega
    · have h := after_20_1
      change 1 ≤ 1+Marked.gameValue original marks_20 .staller {1} ∧ 1+Marked.gameValue original marks_20 .dominator {1} ≤ 2
      omega
    · have h := after_20_2
      change 1 ≤ 1+Marked.gameValue original marks_20 .staller {2} ∧ 1+Marked.gameValue original marks_20 .dominator {2} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_20 ∅ 3) hv)
    · have h := after_20_4
      change 1 ≤ 1+Marked.gameValue original marks_20 .staller {4} ∧ 1+Marked.gameValue original marks_20 .dominator {4} ≤ 2
      omega
    · have h := after_20_5
      change 1 ≤ 1+Marked.gameValue original marks_20 .staller {5} ∧ 1+Marked.gameValue original marks_20 .dominator {5} ≤ 2
      omega
    · have h := after_20_6
      change 1 ≤ 1+Marked.gameValue original marks_20 .staller {6} ∧ 1+Marked.gameValue original marks_20 .dominator {6} ≤ 2
      omega
    · have h := after_20_7
      change 1 ≤ 1+Marked.gameValue original marks_20 .staller {7} ∧ 1+Marked.gameValue original marks_20 .dominator {7} ≤ 2
      omega
    · have h := after_20_8
      change 1 ≤ 1+Marked.gameValue original marks_20 .staller {8} ∧ 1+Marked.gameValue original marks_20 .dominator {8} ≤ 2
      omega
def marks_21 : Finset (Fin 9) := {}
theorem after_21_0 : Marked.gameValue original marks_21 .dominator {0}=2 ∧ Marked.gameValue original marks_21 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_21 marks_7 0 2 2 (by decide +kernel) row_7
theorem after_21_1 : Marked.gameValue original marks_21 .dominator {1}=1 ∧ Marked.gameValue original marks_21 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_21 marks_8 1 1 2 (by decide +kernel) row_8
theorem after_21_2 : Marked.gameValue original marks_21 .dominator {2}=1 ∧ Marked.gameValue original marks_21 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_21 marks_16 2 1 2 (by decide +kernel) row_16
theorem after_21_3 : Marked.gameValue original marks_21 .dominator {3}=1 ∧ Marked.gameValue original marks_21 .staller {3}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_21 marks_20 3 1 2 (by decide +kernel) row_20
theorem after_21_4 : Marked.gameValue original marks_21 .dominator {4}=1 ∧ Marked.gameValue original marks_21 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_21 marks_5 4 1 2 (by decide +kernel) row_5
theorem after_21_5 : Marked.gameValue original marks_21 .dominator {5}=1 ∧ Marked.gameValue original marks_21 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_21 marks_13 5 1 2 (by decide +kernel) row_13
theorem after_21_6 : Marked.gameValue original marks_21 .dominator {6}=2 ∧ Marked.gameValue original marks_21 .staller {6}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_21 marks_19 6 2 3 (by decide +kernel) row_19
theorem after_21_7 : Marked.gameValue original marks_21 .dominator {7}=2 ∧ Marked.gameValue original marks_21 .staller {7}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_21 marks_18 7 2 3 (by decide +kernel) row_18
theorem after_21_8 : Marked.gameValue original marks_21 .dominator {8}=3 ∧ Marked.gameValue original marks_21 .staller {8}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_21 marks_17 8 3 3 (by decide +kernel) row_17
theorem row_21 : Marked.gameValue original marks_21 .dominator ∅=3 ∧ Marked.gameValue original marks_21 .staller ∅=4 := by
  apply LocalProfile.DAG.bellman original marks_21 3 4 0 8 (by decide +kernel) (by decide +kernel)
  · rw [after_21_0.2]
  · rw [after_21_8.1]
  · intro v hv
    fin_cases v
    · have h := after_21_0
      change 3 ≤ 1+Marked.gameValue original marks_21 .staller {0} ∧ 1+Marked.gameValue original marks_21 .dominator {0} ≤ 4
      omega
    · have h := after_21_1
      change 3 ≤ 1+Marked.gameValue original marks_21 .staller {1} ∧ 1+Marked.gameValue original marks_21 .dominator {1} ≤ 4
      omega
    · have h := after_21_2
      change 3 ≤ 1+Marked.gameValue original marks_21 .staller {2} ∧ 1+Marked.gameValue original marks_21 .dominator {2} ≤ 4
      omega
    · have h := after_21_3
      change 3 ≤ 1+Marked.gameValue original marks_21 .staller {3} ∧ 1+Marked.gameValue original marks_21 .dominator {3} ≤ 4
      omega
    · have h := after_21_4
      change 3 ≤ 1+Marked.gameValue original marks_21 .staller {4} ∧ 1+Marked.gameValue original marks_21 .dominator {4} ≤ 4
      omega
    · have h := after_21_5
      change 3 ≤ 1+Marked.gameValue original marks_21 .staller {5} ∧ 1+Marked.gameValue original marks_21 .dominator {5} ≤ 4
      omega
    · have h := after_21_6
      change 3 ≤ 1+Marked.gameValue original marks_21 .staller {6} ∧ 1+Marked.gameValue original marks_21 .dominator {6} ≤ 4
      omega
    · have h := after_21_7
      change 3 ≤ 1+Marked.gameValue original marks_21 .staller {7} ∧ 1+Marked.gameValue original marks_21 .dominator {7} ≤ 4
      omega
    · have h := after_21_8
      change 3 ≤ 1+Marked.gameValue original marks_21 .staller {8} ∧ 1+Marked.gameValue original marks_21 .dominator {8} ≤ 4
      omega
end IsolationGame.FullCanonical.T18
