import FloorLocalBase
import FloorLocalRow017
import FloorLocalRow019
set_option maxRecDepth 4096
set_option maxHeartbeats 1000000
namespace IsolationGame.FloorLocal
def marks_108 : Finset (Fin 7) := {0,1,4}
theorem normalized_108 : ∀v : Fin 7, Marked.White original_02 marks_108 ∅ v ↔ v∈({2,3,5,6} : Finset (Fin 7)) := by decide +kernel
theorem after_108_1 : Marked.gameValue original_02 marks_108 .dominator {1}=1 ∧ Marked.gameValue original_02 marks_108 .staller {1}=1 :=
  LocalProfile.DAG.transport original_02 marks_108 marks_019 1 1 1 (by decide +kernel) row_019
theorem after_108_2 : Marked.gameValue original_02 marks_108 .dominator {2}=1 ∧ Marked.gameValue original_02 marks_108 .staller {2}=1 :=
  LocalProfile.DAG.transport original_02 marks_108 marks_019 2 1 1 (by decide +kernel) row_019
theorem after_108_3 : Marked.gameValue original_02 marks_108 .dominator {3}=1 ∧ Marked.gameValue original_02 marks_108 .staller {3}=1 :=
  LocalProfile.DAG.transport original_02 marks_108 marks_019 3 1 1 (by decide +kernel) row_019
theorem after_108_4 : Marked.gameValue original_02 marks_108 .dominator {4}=1 ∧ Marked.gameValue original_02 marks_108 .staller {4}=1 :=
  LocalProfile.DAG.transport original_02 marks_108 marks_017 4 1 1 (by decide +kernel) row_017
theorem after_108_5 : Marked.gameValue original_02 marks_108 .dominator {5}=1 ∧ Marked.gameValue original_02 marks_108 .staller {5}=1 :=
  LocalProfile.DAG.transport original_02 marks_108 marks_017 5 1 1 (by decide +kernel) row_017
theorem after_108_6 : Marked.gameValue original_02 marks_108 .dominator {6}=1 ∧ Marked.gameValue original_02 marks_108 .staller {6}=1 :=
  LocalProfile.DAG.transport original_02 marks_108 marks_017 6 1 1 (by decide +kernel) row_017
theorem row_108 : Marked.gameValue original_02 marks_108 .dominator ∅=2 ∧ Marked.gameValue original_02 marks_108 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original_02 marks_108 2 2 1 1 (by decide +kernel) (by decide +kernel)
  · rw [after_108_1.2]
  · rw [after_108_1.1]
  · intro v hv
    fin_cases v
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_108 ∅ 0) hv)
    · have h := after_108_1
      change 2≤1+Marked.gameValue original_02 marks_108 .staller {1} ∧ 1+Marked.gameValue original_02 marks_108 .dominator {1}≤2
      omega
    · have h := after_108_2
      change 2≤1+Marked.gameValue original_02 marks_108 .staller {2} ∧ 1+Marked.gameValue original_02 marks_108 .dominator {2}≤2
      omega
    · have h := after_108_3
      change 2≤1+Marked.gameValue original_02 marks_108 .staller {3} ∧ 1+Marked.gameValue original_02 marks_108 .dominator {3}≤2
      omega
    · have h := after_108_4
      change 2≤1+Marked.gameValue original_02 marks_108 .staller {4} ∧ 1+Marked.gameValue original_02 marks_108 .dominator {4}≤2
      omega
    · have h := after_108_5
      change 2≤1+Marked.gameValue original_02 marks_108 .staller {5} ∧ 1+Marked.gameValue original_02 marks_108 .dominator {5}≤2
      omega
    · have h := after_108_6
      change 2≤1+Marked.gameValue original_02 marks_108 .staller {6} ∧ 1+Marked.gameValue original_02 marks_108 .dominator {6}≤2
      omega
#print axioms row_108
end IsolationGame.FloorLocal
