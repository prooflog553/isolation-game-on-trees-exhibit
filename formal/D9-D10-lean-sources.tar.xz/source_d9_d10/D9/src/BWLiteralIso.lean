import BWCoordinates
import BWCenterBounds
namespace IsolationGame.BWCoordinates
open BWBridge
set_option maxHeartbeats 3000000

 theorem decode_ne_root (n : Nat) (i : Fin n) (k : Fin 7) :
    decode n (some (i,k)) ≠ root n := by
  fin_cases k <;> simp [decode,root]

 theorem decode_root_adj (n : Nat) (i : Fin n) (k : Fin 7) :
    MarkedModule.original.Adj (root n) (decode n (some (i,k))) ↔ k=0 := by
  fin_cases k <;> simp [decode,root,MarkedModule.original,GatedGraph.connected,
    GatedGraph.original,GatedGraph.adj,GatedGraph.gateGraph,MarkedModule.star,MarkedModule.owner]

 theorem decode_nodes_adj (n : Nat) (i j : Fin n) (a b : Fin 7) :
    MarkedModule.original.Adj (decode n (some (i,a))) (decode n (some (j,b))) ↔
      i=j ∧ LiteralBW.localAdj a b := by
  fin_cases a <;> fin_cases b <;>
    simp [decode,MarkedModule.original,GatedGraph.connected,GatedGraph.original,
      GatedGraph.adj,GatedGraph.gateGraph,MarkedModule.star,MarkedModule.owner,
      LiteralBW.localAdj,LiteralBW.localForward,eq_comm]

 theorem encode_adj (p q : Nat) (u v : Coordinates p q) :
    (LiteralBW.graph p q).Adj (encode p q u) (encode p q v) ↔
      (BWBridge.original p q).Adj (sides p q u) (sides p q v) := by
  cases u with
  | inl u =>
    cases v with
    | inl v =>
      cases u with
      | none =>
        cases v with
        | none =>
          simp [encode,sides,sideEquiv,decode,BWBridge.original,Attachment.original,root]
        | some v =>
          obtain ⟨j,b⟩ := v
          simp only [encode,LiteralBW.x_adj_node,sides,Equiv.sumCongr_apply,Sum.map_inl,Sum.map_inr,Equiv.coe_fn_mk,sideEquiv,decode,
            BWBridge.original,Attachment.original]
          change ((Fin.castAdd q j).val<p ∧ b=0) ↔ MarkedModule.original.Adj (root p) (decode p (some (j,b)))
          rw [decode_root_adj]
          have hi := j.isLt
          simp only [Fin.coe_castAdd,Fin.coe_natAdd]
          omega
      | some u =>
        cases v with
        | none =>
          obtain ⟨i,a⟩ := u
          rw [(LiteralBW.graph p q).adj_comm,(BWBridge.original p q).adj_comm]
          simp only [encode,LiteralBW.x_adj_node,sides,Equiv.sumCongr_apply,Sum.map_inl,Sum.map_inr,Equiv.coe_fn_mk,sideEquiv,decode,
            BWBridge.original,Attachment.original]
          change ((Fin.castAdd q i).val<p ∧ a=0) ↔ MarkedModule.original.Adj (root p) (decode p (some (i,a)))
          rw [decode_root_adj]
          have hi := i.isLt
          simp only [Fin.coe_castAdd,Fin.coe_natAdd]
          omega
        | some v =>
          obtain ⟨i,a⟩ := u
          obtain ⟨j,b⟩ := v
          simp only [encode,LiteralBW.nodes_adj,sides,Equiv.sumCongr_apply,Sum.map_inl,Sum.map_inr,Equiv.coe_fn_mk,sideEquiv,
            BWBridge.original,Attachment.original]
          rw [left_index_inj,decode_nodes_adj]
    | inr v =>
      cases u with
      | none =>
        cases v with
        | none =>
          simp [encode,sides,sideEquiv,decode,BWBridge.original,Attachment.original,root,LiteralBW.centres_adjacent]
        | some v =>
          obtain ⟨j,b⟩ := v
          simp only [encode,LiteralBW.x_adj_node,sides,Equiv.sumCongr_apply,Sum.map_inl,Sum.map_inr,Equiv.coe_fn_mk,sideEquiv,decode,
            BWBridge.original,Attachment.original]
          have hi := j.isLt
          simp only [Fin.coe_castAdd,Fin.coe_natAdd]
          have hn := decode_ne_root q j b
          simp only [decode,root] at hn
          simp only [root,hn,and_false,true_and]
          apply iff_false_intro
          rintro ⟨h,_⟩
          omega
      | some u =>
        cases v with
        | none =>
          obtain ⟨i,a⟩ := u
          rw [(LiteralBW.graph p q).adj_comm,(BWBridge.original p q).adj_comm]
          simp only [encode,LiteralBW.y_adj_node,sides,Equiv.sumCongr_apply,Sum.map_inl,Sum.map_inr,Equiv.coe_fn_mk,sideEquiv,decode,
            BWBridge.original,Attachment.original]
          have hi := i.isLt
          simp only [Fin.coe_castAdd,Fin.coe_natAdd]
          have hn := decode_ne_root p i a
          simp only [decode,root] at hn
          simp only [root,hn,and_false,true_and]
          apply iff_false_intro
          rintro ⟨h,_⟩
          omega
        | some v =>
          obtain ⟨i,a⟩ := u
          obtain ⟨j,b⟩ := v
          simp only [encode,LiteralBW.nodes_adj,sides,Equiv.sumCongr_apply,Sum.map_inl,Sum.map_inr,Equiv.coe_fn_mk,sideEquiv,
            BWBridge.original,Attachment.original]
          simp [left_ne_right,decode_ne_root]
  | inr u =>
    cases v with
    | inl v =>
      cases u with
      | none =>
        cases v with
        | none =>
          rw [(LiteralBW.graph p q).adj_comm]
          simp [encode,sides,sideEquiv,decode,BWBridge.original,Attachment.original,root,LiteralBW.centres_adjacent]
        | some v =>
          obtain ⟨j,b⟩ := v
          simp only [encode,LiteralBW.y_adj_node,sides,Equiv.sumCongr_apply,Sum.map_inl,Sum.map_inr,Equiv.coe_fn_mk,sideEquiv,decode,
            BWBridge.original,Attachment.original]
          have hi := j.isLt
          simp only [Fin.coe_castAdd,Fin.coe_natAdd]
          have hn := decode_ne_root p j b
          simp only [decode,root] at hn
          simp only [root,hn,and_false,true_and]
          apply iff_false_intro
          rintro ⟨h,_⟩
          omega
      | some u =>
        cases v with
        | none =>
          obtain ⟨i,a⟩ := u
          rw [(LiteralBW.graph p q).adj_comm,(BWBridge.original p q).adj_comm]
          simp only [encode,LiteralBW.x_adj_node,sides,Equiv.sumCongr_apply,Sum.map_inl,Sum.map_inr,Equiv.coe_fn_mk,sideEquiv,decode,
            BWBridge.original,Attachment.original]
          have hi := i.isLt
          simp only [Fin.coe_castAdd,Fin.coe_natAdd]
          have hn := decode_ne_root q i a
          simp only [decode,root] at hn
          simp only [root,hn,and_false,true_and]
          apply iff_false_intro
          rintro ⟨h,_⟩
          omega
        | some v =>
          obtain ⟨i,a⟩ := u
          obtain ⟨j,b⟩ := v
          simp only [encode,LiteralBW.nodes_adj,sides,Equiv.sumCongr_apply,Sum.map_inl,Sum.map_inr,Equiv.coe_fn_mk,sideEquiv,
            BWBridge.original,Attachment.original]
          simp [Ne.symm (left_ne_right p q j i),decode_ne_root]
    | inr v =>
      cases u with
      | none =>
        cases v with
        | none =>
          simp [encode,sides,sideEquiv,decode,BWBridge.original,Attachment.original,root]
        | some v =>
          obtain ⟨j,b⟩ := v
          simp only [encode,LiteralBW.y_adj_node,sides,Equiv.sumCongr_apply,Sum.map_inl,Sum.map_inr,Equiv.coe_fn_mk,sideEquiv,decode,
            BWBridge.original,Attachment.original]
          change (p≤(Fin.natAdd p j).val ∧ b=0) ↔ MarkedModule.original.Adj (root q) (decode q (some (j,b)))
          rw [decode_root_adj]
          have hi := j.isLt
          simp only [Fin.coe_castAdd,Fin.coe_natAdd]
          omega
      | some u =>
        cases v with
        | none =>
          obtain ⟨i,a⟩ := u
          rw [(LiteralBW.graph p q).adj_comm,(BWBridge.original p q).adj_comm]
          simp only [encode,LiteralBW.y_adj_node,sides,Equiv.sumCongr_apply,Sum.map_inl,Sum.map_inr,Equiv.coe_fn_mk,sideEquiv,decode,
            BWBridge.original,Attachment.original]
          change (p≤(Fin.natAdd p i).val ∧ a=0) ↔ MarkedModule.original.Adj (root q) (decode q (some (i,a)))
          rw [decode_root_adj]
          have hi := i.isLt
          simp only [Fin.coe_castAdd,Fin.coe_natAdd]
          omega
        | some v =>
          obtain ⟨i,a⟩ := u
          obtain ⟨j,b⟩ := v
          simp only [encode,LiteralBW.nodes_adj,sides,Equiv.sumCongr_apply,Sum.map_inl,Sum.map_inr,Equiv.coe_fn_mk,sideEquiv,
            BWBridge.original,Attachment.original]
          rw [right_index_inj,decode_nodes_adj]

noncomputable def graphEquiv (p q : Nat) : BWBridge.Vertex p q ≃ LiteralBW.Vertex p q :=
  (sides p q).symm.trans (literalEquiv p q)

 theorem graphEquiv_adj (p q : Nat) (u v : BWBridge.Vertex p q) :
    (LiteralBW.graph p q).Adj (graphEquiv p q u) (graphEquiv p q v) ↔
      (BWBridge.original p q).Adj u v := by
  simpa [graphEquiv,literalEquiv] using encode_adj p q ((sides p q).symm u) ((sides p q).symm v)

 theorem graphEquiv_left_root (p q : Nat) :
    graphEquiv p q (.inl (root p))=LiteralBW.x p q := rfl
 theorem graphEquiv_right_root (p q : Nat) :
    graphEquiv p q (.inr (root q))=LiteralBW.y p q := rfl

#print axioms graphEquiv_adj
end IsolationGame.BWCoordinates
