import RootedBridgeDiameter
import GeneralP4StarModel
import CanonicalTrees
import CoreFamilyAdjacency

/-! Actual root radius for arbitrary core lists and arbitrary receiver parameters. -/
namespace IsolationGame.CoreReceiverGeometry
open RootedBridgeDiameter

/-- Every canonical branch has its accepted actual root-depth-three certificate,
so the literal core assembly has actual root radius at most four. -/
theorem core_rootWalkBound (xs : List Nat) (q : Nat) :
    RootWalkBound (CoreFamily.graph xs q) none 4 := by
  intro v
  cases v with
  | none => exact ⟨.nil, by simp⟩
  | some v =>
    rcases v with ⟨i,v⟩
    let t := CoreFamily.label xs q i
    let f : CanonicalLocal.graph t →g CoreFamily.graph xs q := {
      toFun := fun u => some ⟨i,u⟩
      map_rel' := by
        intro a b h
        exact (CoreFamilySemantics.same_adj xs q i a b).mpr h }
    have he : (CoreFamily.graph xs q).Adj none (f (CanonicalLocal.root t)) :=
      (CoreFamilySemantics.root_adj xs q i (CanonicalLocal.root t)).mpr rfl
    exact attached_local_rootWalk _ _ none (CanonicalLocal.root t) f he
      (rootWalkBound_of_reachThree _ _ (CanonicalLocal.reach_three t)) v

theorem core_root_radius_le_four (xs : List Nat) (q : Nat) (v : CoreFamily.Vertex xs q) :
    (CoreFamily.graph xs q).dist none v ≤ 4 :=
  rootWalkBound_dist _ _ _ (core_rootWalkBound xs q) v

theorem core_connected (xs : List Nat) (q : Nat) : (CoreFamily.graph xs q).Connected :=
  rootWalkBound_connected _ _ _ (core_rootWalkBound xs q)

private theorem p4_root_reachThree : CanonicalLocal.ReachThree P4Receiver.T 0 := by
  unfold CanonicalLocal.ReachThree
  decide +kernel

private theorem ordinary_root_reachThree :
    CanonicalLocal.ReachThree CentreOrdinary.graph 0 := by
  unfold CanonicalLocal.ReachThree
  decide +kernel

private theorem receiver_branch_rootWalk (k p : Nat) (i : Fin k) (r : Fin 4) :
    ∃ w : (GeneralP4Receiver.graph k p).Walk (GeneralP4Receiver.centre k p)
      (GeneralP4Receiver.branch k p i r), w.length ≤ 4 := by
  let f : P4Receiver.T →g GeneralP4Receiver.graph k p := {
    toFun := GeneralP4Receiver.branch k p i
    map_rel' := by intro r s h; exact ⟨rfl,h⟩ }
  have he : (GeneralP4Receiver.graph k p).Adj (GeneralP4Receiver.centre k p) (f 0) := rfl
  exact attached_local_rootWalk _ _ _ 0 f he
    (rootWalkBound_of_reachThree _ _ p4_root_reachThree) r

private theorem receiver_ordinary_rootWalk (k p : Nat) (i : Fin p) (r : Fin 7) :
    ∃ w : (GeneralP4Receiver.graph k p).Walk (GeneralP4Receiver.centre k p)
      (GeneralP4Receiver.ordinary k p i r), w.length ≤ 4 := by
  let f : CentreOrdinary.graph →g GeneralP4Receiver.graph k p := {
    toFun := GeneralP4Receiver.ordinary k p i
    map_rel' := by intro r s h; exact ⟨rfl,h⟩ }
  have he : (GeneralP4Receiver.graph k p).Adj (GeneralP4Receiver.centre k p) (f 0) :=
    ⟨rfl,rfl⟩
  exact attached_local_rootWalk _ _ _ 0 f he
    (rootWalkBound_of_reachThree _ _ ordinary_root_reachThree) r

/-- Includes k=p=0: the unchanged receiver is then the singleton centre. -/
theorem receiver_rootWalkBound (k p : Nat) :
    RootWalkBound (GeneralP4Receiver.graph k p) (GeneralP4Receiver.centre k p) 4 := by
  intro v
  rcases TwoPool.vertex_exhaustion p 0 v with
    ⟨a,rfl⟩ | ⟨i,r,rfl⟩ | ⟨i,r,rfl⟩
  · cases a with
    | none => exact ⟨.nil, by simp⟩
    | some a =>
      rcases a with ⟨i,r⟩
      exact receiver_branch_rootWalk k p i r
  · exact receiver_ordinary_rootWalk k p i r
  · exact Fin.elim0 i

theorem receiver_root_radius_le_four (k p : Nat) (v : GeneralP4Receiver.Vertex k p) :
    (GeneralP4Receiver.graph k p).dist (GeneralP4Receiver.centre k p) v ≤ 4 :=
  rootWalkBound_dist _ _ _ (receiver_rootWalkBound k p) v

#print axioms core_rootWalkBound
#print axioms core_root_radius_le_four
#print axioms core_connected
#print axioms receiver_rootWalkBound
#print axioms receiver_root_radius_le_four
end IsolationGame.CoreReceiverGeometry
