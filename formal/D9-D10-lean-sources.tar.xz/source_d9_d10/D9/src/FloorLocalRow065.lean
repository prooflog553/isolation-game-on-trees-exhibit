import FloorLocalBase
import FloorLocalRow001
import FloorLocalRow016
import FloorLocalRow018
set_option maxRecDepth 4096
set_option maxHeartbeats 1000000
namespace IsolationGame.FloorLocal
def marks_065 : Finset (Fin 7) := {2,3,5,6}
theorem normalized_065 : ∀v : Fin 7, Marked.White original_02 marks_065 ∅ v ↔ v∈({0,1,4} : Finset (Fin 7)) := by decide +kernel
theorem after_065_0 : Marked.gameValue original_02 marks_065 .dominator {0}=0 ∧ Marked.gameValue original_02 marks_065 .staller {0}=0 :=
  LocalProfile.DAG.transport original_02 marks_065 marks_001 0 0 0 (by decide +kernel) row_001
theorem after_065_1 : Marked.gameValue original_02 marks_065 .dominator {1}=0 ∧ Marked.gameValue original_02 marks_065 .staller {1}=0 :=
  LocalProfile.DAG.transport original_02 marks_065 marks_001 1 0 0 (by decide +kernel) row_001
theorem after_065_2 : Marked.gameValue original_02 marks_065 .dominator {2}=1 ∧ Marked.gameValue original_02 marks_065 .staller {2}=1 :=
  LocalProfile.DAG.transport original_02 marks_065 marks_018 2 1 1 (by decide +kernel) row_018
theorem after_065_4 : Marked.gameValue original_02 marks_065 .dominator {4}=0 ∧ Marked.gameValue original_02 marks_065 .staller {4}=0 :=
  LocalProfile.DAG.transport original_02 marks_065 marks_001 4 0 0 (by decide +kernel) row_001
theorem after_065_5 : Marked.gameValue original_02 marks_065 .dominator {5}=1 ∧ Marked.gameValue original_02 marks_065 .staller {5}=1 :=
  LocalProfile.DAG.transport original_02 marks_065 marks_016 5 1 1 (by decide +kernel) row_016
theorem row_065 : Marked.gameValue original_02 marks_065 .dominator ∅=1 ∧ Marked.gameValue original_02 marks_065 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original_02 marks_065 1 2 0 2 (by decide +kernel) (by decide +kernel)
  · rw [after_065_0.2]
  · rw [after_065_2.1]
  · intro v hv
    fin_cases v
    · have h := after_065_0
      change 1≤1+Marked.gameValue original_02 marks_065 .staller {0} ∧ 1+Marked.gameValue original_02 marks_065 .dominator {0}≤2
      omega
    · have h := after_065_1
      change 1≤1+Marked.gameValue original_02 marks_065 .staller {1} ∧ 1+Marked.gameValue original_02 marks_065 .dominator {1}≤2
      omega
    · have h := after_065_2
      change 1≤1+Marked.gameValue original_02 marks_065 .staller {2} ∧ 1+Marked.gameValue original_02 marks_065 .dominator {2}≤2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_065 ∅ 3) hv)
    · have h := after_065_4
      change 1≤1+Marked.gameValue original_02 marks_065 .staller {4} ∧ 1+Marked.gameValue original_02 marks_065 .dominator {4}≤2
      omega
    · have h := after_065_5
      change 1≤1+Marked.gameValue original_02 marks_065 .staller {5} ∧ 1+Marked.gameValue original_02 marks_065 .dominator {5}≤2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_065 ∅ 6) hv)
#print axioms row_065
end IsolationGame.FloorLocal
