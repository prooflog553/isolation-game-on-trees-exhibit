import FullCanonicalDAG
namespace IsolationGame.FullCanonical.T06
abbrev original : SimpleGraph (Fin 5) := CanonicalLocal.graph CanonicalLocal.Index.t06
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
noncomputable def perm_0 : Fin 5 ≃ Fin 5 :=
  Equiv.ofBijective (fun v => ![0,1,2,3,4] v) (by decide +kernel)
theorem adjacency_0 : ∀u v,original.Adj (perm_0 u) (perm_0 v) ↔ original.Adj u v := by decide +kernel
end IsolationGame.FullCanonical.T06
