import FourteenResidualFinite

/-!
The only unbounded objects here are lists and raw natural codes. Non-all-t01
excludes the empty side. Total length at most three then leaves exactly 1|1,
1|2, or 2|1; the last orientation is transported by the swap lemmas.

No theorem below asserts that a one-center game budget is valid, that every
numeric residual is a game counterexample, or that any of the fourteen games
has been solved. Ordinary pools p/q are not bounded or enumerated.
-/
namespace IsolationGame.FourteenResidual
open CanonicalLocal AllProfileCore PairableProfileCore TwoCoreOpening
open WeakOneCenterArithmetic

/-- An exact bounded-list classifier with no sorting assumptions. -/
theorem classify_profiles (xs ys : List Index)
    (hlen : xs.length + ys.length ≤ 3)
    (h : NumericResidual xs ys) : MatchesFourteen xs ys := by
  have hx := numericResidual_nonempty_left h
  have hy := numericResidual_nonempty_right h
  cases xs with
  | nil => exact False.elim (hx rfl)
  | cons a xs =>
    cases ys with
    | nil => exact False.elim (hy rfl)
    | cons b ys =>
      cases xs with
      | nil =>
        cases ys with
        | nil => exact classify11 a b h
        | cons c cs =>
          have hcs : cs = [] := by
            apply List.eq_nil_of_length_eq_zero
            simp only [List.length_cons, List.length_nil] at hlen
            omega
          subst cs
          exact classify12 a b c h
      | cons c cs =>
        have hcs : cs = [] := by
          apply List.eq_nil_of_length_eq_zero
          simp only [List.length_cons] at hlen
          omega
        have hys : ys = [] := by
          apply List.eq_nil_of_length_eq_zero
          simp only [List.length_cons] at hlen
          omega
        subst cs
        subst ys
        exact matchesFourteen_swap (classify12 b a c (numericResidual_swap h))

/-- Raw codes are interpreted only by the already accepted unrestricted decoder.
In particular an invalid code still contributes t00; no validity proof is used. -/
theorem profileScore_map_decode (xs ys : List Nat) :
    profileScore (xs.map NecessaryCore.decode) (ys.map NecessaryCore.decode) =
      signedScore xs ys := by
  simp only [profileScore, profileCost, profileFullCost, profilePairCount,
    profileWeakPairCount, profileSize, signedScore, oneDiscount,
    cost, numericFullCost, pairCount, fullWeakPairCount, localSizeSum,
    List.map_map, Function.comp_def]

theorem noT02_map_decode (xs : List Nat)
    (h : ∀ n ∈ xs, NecessaryCore.decode n ≠ .t02) :
    NoT02 (xs.map NecessaryCore.decode) := by
  intro ht
  rcases List.mem_map.mp ht with ⟨n, hn, heq⟩
  exact h n hn heq

theorem notAllT01_map_decode (xs : List Nat)
    (h : ¬ ∀ n ∈ xs, NecessaryCore.decode n = .t01) :
    NotAllT01 (xs.map NecessaryCore.decode) := by
  intro ht
  apply h
  intro n hn
  exact ht _ (List.mem_map.mpr ⟨n, hn, rfl⟩)

/-- Requested raw-Nat scope. There is no allowedCode, nonzero, sortedness,
profile-exclusion other than t02, or raw upper-bound hypothesis. -/
theorem classify_raw (xs ys : List Nat)
    (hNoLeft : ∀ n ∈ xs, NecessaryCore.decode n ≠ .t02)
    (hNoRight : ∀ n ∈ ys, NecessaryCore.decode n ≠ .t02)
    (hlen : xs.length + ys.length ≤ 3)
    (hLeft : -1 ≤ signedScore xs ys)
    (hRight : -1 ≤ signedScore ys xs)
    (hNonpureLeft : ¬ ∀ n ∈ xs, NecessaryCore.decode n = .t01)
    (hNonpureRight : ¬ ∀ n ∈ ys, NecessaryCore.decode n = .t01) :
    MatchesFourteen (xs.map NecessaryCore.decode) (ys.map NecessaryCore.decode) := by
  apply classify_profiles
  · simpa only [List.length_map] using hlen
  · refine ⟨noT02_map_decode xs hNoLeft, noT02_map_decode ys hNoRight,
      ?_, ?_, notAllT01_map_decode xs hNonpureLeft,
      notAllT01_map_decode ys hNonpureRight⟩
    · rw [profileScore_map_decode]
      exact hLeft
    · rw [profileScore_map_decode]
      exact hRight

#print axioms classify_profiles
#print axioms profileScore_map_decode
#print axioms noT02_map_decode
#print axioms notAllT01_map_decode
#print axioms classify_raw
end IsolationGame.FourteenResidual
