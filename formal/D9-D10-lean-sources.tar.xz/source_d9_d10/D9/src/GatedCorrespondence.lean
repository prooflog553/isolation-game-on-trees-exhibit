import GatedGraph
import GatedState
import GatedTransfer

namespace GatedGraph
open Gated
open Isolation.Graph
variable {I J : Type} [DecidableEq I] [DecidableEq J]

def stateWhite (owner : J → I) (s : Gated.State I J) : Vertex I J → Prop :=
  white owner (fun j => j ∈ s.live) (fun i => i ∈ s.closed)

variable (owner : J → I)

 theorem terminal_iff (s : Gated.State I J) :
    s.P = 0 ↔ TerminalWhite (stateWhite owner s) := by
  simp only [Gated.State.P, Finset.card_eq_zero]
  constructor
  · intro hs v; cases v <;> simp [stateWhite, white, hs]
  · intro ht; apply Finset.eq_empty_iff_forall_not_mem.mpr
    intro j hj; exact ht (.c j) hj

 theorem state_gate_step (s : Gated.State I J) (i : I) :
    (graph owner).noniso ((graph owner).remove (stateWhite owner s) (.gate i)) =
      stateWhite owner (s.openGate i) := by
  unfold stateWhite
  rw [gate_step]
  congr 1
  funext k; apply propext; simp [Gated.State.openGate, and_comm]

 theorem state_b_step (s : Gated.State I J) (j : J) :
    (graph owner).noniso ((graph owner).remove (stateWhite owner s) (.b j)) =
      stateWhite owner (s.deleteUnit j) := by
  unfold stateWhite
  rw [b_step]
  congr 1
  funext k; apply propext; simp [Gated.State.deleteUnit, and_comm]

 theorem state_c_step (s : Gated.State I J) (j : J) :
    (graph owner).noniso ((graph owner).remove (stateWhite owner s) (.c j)) =
      stateWhite owner (s.deleteUnit j) := by
  unfold stateWhite
  rw [c_step]
  congr 1
  funext k; apply propext; simp [Gated.State.deleteUnit, and_comm]

 theorem state_d_step (s : Gated.State I J) (j : J) :
    (graph owner).noniso ((graph owner).remove (stateWhite owner s) (.d j)) =
      stateWhite owner (s.deleteUnit j) := by
  unfold stateWhite
  rw [d_step]
  congr 1
  funext k; apply propext; simp [Gated.State.deleteUnit, and_comm]

/-- Every original graph move is covered, including all dominated gate and
arm vertices. Opening a gate changes closedness but preserves all live units. -/
 theorem graph_to_state (s : Gated.State I J) (v : Vertex I J)
    (h : (graph owner).legal (stateWhite owner s) v) :
    ∃ t, Gated.State.Move owner s t ∧
      (graph owner).noniso ((graph owner).remove (stateWhite owner s) v) = stateWhite owner t := by
  cases v with
  | gate i =>
    refine ⟨s.openGate i, Or.inr ⟨i, ?_, rfl⟩, state_gate_step owner s i⟩
    exact (Gated.State.mem_active owner s i).mpr
      ⟨((legal_gate owner _ _ i).mp h).1,
        (Gated.State.count_pos_iff owner s i).mpr ((legal_gate owner _ _ i).mp h).2⟩
  | b j => exact ⟨s.deleteUnit j, Or.inl ⟨j, (legal_b owner _ _ j).mp h, rfl⟩,
      state_b_step owner s j⟩
  | c j => exact ⟨s.deleteUnit j, Or.inl ⟨j, (legal_c owner _ _ j).mp h, rfl⟩,
      state_c_step owner s j⟩
  | d j => exact ⟨s.deleteUnit j, Or.inl ⟨j, (legal_d owner _ _ j).mp h, rfl⟩,
      state_d_step owner s j⟩

/-- Every abstract unit deletion or group opening is a real legal move in the
fixed original graph, with exactly the stated normalized successor. -/
 theorem state_to_graph {s t : Gated.State I J} (h : Gated.State.Move owner s t) :
    ∃ v, (graph owner).legal (stateWhite owner s) v ∧
      (graph owner).noniso ((graph owner).remove (stateWhite owner s) v) = stateWhite owner t := by
  rcases h with ⟨j,hj,rfl⟩ | ⟨i,hi,rfl⟩
  · exact ⟨.c j, (legal_c owner _ _ j).mpr hj, state_c_step owner s j⟩
  · refine ⟨.gate i, (legal_gate owner _ _ i).mpr ?_, state_gate_step owner s i⟩
    have hi' := (Gated.State.mem_active owner s i).mp hi
    exact ⟨hi'.1, (Gated.State.count_pos_iff owner s i).mp hi'.2⟩

 def bisimulation : Gated.WhiteBisimulation (graph owner)
    (Gated.State.Move owner) Gated.State.P (stateWhite owner) where
  terminal := terminal_iff owner
  graph_to_state := graph_to_state owner
  state_to_graph := state_to_graph owner

 theorem graph_horizon (s : Gated.State I J) (n : Nat) (p : Gated.Turn) :
    (graph owner).WinsWhite n p.toIsolation (stateWhite owner s) ↔
      Gated.winWithin (Gated.State.Move owner) Gated.State.P n p s :=
  ((bisimulation owner).winWithin_iff_white n p s).symm

#print axioms graph_to_state
#print axioms state_to_graph
#print axioms graph_horizon
end GatedGraph
