import DescendantGeometry
import RootedMinimalReduction

namespace IsolationGame.DescendantGeometry
open PartitionBridge
variable {V : Type} [Fintype V] [DecidableEq V]

theorem removed_distance_equation (G : SimpleGraph V) (r b : V)
    (v : Side (outside (retained G r b))) :
    G.dist r v.val=G.dist r b+G.dist b v.val := by
  have hv : v.val∉retained G r b := (Finset.mem_sdiff.mp v.property).2
  simpa [retained] using hv

/-- Every distance-defined descendant piece has its actual expected height.
Tree connectedness and the induced-distance bridge are fully discharged. -/
theorem descendant_height (G : SimpleGraph V) (hT : G.IsTree)
    (r z b : V) (hzb : G.Adj z b) (hdepth : G.dist r b=G.dist r z+1)
    (R : Nat) (hR : ∀v,G.dist r v≤R) :
    ∃hb : b∉retained G r b,
      ∀v : Side (outside (retained G r b)),
        (IsolatedRestriction.induced G (outside (retained G r b))).dist
          ⟨b,by simp [outside,hb]⟩ v≤R-G.dist r b := by
  obtain ⟨hz,hr,hb,hcut,ht,hd⟩ := descendant_partition_spec G hT r z b hzb hdepth
  refine ⟨hb,?_⟩
  intro v
  have he := removed_distance_equation G r b v
  have hg := hR v.val
  rw [hd]
  omega

/-- Minimum-counterexample mass test for EVERY actual outer branch at r.
No one-bridge or induced-tree premise is left for the caller to assume. -/
theorem minimal_outer_mass (G : SimpleGraph V) (hT : G.IsTree)
    (r : V) (hR : ∀v,G.dist r v≤4) (hSmall : RootedReduction.SmallerFloor (Fintype.card V))
    (hCounter : 3*Fintype.card V/7<Marked.gameValue G {r} .dominator ∅)
    (b : V) (hrb : G.Adj r b) :
    ∃hb : b∉retained G r b,
      3*(outside (retained G r b)).card<
        7*((AttachmentGeometry.longStars (IsolatedRestriction.induced G (outside (retained G r b)))
          ⟨b,by simp [outside,hb]⟩).card+2) := by
  have hd : G.dist r b=1 := SimpleGraph.dist_eq_one_iff_adj.mpr hrb
  have hp : G.dist r b=G.dist r r+1 := by simpa only [G.dist_self,Nat.zero_add] using hd
  obtain ⟨hz,hr,hb,hcut,ht,hdist⟩ := descendant_partition_spec G hT r r b hrb hp
  have hheight : RadiusThree (IsolatedRestriction.induced G (outside (retained G r b)))
      ⟨b,by simp [outside,hb]⟩ := by
    intro v
    have he := removed_distance_equation G r b v
    have hg := hR v.val
    rw [hdist]
    omega
  exact ⟨hb,RootedReduction.minimal_height_three_mass G hT r hR hSmall hCounter
    (retained G r b) r b hz hb hcut hr ht hheight⟩

/-- Every actual depth-two descendant subtree has at most four original
vertices in a hypothetical minimum counterexample. -/
theorem minimal_depth_two_order (G : SimpleGraph V) (hT : G.IsTree)
    (r : V) (hR : ∀v,G.dist r v≤4) (hSmall : RootedReduction.SmallerFloor (Fintype.card V))
    (hCounter : 3*Fintype.card V/7<Marked.gameValue G {r} .dominator ∅)
    (z b : V) (hzb : G.Adj z b) (hp : G.dist r b=G.dist r z+1) (hdepth : G.dist r b=2) :
    (outside (retained G r b)).card≤4 := by
  obtain ⟨hz,hr,hb,hcut,ht,hdist⟩ := descendant_partition_spec G hT r z b hzb hp
  have hheight : ∀v : Side (outside (retained G r b)),
      (IsolatedRestriction.induced G (outside (retained G r b))).dist
        ⟨b,by simp [outside,hb]⟩ v≤2 := by
    intro v
    have he := removed_distance_equation G r b v
    have hg := hR v.val
    rw [hdist]
    omega
  exact RootedReduction.minimal_height_two_order G hT r hR hSmall hCounter
    (retained G r b) z b hz hb hcut hr ht hheight

#print axioms descendant_height
#print axioms minimal_outer_mass
#print axioms minimal_depth_two_order
end IsolationGame.DescendantGeometry
