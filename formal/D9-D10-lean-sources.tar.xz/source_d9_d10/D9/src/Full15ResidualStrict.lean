import FullCanonical15
import StrictCompanionPairing

/-! SOURCE-ONLY finite evidence for the common genuine short-leaf/middle
residual. Accepted full15 DAG rows; every original blue action retained. -/
namespace IsolationGame.CompositeWhiteR15Facts
open FullCanonical.T15
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

/-- Actual S local7 followed by actual D local2 gives exactly this mark set.
Neither selected vertex is the local root, so this does not mark the global
attachment centre through a fictitious root selection. -/
theorem actual_marks :
    SelectedVertex.playedMarks original (SelectedVertex.playedMarks original ∅ 7) 2 = marks_3 := by
  ext v
  simp only [SelectedVertex.mem_playedMarks,Finset.not_mem_empty,false_or]
  fin_cases v <;> decide +kernel

/-- R={0,1,2,3,7}, D1/S2. The original blue root0 has follower1; the actual
remaining-arm actions4/5/6 end the local game. All other actions are illegal. -/
theorem r15_strict : MarkedSum.StrictCapacity original marks_3 ∅ 2 := by
  constructor
  · rw [row_3.1] <;> omega
  · intro v hv
    fin_cases v
    · change Marked.gameValue original marks_3 .staller {0}+1≤2
      rw [after_3_0.2] <;> omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_3 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_3 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_3 ∅ 3) hv)
    · change Marked.gameValue original marks_3 .staller {4}+1≤2
      rw [after_3_4.2] <;> omega
    · change Marked.gameValue original marks_3 .staller {5}+1≤2
      rw [after_3_5.2] <;> omega
    · change Marked.gameValue original marks_3 .staller {6}+1≤2
      rw [after_3_6.2] <;> omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_3 ∅ 7) hv)

#print axioms actual_marks
#print axioms r15_strict
end IsolationGame.CompositeWhiteR15Facts
