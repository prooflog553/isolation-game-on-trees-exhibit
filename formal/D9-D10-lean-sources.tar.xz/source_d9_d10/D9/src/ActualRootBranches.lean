import DescendantGeometry
import RootBranchProfiles

namespace IsolationGame.ActualRootBranches
open IsolatedRestriction PartitionBridge
variable {V : Type} [Fintype V] [DecidableEq V]

noncomputable def children (G : SimpleGraph V) (r : V) : Finset V := by
  classical
  exact Finset.univ.filter (G.Adj r)

abbrev Child (G : SimpleGraph V) (r : V) := Active (children G r)

noncomputable def piece (G : SimpleGraph V) (r : V) (a : Child G r) : Finset V :=
  outside (DescendantGeometry.retained G r a.val)

noncomputable def component (G : SimpleGraph V) (r : V) (a : Child G r) :
    Finset (Active (MarkedBoundary.retained r)) :=
  restrict (MarkedBoundary.retained r) (piece G r a)

theorem child_edge (G : SimpleGraph V) (r : V) (a : Child G r) : G.Adj r a.val := by
  classical
  exact (Finset.mem_filter.mp a.property).2

theorem child_depth (G : SimpleGraph V) (r : V) (a : Child G r) : G.dist r a.val=1 :=
  SimpleGraph.dist_eq_one_iff_adj.mpr (child_edge G r a)

theorem mem_piece (G : SimpleGraph V) (r : V) (a : Child G r) (v : V) :
    v∈piece G r a ↔ G.dist r v=G.dist r a.val+G.dist a.val v := by
  classical
  simp [piece,outside,DescendantGeometry.retained]

theorem root_not_piece (G : SimpleGraph V) (r : V) (a : Child G r) : r∉piece G r a := by
  intro h
  have hh := (mem_piece G r a r).mp h
  rw [G.dist_self,child_depth] at hh
  omega

theorem self_mem_piece (G : SimpleGraph V) (r : V) (a : Child G r) : a.val∈piece G r a := by
  rw [mem_piece,G.dist_self,Nat.add_zero]

theorem unique_piece (G : SimpleGraph V) (hT : G.IsTree) (r : V)
    (a b : Child G r) (v : V) (ha : v∈piece G r a) (hb : v∈piece G r b) : a=b := by
  have ea := (mem_piece G r a v).mp ha
  have eb := (mem_piece G r b v).mp hb
  rw [child_depth] at ea eb
  apply Subtype.ext
  exact unique_lower_neighbor hT v (child_edge G r a) (child_edge G r b) (by omega) (by omega)

theorem covered_by_piece (G : SimpleGraph V) (hT : G.IsTree) (r v : V) (hv : v≠r) :
    ∃a : Child G r,v∈piece G r a := by
  obtain ⟨p,hp,hlen⟩ := hT.isConnected.exists_path_of_dist r v
  cases p with
  | nil => exact False.elim (hv rfl)
  | @cons r a v hra p =>
    let a' : Child G r := ⟨a,by simp [children,hra]⟩
    refine ⟨a',?_⟩
    rw [mem_piece,child_depth]
    have ht := tree_path_length_eq_dist hT p hp.of_cons
    simp only [SimpleGraph.Walk.length_cons] at hlen
    change G.dist r v=1+G.dist a v
    omega

theorem components_cover (G : SimpleGraph V) (hT : G.IsTree) (r : V) :
    Finset.univ.biUnion (component G r)=Finset.univ := by
  ext v
  simp only [Finset.mem_univ,iff_true]
  have hv : v.val≠r := (Finset.mem_erase.mp v.property).1
  obtain ⟨a,ha⟩ := covered_by_piece G hT r v.val hv
  exact Finset.mem_biUnion.mpr ⟨a,Finset.mem_univ a,(mem_restrict _ _ v).mpr ha⟩

theorem components_disjoint (G : SimpleGraph V) (hT : G.IsTree) (r : V)
    (a b : Child G r) (hab : a≠b) : Disjoint (component G r a) (component G r b) := by
  apply Finset.disjoint_left.mpr
  intro v ha hb
  exact hab (unique_piece G hT r a b v.val ((mem_restrict _ _ v).mp ha) ((mem_restrict _ _ v).mp hb))

theorem components_noCross (G : SimpleGraph V) (hT : G.IsTree) (r : V)
    (a b : Child G r) (hab : a≠b) :
    ∀u∈component G r a,∀v∈component G r b,¬(MarkedBoundary.deleted G r).Adj u v := by
  intro u hu v hv hadj
  have huP : u.val∈piece G r a := (mem_restrict _ _ u).mp hu
  have hvP : v.val∈piece G r b := (mem_restrict _ _ v).mp hv
  have hvNot : v.val∉piece G r a := fun h=>hab (unique_piece G hT r a b v.val h hvP)
  have hp : G.dist r a.val=G.dist r r+1 := by simpa only [G.dist_self,Nat.zero_add] using child_depth G r a
  obtain ⟨hz,hr,ha,hcut,ht,hd⟩ := DescendantGeometry.descendant_partition_spec G hT r r a.val (child_edge G r a) hp
  have hvIn : v.val∈DescendantGeometry.retained G r a.val := by simpa [piece,outside] using hvNot
  have huOut : u.val∉DescendantGeometry.retained G r a.val := (Finset.mem_sdiff.mp huP).2
  have he := (hcut v.val u.val hvIn huOut).mp (show G.Adj v.val u.val from hadj.symm)
  exact (Finset.mem_erase.mp v.property).1 he.1

#print axioms components_cover
#print axioms components_disjoint
#print axioms components_noCross
end IsolationGame.ActualRootBranches
