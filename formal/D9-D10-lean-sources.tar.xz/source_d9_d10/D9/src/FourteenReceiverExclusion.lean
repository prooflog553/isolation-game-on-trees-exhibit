import FourteenCanonicalTransport
import FullReceiverCeiling

/-!
SOURCE_ONLY. Any all-t01 side is excluded using a full rooted isomorphism to
the accepted all-k receiver family. Empty sides are included, with k=0.
A profile tag or equality of orders would not suffice and is not used.
-/
namespace IsolationGame.FourteenCounterexample
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
open CanonicalLocal NecessaryCore

/-- The unchanged left core and the complete rooted all-t01 right receiver. -/
noncomputable def rightAllP4Iso (xs ys : List Nat) (p q : Nat)
    (hys : ∀ n ∈ ys, decode n = .t01) :
    TwoCoreOpening.graph xs ys p q ≃g
      FullReceiverCeiling.graph xs p ys.length q :=
  OriginalIsoTransport.attachmentIso _ _ _ _
    none none none (GeneralP4Receiver.centre ys.length q)
    (SimpleGraph.Iso.refl : CoreFamily.graph xs p ≃g CoreFamily.graph xs p)
    (CoreFamily.allP4ReceiverIso ys q hys) rfl
    (CoreFamily.allP4ReceiverIso_root ys q hys)

@[simp] theorem rightAllP4Iso_leftRoot (xs ys : List Nat) (p q : Nat)
    (hys : ∀ n ∈ ys, decode n = .t01) :
    rightAllP4Iso xs ys p q hys (.inl none) = .inl none := rfl

@[simp] theorem rightAllP4Iso_rightRoot (xs ys : List Nat) (p q : Nat)
    (hys : ∀ n ∈ ys, decode n = .t01) :
    rightAllP4Iso xs ys p q hys (.inr none) =
      .inr (GeneralP4Receiver.centre ys.length q) := by
  change Sum.inr (CoreFamily.allP4ReceiverIso ys q hys none) = _
  rw [CoreFamily.allP4ReceiverIso_root]

/-- The bound uses accepted FullReceiverCeiling.ordinary_ceil for all k,p,q. -/
theorem right_allP4_ceil (xs ys : List Nat) (p q : Nat)
    (hys : ∀ n ∈ ys, decode n = .t01) :
    isolationNumber (TwoCoreOpening.graph xs ys p q) ≤
      (3*Fintype.card (TwoCoreOpening.Vertex xs ys p q)+6)/7 :=
  ceiling_transport _ _ (rightAllP4Iso xs ys p q hys).symm
    (FullReceiverCeiling.ordinary_ceil xs p ys.length q)

/-- Swap both lists and ordinary pools, then apply the complete right bridge. -/
theorem left_allP4_ceil (xs ys : List Nat) (p q : Nat)
    (hxs : ∀ n ∈ xs, decode n = .t01) :
    isolationNumber (TwoCoreOpening.graph xs ys p q) ≤
      (3*Fintype.card (TwoCoreOpening.Vertex xs ys p q)+6)/7 :=
  ceiling_transport _ _ (swapIso xs ys p q).symm
    (right_allP4_ceil ys xs q p hxs)

/-- No nonempty or positive receiver assumption: pure ordinary sides are covered. -/
theorem strict_counter_not_allP4 (xs ys : List Nat) (p q : Nat)
    (h : (3*Fintype.card (TwoCoreOpening.Vertex xs ys p q)+6)/7 <
      isolationNumber (TwoCoreOpening.graph xs ys p q)) :
    (¬ ∀ n ∈ xs, decode n = .t01) ∧ (¬ ∀ n ∈ ys, decode n = .t01) := by
  constructor
  · intro hxs
    exact (Nat.not_lt_of_ge (left_allP4_ceil xs ys p q hxs)) h
  · intro hys
    exact (Nat.not_lt_of_ge (right_allP4_ceil xs ys p q hys)) h

#print axioms rightAllP4Iso
#print axioms right_allP4_ceil
#print axioms left_allP4_ceil
#print axioms strict_counter_not_allP4
end IsolationGame.FourteenCounterexample
