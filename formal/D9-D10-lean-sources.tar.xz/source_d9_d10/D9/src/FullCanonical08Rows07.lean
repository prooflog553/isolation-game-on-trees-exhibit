import FullCanonical08Rows06
namespace IsolationGame.FullCanonical.T08
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_28 : Finset (Fin 11) := {2,3,5,6}
theorem after_28_0 : Marked.gameValue original marks_28 .dominator {0}=1 ∧ Marked.gameValue original marks_28 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_28 marks_3 0 1 1 (by decide +kernel) row_3
theorem after_28_1 : Marked.gameValue original marks_28 .dominator {1}=1 ∧ Marked.gameValue original marks_28 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_28 marks_13 1 1 2 (by decide +kernel) row_13
theorem after_28_2 : Marked.gameValue original marks_28 .dominator {2}=1 ∧ Marked.gameValue original marks_28 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_28 marks_24 2 1 2 (by decide +kernel) row_24
theorem after_28_4 : Marked.gameValue original marks_28 .dominator {4}=1 ∧ Marked.gameValue original marks_28 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_28 marks_13 4 1 2 (by decide +kernel) row_13
theorem after_28_5 : Marked.gameValue original marks_28 .dominator {5}=1 ∧ Marked.gameValue original marks_28 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_28 marks_24 5 1 2 (by decide +kernel) row_24
theorem after_28_7 : Marked.gameValue original marks_28 .dominator {7}=0 ∧ Marked.gameValue original marks_28 .staller {7}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_28 marks_0 7 0 0 (by decide +kernel) row_0
theorem after_28_8 : Marked.gameValue original marks_28 .dominator {8}=1 ∧ Marked.gameValue original marks_28 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_28 marks_5 8 1 2 (by decide +kernel) row_5
theorem after_28_9 : Marked.gameValue original marks_28 .dominator {9}=1 ∧ Marked.gameValue original marks_28 .staller {9}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_28 marks_17 9 1 2 (by decide +kernel) row_17
theorem after_28_10 : Marked.gameValue original marks_28 .dominator {10}=1 ∧ Marked.gameValue original marks_28 .staller {10}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_28 marks_15 10 1 2 (by decide +kernel) row_15
theorem row_28 : Marked.gameValue original marks_28 .dominator ∅=1 ∧ Marked.gameValue original marks_28 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_28 1 2 7 0 (by decide +kernel) (by decide +kernel)
  · rw [after_28_7.2]
  · rw [after_28_0.1]
  · intro v hv
    fin_cases v
    · have h := after_28_0
      change 1 ≤ 1+Marked.gameValue original marks_28 .staller {0} ∧ 1+Marked.gameValue original marks_28 .dominator {0} ≤ 2
      omega
    · have h := after_28_1
      change 1 ≤ 1+Marked.gameValue original marks_28 .staller {1} ∧ 1+Marked.gameValue original marks_28 .dominator {1} ≤ 2
      omega
    · have h := after_28_2
      change 1 ≤ 1+Marked.gameValue original marks_28 .staller {2} ∧ 1+Marked.gameValue original marks_28 .dominator {2} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_28 ∅ 3) hv)
    · have h := after_28_4
      change 1 ≤ 1+Marked.gameValue original marks_28 .staller {4} ∧ 1+Marked.gameValue original marks_28 .dominator {4} ≤ 2
      omega
    · have h := after_28_5
      change 1 ≤ 1+Marked.gameValue original marks_28 .staller {5} ∧ 1+Marked.gameValue original marks_28 .dominator {5} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_28 ∅ 6) hv)
    · have h := after_28_7
      change 1 ≤ 1+Marked.gameValue original marks_28 .staller {7} ∧ 1+Marked.gameValue original marks_28 .dominator {7} ≤ 2
      omega
    · have h := after_28_8
      change 1 ≤ 1+Marked.gameValue original marks_28 .staller {8} ∧ 1+Marked.gameValue original marks_28 .dominator {8} ≤ 2
      omega
    · have h := after_28_9
      change 1 ≤ 1+Marked.gameValue original marks_28 .staller {9} ∧ 1+Marked.gameValue original marks_28 .dominator {9} ≤ 2
      omega
    · have h := after_28_10
      change 1 ≤ 1+Marked.gameValue original marks_28 .staller {10} ∧ 1+Marked.gameValue original marks_28 .dominator {10} ≤ 2
      omega
def marks_29 : Finset (Fin 11) := {0,1,2,3}
theorem after_29_0 : Marked.gameValue original marks_29 .dominator {0}=2 ∧ Marked.gameValue original marks_29 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_29 marks_11 0 2 2 (by decide +kernel) row_11
theorem after_29_4 : Marked.gameValue original marks_29 .dominator {4}=1 ∧ Marked.gameValue original marks_29 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_29 marks_13 4 1 2 (by decide +kernel) row_13
theorem after_29_5 : Marked.gameValue original marks_29 .dominator {5}=1 ∧ Marked.gameValue original marks_29 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_29 marks_13 5 1 2 (by decide +kernel) row_13
theorem after_29_6 : Marked.gameValue original marks_29 .dominator {6}=1 ∧ Marked.gameValue original marks_29 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_29 marks_13 6 1 2 (by decide +kernel) row_13
theorem after_29_7 : Marked.gameValue original marks_29 .dominator {7}=1 ∧ Marked.gameValue original marks_29 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_29 marks_6 7 1 2 (by decide +kernel) row_6
theorem after_29_8 : Marked.gameValue original marks_29 .dominator {8}=1 ∧ Marked.gameValue original marks_29 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_29 marks_6 8 1 2 (by decide +kernel) row_6
theorem after_29_9 : Marked.gameValue original marks_29 .dominator {9}=2 ∧ Marked.gameValue original marks_29 .staller {9}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_29 marks_18 9 2 2 (by decide +kernel) row_18
theorem after_29_10 : Marked.gameValue original marks_29 .dominator {10}=2 ∧ Marked.gameValue original marks_29 .staller {10}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_29 marks_16 10 2 3 (by decide +kernel) row_16
theorem row_29 : Marked.gameValue original marks_29 .dominator ∅=3 ∧ Marked.gameValue original marks_29 .staller ∅=3 := by
  apply LocalProfile.DAG.bellman original marks_29 3 3 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_29_0.2]
  · rw [after_29_0.1]
  · intro v hv
    fin_cases v
    · have h := after_29_0
      change 3 ≤ 1+Marked.gameValue original marks_29 .staller {0} ∧ 1+Marked.gameValue original marks_29 .dominator {0} ≤ 3
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_29 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_29 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_29 ∅ 3) hv)
    · have h := after_29_4
      change 3 ≤ 1+Marked.gameValue original marks_29 .staller {4} ∧ 1+Marked.gameValue original marks_29 .dominator {4} ≤ 3
      omega
    · have h := after_29_5
      change 3 ≤ 1+Marked.gameValue original marks_29 .staller {5} ∧ 1+Marked.gameValue original marks_29 .dominator {5} ≤ 3
      omega
    · have h := after_29_6
      change 3 ≤ 1+Marked.gameValue original marks_29 .staller {6} ∧ 1+Marked.gameValue original marks_29 .dominator {6} ≤ 3
      omega
    · have h := after_29_7
      change 3 ≤ 1+Marked.gameValue original marks_29 .staller {7} ∧ 1+Marked.gameValue original marks_29 .dominator {7} ≤ 3
      omega
    · have h := after_29_8
      change 3 ≤ 1+Marked.gameValue original marks_29 .staller {8} ∧ 1+Marked.gameValue original marks_29 .dominator {8} ≤ 3
      omega
    · have h := after_29_9
      change 3 ≤ 1+Marked.gameValue original marks_29 .staller {9} ∧ 1+Marked.gameValue original marks_29 .dominator {9} ≤ 3
      omega
    · have h := after_29_10
      change 3 ≤ 1+Marked.gameValue original marks_29 .staller {10} ∧ 1+Marked.gameValue original marks_29 .dominator {10} ≤ 3
      omega
def marks_30 : Finset (Fin 11) := {1,2,3}
theorem after_30_0 : Marked.gameValue original marks_30 .dominator {0}=2 ∧ Marked.gameValue original marks_30 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_30 marks_11 0 2 2 (by decide +kernel) row_11
theorem after_30_1 : Marked.gameValue original marks_30 .dominator {1}=3 ∧ Marked.gameValue original marks_30 .staller {1}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_30 marks_29 1 3 3 (by decide +kernel) row_29
theorem after_30_4 : Marked.gameValue original marks_30 .dominator {4}=1 ∧ Marked.gameValue original marks_30 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_30 marks_13 4 1 2 (by decide +kernel) row_13
theorem after_30_5 : Marked.gameValue original marks_30 .dominator {5}=1 ∧ Marked.gameValue original marks_30 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_30 marks_19 5 1 2 (by decide +kernel) row_19
theorem after_30_6 : Marked.gameValue original marks_30 .dominator {6}=1 ∧ Marked.gameValue original marks_30 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_30 marks_24 6 1 2 (by decide +kernel) row_24
theorem after_30_7 : Marked.gameValue original marks_30 .dominator {7}=1 ∧ Marked.gameValue original marks_30 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_30 marks_6 7 1 2 (by decide +kernel) row_6
theorem after_30_8 : Marked.gameValue original marks_30 .dominator {8}=1 ∧ Marked.gameValue original marks_30 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_30 marks_9 8 1 2 (by decide +kernel) row_9
theorem after_30_9 : Marked.gameValue original marks_30 .dominator {9}=2 ∧ Marked.gameValue original marks_30 .staller {9}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_30 marks_23 9 2 3 (by decide +kernel) row_23
theorem after_30_10 : Marked.gameValue original marks_30 .dominator {10}=2 ∧ Marked.gameValue original marks_30 .staller {10}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_30 marks_22 10 2 3 (by decide +kernel) row_22
theorem row_30 : Marked.gameValue original marks_30 .dominator ∅=3 ∧ Marked.gameValue original marks_30 .staller ∅=4 := by
  apply LocalProfile.DAG.bellman original marks_30 3 4 0 1 (by decide +kernel) (by decide +kernel)
  · rw [after_30_0.2]
  · rw [after_30_1.1]
  · intro v hv
    fin_cases v
    · have h := after_30_0
      change 3 ≤ 1+Marked.gameValue original marks_30 .staller {0} ∧ 1+Marked.gameValue original marks_30 .dominator {0} ≤ 4
      omega
    · have h := after_30_1
      change 3 ≤ 1+Marked.gameValue original marks_30 .staller {1} ∧ 1+Marked.gameValue original marks_30 .dominator {1} ≤ 4
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_30 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_30 ∅ 3) hv)
    · have h := after_30_4
      change 3 ≤ 1+Marked.gameValue original marks_30 .staller {4} ∧ 1+Marked.gameValue original marks_30 .dominator {4} ≤ 4
      omega
    · have h := after_30_5
      change 3 ≤ 1+Marked.gameValue original marks_30 .staller {5} ∧ 1+Marked.gameValue original marks_30 .dominator {5} ≤ 4
      omega
    · have h := after_30_6
      change 3 ≤ 1+Marked.gameValue original marks_30 .staller {6} ∧ 1+Marked.gameValue original marks_30 .dominator {6} ≤ 4
      omega
    · have h := after_30_7
      change 3 ≤ 1+Marked.gameValue original marks_30 .staller {7} ∧ 1+Marked.gameValue original marks_30 .dominator {7} ≤ 4
      omega
    · have h := after_30_8
      change 3 ≤ 1+Marked.gameValue original marks_30 .staller {8} ∧ 1+Marked.gameValue original marks_30 .dominator {8} ≤ 4
      omega
    · have h := after_30_9
      change 3 ≤ 1+Marked.gameValue original marks_30 .staller {9} ∧ 1+Marked.gameValue original marks_30 .dominator {9} ≤ 4
      omega
    · have h := after_30_10
      change 3 ≤ 1+Marked.gameValue original marks_30 .staller {10} ∧ 1+Marked.gameValue original marks_30 .dominator {10} ≤ 4
      omega
def marks_31 : Finset (Fin 11) := {7,10}
theorem after_31_0 : Marked.gameValue original marks_31 .dominator {0}=3 ∧ Marked.gameValue original marks_31 .staller {0}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_31 marks_21 0 3 3 (by decide +kernel) row_21
theorem after_31_1 : Marked.gameValue original marks_31 .dominator {1}=2 ∧ Marked.gameValue original marks_31 .staller {1}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_31 marks_16 1 2 3 (by decide +kernel) row_16
theorem after_31_2 : Marked.gameValue original marks_31 .dominator {2}=2 ∧ Marked.gameValue original marks_31 .staller {2}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_31 marks_22 2 2 3 (by decide +kernel) row_22
theorem after_31_3 : Marked.gameValue original marks_31 .dominator {3}=2 ∧ Marked.gameValue original marks_31 .staller {3}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_31 marks_26 3 2 3 (by decide +kernel) row_26
theorem after_31_4 : Marked.gameValue original marks_31 .dominator {4}=2 ∧ Marked.gameValue original marks_31 .staller {4}=3 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_31 marks_16 4 2 3 (by decide +kernel) row_16
theorem after_31_5 : Marked.gameValue original marks_31 .dominator {5}=2 ∧ Marked.gameValue original marks_31 .staller {5}=3 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_31 marks_22 5 2 3 (by decide +kernel) row_22
theorem after_31_6 : Marked.gameValue original marks_31 .dominator {6}=2 ∧ Marked.gameValue original marks_31 .staller {6}=3 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_31 marks_26 6 2 3 (by decide +kernel) row_26
theorem after_31_7 : Marked.gameValue original marks_31 .dominator {7}=3 ∧ Marked.gameValue original marks_31 .staller {7}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_31 marks_20 7 3 3 (by decide +kernel) row_20
theorem after_31_8 : Marked.gameValue original marks_31 .dominator {8}=3 ∧ Marked.gameValue original marks_31 .staller {8}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_31 marks_25 8 3 4 (by decide +kernel) row_25
theorem after_31_9 : Marked.gameValue original marks_31 .dominator {9}=3 ∧ Marked.gameValue original marks_31 .staller {9}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_31 marks_25 9 3 4 (by decide +kernel) row_25
theorem row_31 : Marked.gameValue original marks_31 .dominator ∅=4 ∧ Marked.gameValue original marks_31 .staller ∅=4 := by
  apply LocalProfile.DAG.bellman original marks_31 4 4 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_31_0.2]
  · rw [after_31_0.1]
  · intro v hv
    fin_cases v
    · have h := after_31_0
      change 4 ≤ 1+Marked.gameValue original marks_31 .staller {0} ∧ 1+Marked.gameValue original marks_31 .dominator {0} ≤ 4
      omega
    · have h := after_31_1
      change 4 ≤ 1+Marked.gameValue original marks_31 .staller {1} ∧ 1+Marked.gameValue original marks_31 .dominator {1} ≤ 4
      omega
    · have h := after_31_2
      change 4 ≤ 1+Marked.gameValue original marks_31 .staller {2} ∧ 1+Marked.gameValue original marks_31 .dominator {2} ≤ 4
      omega
    · have h := after_31_3
      change 4 ≤ 1+Marked.gameValue original marks_31 .staller {3} ∧ 1+Marked.gameValue original marks_31 .dominator {3} ≤ 4
      omega
    · have h := after_31_4
      change 4 ≤ 1+Marked.gameValue original marks_31 .staller {4} ∧ 1+Marked.gameValue original marks_31 .dominator {4} ≤ 4
      omega
    · have h := after_31_5
      change 4 ≤ 1+Marked.gameValue original marks_31 .staller {5} ∧ 1+Marked.gameValue original marks_31 .dominator {5} ≤ 4
      omega
    · have h := after_31_6
      change 4 ≤ 1+Marked.gameValue original marks_31 .staller {6} ∧ 1+Marked.gameValue original marks_31 .dominator {6} ≤ 4
      omega
    · have h := after_31_7
      change 4 ≤ 1+Marked.gameValue original marks_31 .staller {7} ∧ 1+Marked.gameValue original marks_31 .dominator {7} ≤ 4
      omega
    · have h := after_31_8
      change 4 ≤ 1+Marked.gameValue original marks_31 .staller {8} ∧ 1+Marked.gameValue original marks_31 .dominator {8} ≤ 4
      omega
    · have h := after_31_9
      change 4 ≤ 1+Marked.gameValue original marks_31 .staller {9} ∧ 1+Marked.gameValue original marks_31 .dominator {9} ≤ 4
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_31 ∅ 10) hv)
end IsolationGame.FullCanonical.T08
