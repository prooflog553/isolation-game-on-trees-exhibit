import FullCanonical18Rows05
namespace IsolationGame.FullCanonical.T18
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
theorem full_values : Marked.gameValue original ∅ .dominator ∅=3 ∧ Marked.gameValue original ∅ .staller ∅=4 := by
  constructor
  · exact (Marked.value_eq_of_white_eq original ∅ marks_21 ∅ ∅ .dominator (by decide +kernel)).trans row_21.1
  · exact (Marked.value_eq_of_white_eq original ∅ marks_21 ∅ ∅ .staller (by decide +kernel)).trans row_21.2
theorem strict_full : MarkedSum.StrictCapacity original ∅ ∅ 4 := by
  constructor
  · rw [full_values.1] <;> decide +kernel
  · intro v hv
    fin_cases v
    · change Marked.gameValue original marks_21 .staller {0}+1≤4
      rw [after_21_0.2] <;> decide +kernel
    · change Marked.gameValue original marks_21 .staller {1}+1≤4
      rw [after_21_1.2] <;> decide +kernel
    · change Marked.gameValue original marks_21 .staller {2}+1≤4
      rw [after_21_2.2] <;> decide +kernel
    · change Marked.gameValue original marks_21 .staller {3}+1≤4
      rw [after_21_3.2] <;> decide +kernel
    · change Marked.gameValue original marks_21 .staller {4}+1≤4
      rw [after_21_4.2] <;> decide +kernel
    · change Marked.gameValue original marks_21 .staller {5}+1≤4
      rw [after_21_5.2] <;> decide +kernel
    · change Marked.gameValue original marks_21 .staller {6}+1≤4
      rw [after_21_6.2] <;> decide +kernel
    · change Marked.gameValue original marks_21 .staller {7}+1≤4
      rw [after_21_7.2] <;> decide +kernel
    · change Marked.gameValue original marks_21 .staller {8}+1≤4
      rw [after_21_8.2] <;> decide +kernel
#print axioms full_values
#print axioms strict_full
end IsolationGame.FullCanonical.T18
