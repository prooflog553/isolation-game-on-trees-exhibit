import DoubleCentreP4Model
import TwoPoolStrongInduction

/-! SOURCE_ONLY: no Lean elaboration or proof claim is made by this file.
The k=l=0 carrier is transported in full to a fixed K2 and two complete P7
pools. Every original vertex, arbitrary mark, history and legal action remains.
The Bool fixed vertices are false=left centre and true=right centre. -/
namespace IsolationGame.DoubleCentreP4.Zero
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

/-- The physical fixed two-vertex spine, with one undirected edge. -/
def spine : SimpleGraph Bool where
  Adj u v := u ≠ v
  symm := fun _ _ h => Ne.symm h
  loopless := fun _ h => h rfl

instance spineDecidable : DecidableRel spine.Adj := fun _ _ => inferInstanceAs (Decidable (_ ≠ _))

theorem spine_tree : spine.IsTree :=
  CanonicalLocal.tree_of_certificate spine false
    (by unfold CanonicalLocal.ReachThree; decide +kernel) (by decide +kernel)

theorem spine_acyclic : spine.IsAcyclic := spine_tree.IsAcyclic

abbrev PoolVertex (p q : Nat) := TwoPool.Vertex Bool p q

def poolGraph (p q : Nat) : SimpleGraph (PoolVertex p q) :=
  TwoPool.graph spine false true p q

def poolTo (p q : Nat) : PoolVertex p q → DoubleCentreP4.Vertex 0 0 p q
  | .inl false => .inl (.inl none)
  | .inl true => .inr (.inl none)
  | .inr (.inl (i,r)) => .inl (.inr (.inl (i,r)))
  | .inr (.inr (i,r)) => .inr (.inr (.inl (i,r)))

def poolFrom (p q : Nat) : DoubleCentreP4.Vertex 0 0 p q → PoolVertex p q
  | .inl (.inl none) => .inl false
  | .inr (.inl none) => .inl true
  | .inl (.inl (some (i,_))) => Fin.elim0 i
  | .inr (.inl (some (i,_))) => Fin.elim0 i
  | .inl (.inr (.inl (i,r))) => .inr (.inl (i,r))
  | .inr (.inr (.inl (i,r))) => .inr (.inr (i,r))
  | .inl (.inr (.inr (i,_))) => Fin.elim0 i
  | .inr (.inr (.inr (i,_))) => Fin.elim0 i

/-- A concrete bijection of complete carriers; only empty Fin 0 cases vanish. -/
def poolEquiv (p q : Nat) : PoolVertex p q ≃ DoubleCentreP4.Vertex 0 0 p q where
  toFun := poolTo p q
  invFun := poolFrom p q
  left_inv := by
    intro v
    rcases v with (v | (⟨i,r⟩ | ⟨i,r⟩))
    · cases v <;> rfl
    · rfl
    · rfl
  right_inv := by
    intro v
    rcases v with v | v
    all_goals rcases v with (_ | ⟨i,r⟩) | (⟨i,r⟩ | ⟨i,r⟩)
    all_goals first | exact Fin.elim0 i | rfl

@[simp] theorem pool_left (p q : Nat) :
    poolEquiv p q (TwoPool.fixed p q false) = DoubleCentreP4.left 0 0 p q := rfl
@[simp] theorem pool_right (p q : Nat) :
    poolEquiv p q (TwoPool.fixed p q true) = DoubleCentreP4.right 0 0 p q := rfl
@[simp] theorem pool_ordinaryLeft (p q : Nat) (i : Fin p) (r : Fin 7) :
    poolEquiv p q (TwoPool.ordinaryLeft p q i r) = .inl (GeneralP4Receiver.ordinary 0 p i r) := rfl
@[simp] theorem pool_ordinaryRight (p q : Nat) (i : Fin q) (r : Fin 7) :
    poolEquiv p q (TwoPool.ordinaryRight p q i r) = .inr (GeneralP4Receiver.ordinary 0 q i r) := rfl

/-- Literal adjacency, including both central orientations and every cross pair. -/
theorem pool_adj (p q : Nat) (u v : PoolVertex p q) :
    (DoubleCentreP4.graph 0 0 p q).Adj (poolEquiv p q u) (poolEquiv p q v) ↔
      (poolGraph p q).Adj u v := by
  rcases u with (u | (⟨i,r⟩ | ⟨i,r⟩))
  all_goals rcases v with (v | (⟨j,s⟩ | ⟨j,s⟩))
  all_goals first | cases u | skip
  all_goals first | cases v | skip
  all_goals simp [poolGraph,poolEquiv,poolTo,DoubleCentreP4.graph,Attachment.original,
    GeneralP4Receiver.graph,GeneralP4Receiver.fixedGraph,GeneralP4Receiver.centre,
    GeneralP4Receiver.fixed,GeneralP4Receiver.root,TwoPool.graph,TwoPool.fixed,spine]

/-- Both genuine marks and selected histories are transported without restriction. -/
theorem pool_mark_history (p q : Nat) (M X : Finset (PoolVertex p q))
    (v : PoolVertex p q) :
    (poolEquiv p q v ∈ M.image (poolEquiv p q) ↔ v ∈ M) ∧
      (poolEquiv p q v ∈ X.image (poolEquiv p q) ↔ v ∈ X) := by
  simp

/-- In particular, every original selectable marked/blue action is retained. -/
theorem pool_legal (p q : Nat) (M X : Finset (PoolVertex p q)) (v : PoolVertex p q) :
    Marked.Legal (DoubleCentreP4.graph 0 0 p q) (M.image (poolEquiv p q))
      (X.image (poolEquiv p q)) (poolEquiv p q v) ↔
      Marked.Legal (poolGraph p q) M X v :=
  Marked.legal_relabel (poolGraph p q) (DoubleCentreP4.graph 0 0 p q)
    (poolEquiv p q) (pool_adj p q) M X v

theorem pool_white (p q : Nat) (M X : Finset (PoolVertex p q)) (v : PoolVertex p q) :
    Marked.White (DoubleCentreP4.graph 0 0 p q) (M.image (poolEquiv p q))
      (X.image (poolEquiv p q)) (poolEquiv p q v) ↔
      Marked.White (poolGraph p q) M X v :=
  Marked.white_relabel (poolGraph p q) (DoubleCentreP4.graph 0 0 p q)
    (poolEquiv p q) (pool_adj p q) M X v

theorem pool_marked_value (p q : Nat) (M X : Finset (PoolVertex p q)) (t : Player) :
    Marked.gameValue (poolGraph p q) M t X =
      Marked.gameValue (DoubleCentreP4.graph 0 0 p q) (M.image (poolEquiv p q))
        t (X.image (poolEquiv p q)) :=
  (Marked.gameValue_relabel (poolGraph p q) (DoubleCentreP4.graph 0 0 p q)
    (poolEquiv p q) (pool_adj p q) M X t).symm

/-- The TwoPool fixed marks are genuinely empty, rather than played-centre marks. -/
theorem pool_marks_empty (p q : Nat) : TwoPool.marks (∅ : Finset Bool) p q = ∅ := by
  simp [TwoPool.marks]

theorem pool_value (p q : Nat) (t : Player) (X : Finset (PoolVertex p q)) :
    Marked.gameValue (TwoPool.graph spine false true p q)
      (TwoPool.marks (∅ : Finset Bool) p q) t X =
      Marked.gameValue (DoubleCentreP4.graph 0 0 p q) ∅ t (X.image (poolEquiv p q)) := by
  simpa only [poolGraph,pool_marks_empty,Finset.image_empty] using
    pool_marked_value p q ∅ X t

#print axioms spine_tree
#print axioms poolEquiv
#print axioms pool_adj
#print axioms pool_mark_history
#print axioms pool_legal
#print axioms pool_white
#print axioms pool_marked_value
#print axioms pool_value
end IsolationGame.DoubleCentreP4.Zero
