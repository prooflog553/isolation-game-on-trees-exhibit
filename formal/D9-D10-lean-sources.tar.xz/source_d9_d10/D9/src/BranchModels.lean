import MinimalInnerClassification
import ActualRootBudget

namespace IsolationGame.SmallPiece
open IsolatedRestriction ActualRootBranches
variable {V : Type} [Fintype V] [DecidableEq V]

/-- An exact rooted adjacency model for each actual child branch. -/
structure BranchModels (H : SimpleGraph V) (r : V) where
  kind : Child H r→Kind
  equiv : ∀a : Child H r,Active (piece H r a)≃Fin (order (kind a))
  root_map : ∀a,equiv a ⟨a.val,self_mem_piece H r a⟩=root (kind a)
  adjacency : ∀a u v,(model (kind a)).Adj (equiv a u) (equiv a v) ↔ (induced H (piece H r a)).Adj u v

noncomputable def branchModels (H : SimpleGraph V) (r : V)
    (h : ∀a : Child H r,Spec (induced H (piece H r a)) ⟨a.val,self_mem_piece H r a⟩) : BranchModels H r where
  kind a := Classical.choose (h a)
  equiv a := Classical.choose (Classical.choose_spec (h a))
  root_map a := (Classical.choose_spec (Classical.choose_spec (h a))).1
  adjacency a := (Classical.choose_spec (Classical.choose_spec (h a))).2

theorem model_piece_card (H : SimpleGraph V) (r : V) (B : BranchModels H r) (a : Child H r) :
    (piece H r a).card=order (B.kind a) := by
  have h := Fintype.card_congr (B.equiv a)
  simpa only [Fintype.card_coe,Fintype.card_fin] using h

def countKind {Iota : Type} [DecidableEq Iota] (f : Iota→Kind) (I : Finset Iota) (k : Kind) : Nat :=
  (I.filter (fun i=>f i=k)).card

theorem order_sum_counts {Iota : Type} [DecidableEq Iota] (f : Iota→Kind) (I : Finset Iota) :
    (∑i∈I,order (f i))=countKind f I .leaf+2*countKind f I .edge+
      3*countKind f I .long+4*countKind f I .fork := by
  induction I using Finset.induction_on with
  | empty => simp [countKind]
  | @insert i I hi ih =>
    rw [Finset.sum_insert hi]
    cases he : f i <;> simp [countKind,Finset.filter_insert,he,hi,order] at * <;> omega

/-- Exact original order of the rooted graph, from its actual branch models. -/
theorem model_original_order (H : SimpleGraph V) (hT : H.IsTree) (r : V) (B : BranchModels H r) :
    Fintype.card V=1+countKind B.kind Finset.univ .leaf+2*countKind B.kind Finset.univ .edge+
      3*countKind B.kind Finset.univ .long+4*countKind B.kind Finset.univ .fork := by
  have h := actual_order H hT r
  have he : (∑a : Child H r,(piece H r a).card)=∑a : Child H r,order (B.kind a) := by
    apply Finset.sum_congr rfl
    intro a _
    exact model_piece_card H r B a
  rw [he,order_sum_counts] at h
  omega

/-- The exact models furnished by the completed minimum-counterexample
classification, with all original nested-branch hypotheses discharged. -/
noncomputable def minimal_outer_models (G : SimpleGraph V) (hT : G.IsTree)
    (r : V) (hR : ∀v,G.dist r v≤4) (hSmall : RootedReduction.SmallerFloor (Fintype.card V))
    (hCounter : 3*Fintype.card V/7<Marked.gameValue G {r} .dominator ∅) (a : Child G r) :
    BranchModels (outerGraph G r a) (outerRoot G r a) :=
  branchModels _ _ (fun b=>minimal_inner_spec G hT r hR hSmall hCounter a b)

#print axioms model_original_order
#print axioms minimal_outer_models
end IsolationGame.SmallPiece
