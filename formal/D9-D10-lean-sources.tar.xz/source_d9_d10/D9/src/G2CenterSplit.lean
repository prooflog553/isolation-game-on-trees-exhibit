import G2Model
import BWZeroBoundaries

namespace IsolationGame.Marked
variable {V : Type} [Fintype V] [DecidableEq V]

theorem value_eq_of_adj_agree_unmarked (G H : SimpleGraph V) (M X : Finset V)
    (ha : ∀ v w, w∉M → (G.Adj v w ↔ H.Adj v w)) (t : Player) :
    gameValue G M t X=gameValue H M t X := by
  have hc : ∀ v w, w∉M → (Closed G v w ↔ Closed H v w) := by
    intro v w hw
    exact or_congr Iff.rfl (ha v w hw)
  have hu : ∀v,Undominated G M X v ↔ Undominated H M X v := by
    intro v
    constructor <;> rintro ⟨hm,hd⟩ <;> refine ⟨hm,?_⟩
    · rintro ⟨w,hw,hcw⟩
      exact hd ⟨w,hw,(hc w v hm).mpr hcw⟩
    · rintro ⟨w,hw,hcw⟩
      exact hd ⟨w,hw,(hc w v hm).mp hcw⟩
  have hw : White G M X=White H M X := by
    funext v; apply propext
    constructor
    · rintro ⟨hv,w,hvw,hw⟩
      exact ⟨(hu v).mp hv,w,(ha v w hw.1).mp hvw,(hu w).mp hw⟩
    · rintro ⟨hv,w,hvw,hw⟩
      exact ⟨(hu v).mpr hv,w,(ha v w hw.1).mpr hvw,(hu w).mpr hw⟩
  have he (n : Nat) : WinsWithin G M n t X ↔ WinsWithin H M n t X := by
    rw [←ForestFoundation.white_horizon,←ForestFoundation.white_horizon,←hw]
    apply (GuardedEdge.view G).winsWhite_congr
    intro v w hw
    simpa only [GuardedEdge.closed_agree] using hc v w hw.1.1
  apply Nat.le_antisymm
  · exact (gameValue_le_iff _ _ _ _ _).mpr ((he _).mpr ((gameValue_le_iff _ _ _ _ _).mp (Nat.le_refl _)))
  · exact (gameValue_le_iff _ _ _ _ _).mpr ((he _).mp ((gameValue_le_iff _ _ _ _ _).mp (Nat.le_refl _)))
end IsolationGame.Marked

namespace IsolationGame.Attachment
variable {V U : Type} [Fintype V] [DecidableEq V] [Fintype U] [DecidableEq U]

theorem marked_endpoints_value (G : SimpleGraph V) (H : SimpleGraph U) (z : V) (b : U)
    (M : Finset V) (N : Finset U) (hz : z∈M) (hb : b∈N)
    (X : Finset (Sum V U)) (t : Player) :
    Marked.gameValue (original G H z b) (MarkedSum.combine M N) t X=
      Marked.gameValue (MarkedSum.original G H) (MarkedSum.combine M N) t X := by
  apply Marked.value_eq_of_adj_agree_unmarked
  intro v w hw
  cases v with
  | inl v => cases w with
    | inl w => rfl
    | inr w =>
      have hn : w≠b := by intro h; subst w; exact hw ((MarkedSum.combine_inr M N b).mpr hb)
      simp [original,MarkedSum.original,MarkedSum.graph,Isolation.Graph.disjointSum,hn]
  | inr v => cases w with
    | inl w =>
      have hn : w≠z := by intro h; subst w; exact hw ((MarkedSum.combine_inl M N z).mpr hz)
      simp [original,MarkedSum.original,MarkedSum.graph,Isolation.Graph.disjointSum,hn]
    | inr w => rfl
theorem right_played_marks (G : SimpleGraph V) (H : SimpleGraph U) (z : V) (b : U)
    (M : Finset V) (N : Finset U) (hz : z∈M) :
    SelectedVertex.playedMarks (original G H z b) (MarkedSum.combine M N) (.inr b)=
      MarkedSum.combine M (SelectedVertex.playedMarks H N b) := by
  classical
  ext w
  cases w with
  | inl w =>
    simp only [SelectedVertex.mem_playedMarks,MarkedSum.combine_inl,closed_rl]
    constructor
    · rintro (h | ⟨_,rfl⟩); exact h; exact hz
    · exact Or.inl
  | inr w => simp [SelectedVertex.mem_playedMarks]

theorem after_right_root_value (G : SimpleGraph V) (H : SimpleGraph U) (z : V) (b : U)
    (M : Finset V) (N : Finset U) (hz : z∈M) (t : Player) :
    Marked.gameValue (original G H z b) (MarkedSum.combine M N) t {.inr b}=
      Marked.gameValue (MarkedSum.original G H)
        (MarkedSum.combine M (SelectedVertex.playedMarks H N b)) t ∅ := by
  calc
    _=Marked.gameValue (original G H z b)
      (SelectedVertex.playedMarks (original G H z b) (MarkedSum.combine M N) (.inr b)) t ∅ := by
        apply Marked.value_eq_of_white_eq
        intro w
        change Marked.White _ _ (insert (.inr b) ∅) w ↔ _
        rw [SelectedVertex.absorb_white]
    _=_ := by
      rw [right_played_marks G H z b M N hz]
      apply marked_endpoints_value G H z b M _ hz
      exact (SelectedVertex.mem_playedMarks H N b b).mpr (Or.inr (Or.inl rfl))

theorem left_played_marks (G : SimpleGraph V) (H : SimpleGraph U) (z : V) (b : U)
    (M : Finset V) (N : Finset U) :
    SelectedVertex.playedMarks (original G H z b) (MarkedSum.combine M N) (.inl z)=
      MarkedSum.combine (SelectedVertex.playedMarks G M z) (insert b N) := by
  classical
  ext w
  cases w with
  | inl w => simp [SelectedVertex.mem_playedMarks]
  | inr w => simp [SelectedVertex.mem_playedMarks,eq_comm,or_comm]

theorem after_left_root_value (G : SimpleGraph V) (H : SimpleGraph U) (z : V) (b : U)
    (M : Finset V) (N : Finset U) (t : Player) :
    Marked.gameValue (original G H z b) (MarkedSum.combine M N) t {.inl z}=
      Marked.gameValue (MarkedSum.original G H)
        (MarkedSum.combine (SelectedVertex.playedMarks G M z) (insert b N)) t ∅ := by
  calc
    _=Marked.gameValue (original G H z b)
      (SelectedVertex.playedMarks (original G H z b) (MarkedSum.combine M N) (.inl z)) t ∅ := by
        apply Marked.value_eq_of_white_eq
        intro w
        change Marked.White _ _ (insert (.inl z) ∅) w ↔ _
        rw [SelectedVertex.absorb_white]
    _=_ := by
      rw [left_played_marks]
      apply marked_endpoints_value G H z b
      · exact (SelectedVertex.mem_playedMarks G M z z).mpr (Or.inr (Or.inl rfl))
      · exact Finset.mem_insert_self _ _

end IsolationGame.Attachment

namespace IsolationGame.G2Family

/-- Regrouping retains all physical vertices and all original copy identities. -/
def centerEquiv (p q k : Nat) : Vertex p q k ≃ Sum (YVertex q k) (BWBridge.Side p) where
  toFun
    | .inl (.inl u) => .inl (.inl u)
    | .inl (.inr v) => .inr v
    | .inr w => .inl (.inr w)
  invFun
    | .inl (.inl u) => .inl (.inl u)
    | .inl (.inr w) => .inr w
    | .inr v => .inl (.inr v)
  left_inv := by intro v; cases v with
    | inl v => cases v <;> rfl
    | inr v => rfl
  right_inv := by intro v; cases v with
    | inl v => cases v <;> rfl
    | inr v => rfl

theorem centerEquiv_adj (p q k : Nat) (v w : Vertex p q k) :
    (Attachment.original (yGraph q k) MarkedModule.original (.inl (BWBridge.root q)) (BWBridge.root p)).Adj
      (centerEquiv p q k v) (centerEquiv p q k w) ↔ (graph p q k).Adj v w := by
  cases v with
  | inl v => cases v with
    | inl v => cases w with
      | inl w => cases w <;> simp [centerEquiv,Attachment.original,graph,BWBridge.original,yGraph]
      | inr w => simp [centerEquiv,Attachment.original,graph,BWBridge.original,yGraph]
    | inr v => cases w with
      | inl w => cases w <;> simp [centerEquiv,Attachment.original,graph,BWBridge.original,yGraph]
      | inr w => simp [centerEquiv,Attachment.original,graph]
  | inr v => cases w with
    | inl w => cases w with
      | inl w => simp [centerEquiv,Attachment.original,graph,BWBridge.original,yGraph]
      | inr w => simp [centerEquiv,Attachment.original,graph]
    | inr w => simp [centerEquiv,Attachment.original,graph,BWBridge.original,yGraph]

#print axioms centerEquiv_adj
end IsolationGame.G2Family
