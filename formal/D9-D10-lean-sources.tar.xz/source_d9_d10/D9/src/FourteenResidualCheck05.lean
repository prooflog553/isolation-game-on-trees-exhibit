import FourteenResidualData

/-! Finite kernel arithmetic only: first profile fixed to t05.
All arithmetic is checked by kernel reduction; no graph or history search. -/
namespace IsolationGame.FourteenResidual
open CanonicalLocal
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

theorem check11_t05 (b : Index) :
    NumericResidual [.t05] [b] → MatchesFourteen [.t05] [b] := by
  cases b <;> decide +kernel

theorem check12_t05 (b c : Index) :
    NumericResidual [.t05] [b, c] → MatchesFourteen [.t05] [b, c] := by
  cases b <;> cases c <;> decide +kernel

#print axioms check11_t05
#print axioms check12_t05
end IsolationGame.FourteenResidual
