import FullCanonical11Rows01
namespace IsolationGame.FullCanonical.T11
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_8 : Finset (Fin 6) := {}
theorem after_8_0 : Marked.gameValue original marks_8 .dominator {0}=1 ∧ Marked.gameValue original marks_8 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_2 0 1 1 (by decide +kernel) row_2
theorem after_8_1 : Marked.gameValue original marks_8 .dominator {1}=1 ∧ Marked.gameValue original marks_8 .staller {1}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_3 1 1 1 (by decide +kernel) row_3
theorem after_8_2 : Marked.gameValue original marks_8 .dominator {2}=1 ∧ Marked.gameValue original marks_8 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_5 2 1 2 (by decide +kernel) row_5
theorem after_8_3 : Marked.gameValue original marks_8 .dominator {3}=1 ∧ Marked.gameValue original marks_8 .staller {3}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_7 3 1 2 (by decide +kernel) row_7
theorem after_8_4 : Marked.gameValue original marks_8 .dominator {4}=1 ∧ Marked.gameValue original marks_8 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_4 4 1 2 (by decide +kernel) row_4
theorem after_8_5 : Marked.gameValue original marks_8 .dominator {5}=1 ∧ Marked.gameValue original marks_8 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_6 5 1 2 (by decide +kernel) row_6
theorem row_8 : Marked.gameValue original marks_8 .dominator ∅=2 ∧ Marked.gameValue original marks_8 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_8 2 2 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_8_0.2]
  · rw [after_8_0.1]
  · intro v hv
    fin_cases v
    · have h := after_8_0
      change 2 ≤ 1+Marked.gameValue original marks_8 .staller {0} ∧ 1+Marked.gameValue original marks_8 .dominator {0} ≤ 2
      omega
    · have h := after_8_1
      change 2 ≤ 1+Marked.gameValue original marks_8 .staller {1} ∧ 1+Marked.gameValue original marks_8 .dominator {1} ≤ 2
      omega
    · have h := after_8_2
      change 2 ≤ 1+Marked.gameValue original marks_8 .staller {2} ∧ 1+Marked.gameValue original marks_8 .dominator {2} ≤ 2
      omega
    · have h := after_8_3
      change 2 ≤ 1+Marked.gameValue original marks_8 .staller {3} ∧ 1+Marked.gameValue original marks_8 .dominator {3} ≤ 2
      omega
    · have h := after_8_4
      change 2 ≤ 1+Marked.gameValue original marks_8 .staller {4} ∧ 1+Marked.gameValue original marks_8 .dominator {4} ≤ 2
      omega
    · have h := after_8_5
      change 2 ≤ 1+Marked.gameValue original marks_8 .staller {5} ∧ 1+Marked.gameValue original marks_8 .dominator {5} ≤ 2
      omega
end IsolationGame.FullCanonical.T11
