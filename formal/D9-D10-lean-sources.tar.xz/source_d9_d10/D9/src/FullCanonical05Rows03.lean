import FullCanonical05Rows02
namespace IsolationGame.FullCanonical.T05
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_12 : Finset (Fin 16) := {1,2,3,4,5,6,8,9,11,12}
theorem after_12_0 : Marked.gameValue original marks_12 .dominator {0}=1 ∧ Marked.gameValue original marks_12 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_2 0 1 1 (by decide +kernel) row_2
theorem after_12_1 : Marked.gameValue original marks_12 .dominator {1}=1 ∧ Marked.gameValue original marks_12 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_4 1 1 2 (by decide +kernel) row_4
theorem after_12_4 : Marked.gameValue original marks_12 .dominator {4}=1 ∧ Marked.gameValue original marks_12 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_4 4 1 2 (by decide +kernel) row_4
theorem after_12_7 : Marked.gameValue original marks_12 .dominator {7}=1 ∧ Marked.gameValue original marks_12 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_4 7 1 2 (by decide +kernel) row_4
theorem after_12_8 : Marked.gameValue original marks_12 .dominator {8}=1 ∧ Marked.gameValue original marks_12 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_9 8 1 2 (by decide +kernel) row_9
theorem after_12_10 : Marked.gameValue original marks_12 .dominator {10}=1 ∧ Marked.gameValue original marks_12 .staller {10}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_4 10 1 2 (by decide +kernel) row_4
theorem after_12_11 : Marked.gameValue original marks_12 .dominator {11}=1 ∧ Marked.gameValue original marks_12 .staller {11}=2 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_12 marks_9 11 1 2 (by decide +kernel) row_9
theorem after_12_13 : Marked.gameValue original marks_12 .dominator {13}=0 ∧ Marked.gameValue original marks_12 .staller {13}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_0 13 0 0 (by decide +kernel) row_0
theorem after_12_14 : Marked.gameValue original marks_12 .dominator {14}=1 ∧ Marked.gameValue original marks_12 .staller {14}=2 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_12 marks_3 14 1 2 (by decide +kernel) row_3
theorem after_12_15 : Marked.gameValue original marks_12 .dominator {15}=1 ∧ Marked.gameValue original marks_12 .staller {15}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_12 marks_5 15 1 2 (by decide +kernel) row_5
theorem row_12 : Marked.gameValue original marks_12 .dominator ∅=1 ∧ Marked.gameValue original marks_12 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_12 1 2 13 0 (by decide +kernel) (by decide +kernel)
  · rw [after_12_13.2]
  · rw [after_12_0.1]
  · intro v hv
    fin_cases v
    · have h := after_12_0
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {0} ∧ 1+Marked.gameValue original marks_12 .dominator {0} ≤ 2
      omega
    · have h := after_12_1
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {1} ∧ 1+Marked.gameValue original marks_12 .dominator {1} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_12 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_12 ∅ 3) hv)
    · have h := after_12_4
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {4} ∧ 1+Marked.gameValue original marks_12 .dominator {4} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_12 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_12 ∅ 6) hv)
    · have h := after_12_7
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {7} ∧ 1+Marked.gameValue original marks_12 .dominator {7} ≤ 2
      omega
    · have h := after_12_8
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {8} ∧ 1+Marked.gameValue original marks_12 .dominator {8} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_12 ∅ 9) hv)
    · have h := after_12_10
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {10} ∧ 1+Marked.gameValue original marks_12 .dominator {10} ≤ 2
      omega
    · have h := after_12_11
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {11} ∧ 1+Marked.gameValue original marks_12 .dominator {11} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_12 ∅ 12) hv)
    · have h := after_12_13
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {13} ∧ 1+Marked.gameValue original marks_12 .dominator {13} ≤ 2
      omega
    · have h := after_12_14
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {14} ∧ 1+Marked.gameValue original marks_12 .dominator {14} ≤ 2
      omega
    · have h := after_12_15
      change 1 ≤ 1+Marked.gameValue original marks_12 .staller {15} ∧ 1+Marked.gameValue original marks_12 .dominator {15} ≤ 2
      omega
def marks_13 : Finset (Fin 16) := {0,1,2,3,4,5,6,7,8,9}
theorem after_13_0 : Marked.gameValue original marks_13 .dominator {0}=2 ∧ Marked.gameValue original marks_13 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_6 0 2 2 (by decide +kernel) row_6
theorem after_13_10 : Marked.gameValue original marks_13 .dominator {10}=1 ∧ Marked.gameValue original marks_13 .staller {10}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_4 10 1 2 (by decide +kernel) row_4
theorem after_13_11 : Marked.gameValue original marks_13 .dominator {11}=1 ∧ Marked.gameValue original marks_13 .staller {11}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_4 11 1 2 (by decide +kernel) row_4
theorem after_13_12 : Marked.gameValue original marks_13 .dominator {12}=1 ∧ Marked.gameValue original marks_13 .staller {12}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_13 marks_4 12 1 2 (by decide +kernel) row_4
theorem after_13_13 : Marked.gameValue original marks_13 .dominator {13}=1 ∧ Marked.gameValue original marks_13 .staller {13}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_13 marks_4 13 1 2 (by decide +kernel) row_4
theorem after_13_14 : Marked.gameValue original marks_13 .dominator {14}=1 ∧ Marked.gameValue original marks_13 .staller {14}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_13 marks_4 14 1 2 (by decide +kernel) row_4
theorem after_13_15 : Marked.gameValue original marks_13 .dominator {15}=1 ∧ Marked.gameValue original marks_13 .staller {15}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_13 marks_4 15 1 2 (by decide +kernel) row_4
theorem row_13 : Marked.gameValue original marks_13 .dominator ∅=3 ∧ Marked.gameValue original marks_13 .staller ∅=3 := by
  apply LocalProfile.DAG.bellman original marks_13 3 3 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_13_0.2]
  · rw [after_13_0.1]
  · intro v hv
    fin_cases v
    · have h := after_13_0
      change 3 ≤ 1+Marked.gameValue original marks_13 .staller {0} ∧ 1+Marked.gameValue original marks_13 .dominator {0} ≤ 3
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_13 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_13 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_13 ∅ 3) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_13 ∅ 4) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_13 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_13 ∅ 6) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_13 ∅ 7) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_13 ∅ 8) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_13 ∅ 9) hv)
    · have h := after_13_10
      change 3 ≤ 1+Marked.gameValue original marks_13 .staller {10} ∧ 1+Marked.gameValue original marks_13 .dominator {10} ≤ 3
      omega
    · have h := after_13_11
      change 3 ≤ 1+Marked.gameValue original marks_13 .staller {11} ∧ 1+Marked.gameValue original marks_13 .dominator {11} ≤ 3
      omega
    · have h := after_13_12
      change 3 ≤ 1+Marked.gameValue original marks_13 .staller {12} ∧ 1+Marked.gameValue original marks_13 .dominator {12} ≤ 3
      omega
    · have h := after_13_13
      change 3 ≤ 1+Marked.gameValue original marks_13 .staller {13} ∧ 1+Marked.gameValue original marks_13 .dominator {13} ≤ 3
      omega
    · have h := after_13_14
      change 3 ≤ 1+Marked.gameValue original marks_13 .staller {14} ∧ 1+Marked.gameValue original marks_13 .dominator {14} ≤ 3
      omega
    · have h := after_13_15
      change 3 ≤ 1+Marked.gameValue original marks_13 .staller {15} ∧ 1+Marked.gameValue original marks_13 .dominator {15} ≤ 3
      omega
def marks_14 : Finset (Fin 16) := {1,2,3,5,6,8,9,11,12}
theorem after_14_0 : Marked.gameValue original marks_14 .dominator {0}=1 ∧ Marked.gameValue original marks_14 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_2 0 1 1 (by decide +kernel) row_2
theorem after_14_1 : Marked.gameValue original marks_14 .dominator {1}=1 ∧ Marked.gameValue original marks_14 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_4 1 1 2 (by decide +kernel) row_4
theorem after_14_4 : Marked.gameValue original marks_14 .dominator {4}=1 ∧ Marked.gameValue original marks_14 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_4 4 1 2 (by decide +kernel) row_4
theorem after_14_5 : Marked.gameValue original marks_14 .dominator {5}=1 ∧ Marked.gameValue original marks_14 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_12 5 1 2 (by decide +kernel) row_12
theorem after_14_7 : Marked.gameValue original marks_14 .dominator {7}=1 ∧ Marked.gameValue original marks_14 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_4 7 1 2 (by decide +kernel) row_4
theorem after_14_8 : Marked.gameValue original marks_14 .dominator {8}=1 ∧ Marked.gameValue original marks_14 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_4 adjacency_4 marks_14 marks_12 8 1 2 (by decide +kernel) row_12
theorem after_14_10 : Marked.gameValue original marks_14 .dominator {10}=1 ∧ Marked.gameValue original marks_14 .staller {10}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_4 10 1 2 (by decide +kernel) row_4
theorem after_14_11 : Marked.gameValue original marks_14 .dominator {11}=1 ∧ Marked.gameValue original marks_14 .staller {11}=2 :=
  FullCanonicalDAG.transport_perm original perm_5 adjacency_5 marks_14 marks_12 11 1 2 (by decide +kernel) row_12
theorem after_14_13 : Marked.gameValue original marks_14 .dominator {13}=0 ∧ Marked.gameValue original marks_14 .staller {13}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_0 13 0 0 (by decide +kernel) row_0
theorem after_14_14 : Marked.gameValue original marks_14 .dominator {14}=1 ∧ Marked.gameValue original marks_14 .staller {14}=2 :=
  FullCanonicalDAG.transport_perm original perm_6 adjacency_6 marks_14 marks_5 14 1 2 (by decide +kernel) row_5
theorem after_14_15 : Marked.gameValue original marks_14 .dominator {15}=1 ∧ Marked.gameValue original marks_14 .staller {15}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_14 marks_8 15 1 2 (by decide +kernel) row_8
theorem row_14 : Marked.gameValue original marks_14 .dominator ∅=1 ∧ Marked.gameValue original marks_14 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_14 1 2 13 0 (by decide +kernel) (by decide +kernel)
  · rw [after_14_13.2]
  · rw [after_14_0.1]
  · intro v hv
    fin_cases v
    · have h := after_14_0
      change 1 ≤ 1+Marked.gameValue original marks_14 .staller {0} ∧ 1+Marked.gameValue original marks_14 .dominator {0} ≤ 2
      omega
    · have h := after_14_1
      change 1 ≤ 1+Marked.gameValue original marks_14 .staller {1} ∧ 1+Marked.gameValue original marks_14 .dominator {1} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_14 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_14 ∅ 3) hv)
    · have h := after_14_4
      change 1 ≤ 1+Marked.gameValue original marks_14 .staller {4} ∧ 1+Marked.gameValue original marks_14 .dominator {4} ≤ 2
      omega
    · have h := after_14_5
      change 1 ≤ 1+Marked.gameValue original marks_14 .staller {5} ∧ 1+Marked.gameValue original marks_14 .dominator {5} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_14 ∅ 6) hv)
    · have h := after_14_7
      change 1 ≤ 1+Marked.gameValue original marks_14 .staller {7} ∧ 1+Marked.gameValue original marks_14 .dominator {7} ≤ 2
      omega
    · have h := after_14_8
      change 1 ≤ 1+Marked.gameValue original marks_14 .staller {8} ∧ 1+Marked.gameValue original marks_14 .dominator {8} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_14 ∅ 9) hv)
    · have h := after_14_10
      change 1 ≤ 1+Marked.gameValue original marks_14 .staller {10} ∧ 1+Marked.gameValue original marks_14 .dominator {10} ≤ 2
      omega
    · have h := after_14_11
      change 1 ≤ 1+Marked.gameValue original marks_14 .staller {11} ∧ 1+Marked.gameValue original marks_14 .dominator {11} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_14 ∅ 12) hv)
    · have h := after_14_13
      change 1 ≤ 1+Marked.gameValue original marks_14 .staller {13} ∧ 1+Marked.gameValue original marks_14 .dominator {13} ≤ 2
      omega
    · have h := after_14_14
      change 1 ≤ 1+Marked.gameValue original marks_14 .staller {14} ∧ 1+Marked.gameValue original marks_14 .dominator {14} ≤ 2
      omega
    · have h := after_14_15
      change 1 ≤ 1+Marked.gameValue original marks_14 .staller {15} ∧ 1+Marked.gameValue original marks_14 .dominator {15} ≤ 2
      omega
def marks_15 : Finset (Fin 16) := {1,2,3,4,5,6,7,8,9}
theorem after_15_0 : Marked.gameValue original marks_15 .dominator {0}=2 ∧ Marked.gameValue original marks_15 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_6 0 2 2 (by decide +kernel) row_6
theorem after_15_1 : Marked.gameValue original marks_15 .dominator {1}=3 ∧ Marked.gameValue original marks_15 .staller {1}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_13 1 3 3 (by decide +kernel) row_13
theorem after_15_4 : Marked.gameValue original marks_15 .dominator {4}=3 ∧ Marked.gameValue original marks_15 .staller {4}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_13 4 3 3 (by decide +kernel) row_13
theorem after_15_7 : Marked.gameValue original marks_15 .dominator {7}=3 ∧ Marked.gameValue original marks_15 .staller {7}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_13 7 3 3 (by decide +kernel) row_13
theorem after_15_10 : Marked.gameValue original marks_15 .dominator {10}=1 ∧ Marked.gameValue original marks_15 .staller {10}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_4 10 1 2 (by decide +kernel) row_4
theorem after_15_11 : Marked.gameValue original marks_15 .dominator {11}=1 ∧ Marked.gameValue original marks_15 .staller {11}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_7 11 1 2 (by decide +kernel) row_7
theorem after_15_12 : Marked.gameValue original marks_15 .dominator {12}=1 ∧ Marked.gameValue original marks_15 .staller {12}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_15 marks_9 12 1 2 (by decide +kernel) row_9
theorem after_15_13 : Marked.gameValue original marks_15 .dominator {13}=1 ∧ Marked.gameValue original marks_15 .staller {13}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_15 marks_4 13 1 2 (by decide +kernel) row_4
theorem after_15_14 : Marked.gameValue original marks_15 .dominator {14}=1 ∧ Marked.gameValue original marks_15 .staller {14}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_15 marks_7 14 1 2 (by decide +kernel) row_7
theorem after_15_15 : Marked.gameValue original marks_15 .dominator {15}=1 ∧ Marked.gameValue original marks_15 .staller {15}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_15 marks_9 15 1 2 (by decide +kernel) row_9
theorem row_15 : Marked.gameValue original marks_15 .dominator ∅=3 ∧ Marked.gameValue original marks_15 .staller ∅=4 := by
  apply LocalProfile.DAG.bellman original marks_15 3 4 0 1 (by decide +kernel) (by decide +kernel)
  · rw [after_15_0.2]
  · rw [after_15_1.1]
  · intro v hv
    fin_cases v
    · have h := after_15_0
      change 3 ≤ 1+Marked.gameValue original marks_15 .staller {0} ∧ 1+Marked.gameValue original marks_15 .dominator {0} ≤ 4
      omega
    · have h := after_15_1
      change 3 ≤ 1+Marked.gameValue original marks_15 .staller {1} ∧ 1+Marked.gameValue original marks_15 .dominator {1} ≤ 4
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_15 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_15 ∅ 3) hv)
    · have h := after_15_4
      change 3 ≤ 1+Marked.gameValue original marks_15 .staller {4} ∧ 1+Marked.gameValue original marks_15 .dominator {4} ≤ 4
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_15 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_15 ∅ 6) hv)
    · have h := after_15_7
      change 3 ≤ 1+Marked.gameValue original marks_15 .staller {7} ∧ 1+Marked.gameValue original marks_15 .dominator {7} ≤ 4
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_15 ∅ 8) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_15 ∅ 9) hv)
    · have h := after_15_10
      change 3 ≤ 1+Marked.gameValue original marks_15 .staller {10} ∧ 1+Marked.gameValue original marks_15 .dominator {10} ≤ 4
      omega
    · have h := after_15_11
      change 3 ≤ 1+Marked.gameValue original marks_15 .staller {11} ∧ 1+Marked.gameValue original marks_15 .dominator {11} ≤ 4
      omega
    · have h := after_15_12
      change 3 ≤ 1+Marked.gameValue original marks_15 .staller {12} ∧ 1+Marked.gameValue original marks_15 .dominator {12} ≤ 4
      omega
    · have h := after_15_13
      change 3 ≤ 1+Marked.gameValue original marks_15 .staller {13} ∧ 1+Marked.gameValue original marks_15 .dominator {13} ≤ 4
      omega
    · have h := after_15_14
      change 3 ≤ 1+Marked.gameValue original marks_15 .staller {14} ∧ 1+Marked.gameValue original marks_15 .dominator {14} ≤ 4
      omega
    · have h := after_15_15
      change 3 ≤ 1+Marked.gameValue original marks_15 .staller {15} ∧ 1+Marked.gameValue original marks_15 .dominator {15} ≤ 4
      omega
end IsolationGame.FullCanonical.T05
