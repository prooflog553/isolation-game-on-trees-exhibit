import FloorLocalBase
import FloorLocalRow001
import FloorLocalRow016
import FloorLocalRow019
import FloorLocalRow065
import FloorLocalRow066
import FloorLocalRow109
set_option maxRecDepth 4096
set_option maxHeartbeats 1000000
namespace IsolationGame.FloorLocal
def marks_159 : Finset (Fin 7) := {2,3}
theorem normalized_159 : ∀v : Fin 7, Marked.White original_02 marks_159 ∅ v ↔ v∈({0,1,4,5,6} : Finset (Fin 7)) := by decide +kernel
theorem after_159_0 : Marked.gameValue original_02 marks_159 .dominator {0}=1 ∧ Marked.gameValue original_02 marks_159 .staller {0}=1 :=
  LocalProfile.DAG.transport original_02 marks_159 marks_019 0 1 1 (by decide +kernel) row_019
theorem after_159_1 : Marked.gameValue original_02 marks_159 .dominator {1}=1 ∧ Marked.gameValue original_02 marks_159 .staller {1}=2 :=
  LocalProfile.DAG.transport original_02 marks_159 marks_066 1 1 2 (by decide +kernel) row_066
theorem after_159_2 : Marked.gameValue original_02 marks_159 .dominator {2}=1 ∧ Marked.gameValue original_02 marks_159 .staller {2}=2 :=
  LocalProfile.DAG.transport original_02 marks_159 marks_109 2 1 2 (by decide +kernel) row_109
theorem after_159_4 : Marked.gameValue original_02 marks_159 .dominator {4}=0 ∧ Marked.gameValue original_02 marks_159 .staller {4}=0 :=
  LocalProfile.DAG.transport original_02 marks_159 marks_001 4 0 0 (by decide +kernel) row_001
theorem after_159_5 : Marked.gameValue original_02 marks_159 .dominator {5}=1 ∧ Marked.gameValue original_02 marks_159 .staller {5}=1 :=
  LocalProfile.DAG.transport original_02 marks_159 marks_016 5 1 1 (by decide +kernel) row_016
theorem after_159_6 : Marked.gameValue original_02 marks_159 .dominator {6}=1 ∧ Marked.gameValue original_02 marks_159 .staller {6}=2 :=
  LocalProfile.DAG.transport original_02 marks_159 marks_065 6 1 2 (by decide +kernel) row_065
theorem row_159 : Marked.gameValue original_02 marks_159 .dominator ∅=1 ∧ Marked.gameValue original_02 marks_159 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original_02 marks_159 1 2 4 0 (by decide +kernel) (by decide +kernel)
  · rw [after_159_4.2]
  · rw [after_159_0.1]
  · intro v hv
    fin_cases v
    · have h := after_159_0
      change 1≤1+Marked.gameValue original_02 marks_159 .staller {0} ∧ 1+Marked.gameValue original_02 marks_159 .dominator {0}≤2
      omega
    · have h := after_159_1
      change 1≤1+Marked.gameValue original_02 marks_159 .staller {1} ∧ 1+Marked.gameValue original_02 marks_159 .dominator {1}≤2
      omega
    · have h := after_159_2
      change 1≤1+Marked.gameValue original_02 marks_159 .staller {2} ∧ 1+Marked.gameValue original_02 marks_159 .dominator {2}≤2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_159 ∅ 3) hv)
    · have h := after_159_4
      change 1≤1+Marked.gameValue original_02 marks_159 .staller {4} ∧ 1+Marked.gameValue original_02 marks_159 .dominator {4}≤2
      omega
    · have h := after_159_5
      change 1≤1+Marked.gameValue original_02 marks_159 .staller {5} ∧ 1+Marked.gameValue original_02 marks_159 .dominator {5}≤2
      omega
    · have h := after_159_6
      change 1≤1+Marked.gameValue original_02 marks_159 .staller {6} ∧ 1+Marked.gameValue original_02 marks_159 .dominator {6}≤2
      omega
#print axioms row_159
end IsolationGame.FloorLocal
