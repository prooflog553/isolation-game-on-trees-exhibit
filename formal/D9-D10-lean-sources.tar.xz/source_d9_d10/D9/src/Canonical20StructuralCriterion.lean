import CanonicalCounts
import RootedAssemblyGeometry

/-!
SOURCE-ONLY CANDIDATE, 2026-10-19. Not elaborated or native-checked.
A sufficient rooted-ORIGINAL-graph classification, with no game assumptions.
All twenty classes, including t00 and t13, are retained.
-/
namespace IsolationGame.CeilCanonical20
open IsolatedRestriction SmallPiece ActualRootBranches CanonicalLocal
variable {V U : Type} [Fintype V] [DecidableEq V] [Fintype U] [DecidableEq U]

theorem counts_of_parameters_eq (G : SimpleGraph V) (H : SimpleGraph U) (r : V) (s : U)
    (B : BranchModels G r) (C : BranchModels H s)
    (hp : SmallPiece.parameters G r B=SmallPiece.parameters H s C) :
    ∀k : Kind,countKind B.kind Finset.univ k=countKind C.kind Finset.univ k := by
  unfold SmallPiece.parameters at hp
  simp only [Prod.mk.injEq] at hp
  intro k
  cases k with
  | leaf => exact hp.1
  | edge => exact hp.2.1
  | long => exact hp.2.2.2
  | fork => exact hp.2.2.1

/-- Unconditional count-to-actual-graph criterion. The root, all vertices,
and all original adjacencies are preserved by the resulting equivalence. -/
theorem canonical20_of_models_mass (H : SimpleGraph V) (hT : H.IsTree)
    (r : V) (B : BranchModels H r) (hTw : NoNonrootTwins H r)
    (hmass : 3*Fintype.card V<7*((AttachmentGeometry.longStars H r).card+2)) :
    ∃t : Index,RootedAssembly.RootedIso H r (graph t) (root t) := by
  have heps := leaf_count_le_one H hT r hTw B
  have hm := model_original_order H hT r B
  have hk := model_longStars H hT r B
  have hweight : 3*countKind B.kind Finset.univ .leaf+
      6*countKind B.kind Finset.univ .edge+
      5*countKind B.kind Finset.univ .fork+
      2*countKind B.kind Finset.univ .long≤10 := by omega
  have hp : SmallPiece.parameters H r B∈allowedParams :=
    parameters_complete _ _ _ _ heps hweight
  obtain ⟨t,ht⟩ := canonical_index_exists (SmallPiece.parameters H r B) hp
  have hparams : SmallPiece.parameters H r B=
      SmallPiece.parameters (graph t) (root t) (canonical_models t) := by
    rw [canonical_parameters,ht]
  have hcounts := counts_of_parameters_eq H (graph t) r (root t) B (canonical_models t) hparams
  exact ⟨t,RootedAssembly.same_counts_rooted_iso H (graph t) hT (canonical_tree t)
    r (root t) B (canonical_models t) hcounts⟩

/-- A reusable local criterion. Each actual child piece has height≤2,
order≤4, and the correct nonroot-twin convention; the complete rooted
height-three graph has the strict mass inequality. No minimality occurs. -/
theorem canonical20_of_child_constraints (H : SimpleGraph V) (hT : H.IsTree)
    (r : V) (hR : ∀v,H.dist r v≤3) (hTw : NoNonrootTwins H r)
    (hn : ∀a : Child H r,(piece H r a).card≤4)
    (hchildTw : ∀a : Child H r,
      NoNonrootTwins (outerGraph H r a) (outerRoot H r a))
    (hmass : 3*Fintype.card V<7*((AttachmentGeometry.longStars H r).card+2)) :
    ∃t : Index,RootedAssembly.RootedIso H r (graph t) (root t) := by
  have hs (a : Child H r) : SmallPiece.Spec (outerGraph H r a) (outerRoot H r a) := by
    have hp : H.dist r a.val=H.dist r r+1 := by
      simpa only [H.dist_self,Nat.zero_add] using child_depth H r a
    obtain ⟨hb,hh⟩ := DescendantGeometry.descendant_height H hT r r a.val
      (child_edge H r a) hp 3 hR
    have hRa : ∀v,(outerGraph H r a).dist (outerRoot H r a) v≤2 := by
      simpa only [child_depth,Nat.reduceSub] using hh
    exact small_piece_spec _ (outer_tree H hT r a) _ hRa
      (by simpa only [Fintype.card_coe] using hn a) (hchildTw a)
  let B := branchModels H r hs
  exact canonical20_of_models_mass H hT r B hTw hmass

#print axioms canonical20_of_models_mass
#print axioms canonical20_of_child_constraints
end IsolationGame.CeilCanonical20
