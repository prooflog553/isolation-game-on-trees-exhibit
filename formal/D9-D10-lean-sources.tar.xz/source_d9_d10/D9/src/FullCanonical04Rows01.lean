import FullCanonical04Rows00
namespace IsolationGame.FullCanonical.T04
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_4 : Finset (Fin 13) := {0,1,2,3,4,5,6,7,8,9}
theorem after_4_0 : Marked.gameValue original marks_4 .dominator {0}=1 ∧ Marked.gameValue original marks_4 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_4 marks_2 0 1 1 (by decide +kernel) row_2
theorem after_4_10 : Marked.gameValue original marks_4 .dominator {10}=0 ∧ Marked.gameValue original marks_4 .staller {10}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_4 marks_0 10 0 0 (by decide +kernel) row_0
theorem after_4_11 : Marked.gameValue original marks_4 .dominator {11}=0 ∧ Marked.gameValue original marks_4 .staller {11}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_4 marks_0 11 0 0 (by decide +kernel) row_0
theorem after_4_12 : Marked.gameValue original marks_4 .dominator {12}=0 ∧ Marked.gameValue original marks_4 .staller {12}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_4 marks_0 12 0 0 (by decide +kernel) row_0
theorem row_4 : Marked.gameValue original marks_4 .dominator ∅=1 ∧ Marked.gameValue original marks_4 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_4 1 2 10 0 (by decide +kernel) (by decide +kernel)
  · rw [after_4_10.2]
  · rw [after_4_0.1]
  · intro v hv
    fin_cases v
    · have h := after_4_0
      change 1 ≤ 1+Marked.gameValue original marks_4 .staller {0} ∧ 1+Marked.gameValue original marks_4 .dominator {0} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 3) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 4) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 6) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 7) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 8) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 9) hv)
    · have h := after_4_10
      change 1 ≤ 1+Marked.gameValue original marks_4 .staller {10} ∧ 1+Marked.gameValue original marks_4 .dominator {10} ≤ 2
      omega
    · have h := after_4_11
      change 1 ≤ 1+Marked.gameValue original marks_4 .staller {11} ∧ 1+Marked.gameValue original marks_4 .dominator {11} ≤ 2
      omega
    · have h := after_4_12
      change 1 ≤ 1+Marked.gameValue original marks_4 .staller {12} ∧ 1+Marked.gameValue original marks_4 .dominator {12} ≤ 2
      omega
def marks_5 : Finset (Fin 13) := {1,2,3,5,6,8,9,11,12}
theorem after_5_0 : Marked.gameValue original marks_5 .dominator {0}=0 ∧ Marked.gameValue original marks_5 .staller {0}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_5 marks_0 0 0 0 (by decide +kernel) row_0
theorem after_5_1 : Marked.gameValue original marks_5 .dominator {1}=0 ∧ Marked.gameValue original marks_5 .staller {1}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_5 marks_0 1 0 0 (by decide +kernel) row_0
theorem after_5_4 : Marked.gameValue original marks_5 .dominator {4}=0 ∧ Marked.gameValue original marks_5 .staller {4}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_5 marks_0 4 0 0 (by decide +kernel) row_0
theorem after_5_5 : Marked.gameValue original marks_5 .dominator {5}=1 ∧ Marked.gameValue original marks_5 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_5 marks_3 5 1 2 (by decide +kernel) row_3
theorem after_5_7 : Marked.gameValue original marks_5 .dominator {7}=0 ∧ Marked.gameValue original marks_5 .staller {7}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_5 marks_0 7 0 0 (by decide +kernel) row_0
theorem after_5_8 : Marked.gameValue original marks_5 .dominator {8}=1 ∧ Marked.gameValue original marks_5 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_5 marks_3 8 1 2 (by decide +kernel) row_3
theorem after_5_10 : Marked.gameValue original marks_5 .dominator {10}=0 ∧ Marked.gameValue original marks_5 .staller {10}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_5 marks_0 10 0 0 (by decide +kernel) row_0
theorem after_5_11 : Marked.gameValue original marks_5 .dominator {11}=1 ∧ Marked.gameValue original marks_5 .staller {11}=2 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_5 marks_3 11 1 2 (by decide +kernel) row_3
theorem row_5 : Marked.gameValue original marks_5 .dominator ∅=1 ∧ Marked.gameValue original marks_5 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_5 1 2 0 5 (by decide +kernel) (by decide +kernel)
  · rw [after_5_0.2]
  · rw [after_5_5.1]
  · intro v hv
    fin_cases v
    · have h := after_5_0
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {0} ∧ 1+Marked.gameValue original marks_5 .dominator {0} ≤ 2
      omega
    · have h := after_5_1
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {1} ∧ 1+Marked.gameValue original marks_5 .dominator {1} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 3) hv)
    · have h := after_5_4
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {4} ∧ 1+Marked.gameValue original marks_5 .dominator {4} ≤ 2
      omega
    · have h := after_5_5
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {5} ∧ 1+Marked.gameValue original marks_5 .dominator {5} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 6) hv)
    · have h := after_5_7
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {7} ∧ 1+Marked.gameValue original marks_5 .dominator {7} ≤ 2
      omega
    · have h := after_5_8
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {8} ∧ 1+Marked.gameValue original marks_5 .dominator {8} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 9) hv)
    · have h := after_5_10
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {10} ∧ 1+Marked.gameValue original marks_5 .dominator {10} ≤ 2
      omega
    · have h := after_5_11
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {11} ∧ 1+Marked.gameValue original marks_5 .dominator {11} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 12) hv)
def marks_6 : Finset (Fin 13) := {0,1,2,3,4,5,6,7,10}
theorem after_6_7 : Marked.gameValue original marks_6 .dominator {7}=1 ∧ Marked.gameValue original marks_6 .staller {7}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_6 marks_2 7 1 1 (by decide +kernel) row_2
theorem after_6_8 : Marked.gameValue original marks_6 .dominator {8}=1 ∧ Marked.gameValue original marks_6 .staller {8}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_6 marks_2 8 1 1 (by decide +kernel) row_2
theorem after_6_9 : Marked.gameValue original marks_6 .dominator {9}=1 ∧ Marked.gameValue original marks_6 .staller {9}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_6 marks_2 9 1 1 (by decide +kernel) row_2
theorem after_6_10 : Marked.gameValue original marks_6 .dominator {10}=1 ∧ Marked.gameValue original marks_6 .staller {10}=1 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_6 marks_2 10 1 1 (by decide +kernel) row_2
theorem after_6_11 : Marked.gameValue original marks_6 .dominator {11}=1 ∧ Marked.gameValue original marks_6 .staller {11}=1 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_6 marks_2 11 1 1 (by decide +kernel) row_2
theorem after_6_12 : Marked.gameValue original marks_6 .dominator {12}=1 ∧ Marked.gameValue original marks_6 .staller {12}=1 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_6 marks_2 12 1 1 (by decide +kernel) row_2
theorem row_6 : Marked.gameValue original marks_6 .dominator ∅=2 ∧ Marked.gameValue original marks_6 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_6 2 2 7 7 (by decide +kernel) (by decide +kernel)
  · rw [after_6_7.2]
  · rw [after_6_7.1]
  · intro v hv
    fin_cases v
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_6 ∅ 0) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_6 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_6 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_6 ∅ 3) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_6 ∅ 4) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_6 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_6 ∅ 6) hv)
    · have h := after_6_7
      change 2 ≤ 1+Marked.gameValue original marks_6 .staller {7} ∧ 1+Marked.gameValue original marks_6 .dominator {7} ≤ 2
      omega
    · have h := after_6_8
      change 2 ≤ 1+Marked.gameValue original marks_6 .staller {8} ∧ 1+Marked.gameValue original marks_6 .dominator {8} ≤ 2
      omega
    · have h := after_6_9
      change 2 ≤ 1+Marked.gameValue original marks_6 .staller {9} ∧ 1+Marked.gameValue original marks_6 .dominator {9} ≤ 2
      omega
    · have h := after_6_10
      change 2 ≤ 1+Marked.gameValue original marks_6 .staller {10} ∧ 1+Marked.gameValue original marks_6 .dominator {10} ≤ 2
      omega
    · have h := after_6_11
      change 2 ≤ 1+Marked.gameValue original marks_6 .staller {11} ∧ 1+Marked.gameValue original marks_6 .dominator {11} ≤ 2
      omega
    · have h := after_6_12
      change 2 ≤ 1+Marked.gameValue original marks_6 .staller {12} ∧ 1+Marked.gameValue original marks_6 .dominator {12} ≤ 2
      omega
def marks_7 : Finset (Fin 13) := {1,2,3,4,5,6,7,8,9}
theorem after_7_0 : Marked.gameValue original marks_7 .dominator {0}=1 ∧ Marked.gameValue original marks_7 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_2 0 1 1 (by decide +kernel) row_2
theorem after_7_1 : Marked.gameValue original marks_7 .dominator {1}=1 ∧ Marked.gameValue original marks_7 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_4 1 1 2 (by decide +kernel) row_4
theorem after_7_4 : Marked.gameValue original marks_7 .dominator {4}=1 ∧ Marked.gameValue original marks_7 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_4 4 1 2 (by decide +kernel) row_4
theorem after_7_7 : Marked.gameValue original marks_7 .dominator {7}=1 ∧ Marked.gameValue original marks_7 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_4 7 1 2 (by decide +kernel) row_4
theorem after_7_10 : Marked.gameValue original marks_7 .dominator {10}=0 ∧ Marked.gameValue original marks_7 .staller {10}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_0 10 0 0 (by decide +kernel) row_0
theorem after_7_11 : Marked.gameValue original marks_7 .dominator {11}=0 ∧ Marked.gameValue original marks_7 .staller {11}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_0 11 0 0 (by decide +kernel) row_0
theorem after_7_12 : Marked.gameValue original marks_7 .dominator {12}=1 ∧ Marked.gameValue original marks_7 .staller {12}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_1 12 1 1 (by decide +kernel) row_1
theorem row_7 : Marked.gameValue original marks_7 .dominator ∅=1 ∧ Marked.gameValue original marks_7 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_7 1 2 10 0 (by decide +kernel) (by decide +kernel)
  · rw [after_7_10.2]
  · rw [after_7_0.1]
  · intro v hv
    fin_cases v
    · have h := after_7_0
      change 1 ≤ 1+Marked.gameValue original marks_7 .staller {0} ∧ 1+Marked.gameValue original marks_7 .dominator {0} ≤ 2
      omega
    · have h := after_7_1
      change 1 ≤ 1+Marked.gameValue original marks_7 .staller {1} ∧ 1+Marked.gameValue original marks_7 .dominator {1} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_7 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_7 ∅ 3) hv)
    · have h := after_7_4
      change 1 ≤ 1+Marked.gameValue original marks_7 .staller {4} ∧ 1+Marked.gameValue original marks_7 .dominator {4} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_7 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_7 ∅ 6) hv)
    · have h := after_7_7
      change 1 ≤ 1+Marked.gameValue original marks_7 .staller {7} ∧ 1+Marked.gameValue original marks_7 .dominator {7} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_7 ∅ 8) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_7 ∅ 9) hv)
    · have h := after_7_10
      change 1 ≤ 1+Marked.gameValue original marks_7 .staller {10} ∧ 1+Marked.gameValue original marks_7 .dominator {10} ≤ 2
      omega
    · have h := after_7_11
      change 1 ≤ 1+Marked.gameValue original marks_7 .staller {11} ∧ 1+Marked.gameValue original marks_7 .dominator {11} ≤ 2
      omega
    · have h := after_7_12
      change 1 ≤ 1+Marked.gameValue original marks_7 .staller {12} ∧ 1+Marked.gameValue original marks_7 .dominator {12} ≤ 2
      omega
end IsolationGame.FullCanonical.T04
