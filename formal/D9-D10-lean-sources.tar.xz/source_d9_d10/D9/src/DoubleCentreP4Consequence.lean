import DoubleCentreP4Arithmetic

namespace IsolationGame.DoubleCentreP4
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

theorem isolationNumber_budget (k l p q : Nat) :
    IsolationGame.isolationNumber (graph k l p q) ≤
      3*(p+q)+(3*(k+l))/2+2 := by
  have h := D_upper k l p q
  rw [Marked.value_empty_marks] at h
  exact h

theorem isolationNumber_ceil (k l p q : Nat) (h : 1≤k+l) :
    IsolationGame.isolationNumber (graph k l p q) ≤
      (3*Fintype.card (Vertex k l p q)+6)/7 := by
  have hd := D_ceil_order k l p q h
  rw [Marked.value_empty_marks] at hd
  exact hd

theorem isolationNumber_floor (k l p q : Nat) (h : k+l=3 ∨ 5≤k+l) :
    IsolationGame.isolationNumber (graph k l p q) ≤
      (3*Fintype.card (Vertex k l p q))/7 := by
  have hd := D_floor_order k l p q h
  rw [Marked.value_empty_marks] at hd
  exact hd

theorem isolationNumber_floor_scaled (k l p q : Nat) (h : k+l=3 ∨ 5≤k+l) :
    7*IsolationGame.isolationNumber (graph k l p q) ≤
      3*Fintype.card (Vertex k l p q) := by
  have hd := isolationNumber_floor k l p q h
  omega

/-- All-zero parameters give the two-vertex edge, not two edgeless games. -/
theorem zero_D_value : Marked.gameValue (graph 0 0 0 0) ∅ .dominator ∅ = 1 := by
  have ht : Marked.Terminal (graph 0 0 0 0) ∅ {left 0 0 0 0} := by decide +kernel
  have hn : ¬Marked.Terminal (graph 0 0 0 0) ∅ ∅ := by decide +kernel
  have hz := (Marked.value_zero_iff_terminal (graph 0 0 0 0) ∅
    {left 0 0 0 0} .staller).mpr ht
  have hd := Marked.d_move_upper (graph 0 0 0 0) ∅ ∅ (left 0 0 0 0)
    (left_legal 0 0 0 0)
  simp only [Finset.insert_empty] at hd
  have hne : Marked.gameValue (graph 0 0 0 0) ∅ .dominator ∅ ≠ 0 := by
    intro h
    exact hn ((Marked.value_zero_iff_terminal (graph 0 0 0 0) ∅ ∅ .dominator).mp h)
  omega

theorem zero_isolationNumber : IsolationGame.isolationNumber (graph 0 0 0 0) = 1 := by
  have h := zero_D_value
  rw [Marked.value_empty_marks] at h
  exact h

theorem zero_floor_failure :
    ¬IsolationGame.isolationNumber (graph 0 0 0 0) ≤
      (3*Fintype.card (Vertex 0 0 0 0))/7 := by
  rw [zero_isolationNumber,order]
  decide +kernel

#print axioms isolationNumber_budget
#print axioms isolationNumber_ceil
#print axioms isolationNumber_floor
#print axioms isolationNumber_floor_scaled
#print axioms zero_D_value
#print axioms zero_isolationNumber
#print axioms zero_floor_failure
end IsolationGame.DoubleCentreP4
