import FullCanonical04Rows04
namespace IsolationGame.FullCanonical.T04
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_20 : Finset (Fin 13) := {2,3}
theorem after_20_0 : Marked.gameValue original marks_20 .dominator {0}=3 ∧ Marked.gameValue original marks_20 .staller {0}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_20 marks_10 0 3 3 (by decide +kernel) row_10
theorem after_20_1 : Marked.gameValue original marks_20 .dominator {1}=4 ∧ Marked.gameValue original marks_20 .staller {1}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_20 marks_18 1 4 4 (by decide +kernel) row_18
theorem after_20_2 : Marked.gameValue original marks_20 .dominator {2}=4 ∧ Marked.gameValue original marks_20 .staller {2}=5 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_20 marks_19 2 4 5 (by decide +kernel) row_19
theorem after_20_4 : Marked.gameValue original marks_20 .dominator {4}=3 ∧ Marked.gameValue original marks_20 .staller {4}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_20 marks_12 4 3 3 (by decide +kernel) row_12
theorem after_20_5 : Marked.gameValue original marks_20 .dominator {5}=3 ∧ Marked.gameValue original marks_20 .staller {5}=4 :=
  FullCanonicalDAG.transport_perm original perm_4 adjacency_4 marks_20 marks_16 5 3 4 (by decide +kernel) row_16
theorem after_20_6 : Marked.gameValue original marks_20 .dominator {6}=3 ∧ Marked.gameValue original marks_20 .staller {6}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_20 marks_17 6 3 4 (by decide +kernel) row_17
theorem after_20_7 : Marked.gameValue original marks_20 .dominator {7}=3 ∧ Marked.gameValue original marks_20 .staller {7}=3 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_20 marks_12 7 3 3 (by decide +kernel) row_12
theorem after_20_8 : Marked.gameValue original marks_20 .dominator {8}=3 ∧ Marked.gameValue original marks_20 .staller {8}=4 :=
  FullCanonicalDAG.transport_perm original perm_5 adjacency_5 marks_20 marks_16 8 3 4 (by decide +kernel) row_16
theorem after_20_9 : Marked.gameValue original marks_20 .dominator {9}=3 ∧ Marked.gameValue original marks_20 .staller {9}=4 :=
  FullCanonicalDAG.transport_perm original perm_2 adjacency_2 marks_20 marks_17 9 3 4 (by decide +kernel) row_17
theorem after_20_10 : Marked.gameValue original marks_20 .dominator {10}=3 ∧ Marked.gameValue original marks_20 .staller {10}=3 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_20 marks_12 10 3 3 (by decide +kernel) row_12
theorem after_20_11 : Marked.gameValue original marks_20 .dominator {11}=3 ∧ Marked.gameValue original marks_20 .staller {11}=4 :=
  FullCanonicalDAG.transport_perm original perm_6 adjacency_6 marks_20 marks_16 11 3 4 (by decide +kernel) row_16
theorem after_20_12 : Marked.gameValue original marks_20 .dominator {12}=3 ∧ Marked.gameValue original marks_20 .staller {12}=4 :=
  FullCanonicalDAG.transport_perm original perm_3 adjacency_3 marks_20 marks_17 12 3 4 (by decide +kernel) row_17
theorem row_20 : Marked.gameValue original marks_20 .dominator ∅=4 ∧ Marked.gameValue original marks_20 .staller ∅=5 := by
  apply LocalProfile.DAG.bellman original marks_20 4 5 0 1 (by decide +kernel) (by decide +kernel)
  · rw [after_20_0.2]
  · rw [after_20_1.1]
  · intro v hv
    fin_cases v
    · have h := after_20_0
      change 4 ≤ 1+Marked.gameValue original marks_20 .staller {0} ∧ 1+Marked.gameValue original marks_20 .dominator {0} ≤ 5
      omega
    · have h := after_20_1
      change 4 ≤ 1+Marked.gameValue original marks_20 .staller {1} ∧ 1+Marked.gameValue original marks_20 .dominator {1} ≤ 5
      omega
    · have h := after_20_2
      change 4 ≤ 1+Marked.gameValue original marks_20 .staller {2} ∧ 1+Marked.gameValue original marks_20 .dominator {2} ≤ 5
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_20 ∅ 3) hv)
    · have h := after_20_4
      change 4 ≤ 1+Marked.gameValue original marks_20 .staller {4} ∧ 1+Marked.gameValue original marks_20 .dominator {4} ≤ 5
      omega
    · have h := after_20_5
      change 4 ≤ 1+Marked.gameValue original marks_20 .staller {5} ∧ 1+Marked.gameValue original marks_20 .dominator {5} ≤ 5
      omega
    · have h := after_20_6
      change 4 ≤ 1+Marked.gameValue original marks_20 .staller {6} ∧ 1+Marked.gameValue original marks_20 .dominator {6} ≤ 5
      omega
    · have h := after_20_7
      change 4 ≤ 1+Marked.gameValue original marks_20 .staller {7} ∧ 1+Marked.gameValue original marks_20 .dominator {7} ≤ 5
      omega
    · have h := after_20_8
      change 4 ≤ 1+Marked.gameValue original marks_20 .staller {8} ∧ 1+Marked.gameValue original marks_20 .dominator {8} ≤ 5
      omega
    · have h := after_20_9
      change 4 ≤ 1+Marked.gameValue original marks_20 .staller {9} ∧ 1+Marked.gameValue original marks_20 .dominator {9} ≤ 5
      omega
    · have h := after_20_10
      change 4 ≤ 1+Marked.gameValue original marks_20 .staller {10} ∧ 1+Marked.gameValue original marks_20 .dominator {10} ≤ 5
      omega
    · have h := after_20_11
      change 4 ≤ 1+Marked.gameValue original marks_20 .staller {11} ∧ 1+Marked.gameValue original marks_20 .dominator {11} ≤ 5
      omega
    · have h := after_20_12
      change 4 ≤ 1+Marked.gameValue original marks_20 .staller {12} ∧ 1+Marked.gameValue original marks_20 .dominator {12} ≤ 5
      omega
def marks_21 : Finset (Fin 13) := {}
theorem after_21_0 : Marked.gameValue original marks_21 .dominator {0}=4 ∧ Marked.gameValue original marks_21 .staller {0}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_21 marks_15 0 4 4 (by decide +kernel) row_15
theorem after_21_1 : Marked.gameValue original marks_21 .dominator {1}=4 ∧ Marked.gameValue original marks_21 .staller {1}=4 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_21 marks_18 1 4 4 (by decide +kernel) row_18
theorem after_21_2 : Marked.gameValue original marks_21 .dominator {2}=4 ∧ Marked.gameValue original marks_21 .staller {2}=5 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_21 marks_19 2 4 5 (by decide +kernel) row_19
theorem after_21_3 : Marked.gameValue original marks_21 .dominator {3}=4 ∧ Marked.gameValue original marks_21 .staller {3}=5 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_21 marks_20 3 4 5 (by decide +kernel) row_20
theorem after_21_4 : Marked.gameValue original marks_21 .dominator {4}=4 ∧ Marked.gameValue original marks_21 .staller {4}=4 :=
  FullCanonicalDAG.transport_perm original perm_4 adjacency_4 marks_21 marks_18 4 4 4 (by decide +kernel) row_18
theorem after_21_5 : Marked.gameValue original marks_21 .dominator {5}=4 ∧ Marked.gameValue original marks_21 .staller {5}=5 :=
  FullCanonicalDAG.transport_perm original perm_4 adjacency_4 marks_21 marks_19 5 4 5 (by decide +kernel) row_19
theorem after_21_6 : Marked.gameValue original marks_21 .dominator {6}=4 ∧ Marked.gameValue original marks_21 .staller {6}=5 :=
  FullCanonicalDAG.transport_perm original perm_4 adjacency_4 marks_21 marks_20 6 4 5 (by decide +kernel) row_20
theorem after_21_7 : Marked.gameValue original marks_21 .dominator {7}=4 ∧ Marked.gameValue original marks_21 .staller {7}=4 :=
  FullCanonicalDAG.transport_perm original perm_5 adjacency_5 marks_21 marks_18 7 4 4 (by decide +kernel) row_18
theorem after_21_8 : Marked.gameValue original marks_21 .dominator {8}=4 ∧ Marked.gameValue original marks_21 .staller {8}=5 :=
  FullCanonicalDAG.transport_perm original perm_5 adjacency_5 marks_21 marks_19 8 4 5 (by decide +kernel) row_19
theorem after_21_9 : Marked.gameValue original marks_21 .dominator {9}=4 ∧ Marked.gameValue original marks_21 .staller {9}=5 :=
  FullCanonicalDAG.transport_perm original perm_5 adjacency_5 marks_21 marks_20 9 4 5 (by decide +kernel) row_20
theorem after_21_10 : Marked.gameValue original marks_21 .dominator {10}=4 ∧ Marked.gameValue original marks_21 .staller {10}=4 :=
  FullCanonicalDAG.transport_perm original perm_6 adjacency_6 marks_21 marks_18 10 4 4 (by decide +kernel) row_18
theorem after_21_11 : Marked.gameValue original marks_21 .dominator {11}=4 ∧ Marked.gameValue original marks_21 .staller {11}=5 :=
  FullCanonicalDAG.transport_perm original perm_6 adjacency_6 marks_21 marks_19 11 4 5 (by decide +kernel) row_19
theorem after_21_12 : Marked.gameValue original marks_21 .dominator {12}=4 ∧ Marked.gameValue original marks_21 .staller {12}=5 :=
  FullCanonicalDAG.transport_perm original perm_6 adjacency_6 marks_21 marks_20 12 4 5 (by decide +kernel) row_20
theorem row_21 : Marked.gameValue original marks_21 .dominator ∅=5 ∧ Marked.gameValue original marks_21 .staller ∅=5 := by
  apply LocalProfile.DAG.bellman original marks_21 5 5 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_21_0.2]
  · rw [after_21_0.1]
  · intro v hv
    fin_cases v
    · have h := after_21_0
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {0} ∧ 1+Marked.gameValue original marks_21 .dominator {0} ≤ 5
      omega
    · have h := after_21_1
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {1} ∧ 1+Marked.gameValue original marks_21 .dominator {1} ≤ 5
      omega
    · have h := after_21_2
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {2} ∧ 1+Marked.gameValue original marks_21 .dominator {2} ≤ 5
      omega
    · have h := after_21_3
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {3} ∧ 1+Marked.gameValue original marks_21 .dominator {3} ≤ 5
      omega
    · have h := after_21_4
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {4} ∧ 1+Marked.gameValue original marks_21 .dominator {4} ≤ 5
      omega
    · have h := after_21_5
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {5} ∧ 1+Marked.gameValue original marks_21 .dominator {5} ≤ 5
      omega
    · have h := after_21_6
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {6} ∧ 1+Marked.gameValue original marks_21 .dominator {6} ≤ 5
      omega
    · have h := after_21_7
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {7} ∧ 1+Marked.gameValue original marks_21 .dominator {7} ≤ 5
      omega
    · have h := after_21_8
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {8} ∧ 1+Marked.gameValue original marks_21 .dominator {8} ≤ 5
      omega
    · have h := after_21_9
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {9} ∧ 1+Marked.gameValue original marks_21 .dominator {9} ≤ 5
      omega
    · have h := after_21_10
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {10} ∧ 1+Marked.gameValue original marks_21 .dominator {10} ≤ 5
      omega
    · have h := after_21_11
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {11} ∧ 1+Marked.gameValue original marks_21 .dominator {11} ≤ 5
      omega
    · have h := after_21_12
      change 5 ≤ 1+Marked.gameValue original marks_21 .staller {12} ∧ 1+Marked.gameValue original marks_21 .dominator {12} ≤ 5
      omega
end IsolationGame.FullCanonical.T04
