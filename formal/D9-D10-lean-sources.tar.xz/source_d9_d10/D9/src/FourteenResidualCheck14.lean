import FourteenResidualData

/-! Finite kernel arithmetic only: first profile fixed to t14.
All arithmetic is checked by kernel reduction; no graph or history search. -/
namespace IsolationGame.FourteenResidual
open CanonicalLocal
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

theorem check11_t14 (b : Index) :
    NumericResidual [.t14] [b] → MatchesFourteen [.t14] [b] := by
  cases b <;> decide +kernel

theorem check12_t14 (b c : Index) :
    NumericResidual [.t14] [b, c] → MatchesFourteen [.t14] [b, c] := by
  cases b <;> cases c <;> decide +kernel

#print axioms check11_t14
#print axioms check12_t14
end IsolationGame.FourteenResidual
