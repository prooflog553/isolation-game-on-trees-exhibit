import G2CopyInsertion
import G2ForestBase

namespace IsolationGame.G2Family

theorem acyclic_transport {V W : Type} [DecidableEq V] [DecidableEq W]
    (G : SimpleGraph V) (H : SimpleGraph W) (e : V ≃ W)
    (he : ∀ u v, H.Adj (e u) (e v) ↔ G.Adj u v) (hG : G.IsAcyclic) : H.IsAcyclic := by
  let f : H →g G := ⟨e.symm,by
    intro u v h
    exact (he (e.symm u) (e.symm v)).mp (by simpa using h)⟩
  intro v c hc
  exact hG (c.map f) (hc.map e.symm.injective)

theorem cGraph_acyclic (p q k : Nat) (hk : k ≤ 2) : (cGraph p q k).IsAcyclic := by
  have hzero : ∀ q, (cGraph 0 q k).IsAcyclic := by
    intro q
    induction q with
    | zero => exact cGraph_base_acyclic k hk
    | succ q ih =>
      exact acyclic_transport _ _ (insertYEquiv 0 q k 0) (insertY_adj 0 q k 0)
        (P7Graft.graph_acyclic (cGraph 0 q k) (cy 0 q k) ih)
  induction p with
  | zero => exact hzero q
  | succ p ih =>
    exact acyclic_transport _ _ (insertXEquiv p q k 0) (insertX_adj p q k 0)
      (P7Graft.graph_acyclic (cGraph p q k) (cx p q k) ih)

theorem graph_acyclic (p q k : Nat) (hk : k ≤ 2) : (graph p q k).IsAcyclic :=
  acyclic_transport _ _ (cEquiv p q k) (cEquiv_adj p q k) (cGraph_acyclic p q k hk)

def yEmbed (q k : Nat) : YVertex q k → Vertex 0 q k
  | .inl v => .inl (.inl v)
  | .inr v => .inr v

theorem yEmbed_injective (q k : Nat) : Function.Injective (yEmbed q k) := by
  intro u v h
  cases u <;> cases v <;> simpa [yEmbed] using h

theorem yEmbed_adj (q k : Nat) (u v : YVertex q k) :
    (graph 0 q k).Adj (yEmbed q k u) (yEmbed q k v) ↔ (yGraph q k).Adj u v := by
  cases u <;> cases v <;> simp [graph,yGraph,yEmbed,BWBridge.original,Attachment.original]

theorem yGraph_acyclic (q k : Nat) (hk : k ≤ 2) : (yGraph q k).IsAcyclic := by
  let f : yGraph q k →g graph 0 q k := ⟨yEmbed q k,by
    intro u v h
    exact (yEmbed_adj q k u v).mpr h⟩
  intro v c hc
  exact graph_acyclic 0 q k hk (c.map f) (hc.map (yEmbed_injective q k))

end IsolationGame.G2Family
