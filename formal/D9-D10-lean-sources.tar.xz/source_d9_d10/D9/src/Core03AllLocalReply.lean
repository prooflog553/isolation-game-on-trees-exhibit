import Core03EndReplyFacts
import ReplyCapacityRelabel

namespace IsolationGame.CompositeWhiteCore03Facts
open FullCanonical.T03
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

noncomputable def played (a : Fin 10) : Finset (Fin 10) :=
  SelectedVertex.playedMarks original ∅ a

private def finitePlayed (a : Fin 10) : Finset (Fin 10) :=
  Finset.univ.filter (fun v => Closed original a v)
private theorem played_finite (a : Fin 10) : played a = finitePlayed a := by
  ext v
  simp [played,finitePlayed,SelectedVertex.mem_playedMarks]

private theorem absorb_S (a : Fin 10) :
    Marked.gameValue original (played a) .staller ∅ =
      Marked.gameValue original ∅ .staller {a} := by
  symm
  apply Marked.value_eq_of_white_eq
  intro w
  change Marked.White _ _ (insert a ∅) w ↔ _
  rw [SelectedVertex.absorb_white] <;> rfl

/-- All four root-dominating original moves have S follower3. -/
theorem root_dominated_follower (a : Fin 10) (ha : (0 : Fin 10) ∈ played a) :
    Marked.gameValue original (played a) .staller ∅ ≤ 3 := by
  rw [absorb_S]
  fin_cases a
  · exact after_14_0.2.le
  · exact after_14_1.2.le
  · exact False.elim ((by simp only [played_finite]; decide +kernel : (0 : Fin 10) ∉ played 2) ha)
  · exact False.elim ((by simp only [played_finite]; decide +kernel : (0 : Fin 10) ∉ played 3) ha)
  · exact after_14_4.2.le
  · exact False.elim ((by simp only [played_finite]; decide +kernel : (0 : Fin 10) ∉ played 5) ha)
  · exact False.elim ((by simp only [played_finite]; decide +kernel : (0 : Fin 10) ∉ played 6) ha)
  · exact after_14_7.2.le
  · exact False.elim ((by simp only [played_finite]; decide +kernel : (0 : Fin 10) ∉ played 8) ha)
  · exact False.elim ((by simp only [played_finite]; decide +kernel : (0 : Fin 10) ∉ played 9) ha)

private noncomputable def swap13 : Fin 10 ≃ Fin 10 := perm_2.trans perm_1
private theorem swap13_adj : ∀u v,
    original.Adj (swap13 u) (swap13 v) ↔ original.Adj u v := by
  intro u v
  exact (adjacency_1 (perm_2 u) (perm_2 v)).trans (adjacency_2 u v)

/-- Middle actual moves are strict4; end actual moves are reply4, including
all arm permutations on the FULL original ten-vertex carrier. -/
theorem root_live_reply (a : Fin 10) (ha : (0 : Fin 10) ∉ played a) :
    MarkedSum.ReplyStrictCapacity original (played a) ∅ 4 := by
  have hm2 : played 2=marks_12 := by
    ext v
    simp only [played_finite]
    fin_cases v <;> decide +kernel
  have hm3 : played 3=marks_13 := by
    ext v
    simp only [played_finite]
    fin_cases v <;> decide +kernel
  have middle := MarkedSum.strict_to_reply original marks_12 ∅ 4 middle_strict
  fin_cases a
  · exact False.elim (ha (by simp only [played_finite]; decide +kernel))
  · exact False.elim (ha (by simp only [played_finite]; decide +kernel))
  · change MarkedSum.ReplyStrictCapacity original (played 2) ∅ 4
    rw [hm2]; exact middle
  · change MarkedSum.ReplyStrictCapacity original (played 3) ∅ 4
    rw [hm3]; exact end_reply_four
  · exact False.elim (ha (by simp only [played_finite]; decide +kernel))
  · have h := MarkedSum.reply_relabel original original perm_2 adjacency_2 marks_12 ∅ 4 middle
    have he : marks_12.image perm_2=played 5 := by
      ext v
      simp only [played_finite]
      fin_cases v <;> decide +kernel
    simpa only [he,Finset.image_empty] using h
  · have h := MarkedSum.reply_relabel original original perm_2 adjacency_2 marks_13 ∅ 4 end_reply_four
    have he : marks_13.image perm_2=played 6 := by
      ext v
      simp only [played_finite]
      fin_cases v <;> decide +kernel
    simpa only [he,Finset.image_empty] using h
  · exact False.elim (ha (by simp only [played_finite]; decide +kernel))
  · have h := MarkedSum.reply_relabel original original swap13 swap13_adj marks_12 ∅ 4 middle
    have he : marks_12.image swap13=played 8 := by
      ext v
      simp only [played_finite]
      fin_cases v <;> decide +kernel
    simpa only [he,Finset.image_empty] using h
  · have h := MarkedSum.reply_relabel original original swap13 swap13_adj marks_13 ∅ 4 end_reply_four
    have he : marks_13.image swap13=played 9 := by
      ext v
      simp only [played_finite]
      fin_cases v <;> decide +kernel
    simpa only [he,Finset.image_empty] using h

/-- A single finite geometry statement supplies a real private original
arm-start for every root-live case. The accepted augmentation theorem then
quantifies over all smaller future white sets. -/
theorem root_live_private (a : Fin 10) (ha : (0 : Fin 10) ∉ played a) :
    ∃g : Fin 10, original.Adj g 0 ∧
      ∀w,Marked.White original (played a) ∅ w → original.Adj g w → w=0 := by
  have h : ∀a : Fin 10, (0 : Fin 10) ∉ played a →
      ∃g : Fin 10, original.Adj g 0 ∧
        ∀w,Marked.White original (played a) ∅ w → original.Adj g w → w=0 := by
    simp only [played_finite]
    decide +kernel
  exact h a ha
end IsolationGame.CompositeWhiteCore03Facts
