import CoreExtractionContract

namespace IsolationGame.CoreFamily
open CanonicalLocal ActualRootBranches SmallPiece NecessaryCore

/-- The first entries are the ordered exceptional multiset. All remaining
entries are ordinary P7 branches. Neither list length nor p is bounded here. -/
def label (xs : List Nat) (p : Nat) (j : Fin (xs.length+p)) : Index :=
  if h : j.val<xs.length then decode (xs.get ⟨j.val,h⟩) else .t02

abbrev Vertex (xs : List Nat) (p : Nat) :=
  Option (Σj : Fin (xs.length+p), Fin (size (label xs p j)))

/-- A literal original graph: add one root and attach every original local
canonical graph at its designated root. fromRel only symmetrizes the displayed
original edges; no game-value or white-state quotient is used. -/
def graph (xs : List Nat) (p : Nat) : SimpleGraph (Vertex xs p) :=
  SimpleGraph.fromRel (fun u v=>
    (∃j,u=none ∧ v=some ⟨j,root (label xs p j)⟩) ∨
    (∃j a b,(CanonicalLocal.graph (label xs p j)).Adj a b ∧
      u=some ⟨j,a⟩ ∧ v=some ⟨j,b⟩))

variable {V : Type} [Fintype V] [DecidableEq V]

def AssemblySpec (G : SimpleGraph V) (r : V)
    (xs : List Nat) (p : Nat) : Prop :=
  RootedAssembly.RootedIso G r (graph xs p) none

/- Requested theorem signature (not assumed):
assemble_core_family (G : SimpleGraph V) (hT : G.IsTree) (r : V)
  (f : Child G r→Index)
  (hf : ∀a,RootedAssembly.RootedIso (outerGraph G r a) (outerRoot G r a)
    (CanonicalLocal.graph (f a)) (root (f a)))
  (xs : List Nat) (p : Nat)
  (hperm : xs.Perm (sourceCodes f Finset.univ))
  (hp : p=(Finset.univ.filter (fun a=>f a=.t02)).card) :
  AssemblySpec G r xs p.
No sorting, capacity, game, empty-type exclusion, or multiplicity bound is
needed for this structural assembly statement. -/

end IsolationGame.CoreFamily
