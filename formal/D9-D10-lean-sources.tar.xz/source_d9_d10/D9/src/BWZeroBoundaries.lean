import BWPositiveUpper

namespace IsolationGame.BWBridge
open Isolation.Graph
open MarkedModule

/-- The zero side still has its real original root. -/
theorem side_zero_eq (v : Side 0) : v=root 0 := by
  cases v with
  | gate o => cases o with
    | none => rfl
    | some i => exact Fin.elim0 i
  | b j => exact Fin.elim0 j.1
  | c j => exact Fin.elim0 j.1
  | d j => exact Fin.elim0 j.1

/-- At the right-zero boundary the original unmarked right root is inert.
The equality records normalization, and does not mark or select that vertex. -/
theorem right_zero_initial_white (p : Nat) :
    Marked.White (original p 0) (marks p 0) ∅ =
      whiteSum p 0 (white (whole p)) (white (whole 0)) := by
  have hraw : (view p 0).raw (fun v=>v∈marks p 0)
      (fun v=>v∈(∅ : Finset (Vertex p 0))) =
      whiteSum p 0 (white (whole p)) (fun _=>True) := by
    funext v; apply propext
    cases v with
    | inl v => cases v with
      | gate o => cases o <;> simp [Isolation.Graph.raw,marks,root,whiteSum,
          Isolation.Graph.whiteSum,white,whole,Status.middle]
      | b j => simp [Isolation.Graph.raw,marks,root,whiteSum,
          Isolation.Graph.whiteSum,white,whole,Status.live,Status.closed]
      | c j => simp [Isolation.Graph.raw,marks,root,whiteSum,
          Isolation.Graph.whiteSum,white,whole,Status.live]
      | d j => simp [Isolation.Graph.raw,marks,root,whiteSum,
          Isolation.Graph.whiteSum,white,whole,Status.live]
    | inr v => simp [Isolation.Graph.raw,marks,whiteSum,Isolation.Graph.whiteSum]
  have hzero : MarkedModule.graph.noniso (fun _ : Side 0=>True)=white (whole 0) := by
    funext v; rw [side_zero_eq v]
    apply propext
    constructor
    · rintro ⟨_,w,_,ha⟩
      rw [side_zero_eq w] at ha
      exact False.elim (MarkedModule.graph.loopless _ ha)
    · simp [root,white]
  funext v; apply propext
  rw [←GuardedEdge.white_agree]
  change (view p 0).noniso ((view p 0).raw _ _) v ↔ _
  rw [hraw,normalize_split p 0 _ _ (by simp [root,white]),module_normalized,hzero]

/-- Exact pure-module reduction, retaining the original inert unmarked root. -/
theorem right_zero_value (p : Nat) (t : Player) :
    Marked.gameValue (original p 0) (marks p 0) t ∅ =
      Marked.gameValue (MarkedModule.original (B:=Fin p)) MarkedModule.initialMarks t ∅ := by
  have hsplit := split_value p 0 (marks p 0) ∅ MarkedModule.initialMarks
    MarkedModule.initialMarks (white (whole p)) (white (whole 0))
    (right_zero_initial_white p) (pure_white p) (pure_white 0)
    (by simp [root,white]) (by simp [root,white]) t
  rw [hsplit]
  have h := MarkedSum.balanced_right
    (MarkedModule.original (B:=Fin p)) (MarkedModule.original (B:=Fin 0))
    (Marked.forest_no_minus _ (module_acyclic p))
    (Marked.forest_no_minus _ (module_acyclic 0))
    MarkedModule.initialMarks ∅ MarkedModule.initialMarks ∅ 0
    (MarkedModule.empty_value .dominator) (MarkedModule.empty_value .staller)
  cases t
  · simpa [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight] using h.1
  · simpa [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight] using h.2

/-- The empty left component contributes no turn or fabricated move. -/
theorem zero_left_sum_value (q : Nat) (N : Finset (Side q)) (t : Player) :
    Marked.gameValue (MarkedSum.original (MarkedModule.original (B:=Fin 0))
      (MarkedModule.original (B:=Fin q)))
      (MarkedSum.combine MarkedModule.initialMarks N) t ∅ =
      Marked.gameValue MarkedModule.original N t ∅ := by
  have h := MarkedSum.terminal_left_value
    (MarkedModule.original (B:=Fin 0)) (MarkedModule.original (B:=Fin q))
    MarkedModule.initialMarks ∅ N ∅ MarkedModule.empty_terminal t
  simpa [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight] using h

/-- S selecting the actual white right root leaves exactly n balanced units. -/
theorem left_zero_right_center_value (q : Nat) (hq : 1≤q) (t : Player) :
    Marked.gameValue (original 0 q) (marks 0 q) t {.inr (root q)}=3*q := by
  rw [right_center_value 0 q hq,zero_left_sum_value,gated_whole_value]

/-- For a middle first action, the marked original left leaf remains in the
exact split follower; it is terminal only after this genuine action. -/
theorem left_zero_middle_D_bound (q : Nat) (hq : 1≤q) (i : Fin q) :
    Marked.gameValue (original 0 q) (marks 0 q) .dominator
      {.inr (.gate (some i))}≤3*q := by
  rw [right_middle_value 0 q hq i,zero_left_sum_value]
  exact (Marked.forest_no_minus _ (module_acyclic q) _ _).trans (opened_middle_S_bound q i)

/-- The existing exact arm/root normalization applies without a positive
left module; no move is charged when the proposed reply is inert. -/
theorem left_zero_arm_D_bound (q : Nat) (hq : 1≤q)
    (i : Fin q) (a : Arm) (s : Bool) :
    Marked.gameValue (original 0 q) (marks 0 q) .dominator
      {.inr (arm a i s)}≤3*q := by
  have hs := right_arm_root_S_bound 0 q hq i a s
  have hds : Marked.gameValue (original 0 q) (marks 0 q) .dominator
      {(.inr (root q)),(.inr (arm a i s))} ≤
      Marked.gameValue (original 0 q) (marks 0 q) .staller
      {(.inr (root q)),(.inr (arm a i s))} := by
    rw [right_arm_root_value 0 q hq,right_arm_root_value 0 q hq]
    exact split_D_le_S 0 q _ _
  have h := response_or_inert_bound (original 0 q) (marks 0 q)
    {(.inr (arm a i s))} (.inr (root q)) (3*(0+q)-1) hs hds
  omega

/-- Covers every original action, including selection of the genuine marked
left leaf, which marks the white right root and leaves M_q. -/
theorem left_zero_first_D_bound (q : Nat) (hq : 1≤q) (v : Vertex 0 q) :
    Marked.gameValue (original 0 q) (marks 0 q) .dominator {v}≤3*q := by
  cases v with
  | inl v =>
    rw [side_zero_eq v]
    simpa using left_center_D_bound 0 q hq
  | inr v => cases v with
    | gate o => cases o with
      | none => exact (left_zero_right_center_value q hq .dominator).le
      | some i => exact left_zero_middle_D_bound q hq i
    | b j => exact left_zero_arm_D_bound q hq j.1 .b j.2
    | c j => exact left_zero_arm_D_bound q hq j.1 .c j.2
    | d j => exact left_zero_arm_D_bound q hq j.1 .d j.2

theorem left_zero_S_upper_bound (q : Nat) (hq : 1≤q) :
    Marked.gameValue (original 0 q) (marks 0 q) .staller ∅ ≤ 3*q+1 := by
  apply (Marked.gameValue_le_iff _ _ _ _ _).mpr
  apply Or.inr
  intro v _
  apply (Marked.gameValue_le_iff _ _ .dominator (insert v ∅) (3*q)).mp
  simpa only [Finset.insert_empty] using left_zero_first_D_bound q hq v

/-- BW upper bound on the unchanged original marked graph for all parameters. -/
theorem S_upper_bound (p q : Nat) :
    Marked.gameValue (original p q) (marks p q) .staller ∅ ≤ 3*(p+q)+1 := by
  by_cases hq : q=0
  · subst q
    rw [right_zero_value,MarkedModule.pure_S_value_all]
    simp only [Fintype.card_fin,Nat.add_zero]
    split_ifs <;> omega
  · by_cases hp : p=0
    · subst p
      simpa using left_zero_S_upper_bound q (by omega)
    · exact positive_S_upper_bound p q (by omega) (by omega)

#print axioms right_zero_value
#print axioms left_zero_S_upper_bound
#print axioms S_upper_bound
end IsolationGame.BWBridge
