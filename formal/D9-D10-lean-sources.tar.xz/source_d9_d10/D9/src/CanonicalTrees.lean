import CanonicalData

namespace IsolationGame.CanonicalLocal

set_option maxRecDepth 65536
set_option maxHeartbeats 0

/-- Complete finite adjacency certificates of radius at most three. -/
theorem reach_three (t : Index) : ReachThree (graph t) (root t) := by
  unfold ReachThree
  cases t <;> decide +kernel

/-- Exact original edge counts; no game values enter this tree check. -/
theorem edge_count (t : Index) : (graph t).edgeFinset.card+1=size t := by
  cases t <;> decide +kernel

theorem canonical_tree (t : Index) : (graph t).IsTree :=
  tree_of_certificate (graph t) (root t) (reach_three t) (by simpa only [Fintype.card_fin] using edge_count t)

#print axioms reach_three
#print axioms edge_count
#print axioms canonical_tree
end IsolationGame.CanonicalLocal
