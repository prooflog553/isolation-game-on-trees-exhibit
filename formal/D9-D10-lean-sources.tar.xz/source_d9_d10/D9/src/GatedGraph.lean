import Normalization

namespace GatedGraph
open Isolation
open Isolation.Graph

inductive Vertex (I J : Type) where
  | gate : I → Vertex I J
  | b : J → Vertex I J
  | c : J → Vertex I J
  | d : J → Vertex I J
  deriving DecidableEq

variable {I J : Type}

@[simp] theorem exists_vertex (P : Vertex I J → Prop) :
    (∃ v, P v) ↔ (∃ i, P (.gate i)) ∨ (∃ j, P (.b j)) ∨
      (∃ j, P (.c j)) ∨ (∃ j, P (.d j)) := by
  constructor
  · rintro ⟨v,h⟩; cases v with
    | gate i => exact Or.inl ⟨i,h⟩
    | b j => exact Or.inr (Or.inl ⟨j,h⟩)
    | c j => exact Or.inr (Or.inr (Or.inl ⟨j,h⟩))
    | d j => exact Or.inr (Or.inr (Or.inr ⟨j,h⟩))
  · rintro (⟨i,h⟩ | ⟨j,h⟩ | ⟨j,h⟩ | ⟨j,h⟩)
    · exact ⟨.gate i,h⟩
    · exact ⟨.b j,h⟩
    · exact ⟨.c j,h⟩
    · exact ⟨.d j,h⟩

def adj (owner : J → I) : Vertex I J → Vertex I J → Prop
  | .gate i, .b j => owner j = i
  | .b j, .gate i => owner j = i
  | .b j, .c k => j = k
  | .c j, .b k => j = k
  | .c j, .d k => j = k
  | .d j, .c k => j = k
  | _, _ => False

def graph (owner : J → I) : Graph (Vertex I J) where
  adj := adj owner
  symm := by intro v w; cases v <;> cases w <;> simp [adj, eq_comm]
  loopless := by intro v; cases v <;> simp [adj]

def white (owner : J → I) (live : J → Prop) (closed : I → Prop) :
    Vertex I J → Prop
  | .gate _ => False
  | .b j => live j ∧ closed (owner j)
  | .c j => live j
  | .d j => live j

variable (owner : J → I) (L : J → Prop) (C : I → Prop)

@[simp] theorem legal_gate (i : I) :
    (graph owner).legal (white owner L C) (.gate i) ↔
      C i ∧ ∃ j, L j ∧ owner j=i := by
  simp only [Isolation.Graph.legal, exists_vertex]
  simp [white, Isolation.Graph.closed, graph, adj]
  constructor
  · rintro ⟨j,⟨hj,hc⟩,he⟩; subst i; exact ⟨hc,j,hj,rfl⟩
  · rintro ⟨hc,j,hj,he⟩; subst i; exact ⟨j,⟨hj,hc⟩,rfl⟩

@[simp] theorem legal_b (j : J) :
    (graph owner).legal (white owner L C) (.b j) ↔ L j := by
  simp [Isolation.Graph.legal, exists_vertex, white, Isolation.Graph.closed, graph, adj] <;> grind

@[simp] theorem legal_c (j : J) :
    (graph owner).legal (white owner L C) (.c j) ↔ L j := by
  simp [Isolation.Graph.legal, exists_vertex, white, Isolation.Graph.closed, graph, adj] <;> grind

@[simp] theorem legal_d (j : J) :
    (graph owner).legal (white owner L C) (.d j) ↔ L j := by
  simp [Isolation.Graph.legal, exists_vertex, white, Isolation.Graph.closed, graph, adj] <;> grind

@[simp] theorem white_normalized (v : Vertex I J) :
    (graph owner).noniso (white owner L C) v ↔ white owner L C v := by
  cases v <;> simp [Isolation.Graph.noniso, exists_vertex, white, graph, adj] <;> grind

 theorem gate_step (i : I) :
    (graph owner).noniso ((graph owner).remove (white owner L C) (.gate i)) =
      white owner L (fun k => C k ∧ k ≠ i) := by
  funext v; apply propext
  cases v <;> simp [Isolation.Graph.noniso, Isolation.Graph.remove, Isolation.Graph.closed,
    exists_vertex, white, graph, adj] <;> grind

 theorem b_step (j : J) :
    (graph owner).noniso ((graph owner).remove (white owner L C) (.b j)) =
      white owner (fun k => L k ∧ k ≠ j) C := by
  funext v; apply propext
  cases v <;> simp [Isolation.Graph.noniso, Isolation.Graph.remove, Isolation.Graph.closed,
    exists_vertex, white, graph, adj, eq_comm] <;> grind

 theorem c_step (j : J) :
    (graph owner).noniso ((graph owner).remove (white owner L C) (.c j)) =
      white owner (fun k => L k ∧ k ≠ j) C := by
  funext v; apply propext
  cases v <;> simp [Isolation.Graph.noniso, Isolation.Graph.remove, Isolation.Graph.closed,
    exists_vertex, white, graph, adj, eq_comm] <;> grind

 theorem d_step (j : J) :
    (graph owner).noniso ((graph owner).remove (white owner L C) (.d j)) =
      white owner (fun k => L k ∧ k ≠ j) C := by
  funext v; apply propext
  cases v <;> simp [Isolation.Graph.noniso, Isolation.Graph.remove, Isolation.Graph.closed,
    exists_vertex, white, graph, adj, eq_comm] <;> grind

#print axioms gate_step
#print axioms d_step
end GatedGraph
