import FullCanonical11Rows02
namespace IsolationGame.FullCanonical.T11
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
theorem full_values : Marked.gameValue original ∅ .dominator ∅=2 ∧ Marked.gameValue original ∅ .staller ∅=2 := by
  constructor
  · exact (Marked.value_eq_of_white_eq original ∅ marks_8 ∅ ∅ .dominator (by decide +kernel)).trans row_8.1
  · exact (Marked.value_eq_of_white_eq original ∅ marks_8 ∅ ∅ .staller (by decide +kernel)).trans row_8.2
theorem not_strict_full : ¬MarkedSum.StrictCapacity original ∅ ∅ 2 := by
  intro h
  have hd := h.1
  rw [full_values.1] at hd
  omega
#print axioms full_values
#print axioms not_strict_full
end IsolationGame.FullCanonical.T11
