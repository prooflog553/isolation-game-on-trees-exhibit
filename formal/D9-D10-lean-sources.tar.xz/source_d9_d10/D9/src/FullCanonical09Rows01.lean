import FullCanonical09Rows00
namespace IsolationGame.FullCanonical.T09
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_4 : Finset (Fin 9) := {0,1,4,5,8}
theorem after_4_1 : Marked.gameValue original marks_4 .dominator {1}=1 ∧ Marked.gameValue original marks_4 .staller {1}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_4 marks_1 1 1 1 (by decide +kernel) row_1
theorem after_4_2 : Marked.gameValue original marks_4 .dominator {2}=1 ∧ Marked.gameValue original marks_4 .staller {2}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_4 marks_1 2 1 1 (by decide +kernel) row_1
theorem after_4_3 : Marked.gameValue original marks_4 .dominator {3}=1 ∧ Marked.gameValue original marks_4 .staller {3}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_4 marks_1 3 1 1 (by decide +kernel) row_1
theorem after_4_5 : Marked.gameValue original marks_4 .dominator {5}=1 ∧ Marked.gameValue original marks_4 .staller {5}=1 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_4 marks_1 5 1 1 (by decide +kernel) row_1
theorem after_4_6 : Marked.gameValue original marks_4 .dominator {6}=1 ∧ Marked.gameValue original marks_4 .staller {6}=1 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_4 marks_1 6 1 1 (by decide +kernel) row_1
theorem after_4_7 : Marked.gameValue original marks_4 .dominator {7}=1 ∧ Marked.gameValue original marks_4 .staller {7}=1 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_4 marks_1 7 1 1 (by decide +kernel) row_1
theorem row_4 : Marked.gameValue original marks_4 .dominator ∅=2 ∧ Marked.gameValue original marks_4 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_4 2 2 1 1 (by decide +kernel) (by decide +kernel)
  · rw [after_4_1.2]
  · rw [after_4_1.1]
  · intro v hv
    fin_cases v
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 0) hv)
    · have h := after_4_1
      change 2 ≤ 1+Marked.gameValue original marks_4 .staller {1} ∧ 1+Marked.gameValue original marks_4 .dominator {1} ≤ 2
      omega
    · have h := after_4_2
      change 2 ≤ 1+Marked.gameValue original marks_4 .staller {2} ∧ 1+Marked.gameValue original marks_4 .dominator {2} ≤ 2
      omega
    · have h := after_4_3
      change 2 ≤ 1+Marked.gameValue original marks_4 .staller {3} ∧ 1+Marked.gameValue original marks_4 .dominator {3} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 4) hv)
    · have h := after_4_5
      change 2 ≤ 1+Marked.gameValue original marks_4 .staller {5} ∧ 1+Marked.gameValue original marks_4 .dominator {5} ≤ 2
      omega
    · have h := after_4_6
      change 2 ≤ 1+Marked.gameValue original marks_4 .staller {6} ∧ 1+Marked.gameValue original marks_4 .dominator {6} ≤ 2
      omega
    · have h := after_4_7
      change 2 ≤ 1+Marked.gameValue original marks_4 .staller {7} ∧ 1+Marked.gameValue original marks_4 .dominator {7} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_4 ∅ 8) hv)
def marks_5 : Finset (Fin 9) := {0,1,2,3,4}
theorem after_5_0 : Marked.gameValue original marks_5 .dominator {0}=1 ∧ Marked.gameValue original marks_5 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_5 marks_1 0 1 1 (by decide +kernel) row_1
theorem after_5_5 : Marked.gameValue original marks_5 .dominator {5}=0 ∧ Marked.gameValue original marks_5 .staller {5}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_5 marks_0 5 0 0 (by decide +kernel) row_0
theorem after_5_6 : Marked.gameValue original marks_5 .dominator {6}=0 ∧ Marked.gameValue original marks_5 .staller {6}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_5 marks_0 6 0 0 (by decide +kernel) row_0
theorem after_5_7 : Marked.gameValue original marks_5 .dominator {7}=1 ∧ Marked.gameValue original marks_5 .staller {7}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_5 marks_2 7 1 1 (by decide +kernel) row_2
theorem after_5_8 : Marked.gameValue original marks_5 .dominator {8}=1 ∧ Marked.gameValue original marks_5 .staller {8}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_5 marks_1 8 1 1 (by decide +kernel) row_1
theorem row_5 : Marked.gameValue original marks_5 .dominator ∅=1 ∧ Marked.gameValue original marks_5 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_5 1 2 5 0 (by decide +kernel) (by decide +kernel)
  · rw [after_5_5.2]
  · rw [after_5_0.1]
  · intro v hv
    fin_cases v
    · have h := after_5_0
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {0} ∧ 1+Marked.gameValue original marks_5 .dominator {0} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 3) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_5 ∅ 4) hv)
    · have h := after_5_5
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {5} ∧ 1+Marked.gameValue original marks_5 .dominator {5} ≤ 2
      omega
    · have h := after_5_6
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {6} ∧ 1+Marked.gameValue original marks_5 .dominator {6} ≤ 2
      omega
    · have h := after_5_7
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {7} ∧ 1+Marked.gameValue original marks_5 .dominator {7} ≤ 2
      omega
    · have h := after_5_8
      change 1 ≤ 1+Marked.gameValue original marks_5 .staller {8} ∧ 1+Marked.gameValue original marks_5 .dominator {8} ≤ 2
      omega
def marks_6 : Finset (Fin 9) := {1,4,6,7}
theorem after_6_0 : Marked.gameValue original marks_6 .dominator {0}=1 ∧ Marked.gameValue original marks_6 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_6 marks_1 0 1 1 (by decide +kernel) row_1
theorem after_6_1 : Marked.gameValue original marks_6 .dominator {1}=1 ∧ Marked.gameValue original marks_6 .staller {1}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_6 marks_2 1 1 1 (by decide +kernel) row_2
theorem after_6_2 : Marked.gameValue original marks_6 .dominator {2}=1 ∧ Marked.gameValue original marks_6 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_6 marks_3 2 1 2 (by decide +kernel) row_3
theorem after_6_3 : Marked.gameValue original marks_6 .dominator {3}=1 ∧ Marked.gameValue original marks_6 .staller {3}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_6 marks_3 3 1 2 (by decide +kernel) row_3
theorem after_6_5 : Marked.gameValue original marks_6 .dominator {5}=1 ∧ Marked.gameValue original marks_6 .staller {5}=1 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_6 marks_1 5 1 1 (by decide +kernel) row_1
theorem after_6_6 : Marked.gameValue original marks_6 .dominator {6}=1 ∧ Marked.gameValue original marks_6 .staller {6}=1 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_6 marks_1 6 1 1 (by decide +kernel) row_1
theorem after_6_8 : Marked.gameValue original marks_6 .dominator {8}=1 ∧ Marked.gameValue original marks_6 .staller {8}=1 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_6 marks_1 8 1 1 (by decide +kernel) row_1
theorem row_6 : Marked.gameValue original marks_6 .dominator ∅=2 ∧ Marked.gameValue original marks_6 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_6 2 2 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_6_0.2]
  · rw [after_6_0.1]
  · intro v hv
    fin_cases v
    · have h := after_6_0
      change 2 ≤ 1+Marked.gameValue original marks_6 .staller {0} ∧ 1+Marked.gameValue original marks_6 .dominator {0} ≤ 2
      omega
    · have h := after_6_1
      change 2 ≤ 1+Marked.gameValue original marks_6 .staller {1} ∧ 1+Marked.gameValue original marks_6 .dominator {1} ≤ 2
      omega
    · have h := after_6_2
      change 2 ≤ 1+Marked.gameValue original marks_6 .staller {2} ∧ 1+Marked.gameValue original marks_6 .dominator {2} ≤ 2
      omega
    · have h := after_6_3
      change 2 ≤ 1+Marked.gameValue original marks_6 .staller {3} ∧ 1+Marked.gameValue original marks_6 .dominator {3} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_6 ∅ 4) hv)
    · have h := after_6_5
      change 2 ≤ 1+Marked.gameValue original marks_6 .staller {5} ∧ 1+Marked.gameValue original marks_6 .dominator {5} ≤ 2
      omega
    · have h := after_6_6
      change 2 ≤ 1+Marked.gameValue original marks_6 .staller {6} ∧ 1+Marked.gameValue original marks_6 .dominator {6} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_6 ∅ 7) hv)
    · have h := after_6_8
      change 2 ≤ 1+Marked.gameValue original marks_6 .staller {8} ∧ 1+Marked.gameValue original marks_6 .dominator {8} ≤ 2
      omega
def marks_7 : Finset (Fin 9) := {2,3,6,7}
theorem after_7_0 : Marked.gameValue original marks_7 .dominator {0}=0 ∧ Marked.gameValue original marks_7 .staller {0}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_0 0 0 0 (by decide +kernel) row_0
theorem after_7_1 : Marked.gameValue original marks_7 .dominator {1}=1 ∧ Marked.gameValue original marks_7 .staller {1}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_2 1 1 1 (by decide +kernel) row_2
theorem after_7_2 : Marked.gameValue original marks_7 .dominator {2}=1 ∧ Marked.gameValue original marks_7 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_3 2 1 2 (by decide +kernel) row_3
theorem after_7_4 : Marked.gameValue original marks_7 .dominator {4}=1 ∧ Marked.gameValue original marks_7 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_7 marks_3 4 1 2 (by decide +kernel) row_3
theorem after_7_5 : Marked.gameValue original marks_7 .dominator {5}=1 ∧ Marked.gameValue original marks_7 .staller {5}=1 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_7 marks_2 5 1 1 (by decide +kernel) row_2
theorem after_7_6 : Marked.gameValue original marks_7 .dominator {6}=1 ∧ Marked.gameValue original marks_7 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_7 marks_3 6 1 2 (by decide +kernel) row_3
theorem after_7_8 : Marked.gameValue original marks_7 .dominator {8}=1 ∧ Marked.gameValue original marks_7 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_7 marks_3 8 1 2 (by decide +kernel) row_3
theorem row_7 : Marked.gameValue original marks_7 .dominator ∅=1 ∧ Marked.gameValue original marks_7 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_7 1 2 0 1 (by decide +kernel) (by decide +kernel)
  · rw [after_7_0.2]
  · rw [after_7_1.1]
  · intro v hv
    fin_cases v
    · have h := after_7_0
      change 1 ≤ 1+Marked.gameValue original marks_7 .staller {0} ∧ 1+Marked.gameValue original marks_7 .dominator {0} ≤ 2
      omega
    · have h := after_7_1
      change 1 ≤ 1+Marked.gameValue original marks_7 .staller {1} ∧ 1+Marked.gameValue original marks_7 .dominator {1} ≤ 2
      omega
    · have h := after_7_2
      change 1 ≤ 1+Marked.gameValue original marks_7 .staller {2} ∧ 1+Marked.gameValue original marks_7 .dominator {2} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_7 ∅ 3) hv)
    · have h := after_7_4
      change 1 ≤ 1+Marked.gameValue original marks_7 .staller {4} ∧ 1+Marked.gameValue original marks_7 .dominator {4} ≤ 2
      omega
    · have h := after_7_5
      change 1 ≤ 1+Marked.gameValue original marks_7 .staller {5} ∧ 1+Marked.gameValue original marks_7 .dominator {5} ≤ 2
      omega
    · have h := after_7_6
      change 1 ≤ 1+Marked.gameValue original marks_7 .staller {6} ∧ 1+Marked.gameValue original marks_7 .dominator {6} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_7 ∅ 7) hv)
    · have h := after_7_8
      change 1 ≤ 1+Marked.gameValue original marks_7 .staller {8} ∧ 1+Marked.gameValue original marks_7 .dominator {8} ≤ 2
      omega
end IsolationGame.FullCanonical.T09
