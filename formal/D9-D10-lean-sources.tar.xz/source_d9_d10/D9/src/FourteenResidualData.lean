import WeakBudgetThreeProfileReduction

/-!
SOURCE ONLY: not compiled or accepted. No native computation is used.

The definitions below are pure arithmetic on the accepted twenty profile types.
They assert no full-game value, StrictCapacity, actual counterexample, graph
isomorphism, or validity of either one-center game budget. In particular the
numeric weak t12 flag remains a weak flag.
-/
namespace IsolationGame.FourteenResidual
open CanonicalLocal AllProfileCore PairableProfileCore TwoCoreOpening
open WeakOneCenterArithmetic

set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

/-- The fourteen rows, indexed by a genuinely finite inductive type. -/
inductive Pattern where
  | r00
  | r01
  | r02
  | r03
  | r04
  | r05
  | r06
  | r07
  | r08
  | r09
  | r10
  | r11
  | r12
  | r13
  deriving DecidableEq

instance : Fintype Pattern :=
  ⟨{.r00, .r01, .r02, .r03, .r04, .r05, .r06, .r07, .r08, .r09, .r10, .r11, .r12, .r13}, by
    intro k
    cases k <;> simp⟩

def Pattern.left : Pattern → List Index
  | .r00 => [.t00]
  | .r01 => [.t03]
  | .r02 => [.t03]
  | .r03 => [.t07]
  | .r04 => [.t08]
  | .r05 => [.t08]
  | .r06 => [.t10]
  | .r07 => [.t15]
  | .r08 => [.t15]
  | .r09 => [.t15]
  | .r10 => [.t08]
  | .r11 => [.t08]
  | .r12 => [.t15]
  | .r13 => [.t15]

def Pattern.right : Pattern → List Index
  | .r00 => [.t08]
  | .r01 => [.t08]
  | .r02 => [.t12]
  | .r03 => [.t08]
  | .r04 => [.t10]
  | .r05 => [.t15]
  | .r06 => [.t12]
  | .r07 => [.t15]
  | .r08 => [.t16]
  | .r09 => [.t19]
  | .r10 => [.t08, .t08]
  | .r11 => [.t01, .t08]
  | .r12 => [.t03, .t15]
  | .r13 => [.t10, .t15]

/-- On the rows used here each side has length at most two. Thus equality
or equality with the reverse explicitly includes both possible internal orders.
This relation retains repeated entries and does not require sorted input. -/
def SideMatch (xs row : List Index) : Prop := xs = row ∨ xs = row.reverse

def MatchesPattern (xs ys : List Index) (k : Pattern) : Prop :=
  (SideMatch xs k.left ∧ SideMatch ys k.right) ∨
  (SideMatch xs k.right ∧ SideMatch ys k.left)

def MatchesFourteen (xs ys : List Index) : Prop :=
  ∃ k : Pattern, MatchesPattern xs ys k

instance (xs row : List Index) : Decidable (SideMatch xs row) :=
  inferInstanceAs (Decidable (xs = row ∨ xs = row.reverse))

instance (xs ys : List Index) (k : Pattern) :
    Decidable (MatchesPattern xs ys k) :=
  inferInstanceAs (Decidable
    ((SideMatch xs k.left ∧ SideMatch ys k.right) ∨
     (SideMatch xs k.right ∧ SideMatch ys k.left)))

instance (xs ys : List Index) : Decidable (MatchesFourteen xs ys) :=
  inferInstanceAs (Decidable (∃ k : Pattern, MatchesPattern xs ys k))

/-- Sums are evaluated on Index lists, avoiding any finite bound on raw codes. -/
def profileCost (xs : List Index) : Nat := (xs.map expectedS).sum

def profileFullCost (xs : List Index) : Nat := (xs.map numericFullS).sum

def profilePairCount (xs : List Index) : Nat := (xs.map pairFlag).sum

def profileWeakPairCount (xs : List Index) : Nat := (xs.map fullWeakPairFlag).sum

def profileSize (xs : List Index) : Nat := (xs.map size).sum

/-- Integer subtraction, with the same single cross-side floor as signedScore. -/
def profileScore (xs ys : List Index) : Int :=
  7 * ((profileCost xs + profileFullCost ys : Nat) : Int) -
    7 * (((profilePairCount xs + profileWeakPairCount ys) / 2 : Nat) : Int) -
    3 * ((profileSize xs + profileSize ys : Nat) : Int)

def NoT02 (xs : List Index) : Prop := .t02 ∉ xs

def NotAllT01 (xs : List Index) : Prop := ¬ ∀ t ∈ xs, t = .t01

/-- Numerical failure hypotheses only; this is not an actual-game predicate. -/
def NumericResidual (xs ys : List Index) : Prop :=
  NoT02 xs ∧ NoT02 ys ∧
    (-1 ≤ profileScore xs ys) ∧ (-1 ≤ profileScore ys xs) ∧
    NotAllT01 xs ∧ NotAllT01 ys

instance (xs : List Index) : Decidable (NoT02 xs) :=
  inferInstanceAs (Decidable (Index.t02 ∉ xs))

instance (xs : List Index) : Decidable (NotAllT01 xs) :=
  inferInstanceAs (Decidable (¬ ∀ t ∈ xs, t = .t01))

instance (xs ys : List Index) : Decidable (NumericResidual xs ys) :=
  inferInstanceAs (Decidable
    (NoT02 xs ∧ NoT02 ys ∧
      (-1 ≤ profileScore xs ys) ∧ (-1 ≤ profileScore ys xs) ∧
      NotAllT01 xs ∧ NotAllT01 ys))

theorem matchesFourteen_swap {xs ys : List Index}
    (h : MatchesFourteen xs ys) : MatchesFourteen ys xs := by
  rcases h with ⟨k, h | h⟩
  · exact ⟨k, Or.inr ⟨h.2, h.1⟩⟩
  · exact ⟨k, Or.inl ⟨h.2, h.1⟩⟩

/-- A reusable bridge to genuine list permutations for later reindexing. -/
theorem sideMatch_perm {xs row : List Index}
    (h : SideMatch xs row) : xs.Perm row := by
  rcases h with rfl | rfl
  · exact List.Perm.refl _
  · exact List.reverse_perm _

theorem matchesFourteen_perms {xs ys : List Index}
    (h : MatchesFourteen xs ys) :
    ∃ k : Pattern, (xs.Perm k.left ∧ ys.Perm k.right) ∨
      (xs.Perm k.right ∧ ys.Perm k.left) := by
  rcases h with ⟨k, h | h⟩
  · exact ⟨k, Or.inl ⟨sideMatch_perm h.1, sideMatch_perm h.2⟩⟩
  · exact ⟨k, Or.inr ⟨sideMatch_perm h.1, sideMatch_perm h.2⟩⟩

theorem numericResidual_swap {xs ys : List Index}
    (h : NumericResidual xs ys) : NumericResidual ys xs := by
  rcases h with ⟨hx, hy, hl, hr, hnx, hny⟩
  exact ⟨hy, hx, hr, hl, hny, hnx⟩

theorem numericResidual_nonempty_left {xs ys : List Index}
    (h : NumericResidual xs ys) : xs ≠ [] := by
  intro hx
  rcases h with ⟨_, _, _, _, hnx, _⟩
  subst xs
  exact hnx (by simp)

theorem numericResidual_nonempty_right {xs ys : List Index}
    (h : NumericResidual xs ys) : ys ≠ [] :=
  numericResidual_nonempty_left (numericResidual_swap h)

/-- The finite type has exactly fourteen entries. -/
theorem pattern_count : Fintype.card Pattern = 14 := by decide +kernel

/-- Every displayed row genuinely satisfies the numerical residual predicate. -/
theorem pattern_is_numericResidual (k : Pattern) :
    NumericResidual k.left k.right := by
  cases k <;> decide +kernel

theorem pattern_length_le_three (k : Pattern) :
    k.left.length + k.right.length ≤ 3 := by
  cases k <;> decide +kernel

/-- The fourteen displayed rows are different even after side reversal and
exchange. This also certifies that the table contains no duplicate orbit. -/
theorem pattern_orbits_distinct (i j : Pattern) :
    MatchesPattern i.left i.right j → i = j := by
  cases i <;> cases j <;> decide +kernel

#print axioms sideMatch_perm
#print axioms matchesFourteen_perms
#print axioms pattern_count
#print axioms pattern_is_numericResidual
#print axioms pattern_length_le_three
#print axioms pattern_orbits_distinct
end IsolationGame.FourteenResidual
