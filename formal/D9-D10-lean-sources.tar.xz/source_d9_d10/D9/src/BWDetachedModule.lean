import PureModuleStrict
import BWCoordinates
import BWBoundaryFee
namespace IsolationGame.BWDetachedModule
open CoreFamily CoreFamilySemantics CoreForest PureModuleStrict

 theorem family_isolated_follower (p : Nat) (i : Fin (0+p)) (u : Fin 7) :
    Marked.gameValue (MarkedBoundary.isolateVertex (CoreFamily.graph [] p) none) {none}
      .staller {some ⟨i,u⟩} ≤ 3*p-1 := by
  classical
  rw [←PureModuleStrict.initial_marks p,MarkedBoundary.isolated_value_eq_deleted]
  change Marked.gameValue (forest [] p) (forestMarks [] p (W p)) .staller
    (IsolatedRestriction.restrict (MarkedBoundary.retained none) {some ⟨i,u⟩}) ≤ _
  rw [CoreForest.restrict_move,local_next_value [] p (W p) (normalized p)]
  let c : Fin (0+p)→Nat := fun j=>if j=i then 2 else 3
  have hc : ∀j : Fin (0+p),Marked.gameValue (CanonicalLocal.graph (label [] p j))
      (ForestFoundation.canonicalMarks (playLocal [] p (W p) i u j)) .staller ∅≤c j := by
    intro j
    by_cases hj : j=i
    · subst j
      simp only [playLocal,Function.update_self,c,ite_true]
      exact local_follow_S u
    · simp only [playLocal,Function.update_of_ne hj,c,if_neg hj]
      exact local_initial_S.le
  have hf := mixed_s_upper [] p (family_tree [] p).IsAcyclic
    (playLocal [] p (W p) i u) c ∅ hc (by simp)
  simp only [Finset.card_empty,Nat.zero_div,Nat.sub_zero] at hf
  have hsum : (∑j,c j)+1=3*p := by
    simpa [c] using one_cost_sum i
  exact hf.trans (Nat.le_of_eq (Nat.eq_sub_of_add_eq hsum))

 theorem isolated_middle_bound (p : Nat) (i : Fin p) :
    Marked.gameValue (MarkedBoundary.isolateVertex MarkedModule.original (BWBridge.root p))
      MarkedModule.initialMarks .staller {.gate (some i)}≤3*p-1 := by
  obtain ⟨e,hr,hbase⟩ := CoreFamily.pure_module_family_iso p
  have he : ∀v w, (MarkedBoundary.isolateVertex MarkedModule.original (BWBridge.root p)).Adj (e v) (e w) ↔
      (MarkedBoundary.isolateVertex (CoreFamily.graph [] p) none).Adj v w := by
    intro v w
    have hroot : e none=BWBridge.root p := hr
    simp only [MarkedBoundary.isolateVertex]
    rw [hbase,←hroot,e.injective.ne_iff,e.injective.ne_iff]
  obtain ⟨j,u,hei⟩ : ∃ (j : Fin (0+p)) (u : Fin 7), e (some ⟨j,u⟩)=.gate (some i) := by
    cases hv : e.symm (.gate (some i)) with
    | none =>
      have hh := congrArg e hv
      simp only [Equiv.apply_symm_apply,hr] at hh
      simp at hh
    | some v =>
      obtain ⟨j,u⟩ := v
      exact ⟨j,u,by rw [←hv]; exact e.apply_symm_apply _⟩
  have h := Marked.gameValue_relabel
    (MarkedBoundary.isolateVertex (CoreFamily.graph [] p) none)
    (MarkedBoundary.isolateVertex MarkedModule.original (BWBridge.root p)) e he
    {none} {some ⟨j,u⟩} .staller
  rw [Finset.image_singleton,Finset.image_singleton,hr,hei] at h
  exact h.trans_le (family_isolated_follower p j u)

#print axioms isolated_middle_bound
end IsolationGame.BWDetachedModule
