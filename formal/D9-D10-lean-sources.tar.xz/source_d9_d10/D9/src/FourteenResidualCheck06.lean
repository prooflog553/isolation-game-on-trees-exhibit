import FourteenResidualData

/-! Finite kernel arithmetic only: first profile fixed to t06.
All arithmetic is checked by kernel reduction; no graph or history search. -/
namespace IsolationGame.FourteenResidual
open CanonicalLocal
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

theorem check11_t06 (b : Index) :
    NumericResidual [.t06] [b] → MatchesFourteen [.t06] [b] := by
  cases b <;> decide +kernel

theorem check12_t06 (b c : Index) :
    NumericResidual [.t06] [b, c] → MatchesFourteen [.t06] [b, c] := by
  cases b <;> cases c <;> decide +kernel

#print axioms check11_t06
#print axioms check12_t06
end IsolationGame.FourteenResidual
