import FullCanonical08Rows01
namespace IsolationGame.FullCanonical.T08
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_8 : Finset (Fin 11) := {0,1,4,7,8,9,10}
theorem after_8_1 : Marked.gameValue original marks_8 .dominator {1}=1 ∧ Marked.gameValue original marks_8 .staller {1}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_2 1 1 1 (by decide +kernel) row_2
theorem after_8_2 : Marked.gameValue original marks_8 .dominator {2}=1 ∧ Marked.gameValue original marks_8 .staller {2}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_2 2 1 1 (by decide +kernel) row_2
theorem after_8_3 : Marked.gameValue original marks_8 .dominator {3}=1 ∧ Marked.gameValue original marks_8 .staller {3}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_8 marks_2 3 1 1 (by decide +kernel) row_2
theorem after_8_4 : Marked.gameValue original marks_8 .dominator {4}=1 ∧ Marked.gameValue original marks_8 .staller {4}=1 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_8 marks_2 4 1 1 (by decide +kernel) row_2
theorem after_8_5 : Marked.gameValue original marks_8 .dominator {5}=1 ∧ Marked.gameValue original marks_8 .staller {5}=1 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_8 marks_2 5 1 1 (by decide +kernel) row_2
theorem after_8_6 : Marked.gameValue original marks_8 .dominator {6}=1 ∧ Marked.gameValue original marks_8 .staller {6}=1 :=
  FullCanonicalDAG.transport_perm original perm_1 adjacency_1 marks_8 marks_2 6 1 1 (by decide +kernel) row_2
theorem row_8 : Marked.gameValue original marks_8 .dominator ∅=2 ∧ Marked.gameValue original marks_8 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_8 2 2 1 1 (by decide +kernel) (by decide +kernel)
  · rw [after_8_1.2]
  · rw [after_8_1.1]
  · intro v hv
    fin_cases v
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_8 ∅ 0) hv)
    · have h := after_8_1
      change 2 ≤ 1+Marked.gameValue original marks_8 .staller {1} ∧ 1+Marked.gameValue original marks_8 .dominator {1} ≤ 2
      omega
    · have h := after_8_2
      change 2 ≤ 1+Marked.gameValue original marks_8 .staller {2} ∧ 1+Marked.gameValue original marks_8 .dominator {2} ≤ 2
      omega
    · have h := after_8_3
      change 2 ≤ 1+Marked.gameValue original marks_8 .staller {3} ∧ 1+Marked.gameValue original marks_8 .dominator {3} ≤ 2
      omega
    · have h := after_8_4
      change 2 ≤ 1+Marked.gameValue original marks_8 .staller {4} ∧ 1+Marked.gameValue original marks_8 .dominator {4} ≤ 2
      omega
    · have h := after_8_5
      change 2 ≤ 1+Marked.gameValue original marks_8 .staller {5} ∧ 1+Marked.gameValue original marks_8 .dominator {5} ≤ 2
      omega
    · have h := after_8_6
      change 2 ≤ 1+Marked.gameValue original marks_8 .staller {6} ∧ 1+Marked.gameValue original marks_8 .dominator {6} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_8 ∅ 7) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_8 ∅ 8) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_8 ∅ 9) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_8 ∅ 10) hv)
def marks_9 : Finset (Fin 11) := {1,2,3,7,8,9,10}
theorem after_9_0 : Marked.gameValue original marks_9 .dominator {0}=1 ∧ Marked.gameValue original marks_9 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_9 marks_2 0 1 1 (by decide +kernel) row_2
theorem after_9_1 : Marked.gameValue original marks_9 .dominator {1}=1 ∧ Marked.gameValue original marks_9 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_9 marks_6 1 1 2 (by decide +kernel) row_6
theorem after_9_4 : Marked.gameValue original marks_9 .dominator {4}=0 ∧ Marked.gameValue original marks_9 .staller {4}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_9 marks_0 4 0 0 (by decide +kernel) row_0
theorem after_9_5 : Marked.gameValue original marks_9 .dominator {5}=0 ∧ Marked.gameValue original marks_9 .staller {5}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_9 marks_0 5 0 0 (by decide +kernel) row_0
theorem after_9_6 : Marked.gameValue original marks_9 .dominator {6}=1 ∧ Marked.gameValue original marks_9 .staller {6}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_9 marks_1 6 1 1 (by decide +kernel) row_1
theorem after_9_7 : Marked.gameValue original marks_9 .dominator {7}=1 ∧ Marked.gameValue original marks_9 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_9 marks_6 7 1 2 (by decide +kernel) row_6
theorem row_9 : Marked.gameValue original marks_9 .dominator ∅=1 ∧ Marked.gameValue original marks_9 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_9 1 2 4 0 (by decide +kernel) (by decide +kernel)
  · rw [after_9_4.2]
  · rw [after_9_0.1]
  · intro v hv
    fin_cases v
    · have h := after_9_0
      change 1 ≤ 1+Marked.gameValue original marks_9 .staller {0} ∧ 1+Marked.gameValue original marks_9 .dominator {0} ≤ 2
      omega
    · have h := after_9_1
      change 1 ≤ 1+Marked.gameValue original marks_9 .staller {1} ∧ 1+Marked.gameValue original marks_9 .dominator {1} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_9 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_9 ∅ 3) hv)
    · have h := after_9_4
      change 1 ≤ 1+Marked.gameValue original marks_9 .staller {4} ∧ 1+Marked.gameValue original marks_9 .dominator {4} ≤ 2
      omega
    · have h := after_9_5
      change 1 ≤ 1+Marked.gameValue original marks_9 .staller {5} ∧ 1+Marked.gameValue original marks_9 .dominator {5} ≤ 2
      omega
    · have h := after_9_6
      change 1 ≤ 1+Marked.gameValue original marks_9 .staller {6} ∧ 1+Marked.gameValue original marks_9 .dominator {6} ≤ 2
      omega
    · have h := after_9_7
      change 1 ≤ 1+Marked.gameValue original marks_9 .staller {7} ∧ 1+Marked.gameValue original marks_9 .dominator {7} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_9 ∅ 8) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_9 ∅ 9) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_9 ∅ 10) hv)
def marks_10 : Finset (Fin 11) := {1,2,3,5,6,7,10}
theorem after_10_0 : Marked.gameValue original marks_10 .dominator {0}=1 ∧ Marked.gameValue original marks_10 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_10 marks_3 0 1 1 (by decide +kernel) row_3
theorem after_10_1 : Marked.gameValue original marks_10 .dominator {1}=1 ∧ Marked.gameValue original marks_10 .staller {1}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_10 marks_3 1 1 1 (by decide +kernel) row_3
theorem after_10_4 : Marked.gameValue original marks_10 .dominator {4}=1 ∧ Marked.gameValue original marks_10 .staller {4}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_10 marks_3 4 1 1 (by decide +kernel) row_3
theorem after_10_5 : Marked.gameValue original marks_10 .dominator {5}=1 ∧ Marked.gameValue original marks_10 .staller {5}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_10 marks_3 5 1 1 (by decide +kernel) row_3
theorem after_10_7 : Marked.gameValue original marks_10 .dominator {7}=0 ∧ Marked.gameValue original marks_10 .staller {7}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_10 marks_0 7 0 0 (by decide +kernel) row_0
theorem after_10_8 : Marked.gameValue original marks_10 .dominator {8}=1 ∧ Marked.gameValue original marks_10 .staller {8}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_10 marks_1 8 1 1 (by decide +kernel) row_1
theorem after_10_9 : Marked.gameValue original marks_10 .dominator {9}=1 ∧ Marked.gameValue original marks_10 .staller {9}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_10 marks_1 9 1 1 (by decide +kernel) row_1
theorem row_10 : Marked.gameValue original marks_10 .dominator ∅=1 ∧ Marked.gameValue original marks_10 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_10 1 2 7 0 (by decide +kernel) (by decide +kernel)
  · rw [after_10_7.2]
  · rw [after_10_0.1]
  · intro v hv
    fin_cases v
    · have h := after_10_0
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {0} ∧ 1+Marked.gameValue original marks_10 .dominator {0} ≤ 2
      omega
    · have h := after_10_1
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {1} ∧ 1+Marked.gameValue original marks_10 .dominator {1} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_10 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_10 ∅ 3) hv)
    · have h := after_10_4
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {4} ∧ 1+Marked.gameValue original marks_10 .dominator {4} ≤ 2
      omega
    · have h := after_10_5
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {5} ∧ 1+Marked.gameValue original marks_10 .dominator {5} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_10 ∅ 6) hv)
    · have h := after_10_7
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {7} ∧ 1+Marked.gameValue original marks_10 .dominator {7} ≤ 2
      omega
    · have h := after_10_8
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {8} ∧ 1+Marked.gameValue original marks_10 .dominator {8} ≤ 2
      omega
    · have h := after_10_9
      change 1 ≤ 1+Marked.gameValue original marks_10 .staller {9} ∧ 1+Marked.gameValue original marks_10 .dominator {9} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_10 ∅ 10) hv)
def marks_11 : Finset (Fin 11) := {0,1,2,3,4,7,10}
theorem after_11_4 : Marked.gameValue original marks_11 .dominator {4}=1 ∧ Marked.gameValue original marks_11 .staller {4}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_11 marks_3 4 1 1 (by decide +kernel) row_3
theorem after_11_5 : Marked.gameValue original marks_11 .dominator {5}=1 ∧ Marked.gameValue original marks_11 .staller {5}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_11 marks_3 5 1 1 (by decide +kernel) row_3
theorem after_11_6 : Marked.gameValue original marks_11 .dominator {6}=1 ∧ Marked.gameValue original marks_11 .staller {6}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_11 marks_3 6 1 1 (by decide +kernel) row_3
theorem after_11_7 : Marked.gameValue original marks_11 .dominator {7}=1 ∧ Marked.gameValue original marks_11 .staller {7}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_11 marks_2 7 1 1 (by decide +kernel) row_2
theorem after_11_8 : Marked.gameValue original marks_11 .dominator {8}=1 ∧ Marked.gameValue original marks_11 .staller {8}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_11 marks_2 8 1 1 (by decide +kernel) row_2
theorem after_11_9 : Marked.gameValue original marks_11 .dominator {9}=1 ∧ Marked.gameValue original marks_11 .staller {9}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_11 marks_2 9 1 1 (by decide +kernel) row_2
theorem row_11 : Marked.gameValue original marks_11 .dominator ∅=2 ∧ Marked.gameValue original marks_11 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_11 2 2 4 4 (by decide +kernel) (by decide +kernel)
  · rw [after_11_4.2]
  · rw [after_11_4.1]
  · intro v hv
    fin_cases v
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_11 ∅ 0) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_11 ∅ 1) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_11 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_11 ∅ 3) hv)
    · have h := after_11_4
      change 2 ≤ 1+Marked.gameValue original marks_11 .staller {4} ∧ 1+Marked.gameValue original marks_11 .dominator {4} ≤ 2
      omega
    · have h := after_11_5
      change 2 ≤ 1+Marked.gameValue original marks_11 .staller {5} ∧ 1+Marked.gameValue original marks_11 .dominator {5} ≤ 2
      omega
    · have h := after_11_6
      change 2 ≤ 1+Marked.gameValue original marks_11 .staller {6} ∧ 1+Marked.gameValue original marks_11 .dominator {6} ≤ 2
      omega
    · have h := after_11_7
      change 2 ≤ 1+Marked.gameValue original marks_11 .staller {7} ∧ 1+Marked.gameValue original marks_11 .dominator {7} ≤ 2
      omega
    · have h := after_11_8
      change 2 ≤ 1+Marked.gameValue original marks_11 .staller {8} ∧ 1+Marked.gameValue original marks_11 .dominator {8} ≤ 2
      omega
    · have h := after_11_9
      change 2 ≤ 1+Marked.gameValue original marks_11 .staller {9} ∧ 1+Marked.gameValue original marks_11 .dominator {9} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_11 ∅ 10) hv)
end IsolationGame.FullCanonical.T08
