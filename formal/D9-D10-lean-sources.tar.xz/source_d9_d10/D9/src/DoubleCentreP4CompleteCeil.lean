import DoubleCentreP4ZeroBounds
import DoubleCentreP4Consequence

/-! SOURCE_ONLY: combines the new r=0 ceiling with the preceding positive-r
ceiling. This concerns only this explicitly defined full two-centre family.
No all-parameter floor assertion is made; its K2 member disproves that. -/
namespace IsolationGame.DoubleCentreP4
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

theorem zero_ceiling_arithmetic (p q : Nat) :
    (3*(2+7*(p+q))+6)/7 = 3*(p+q)+1 := by omega

theorem zero_D_ceil_order (p q : Nat) :
    Marked.gameValue (graph 0 0 p q) ∅ .dominator ∅ ≤
      (3*Fintype.card (Vertex 0 0 p q)+6)/7 := by
  have h := Zero.D_upper p q
  rw [order]
  simpa only [Nat.add_zero,Nat.zero_add,Nat.mul_zero,zero_ceiling_arithmetic] using h

/-- All four natural parameters, on the literal original graph and empty marks. -/
theorem D_ceil_order_all (k l p q : Nat) :
    Marked.gameValue (graph k l p q) ∅ .dominator ∅ ≤
      (3*Fintype.card (Vertex k l p q)+6)/7 := by
  by_cases h : 1≤k+l
  · exact D_ceil_order k l p q h
  · have hk : k=0 := by omega
    have hl : l=0 := by omega
    subst k
    subst l
    exact zero_D_ceil_order p q

theorem isolationNumber_ceil_all (k l p q : Nat) :
    IsolationGame.isolationNumber (graph k l p q) ≤
      (3*Fintype.card (Vertex k l p q)+6)/7 := by
  have h := D_ceil_order_all k l p q
  rw [Marked.value_empty_marks] at h
  exact h

/-- The all-zero original graph remains K2, so a uniform floor claim is false. -/
theorem no_all_parameter_floor :
    ¬(∀ k l p q : Nat, IsolationGame.isolationNumber (graph k l p q) ≤
      (3*Fintype.card (Vertex k l p q))/7) := by
  intro h
  exact zero_floor_failure (h 0 0 0 0)

#print axioms zero_ceiling_arithmetic
#print axioms zero_D_ceil_order
#print axioms D_ceil_order_all
#print axioms isolationNumber_ceil_all
#print axioms no_all_parameter_floor
end IsolationGame.DoubleCentreP4
