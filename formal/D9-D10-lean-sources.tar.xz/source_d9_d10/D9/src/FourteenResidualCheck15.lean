import FourteenResidualData

/-! Finite kernel arithmetic only: first profile fixed to t15.
All arithmetic is checked by kernel reduction; no graph or history search. -/
namespace IsolationGame.FourteenResidual
open CanonicalLocal
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

theorem check11_t15 (b : Index) :
    NumericResidual [.t15] [b] → MatchesFourteen [.t15] [b] := by
  cases b <;> decide +kernel

theorem check12_t15 (b c : Index) :
    NumericResidual [.t15] [b, c] → MatchesFourteen [.t15] [b, c] := by
  cases b <;> cases c <;> decide +kernel

#print axioms check11_t15
#print axioms check12_t15
end IsolationGame.FourteenResidual
