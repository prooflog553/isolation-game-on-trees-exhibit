import CoreData

namespace IsolationGame.NecessaryCore
open CanonicalLocal
variable {A : Type} [DecidableEq A]

noncomputable def sourceCodes (f : A→Index) (I : Finset A) : List Nat :=
  (I.filter (fun a=>f a≠.t02)).toList.map (fun a=>code (f a))

/-- Exact multiplicity-preserving sorted extraction. This defines the target
proposition only; the requested theorem must actually prove it. -/
def ExtractionSpec (f : A→Index) (I : Finset A) : Prop :=
  ∃xs : List Nat,
    xs.Perm (sourceCodes f I) ∧
    xs.Pairwise (·≤·) ∧ xs.all allowedCode=true ∧
    xs.length=exceptionalCount f I ∧
    coreDefect xs=(∑a∈I,defect (f a))-7*((strictCount f I/2 : Nat):Int) ∧
    1+(∑a∈I,size (f a))=coreOrder xs+7*(I.filter (fun a=>f a=.t02)).card

end IsolationGame.NecessaryCore
