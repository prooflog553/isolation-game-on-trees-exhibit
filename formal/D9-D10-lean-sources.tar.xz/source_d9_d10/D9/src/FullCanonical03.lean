import FullCanonical03Rows03
namespace IsolationGame.FullCanonical.T03
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
theorem full_values : Marked.gameValue original ∅ .dominator ∅=4 ∧ Marked.gameValue original ∅ .staller ∅=4 := by
  constructor
  · exact (Marked.value_eq_of_white_eq original ∅ marks_14 ∅ ∅ .dominator (by decide +kernel)).trans row_14.1
  · exact (Marked.value_eq_of_white_eq original ∅ marks_14 ∅ ∅ .staller (by decide +kernel)).trans row_14.2
theorem not_strict_full : ¬MarkedSum.StrictCapacity original ∅ ∅ 4 := by
  intro h
  have hd := h.1
  rw [full_values.1] at hd
  omega
#print axioms full_values
#print axioms not_strict_full
end IsolationGame.FullCanonical.T03
