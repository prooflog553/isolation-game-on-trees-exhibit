import FullCanonical18Rows03
namespace IsolationGame.FullCanonical.T18
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000
def marks_16 : Finset (Fin 9) := {1,2,3}
theorem after_16_0 : Marked.gameValue original marks_16 .dominator {0}=1 ∧ Marked.gameValue original marks_16 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_2 0 1 1 (by decide +kernel) row_2
theorem after_16_1 : Marked.gameValue original marks_16 .dominator {1}=1 ∧ Marked.gameValue original marks_16 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_8 1 1 2 (by decide +kernel) row_8
theorem after_16_4 : Marked.gameValue original marks_16 .dominator {4}=0 ∧ Marked.gameValue original marks_16 .staller {4}=0 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_0 4 0 0 (by decide +kernel) row_0
theorem after_16_5 : Marked.gameValue original marks_16 .dominator {5}=1 ∧ Marked.gameValue original marks_16 .staller {5}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_4 5 1 1 (by decide +kernel) row_4
theorem after_16_6 : Marked.gameValue original marks_16 .dominator {6}=1 ∧ Marked.gameValue original marks_16 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_10 6 1 2 (by decide +kernel) row_10
theorem after_16_7 : Marked.gameValue original marks_16 .dominator {7}=1 ∧ Marked.gameValue original marks_16 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_9 7 1 2 (by decide +kernel) row_9
theorem after_16_8 : Marked.gameValue original marks_16 .dominator {8}=1 ∧ Marked.gameValue original marks_16 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_16 marks_8 8 1 2 (by decide +kernel) row_8
theorem row_16 : Marked.gameValue original marks_16 .dominator ∅=1 ∧ Marked.gameValue original marks_16 .staller ∅=2 := by
  apply LocalProfile.DAG.bellman original marks_16 1 2 4 0 (by decide +kernel) (by decide +kernel)
  · rw [after_16_4.2]
  · rw [after_16_0.1]
  · intro v hv
    fin_cases v
    · have h := after_16_0
      change 1 ≤ 1+Marked.gameValue original marks_16 .staller {0} ∧ 1+Marked.gameValue original marks_16 .dominator {0} ≤ 2
      omega
    · have h := after_16_1
      change 1 ≤ 1+Marked.gameValue original marks_16 .staller {1} ∧ 1+Marked.gameValue original marks_16 .dominator {1} ≤ 2
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_16 ∅ 2) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_16 ∅ 3) hv)
    · have h := after_16_4
      change 1 ≤ 1+Marked.gameValue original marks_16 .staller {4} ∧ 1+Marked.gameValue original marks_16 .dominator {4} ≤ 2
      omega
    · have h := after_16_5
      change 1 ≤ 1+Marked.gameValue original marks_16 .staller {5} ∧ 1+Marked.gameValue original marks_16 .dominator {5} ≤ 2
      omega
    · have h := after_16_6
      change 1 ≤ 1+Marked.gameValue original marks_16 .staller {6} ∧ 1+Marked.gameValue original marks_16 .dominator {6} ≤ 2
      omega
    · have h := after_16_7
      change 1 ≤ 1+Marked.gameValue original marks_16 .staller {7} ∧ 1+Marked.gameValue original marks_16 .dominator {7} ≤ 2
      omega
    · have h := after_16_8
      change 1 ≤ 1+Marked.gameValue original marks_16 .staller {8} ∧ 1+Marked.gameValue original marks_16 .dominator {8} ≤ 2
      omega
def marks_17 : Finset (Fin 9) := {0,8}
theorem after_17_0 : Marked.gameValue original marks_17 .dominator {0}=2 ∧ Marked.gameValue original marks_17 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_7 0 2 2 (by decide +kernel) row_7
theorem after_17_1 : Marked.gameValue original marks_17 .dominator {1}=1 ∧ Marked.gameValue original marks_17 .staller {1}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_8 1 1 2 (by decide +kernel) row_8
theorem after_17_2 : Marked.gameValue original marks_17 .dominator {2}=1 ∧ Marked.gameValue original marks_17 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_8 2 1 2 (by decide +kernel) row_8
theorem after_17_3 : Marked.gameValue original marks_17 .dominator {3}=1 ∧ Marked.gameValue original marks_17 .staller {3}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_8 3 1 2 (by decide +kernel) row_8
theorem after_17_4 : Marked.gameValue original marks_17 .dominator {4}=1 ∧ Marked.gameValue original marks_17 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_5 4 1 2 (by decide +kernel) row_5
theorem after_17_5 : Marked.gameValue original marks_17 .dominator {5}=1 ∧ Marked.gameValue original marks_17 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_5 5 1 2 (by decide +kernel) row_5
theorem after_17_6 : Marked.gameValue original marks_17 .dominator {6}=2 ∧ Marked.gameValue original marks_17 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_12 6 2 2 (by decide +kernel) row_12
theorem after_17_7 : Marked.gameValue original marks_17 .dominator {7}=2 ∧ Marked.gameValue original marks_17 .staller {7}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_17 marks_11 7 2 3 (by decide +kernel) row_11
theorem row_17 : Marked.gameValue original marks_17 .dominator ∅=3 ∧ Marked.gameValue original marks_17 .staller ∅=3 := by
  apply LocalProfile.DAG.bellman original marks_17 3 3 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_17_0.2]
  · rw [after_17_0.1]
  · intro v hv
    fin_cases v
    · have h := after_17_0
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {0} ∧ 1+Marked.gameValue original marks_17 .dominator {0} ≤ 3
      omega
    · have h := after_17_1
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {1} ∧ 1+Marked.gameValue original marks_17 .dominator {1} ≤ 3
      omega
    · have h := after_17_2
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {2} ∧ 1+Marked.gameValue original marks_17 .dominator {2} ≤ 3
      omega
    · have h := after_17_3
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {3} ∧ 1+Marked.gameValue original marks_17 .dominator {3} ≤ 3
      omega
    · have h := after_17_4
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {4} ∧ 1+Marked.gameValue original marks_17 .dominator {4} ≤ 3
      omega
    · have h := after_17_5
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {5} ∧ 1+Marked.gameValue original marks_17 .dominator {5} ≤ 3
      omega
    · have h := after_17_6
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {6} ∧ 1+Marked.gameValue original marks_17 .dominator {6} ≤ 3
      omega
    · have h := after_17_7
      change 3 ≤ 1+Marked.gameValue original marks_17 .staller {7} ∧ 1+Marked.gameValue original marks_17 .dominator {7} ≤ 3
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_17 ∅ 8) hv)
def marks_18 : Finset (Fin 9) := {4,7}
theorem after_18_0 : Marked.gameValue original marks_18 .dominator {0}=2 ∧ Marked.gameValue original marks_18 .staller {0}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_18 marks_7 0 2 2 (by decide +kernel) row_7
theorem after_18_1 : Marked.gameValue original marks_18 .dominator {1}=1 ∧ Marked.gameValue original marks_18 .staller {1}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_18 marks_2 1 1 1 (by decide +kernel) row_2
theorem after_18_2 : Marked.gameValue original marks_18 .dominator {2}=1 ∧ Marked.gameValue original marks_18 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_18 marks_9 2 1 2 (by decide +kernel) row_9
theorem after_18_3 : Marked.gameValue original marks_18 .dominator {3}=1 ∧ Marked.gameValue original marks_18 .staller {3}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_18 marks_14 3 1 2 (by decide +kernel) row_14
theorem after_18_4 : Marked.gameValue original marks_18 .dominator {4}=1 ∧ Marked.gameValue original marks_18 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_18 marks_5 4 1 2 (by decide +kernel) row_5
theorem after_18_5 : Marked.gameValue original marks_18 .dominator {5}=1 ∧ Marked.gameValue original marks_18 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_18 marks_13 5 1 2 (by decide +kernel) row_13
theorem after_18_6 : Marked.gameValue original marks_18 .dominator {6}=1 ∧ Marked.gameValue original marks_18 .staller {6}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_18 marks_13 6 1 2 (by decide +kernel) row_13
theorem after_18_8 : Marked.gameValue original marks_18 .dominator {8}=2 ∧ Marked.gameValue original marks_18 .staller {8}=3 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_18 marks_11 8 2 3 (by decide +kernel) row_11
theorem row_18 : Marked.gameValue original marks_18 .dominator ∅=2 ∧ Marked.gameValue original marks_18 .staller ∅=3 := by
  apply LocalProfile.DAG.bellman original marks_18 2 3 1 0 (by decide +kernel) (by decide +kernel)
  · rw [after_18_1.2]
  · rw [after_18_0.1]
  · intro v hv
    fin_cases v
    · have h := after_18_0
      change 2 ≤ 1+Marked.gameValue original marks_18 .staller {0} ∧ 1+Marked.gameValue original marks_18 .dominator {0} ≤ 3
      omega
    · have h := after_18_1
      change 2 ≤ 1+Marked.gameValue original marks_18 .staller {1} ∧ 1+Marked.gameValue original marks_18 .dominator {1} ≤ 3
      omega
    · have h := after_18_2
      change 2 ≤ 1+Marked.gameValue original marks_18 .staller {2} ∧ 1+Marked.gameValue original marks_18 .dominator {2} ≤ 3
      omega
    · have h := after_18_3
      change 2 ≤ 1+Marked.gameValue original marks_18 .staller {3} ∧ 1+Marked.gameValue original marks_18 .dominator {3} ≤ 3
      omega
    · have h := after_18_4
      change 2 ≤ 1+Marked.gameValue original marks_18 .staller {4} ∧ 1+Marked.gameValue original marks_18 .dominator {4} ≤ 3
      omega
    · have h := after_18_5
      change 2 ≤ 1+Marked.gameValue original marks_18 .staller {5} ∧ 1+Marked.gameValue original marks_18 .dominator {5} ≤ 3
      omega
    · have h := after_18_6
      change 2 ≤ 1+Marked.gameValue original marks_18 .staller {6} ∧ 1+Marked.gameValue original marks_18 .dominator {6} ≤ 3
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_18 ∅ 7) hv)
    · have h := after_18_8
      change 2 ≤ 1+Marked.gameValue original marks_18 .staller {8} ∧ 1+Marked.gameValue original marks_18 .dominator {8} ≤ 3
      omega
def marks_19 : Finset (Fin 9) := {5,6}
theorem after_19_0 : Marked.gameValue original marks_19 .dominator {0}=1 ∧ Marked.gameValue original marks_19 .staller {0}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_19 marks_1 0 1 1 (by decide +kernel) row_1
theorem after_19_1 : Marked.gameValue original marks_19 .dominator {1}=1 ∧ Marked.gameValue original marks_19 .staller {1}=1 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_19 marks_3 1 1 1 (by decide +kernel) row_3
theorem after_19_2 : Marked.gameValue original marks_19 .dominator {2}=1 ∧ Marked.gameValue original marks_19 .staller {2}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_19 marks_10 2 1 2 (by decide +kernel) row_10
theorem after_19_3 : Marked.gameValue original marks_19 .dominator {3}=1 ∧ Marked.gameValue original marks_19 .staller {3}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_19 marks_15 3 1 2 (by decide +kernel) row_15
theorem after_19_4 : Marked.gameValue original marks_19 .dominator {4}=1 ∧ Marked.gameValue original marks_19 .staller {4}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_19 marks_5 4 1 2 (by decide +kernel) row_5
theorem after_19_5 : Marked.gameValue original marks_19 .dominator {5}=1 ∧ Marked.gameValue original marks_19 .staller {5}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_19 marks_13 5 1 2 (by decide +kernel) row_13
theorem after_19_7 : Marked.gameValue original marks_19 .dominator {7}=1 ∧ Marked.gameValue original marks_19 .staller {7}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_19 marks_13 7 1 2 (by decide +kernel) row_13
theorem after_19_8 : Marked.gameValue original marks_19 .dominator {8}=2 ∧ Marked.gameValue original marks_19 .staller {8}=2 :=
  FullCanonicalDAG.transport_perm original perm_0 adjacency_0 marks_19 marks_12 8 2 2 (by decide +kernel) row_12
theorem row_19 : Marked.gameValue original marks_19 .dominator ∅=2 ∧ Marked.gameValue original marks_19 .staller ∅=3 := by
  apply LocalProfile.DAG.bellman original marks_19 2 3 0 8 (by decide +kernel) (by decide +kernel)
  · rw [after_19_0.2]
  · rw [after_19_8.1]
  · intro v hv
    fin_cases v
    · have h := after_19_0
      change 2 ≤ 1+Marked.gameValue original marks_19 .staller {0} ∧ 1+Marked.gameValue original marks_19 .dominator {0} ≤ 3
      omega
    · have h := after_19_1
      change 2 ≤ 1+Marked.gameValue original marks_19 .staller {1} ∧ 1+Marked.gameValue original marks_19 .dominator {1} ≤ 3
      omega
    · have h := after_19_2
      change 2 ≤ 1+Marked.gameValue original marks_19 .staller {2} ∧ 1+Marked.gameValue original marks_19 .dominator {2} ≤ 3
      omega
    · have h := after_19_3
      change 2 ≤ 1+Marked.gameValue original marks_19 .staller {3} ∧ 1+Marked.gameValue original marks_19 .dominator {3} ≤ 3
      omega
    · have h := after_19_4
      change 2 ≤ 1+Marked.gameValue original marks_19 .staller {4} ∧ 1+Marked.gameValue original marks_19 .dominator {4} ≤ 3
      omega
    · have h := after_19_5
      change 2 ≤ 1+Marked.gameValue original marks_19 .staller {5} ∧ 1+Marked.gameValue original marks_19 .dominator {5} ≤ 3
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original marks_19 ∅ 6) hv)
    · have h := after_19_7
      change 2 ≤ 1+Marked.gameValue original marks_19 .staller {7} ∧ 1+Marked.gameValue original marks_19 .dominator {7} ≤ 3
      omega
    · have h := after_19_8
      change 2 ≤ 1+Marked.gameValue original marks_19 .staller {8} ∧ 1+Marked.gameValue original marks_19 .dominator {8} ≤ 3
      omega
end IsolationGame.FullCanonical.T18
