import DoubleCentreP4Model

namespace IsolationGame.DoubleCentreP4
set_option maxRecDepth 8192
set_option maxHeartbeats 2000000

theorem left_follower_S (k l p q : Nat) :
    Marked.gameValue (graph k l p q) ∅ .staller {left k l p q} ≤
      3*(p+q)+(3*k+1)/2+(3*l)/2+1 := by
  rw [left_follower_split]
  have hsum := MarkedSum.S_upper_value (GeneralP4Receiver.graph k p) (GeneralP4Receiver.graph l q)
    (Marked.forest_no_minus _ (GeneralP4Receiver.graph_acyclic k p))
    (Marked.forest_no_minus _ (GeneralP4Receiver.graph_acyclic l q))
    (SelectedVertex.playedMarks (GeneralP4Receiver.graph k p) (GeneralP4Receiver.marks k p) (GeneralP4Receiver.centre k p)) ∅
    (GeneralP4Receiver.marks l q) ∅
  have he : MarkedSum.combine (∅ : Finset (GeneralP4Receiver.Vertex k p))
      (∅ : Finset (GeneralP4Receiver.Vertex l q)) = ∅ := by
    simp [MarkedSum.combine,MarkedSum.liftLeft,MarkedSum.liftRight]
  rw [he] at hsum
  have hsumExact : Marked.gameValue
      (MarkedSum.original (GeneralP4Receiver.graph k p) (GeneralP4Receiver.graph l q))
      (MarkedSum.combine
        (SelectedVertex.playedMarks (GeneralP4Receiver.graph k p)
          (GeneralP4Receiver.marks k p) (GeneralP4Receiver.centre k p))
        (GeneralP4Receiver.marks l q)) .staller ∅ ≤
      Marked.gameValue (GeneralP4Receiver.graph k p)
        (SelectedVertex.playedMarks (GeneralP4Receiver.graph k p)
          (GeneralP4Receiver.marks k p) (GeneralP4Receiver.centre k p)) .staller ∅ +
      Marked.gameValue (GeneralP4Receiver.graph l q) (GeneralP4Receiver.marks l q) .staller ∅ := by
    convert hsum using 1 <;> congr 1 <;> apply Subsingleton.elim
  have hleft := GeneralP4Receiver.root_played_S_strong k p
  have hright := GeneralP4Receiver.S_upper_strong l q
  dsimp [GeneralP4Receiver.cBudget] at hleft
  omega

theorem left_opening (k l p q : Nat) :
    Marked.gameValue (graph k l p q) ∅ .dominator ∅ ≤
      3*(p+q)+(3*k+1)/2+(3*l)/2+2 := by
  have hd := Marked.d_move_upper (graph k l p q) ∅ ∅ (left k l p q)
    (left_legal k l p q)
  simp only [Finset.insert_empty] at hd
  have hs := left_follower_S k l p q
  omega

theorem right_opening (k l p q : Nat) :
    Marked.gameValue (graph k l p q) ∅ .dominator ∅ ≤
      3*(p+q)+(3*l+1)/2+(3*k)/2+2 := by
  have hs := left_opening l k q p
  have he := value_swap k l p q .dominator ∅
  simp only [Finset.image_empty] at he
  omega

theorem min_half_budget (k l : Nat) :
    min ((3*k+1)/2+(3*l)/2) ((3*l+1)/2+(3*k)/2) = (3*(k+l))/2 := by
  have hk := Nat.mod_add_div k 2
  have hl := Nat.mod_add_div l 2
  have hklt := Nat.mod_lt k (by decide : 0<2)
  have hllt := Nat.mod_lt l (by decide : 0<2)
  by_cases hk0 : k%2=0 <;> by_cases hl0 : l%2=0 <;> omega

/-- Unconditional all-parameter bound on the actual initially empty-mark game. -/
theorem D_upper (k l p q : Nat) :
    Marked.gameValue (graph k l p q) ∅ .dominator ∅ ≤
      3*(p+q)+(3*(k+l))/2+2 := by
  have hl := left_opening k l p q
  have hr := right_opening k l p q
  have hm := min_half_budget k l
  omega

#print axioms left_follower_S
#print axioms left_opening
#print axioms right_opening
#print axioms min_half_budget
#print axioms D_upper
end IsolationGame.DoubleCentreP4
