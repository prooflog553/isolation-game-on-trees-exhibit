import FloorLocalBase
import FloorLocalRow001
set_option maxRecDepth 4096
set_option maxHeartbeats 1000000
namespace IsolationGame.FloorLocal
def marks_016 : Finset (Fin 7) := {2,3,4,5,6}
theorem normalized_016 : ∀v : Fin 7, Marked.White original_02 marks_016 ∅ v ↔ v∈({0,1} : Finset (Fin 7)) := by decide +kernel
theorem after_016_0 : Marked.gameValue original_02 marks_016 .dominator {0}=0 ∧ Marked.gameValue original_02 marks_016 .staller {0}=0 :=
  LocalProfile.DAG.transport original_02 marks_016 marks_001 0 0 0 (by decide +kernel) row_001
theorem after_016_1 : Marked.gameValue original_02 marks_016 .dominator {1}=0 ∧ Marked.gameValue original_02 marks_016 .staller {1}=0 :=
  LocalProfile.DAG.transport original_02 marks_016 marks_001 1 0 0 (by decide +kernel) row_001
theorem after_016_2 : Marked.gameValue original_02 marks_016 .dominator {2}=0 ∧ Marked.gameValue original_02 marks_016 .staller {2}=0 :=
  LocalProfile.DAG.transport original_02 marks_016 marks_001 2 0 0 (by decide +kernel) row_001
theorem after_016_4 : Marked.gameValue original_02 marks_016 .dominator {4}=0 ∧ Marked.gameValue original_02 marks_016 .staller {4}=0 :=
  LocalProfile.DAG.transport original_02 marks_016 marks_001 4 0 0 (by decide +kernel) row_001
theorem row_016 : Marked.gameValue original_02 marks_016 .dominator ∅=1 ∧ Marked.gameValue original_02 marks_016 .staller ∅=1 := by
  apply LocalProfile.DAG.bellman original_02 marks_016 1 1 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_016_0.2]
  · rw [after_016_0.1]
  · intro v hv
    fin_cases v
    · have h := after_016_0
      change 1≤1+Marked.gameValue original_02 marks_016 .staller {0} ∧ 1+Marked.gameValue original_02 marks_016 .dominator {0}≤1
      omega
    · have h := after_016_1
      change 1≤1+Marked.gameValue original_02 marks_016 .staller {1} ∧ 1+Marked.gameValue original_02 marks_016 .dominator {1}≤1
      omega
    · have h := after_016_2
      change 1≤1+Marked.gameValue original_02 marks_016 .staller {2} ∧ 1+Marked.gameValue original_02 marks_016 .dominator {2}≤1
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_016 ∅ 3) hv)
    · have h := after_016_4
      change 1≤1+Marked.gameValue original_02 marks_016 .staller {4} ∧ 1+Marked.gameValue original_02 marks_016 .dominator {4}≤1
      omega
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_016 ∅ 5) hv)
    · exact False.elim ((by decide +kernel : ¬Marked.Legal original_02 marks_016 ∅ 6) hv)
#print axioms row_016
end IsolationGame.FloorLocal
