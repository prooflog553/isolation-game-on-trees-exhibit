import CanonicalBlockModels

namespace IsolationGame.CanonicalLocal
open IsolatedRestriction PartitionBridge ActualRootBranches SmallPiece

noncomputable def childToBlock (t : Index) (a : Child (graph t) (root t)) : Block t :=
  Classical.choose ((root_candidates t a.val).mp (child_edge (graph t) (root t) a))

theorem child_block_root (t : Index) (a : Child (graph t) (root t)) :
    a.val=blockRoot t (childToBlock t a) :=
  Classical.choose_spec ((root_candidates t a.val).mp (child_edge (graph t) (root t) a))

noncomputable def blockToChild (t : Index) (j : Block t) : Child (graph t) (root t) :=
  ⟨blockRoot t j,by
    simp only [children,Finset.mem_filter,Finset.mem_univ,true_and]
    exact block_root_edge t j⟩

noncomputable def childEnum (t : Index) : Child (graph t) (root t)≃Block t where
  toFun := childToBlock t
  invFun := blockToChild t
  left_inv a := by
    apply Subtype.ext
    exact (child_block_root t a).symm
  right_inv j := by
    apply roots_injective t
    exact (child_block_root t (blockToChild t j)).symm

theorem actual_piece_block (t : Index) (a : Child (graph t) (root t)) :
    piece (graph t) (root t) a=blockVertices t (childToBlock t a) := by
  let j := childToBlock t a
  let A := Finset.univ\blockVertices t j
  have hr : root t∈A := by simp [A,root_not_block]
  have haB : a.val∈blockVertices t j := by rw [child_block_root];exact root_mem_block t j
  have ha : a.val∉A := by simp [A,haB]
  have hc : OneBridge (graph t) A (root t) a.val := by
    rw [child_block_root]
    exact block_cut t j
  have hp := piece_eq_of_cut (graph t) (canonical_tree t) (root t) a A hr ha hc
  have he : outside A=blockVertices t j := by
    ext v
    simp [outside,A]
  exact hp.trans he

def finsetEquiv {V : Type} [Fintype V] [DecidableEq V] (A B : Finset V) (h : A=B) : Active A≃Active B where
  toFun v := ⟨v.val,h ▸ v.property⟩
  invFun v := ⟨v.val,h.symm ▸ v.property⟩
  left_inv v := rfl
  right_inv v := rfl

noncomputable def pieceModelEquiv (t : Index) (a : Child (graph t) (root t)) :
    Active (piece (graph t) (root t) a)≃Fin (order (blockKind t (childToBlock t a))) :=
  (finsetEquiv _ _ (actual_piece_block t a)).trans (blockEquiv t (childToBlock t a))

/-- Actual root branches of each canonical graph are exactly the displayed
four-type blocks, with a full rooted adjacency equivalence on every block. -/
noncomputable def canonical_models (t : Index) : BranchModels (graph t) (root t) where
  kind a := blockKind t (childToBlock t a)
  equiv a := pieceModelEquiv t a
  root_map a := by
    apply Fin.ext
    change a.val.val-(blockData t (childToBlock t a)).rootLabel=0
    have hv := congrArg Fin.val (child_block_root t a)
    change a.val.val=(blockData t (childToBlock t a)).rootLabel at hv
    omega
  adjacency a u v := by
    let j := childToBlock t a
    let e := finsetEquiv _ _ (actual_piece_block t a)
    exact block_model_adjacency t j (e u) (e v)

#print axioms actual_piece_block
#print axioms canonical_models
end IsolationGame.CanonicalLocal
