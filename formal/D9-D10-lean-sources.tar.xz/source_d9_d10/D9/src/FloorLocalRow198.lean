import FloorLocalBase
import FloorLocalRow064
import FloorLocalRow066
import FloorLocalRow108
set_option maxRecDepth 4096
set_option maxHeartbeats 1000000
namespace IsolationGame.FloorLocal
def marks_198 : Finset (Fin 7) := {0}
theorem normalized_198 : ∀v : Fin 7, Marked.White original_02 marks_198 ∅ v ↔ v∈({1,2,3,4,5,6} : Finset (Fin 7)) := by decide +kernel
theorem after_198_0 : Marked.gameValue original_02 marks_198 .dominator {0}=2 ∧ Marked.gameValue original_02 marks_198 .staller {0}=2 :=
  LocalProfile.DAG.transport original_02 marks_198 marks_108 0 2 2 (by decide +kernel) row_108
theorem after_198_1 : Marked.gameValue original_02 marks_198 .dominator {1}=1 ∧ Marked.gameValue original_02 marks_198 .staller {1}=2 :=
  LocalProfile.DAG.transport original_02 marks_198 marks_066 1 1 2 (by decide +kernel) row_066
theorem after_198_2 : Marked.gameValue original_02 marks_198 .dominator {2}=1 ∧ Marked.gameValue original_02 marks_198 .staller {2}=2 :=
  LocalProfile.DAG.transport original_02 marks_198 marks_066 2 1 2 (by decide +kernel) row_066
theorem after_198_3 : Marked.gameValue original_02 marks_198 .dominator {3}=1 ∧ Marked.gameValue original_02 marks_198 .staller {3}=2 :=
  LocalProfile.DAG.transport original_02 marks_198 marks_066 3 1 2 (by decide +kernel) row_066
theorem after_198_4 : Marked.gameValue original_02 marks_198 .dominator {4}=1 ∧ Marked.gameValue original_02 marks_198 .staller {4}=2 :=
  LocalProfile.DAG.transport original_02 marks_198 marks_064 4 1 2 (by decide +kernel) row_064
theorem after_198_5 : Marked.gameValue original_02 marks_198 .dominator {5}=1 ∧ Marked.gameValue original_02 marks_198 .staller {5}=2 :=
  LocalProfile.DAG.transport original_02 marks_198 marks_064 5 1 2 (by decide +kernel) row_064
theorem after_198_6 : Marked.gameValue original_02 marks_198 .dominator {6}=1 ∧ Marked.gameValue original_02 marks_198 .staller {6}=2 :=
  LocalProfile.DAG.transport original_02 marks_198 marks_064 6 1 2 (by decide +kernel) row_064
theorem row_198 : Marked.gameValue original_02 marks_198 .dominator ∅=3 ∧ Marked.gameValue original_02 marks_198 .staller ∅=3 := by
  apply LocalProfile.DAG.bellman original_02 marks_198 3 3 0 0 (by decide +kernel) (by decide +kernel)
  · rw [after_198_0.2]
  · rw [after_198_0.1]
  · intro v hv
    fin_cases v
    · have h := after_198_0
      change 3≤1+Marked.gameValue original_02 marks_198 .staller {0} ∧ 1+Marked.gameValue original_02 marks_198 .dominator {0}≤3
      omega
    · have h := after_198_1
      change 3≤1+Marked.gameValue original_02 marks_198 .staller {1} ∧ 1+Marked.gameValue original_02 marks_198 .dominator {1}≤3
      omega
    · have h := after_198_2
      change 3≤1+Marked.gameValue original_02 marks_198 .staller {2} ∧ 1+Marked.gameValue original_02 marks_198 .dominator {2}≤3
      omega
    · have h := after_198_3
      change 3≤1+Marked.gameValue original_02 marks_198 .staller {3} ∧ 1+Marked.gameValue original_02 marks_198 .dominator {3}≤3
      omega
    · have h := after_198_4
      change 3≤1+Marked.gameValue original_02 marks_198 .staller {4} ∧ 1+Marked.gameValue original_02 marks_198 .dominator {4}≤3
      omega
    · have h := after_198_5
      change 3≤1+Marked.gameValue original_02 marks_198 .staller {5} ∧ 1+Marked.gameValue original_02 marks_198 .dominator {5}≤3
      omega
    · have h := after_198_6
      change 3≤1+Marked.gameValue original_02 marks_198 .staller {6} ∧ 1+Marked.gameValue original_02 marks_198 .dominator {6}≤3
      omega
#print axioms row_198
end IsolationGame.FloorLocal
