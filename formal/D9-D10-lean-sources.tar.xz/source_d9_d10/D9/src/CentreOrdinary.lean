import FloorLocalRow198

/-! The complete seven-vertex ordinary branch, with its actual midpoint root.
The vertex labels are r=0, b₁=1, c₁=2, d₁=3, b₂=4, c₂=5, d₂=6.
All value transfers below use equality of the entire original adjacency relation.
Root-only predomination is distinguished from an actual selection of the root. -/
namespace IsolationGame.CentreOrdinary

set_option maxRecDepth 4096
set_option maxHeartbeats 1000000

abbrev Vertex := Fin 7

def root : Vertex := 0

/-- Exactly the six undirected edges of the complete midpoint-rooted P7. -/
def graph : SimpleGraph Vertex where
  Adj u v :=
    (u = 0 ∧ v = 1) ∨ (u = 1 ∧ v = 0) ∨
    (u = 1 ∧ v = 2) ∨ (u = 2 ∧ v = 1) ∨
    (u = 2 ∧ v = 3) ∨ (u = 3 ∧ v = 2) ∨
    (u = 0 ∧ v = 4) ∨ (u = 4 ∧ v = 0) ∨
    (u = 4 ∧ v = 5) ∨ (u = 5 ∧ v = 4) ∨
    (u = 5 ∧ v = 6) ∨ (u = 6 ∧ v = 5)
  symm := by unfold Symmetric; decide +kernel
  loopless := by unfold Irreflexive; decide +kernel

instance : DecidableRel graph.Adj := fun _ _ => inferInstanceAs (Decidable (_ ∨ _))

/-- The full original graph agrees, with these labels, with the verified row. -/
theorem adjacency_agrees : ∀ u v : Vertex,
    graph.Adj u v ↔ FloorLocal.original_02.Adj u v := by decide +kernel

theorem graph_eq_original : graph = FloorLocal.original_02 := by
  ext u v
  exact adjacency_agrees u v

/-- The graph retains all seven original vertices. -/
theorem original_order : Fintype.card Vertex = 7 := rfl

theorem graph_isTree : graph.IsTree :=
  CanonicalLocal.tree_of_certificate graph root (by unfold CanonicalLocal.ReachThree; decide +kernel) (by decide +kernel)

/-- Only the attachment root is genuinely marked. -/
def rootMarks : Finset Vertex := {root}

/-- Genuine closed-neighborhood marks created by actually selecting the root. -/
def closedRootMarks : Finset Vertex := Finset.univ.filter (Closed graph root)

theorem rootMarks_exact : rootMarks = ({0} : Finset Vertex) := rfl

theorem closedRootMarks_exact : closedRootMarks = ({0, 1, 4} : Finset Vertex) :=
  by decide +kernel

theorem rootMarks_ne_closedRootMarks : rootMarks ≠ closedRootMarks := by decide +kernel

theorem root_legal : Marked.Legal graph rootMarks ∅ root := by decide +kernel

/-- Root-only marking leaves both complete arms as genuine white vertices. -/
theorem root_marked_white_exact : ∀ v : Vertex,
    Marked.White graph rootMarks ∅ v ↔ v ∈ ({1, 2, 3, 4, 5, 6} : Finset Vertex) :=
  by decide +kernel

/-- The complete ordinary component is balanced at three, with empty history. -/
theorem root_marked_value :
    Marked.gameValue graph rootMarks .dominator ∅ = 3 ∧
    Marked.gameValue graph rootMarks .staller ∅ = 3 := by
  simpa only [graph_eq_original, rootMarks, root, FloorLocal.marks_198]
    using FloorLocal.row_198

/-- Root-only marking supplies no strict flag at capacity three. -/
theorem root_marked_not_strict : ¬MarkedSum.StrictCapacity graph rootMarks ∅ 3 := by
  intro h
  have hd := h.1
  rw [root_marked_value.1] at hd
  omega

/-- Actual root selection consumes a move and changes the follower value to two. -/
theorem root_selected_value :
    Marked.gameValue graph rootMarks .dominator {root} = 2 ∧
    Marked.gameValue graph rootMarks .staller {root} = 2 := by
  simpa only [graph_eq_original, rootMarks, root, FloorLocal.marks_198]
    using FloorLocal.after_198_0

/-- Closed-neighborhood marks are the same-original-graph follower after selection. -/
theorem root_selected_eq_closed_marks (p : Player) :
    Marked.gameValue graph rootMarks p {root} =
      Marked.gameValue graph closedRootMarks p ∅ :=
  Marked.value_eq_of_white_eq graph rootMarks closedRootMarks {root} ∅ p
    (by decide +kernel)

theorem closed_root_marked_value :
    Marked.gameValue graph closedRootMarks .dominator ∅ = 2 ∧
    Marked.gameValue graph closedRootMarks .staller ∅ = 2 := by
  rw [← root_selected_eq_closed_marks, ← root_selected_eq_closed_marks]
  exact root_selected_value

/-- The same result for actual root selection from the initially unmarked graph. -/
theorem unmarked_root_selected_value :
    Marked.gameValue graph ∅ .dominator {root} = 2 ∧
    Marked.gameValue graph ∅ .staller {root} = 2 := by
  have hv (p : Player) : Marked.gameValue graph ∅ p {root} =
      Marked.gameValue graph closedRootMarks p ∅ :=
    Marked.value_eq_of_white_eq graph ∅ closedRootMarks {root} ∅ p
      (by decide +kernel)
  rw [hv, hv]
  exact closed_root_marked_value

/-- The two different marking conventions are observably different game positions. -/
theorem root_only_not_closed_value (p : Player) :
    Marked.gameValue graph rootMarks p ∅ ≠ Marked.gameValue graph closedRootMarks p ∅ := by
  cases p
  · rw [root_marked_value.1, closed_root_marked_value.1]
    decide
  · rw [root_marked_value.2, closed_root_marked_value.2]
    decide

#print axioms adjacency_agrees
#print axioms graph_isTree
#print axioms root_marked_value
#print axioms root_selected_value
#print axioms unmarked_root_selected_value
#print axioms root_marked_not_strict
#print axioms closed_root_marked_value
end IsolationGame.CentreOrdinary
