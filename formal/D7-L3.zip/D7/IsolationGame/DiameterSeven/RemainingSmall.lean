import IsolationGame.DiameterSeven.SmallCoverage
import IsolationGame.DiameterSeven.SixteenClassification
import IsolationGame.DiameterSeven.Assembly

namespace IsolationGame.DiameterSeven

universe u

/-- The eight numerical parameter triples isolated before the sharper small policies. -/
def RemainingTriple (b k e : Nat) : Prop :=
  (b=3 ∧ k=3 ∧ e=2) ∨ (b=3 ∧ k=4 ∧ e=2) ∨ (b=3 ∧ k=4 ∧ e=3) ∨
  (b=3 ∧ k=5 ∧ e=1) ∨ (b=4 ∧ k=4 ∧ e=2) ∨ (b=4 ∧ k=5 ∧ e=0) ∨
  (b=4 ∧ k=5 ∧ e=2) ∨ (b=4 ∧ k=6 ∧ e=0)

set_option maxHeartbeats 4000000 in
/-- Exhaustive arithmetic reduction using only already proved policies. -/
theorem remaining_partition {b k e n L : Nat} (hb : 2 ≤ b) (hk : b ≤ k)
    (hn : n=2+b+2*k+e) (ho : n=13 ∨ n=15 ∨ n=16 ∨ n=18)
    (hL : L ≤ envelope b k e)
    (htwo : b=2 → e ≤ 3 → L ≤ 3+min 2 (k-1))
    (hzero : b ≤ 3 → b < k → e=0 → L ≤ k+1)
    (hfail : ¬ L ≤ 3*n/7) : RemainingTriple b k e := by
  have hbmax : b ≤ 5 := by omega
  have hkmax : k ≤ 8 := by omega
  interval_cases b <;> interval_cases k <;>
    norm_num [envelope,gBound,uBound,zBound,sBound,RemainingTriple] at hL htwo hzero ⊢ <;>
    (try split_ifs at hL) <;> omega

/-- Exact proof obligation for one remaining parameter class.
This definition is not a theorem asserting the bound. -/
def ParameterBound (b k e m : Nat) : Prop :=
  ∀ {V : Type u} [Fintype V] [DecidableEq V] (G : SimpleGraph V) (hT : G.IsTree)
    (x y : V) (hc : CenterEdge G x y), G.diam=7 →
    ((DoubleRooted.allIndices x y).image (DoubleRooted.parent x y hT hc)).card=b →
    (DoubleRooted.allIndices (G := G) x y).card=k →
    (DoubleRooted.extras x y hT hc).card=e → isolationNumber G ≤ m

/-- Only the balanced two-versus-two zero-extra class remains here;
the one-versus-three class already has a real-game proof. -/
def BalancedParameterBound (k m : Nat) : Prop :=
  ∀ {V : Type u} [Fintype V] [DecidableEq V] (G : SimpleGraph V) (hT : G.IsTree)
    (x y : V) (hc : CenterEdge G x y), G.diam=7 →
    ((DoubleRooted.allIndices x y).image (DoubleRooted.parent x y hT hc)).card=4 →
    (DoubleRooted.allIndices (G := G) x y).card=k →
    (DoubleRooted.extras x y hT hc).card=0 →
    (DoubleRooted.sideParents x y hT hc x).card=2 →
    (DoubleRooted.sideParents x y hT hc y).card=2 → isolationNumber G ≤ m

/-- Named small-order obligation: order thirteen, (3,3,2). -/
def Order13_332 : Prop := ParameterBound.{u} 3 3 2 5
/-- Named small-order obligation: order fifteen, (3,4,2). -/
def Order15_342 : Prop := ParameterBound.{u} 3 4 2 6
/-- Named small-order obligation: order sixteen, (3,4,3). -/
def Order16_343 : Prop := ParameterBound.{u} 3 4 3 6
/-- Named small-order obligation: order sixteen, (3,5,1). -/
def Order16_351 : Prop := ParameterBound.{u} 3 5 1 6
/-- Named small-order obligation: order sixteen, (4,4,2). -/
def Order16_442 : Prop := ParameterBound.{u} 4 4 2 6
/-- Classification and transport obligation for T16. -/
def Order16_450Balanced : Prop := BalancedParameterBound.{u} 5 6
/-- Named small-order obligation: order eighteen, (4,5,2). -/
def Order18_452 : Prop := ParameterBound.{u} 4 5 2 7
/-- Named small-order obligation: the three balanced eighteen-vertex configurations. -/
def Order18_460Balanced : Prop := BalancedParameterBound.{u} 6 7

/-- An explicit ledger of the remaining proofs, never an axiom or instance. -/
def RemainingSmallProofs : Prop :=
  Order13_332.{u} ∧ Order15_342.{u} ∧ Order16_343.{u} ∧ Order16_351.{u} ∧
  Order16_442.{u} ∧ Order16_450Balanced.{u} ∧ Order18_452.{u} ∧ Order18_460Balanced.{u}

theorem four_zero_of_balanced {k : Nat} (hk : 5 ≤ k)
    (hbal : BalancedParameterBound.{u} k (k+1)) : ParameterBound.{u} 4 k 0 (k+1) := by
  intro V inst instD G hT x y hc hd hb hstars he
  have hmore : ((DoubleRooted.allIndices x y).image (DoubleRooted.parent x y hT hc)).card <
      (DoubleRooted.allIndices (G := G) x y).card := by omega
  have hsum := DoubleRooted.sideParents_partition x y hT hc
  have hpos := DoubleRooted.sideParents_pos x y hT hc hd
  by_cases hx : (DoubleRooted.sideParents x y hT hc x).card ≤ 1
  · have hm' : ((DoubleRooted.allIndices y x).image
        (DoubleRooted.parent y x hT (centerEdge_symm hc))).card <
        (DoubleRooted.allIndices (G := G) y x).card := by
      rw [DoubleRooted.groups_swap x y hT hc,DoubleRooted.stars_swap x y]; exact hmore
    have hx' : (DoubleRooted.sideParents y x hT (centerEdge_symm hc) x).card ≤ 1 := by
      rw [DoubleRooted.sideParents_swap x y hT hc]; exact hx
    have he' : (DoubleRooted.extras y x hT (centerEdge_symm hc)).card=0 := by
      rw [DoubleRooted.extras_swap x y hT hc]; exact he
    have hh := DoubleRooted.one_opposite_group_zero_extras y x hT (centerEdge_symm hc) hd hm' hx' he'
    simpa only [DoubleRooted.stars_swap x y,hstars] using hh
  · by_cases hy : (DoubleRooted.sideParents x y hT hc y).card ≤ 1
    · have hh := DoubleRooted.one_opposite_group_zero_extras x y hT hc hd hmore hy he
      simpa only [hstars] using hh
    · exact hbal G hT x y hc hd hb hstars he (by omega) (by omega)

/-- Assembly from the eight explicitly named parameter bounds. -/
theorem small_bound_of_remaining (h : RemainingSmallProofs.{u}) : SmallOrderBound.{u} := by
  intro V inst G hT hn3 hn18 hd
  classical
  by_cases hcovered : Fintype.card V ≤ 12 ∨ Fintype.card V=14 ∨ Fintype.card V=17
  · exact covered_small_orders G hT hd hcovered
  · have horder : Fintype.card V=13 ∨ Fintype.card V=15 ∨ Fintype.card V=16 ∨ Fintype.card V=18 := by omega
    change isolationNumber G ≤ _
    by_contra hfail
    obtain ⟨x,y,hc⟩ := exists_centerEdge hT hd
    have hb := DoubleRooted.two_groups x y hT hc hd
    have hk := DoubleRooted.groups_le_stars x y hT hc
    have hn := DoubleRooted.exact_count x y hT hc
    have hp := remaining_partition hb hk hn horder (DoubleRooted.envelope_bound x y hT hc hd)
      (fun hb he => DoubleRooted.two_groups_bound x y hT hc hd hb he)
      (fun hb hm he => DoubleRooted.few_groups_zero_extras x y hT hc hd hb hm he) hfail
    obtain ⟨h13,h15,h163,h165,h164,h16b,h184,h18b⟩ := h
    have h16 : ParameterBound.{u} 4 5 0 6 := by
      exact four_zero_of_balanced (k := 5) (by decide) h16b
    have h18 : ParameterBound.{u} 4 6 0 7 := by
      exact four_zero_of_balanced (k := 6) (by decide) h18b
    rcases hp with ⟨hb,hk,he⟩ | ⟨hb,hk,he⟩ | ⟨hb,hk,he⟩ | ⟨hb,hk,he⟩ |
      ⟨hb,hk,he⟩ | ⟨hb,hk,he⟩ | ⟨hb,hk,he⟩ | ⟨hb,hk,he⟩
    · have hh := h13 G hT x y hc hd hb hk he; omega
    · have hh := h15 G hT x y hc hd hb hk he; omega
    · have hh := h163 G hT x y hc hd hb hk he; omega
    · have hh := h165 G hT x y hc hd hb hk he; omega
    · have hh := h164 G hT x y hc hd hb hk he; omega
    · have hh := h16 G hT x y hc hd hb hk he; omega
    · have hh := h184 G hT x y hc hd hb hk he; omega
    · have hh := h18 G hT x y hc hd hb hk he; omega


/-- Direct small strategies, proved for arbitrary trees. -/
theorem order13_332 : Order13_332.{u} := by
  intro V inst instD G hT x y hc hd hb hk he
  have hh := DoubleRooted.three_groups_sparse_extras x y hT hc hd (by omega) (by omega)
  omega

theorem order15_342 : Order15_342.{u} := by
  intro V inst instD G hT x y hc hd hb hk he
  have hh := DoubleRooted.three_groups_sparse_extras x y hT hc hd (by omega) (by omega)
  omega

theorem order16_343 : Order16_343.{u} := by
  intro V inst instD G hT x y hc hd hb hk he
  have hh := DoubleRooted.three_groups_sparse_extras x y hT hc hd (by omega) (by omega)
  omega

theorem order16_351 : Order16_351.{u} := by
  intro V inst instD G hT x y hc hd hb hk he
  exact DoubleRooted.three_groups_five_stars_one_extra x y hT hc hd hb hk (by omega)

theorem order16_442 : Order16_442.{u} := by
  intro V inst instD G hT x y hc hd hb hk he
  have hh := DoubleRooted.four_groups_two_extras x y hT hc hd hb he
  omega

theorem order16_450Balanced : Order16_450Balanced.{u} := by
  intro V inst instD G hT x y hc hd hb hk he hl hr
  exact DoubleRooted.sixteen_balanced_bound x y hT hc hb hk he hl hr

theorem order18_452 : Order18_452.{u} := by
  intro V inst instD G hT x y hc hd hb hk he
  have hh := DoubleRooted.four_groups_two_extras x y hT hc hd hb he
  omega

end IsolationGame.DiameterSeven
