import IsolationGame.DiameterSeven.UniformLarge

namespace IsolationGame.DiameterSeven

universe u

/-- The exact remaining finite-order obligation. This is a proposition,
not an assumed axiom and not a proof of the finite cases. -/
def SmallOrderBound : Prop :=
  ∀ {V : Type u} [Fintype V] (T : SimpleGraph V), T.IsTree →
    3 ≤ Fintype.card V → Fintype.card V ≤ 18 → T.diam=7 →
      gameIsolationNumber T ≤ 3*Fintype.card V/7

/-- The unchanged full target. No additional hypothesis is built into it. -/
def FullDiameterSevenBound : Prop :=
  ∀ {V : Type u} [Fintype V] (T : SimpleGraph V), T.IsTree →
    3 ≤ Fintype.card V → T.diam ≤ 7 →
      gameIsolationNumber T ≤ 3*Fintype.card V/7

/-- The original assembly interface. `SmallOrders.smallOrderBound` supplies
its premise in the unconditional complete theorem. -/
theorem full_bound_of_small_orders (hsmall : SmallOrderBound.{u}) :
    FullDiameterSevenBound.{u} := by
  intro V inst T hT hn hd
  by_cases hd6 : T.diam ≤ 6
  · exact diameter_six_case T hT hn hd6
  · have hd7 : T.diam=7 := by omega
    by_cases hlarge : 19 ≤ Fintype.card V
    · exact diameter_seven_large T hT hd7 hlarge
    · exact hsmall T hT hn (by omega) hd7

end IsolationGame.DiameterSeven
