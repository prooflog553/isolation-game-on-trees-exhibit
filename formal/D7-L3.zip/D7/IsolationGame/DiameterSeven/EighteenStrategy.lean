import IsolationGame.DiameterSeven.EighteenCertificate0
import IsolationGame.DiameterSeven.EighteenCertificate1
import IsolationGame.DiameterSeven.EighteenCertificate2

namespace IsolationGame.DiameterSeven.Small

theorem E18_accounting (t : Fin 3) :
    AccountingCertificate (E18 t) (E18Rank t) .staller {0} [] := by
  apply accountingCheck_sound (E18 t) (E18Rank t) (E18Reply t) 6
  fin_cases t
  · exact E18_accounting_0
  · exact E18_accounting_1
  · exact E18_accounting_2

theorem E18_first_legal : ∀ t : Fin 3, Legal (E18 t) ∅ 0 := by decide

/-- The seven-move bound follows from the certified legal strategy and
the original six-star zeros/savings identity. -/
theorem eighteen_seven_moves (t : Fin 3) : isolationNumber (E18 t) ≤ 7 := by
  apply (isolationNumber_le_iff (E18 t) 7).mpr
  refine Or.inr ⟨0,E18_first_legal t,?_⟩
  simpa using (E18_accounting t).wins

end IsolationGame.DiameterSeven.Small
