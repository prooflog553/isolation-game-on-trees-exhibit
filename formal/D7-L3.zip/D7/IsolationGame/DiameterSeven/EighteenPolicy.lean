import IsolationGame.DiameterSeven.EighteenStructure
import IsolationGame.DiameterSeven.AccountingStrategy

namespace IsolationGame.DiameterSeven.Small

def E18Center (i : Fin 6) : Fin 18 := ⟨6+2*i.val,by omega⟩

/-- The number of actual undominated deep-star centers. Every edge-star
in the structural classification has exactly one of these six centers. -/
def E18Rank (t : Fin 3) (X : Finset (Fin 18)) : Nat :=
  (Finset.univ.filter (fun i : Fin 6 => Undominated (E18 t) X (E18Center i))).card

def E18Group (t : Fin 3) (i : Fin 6) : Fin 18 :=
  if i.val < 2 then 2
  else if i.val=2 then (if t.val=0 then 2 else 3)
  else if i.val=3 then (if t.val=2 then 4 else 3)
  else if i.val=4 then 4 else 5

def E18Count (t : Fin 3) (X : Finset (Fin 18)) (q : Fin 18) : Nat :=
  (Finset.univ.filter (fun i : Fin 6 => E18Group t i=q ∧ Undominated (E18 t) X (E18Center i))).card

/-- Largest surviving group, with the fixed order 2,3,4,5 to break ties. -/
def E18Largest (t : Fin 3) (X : Finset (Fin 18)) : Fin 18 :=
  let a := E18Count t X 2
  let b := E18Count t X 3
  let c := E18Count t X 4
  let d := E18Count t X 5
  if b ≤ a ∧ c ≤ a ∧ d ≤ a then 2
  else if c ≤ b ∧ d ≤ b then 3
  else if d ≤ c then 4 else 5

/-- Section 8's actual strategy. In the balanced case the closed double
group is cleared immediately after its leaf is played. On the later
one-unit hit to A, clearing the closed singleton makes root 1 illegal. -/
def E18Reply (t : Fin 3) (X : Finset (Fin 18)) : Fin 18 :=
  if t.val=2 ∧ X.card=2 ∧ (E18Count t X 4=2 ∨ 13∈X ∨ 15∈X) then 4
  else if t.val=2 ∧ (13∈X ∨ 15∈X) ∧ 4∈X ∧ E18Count t X 2=1 ∧ E18Count t X 5=1 then 5
  else E18Largest t X

theorem E18_rank_initial : ∀ t : Fin 3, E18Rank t {0}=6 := by decide

theorem E18_rank_mono (t : Fin 3) {X Y : Finset (Fin 18)} (h : X⊆Y) :
    E18Rank t Y ≤ E18Rank t X := by
  apply Finset.card_le_card
  intro i hi
  exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,undominated_anti (E18 t) h (Finset.mem_filter.mp hi).2⟩

/-- Named state changes keep large certificates shared instead of reducing
an entire strategy tree again at each use. -/
theorem E18_check_after {t : Fin 3} {m : Nat} {p : Player}
    {X Y : Finset (Fin 18)} {v : Fin 18} {xs : List Nat} {d : Nat}
    (hset : insert v X=Y) (hdrop : E18Rank t X-E18Rank t Y=d)
    (h : accountingCheck (E18 t) (E18Rank t) (E18Reply t) m p Y (d::xs)=true) :
    accountingCheck (E18 t) (E18Rank t) (E18Reply t) m p (insert v X)
      ((E18Rank t X-E18Rank t (insert v X))::xs)=true := by
  rwa [hset,hdrop]

end IsolationGame.DiameterSeven.Small
