import IsolationGame.DiameterSeven.FiveStars
import IsolationGame.DiameterSeven.Sixteen

namespace IsolationGame.DiameterSeven

variable {V I : Type*} [Fintype V] [DecidableEq V] [DecidableEq I]
variable {G : SimpleGraph V}

/-- Five objects in four fibers consist of a double fiber and three
single fibers. The displayed cover is the part used by the graph transport. -/
theorem five_four_cover (R : Finset I) (f : I → V)
    (hk : R.card=5) (hb : (R.image f).card=4) :
    ∃ i j a b c, R={i,j,a,b,c} ∧ f i=f j := by
  classical
  obtain ⟨i,hi,j,hj,hij,hf⟩ := Finset.exists_ne_map_eq_of_card_lt_of_maps_to
    (by omega : (R.image f).card < R.card) (fun z hz => Finset.mem_image.mpr ⟨z,hz,rfl⟩)
  have hsub : ({i,j} : Finset I) ⊆ R := by simp [Finset.insert_subset_iff,hi,hj]
  have hcard : (R \ {i,j}).card=3 := by rw [Finset.card_sdiff hsub]; simp [hk,hij]
  obtain ⟨a,b,c,_,_,_,habc⟩ := Finset.card_eq_three.mp hcard
  refine ⟨i,j,a,b,c,?_,hf⟩
  have hh := Finset.union_sdiff_of_subset hsub
  rw [habc] at hh
  calc
    R={i,j} ∪ {a,b,c} := hh.symm
    _={i,j,a,b,c} := by ext z; simp [or_assoc,or_comm,or_left_comm]

def T16Label (r s p c l q d m t e n u f g h k : V) (z : Fin 16) : V :=
  match z.val with
  | 0 => r | 1 => s | 2 => p | 3 => c | 4 => l | 5 => q
  | 6 => d | 7 => m | 8 => t | 9 => e | 10 => n | 11 => u
  | 12 => f | 13 => g | 14 => h | _ => k

set_option maxHeartbeats 4000000 in
theorem T16_iso_of_cover (hT : G.IsTree) (hn : Fintype.card V=16)
    (A : StarSystem G I) (R : Finset I) (r s : V) (i j a b c : I)
    (hcover : insert s (A.countedVertices r R)=Finset.univ)
    (hR : R={i,j,a,b,c}) (hij : A.parent i=A.parent j) (hrs : G.Adj r s)
    (hi : G.Adj (A.parent i) r) (ha : G.Adj (A.parent a) r)
    (hb : G.Adj (A.parent b) s) (hc : G.Adj (A.parent c) s) :
    Nonempty (Small.T16 ≃g G) := by
  classical
  let f := T16Label r s (A.parent a) (A.center a) (A.chosenLeaf a)
    (A.parent b) (A.center b) (A.chosenLeaf b)
    (A.parent c) (A.center c) (A.chosenLeaf c)
    (A.parent i) (A.center i) (A.chosenLeaf i) (A.center j) (A.chosenLeaf j)
  have hsurj : Function.Surjective f := by
    intro v
    have hv : v∈insert s (A.countedVertices r R) := by rw [hcover]; simp
    simp only [StarSystem.countedVertices,hR,Finset.image_insert,Finset.image_singleton,
      Finset.mem_insert,Finset.mem_singleton,Finset.mem_union,← hij] at hv
    rcases hv with rfl | rfl | (rfl | rfl | rfl | rfl | rfl) |
      (rfl | rfl | rfl | rfl | rfl) | (rfl | rfl | rfl | rfl | rfl)
    all_goals first
      | exact ⟨0,rfl⟩ | exact ⟨1,rfl⟩ | exact ⟨2,rfl⟩ | exact ⟨3,rfl⟩
      | exact ⟨4,rfl⟩ | exact ⟨5,rfl⟩ | exact ⟨6,rfl⟩ | exact ⟨7,rfl⟩
      | exact ⟨8,rfl⟩ | exact ⟨9,rfl⟩ | exact ⟨10,rfl⟩ | exact ⟨11,rfl⟩
      | exact ⟨12,rfl⟩ | exact ⟨13,rfl⟩ | exact ⟨14,rfl⟩ | exact ⟨15,rfl⟩
  have hbij : Function.Bijective f :=
    (Fintype.bijective_iff_surjective_and_card f).mpr ⟨hsurj,by simp [hn]⟩
  have pc (z : I) : G.Adj (A.parent z) (A.center z) :=
    (A.adj_iff z _ (A.center_mem z) _).mpr (Or.inr (Or.inr ⟨rfl,rfl⟩))
  have cl (z : I) : G.Adj (A.center z) (A.chosenLeaf z) :=
    (A.adj_chosenLeaf z _).mpr rfl
  have pij : G.Adj (A.parent i) (A.center j) := hij ▸ pc j
  have he : ∀ u v, Small.T16.Adj u v → G.Adj (f u) (f v) := by
    intro u v
    fin_cases u <;> fin_cases v <;>
      norm_num [Small.T16,edgeGraph,SimpleGraph.fromRel_adj,f,T16Label]
    all_goals first
      | exact hrs | exact hrs.symm | exact hi | exact hi.symm
      | exact ha | exact ha.symm | exact hb | exact hb.symm | exact hc | exact hc.symm
      | exact pc _ | exact (pc _).symm | exact cl _ | exact (cl _).symm
      | exact pij | exact pij.symm
  have hconn : Small.T16.Connected := connected_of_lower_labels (by decide) _ (by decide)
  exact ⟨treeIsoOfHom hT hconn (Equiv.ofBijective f hbij) he⟩

namespace DoubleRooted

variable (x y : V) (hT : G.IsTree) (hc : CenterEdge G x y)

set_option maxHeartbeats 4000000 in
theorem double_group_side_split (i j a b c : Index (G := G) x y)
    (hR : allIndices x y={i,j,a,b,c}) (hij : parent x y hT hc i=parent x y hT hc j)
    (hi : G.Adj (parent x y hT hc i) x)
    (hl : (sideParents x y hT hc x).card=2)
    (hr : (sideParents x y hT hc y).card=2) :
    ∃ a b c : Index (G := G) x y, allIndices x y={i,j,a,b,c} ∧
      G.Adj (parent x y hT hc a) x ∧ G.Adj (parent x y hT hc b) y ∧
      G.Adj (parent x y hT hc c) y := by
  classical
  have hiy : ¬ G.Adj y (parent x y hT hc i) :=
    fun h => parent_not_both_roots x y hT hc i ⟨hi,h.symm⟩
  have hRa : allIndices x y={i,j,b,a,c} := by ext z; simp [hR,or_comm,or_left_comm,or_assoc]
  have hRb : allIndices x y={i,j,c,a,b} := by ext z; simp [hR,or_comm,or_left_comm,or_assoc]
  have not_other (z : Index (G := G) x y) :
      (G.Adj (parent x y hT hc z) x → ¬ G.Adj y (parent x y hT hc z)) ∧
      (G.Adj (parent x y hT hc z) y → ¬ G.Adj x (parent x y hT hc z)) := by
    exact ⟨fun hx hy => parent_not_both_roots x y hT hc z ⟨hx,hy.symm⟩,
      fun hy hx => parent_not_both_roots x y hT hc z ⟨hx.symm,hy⟩⟩
  rcases parent_adj_root x y hT hc a with ha | ha <;>
    rcases parent_adj_root x y hT hc b with hb | hb <;>
    rcases parent_adj_root x y hT hc c with hcc | hcc
  all_goals first
    | exact ⟨a,b,c,hR,ha,hb,hcc⟩
    | exact ⟨b,a,c,hRa,hb,ha,hcc⟩
    | exact ⟨c,a,b,hRb,hcc,ha,hb⟩
    | simp [sideParents,hR,Finset.filter_insert,Finset.filter_singleton,← hij,hi.symm,hiy,ha.symm,hb.symm,hcc.symm,
        (not_other a).1,(not_other a).2,(not_other b).1,(not_other b).2,
        (not_other c).1,(not_other c).2,ha,hb,hcc] at hl hr

set_option maxHeartbeats 4000000 in
/-- Exhaustive structure classification of the balanced (4,5,0) family.
The double-group side is the side of T16's root 0; the retained marked
root therefore remains the original single-arm H.x. -/
theorem sixteen_balanced_iso (hb : ((allIndices x y).image (parent x y hT hc)).card=4)
    (hk : (allIndices (G := G) x y).card=5) (he : (extras x y hT hc).card=0)
    (hl : (sideParents x y hT hc x).card=2)
    (hr : (sideParents x y hT hc y).card=2) : Nonempty (Small.T16 ≃g G) := by
  classical
  let A := system x y hT hc
  let R := allIndices (G := G) x y
  have hn : Fintype.card V=16 := by have hh := exact_count x y hT hc; omega
  have hcover : insert y (A.countedVertices x R)=Finset.univ := cover_of_zero_extras x y hT hc he
  obtain ⟨i,j,a,b,c,hR,hij⟩ := five_four_cover (allIndices x y) (parent x y hT hc) hk hb
  rcases parent_adj_root x y hT hc i with hi | hi
  · obtain ⟨a,b,c,hR,ha,hb,hcc⟩ := double_group_side_split x y hT hc i j a b c hR hij hi hl hr
    exact T16_iso_of_cover hT hn A R x y i j a b c hcover hR hij hc.1 hi ha hb hcc
  · let sw := swapIndex (G := G) x y
    have hR' : allIndices (G := G) y x={sw i,sw j,sw a,sw b,sw c} := by
      ext z
      have hmem : sw.symm z∈allIndices (G := G) x y := by simp [allIndices]
      simp only [hR,Finset.mem_insert,Finset.mem_singleton] at hmem
      simp only [allIndices,Finset.mem_univ,true_iff,Finset.mem_insert,Finset.mem_singleton]
      rcases hmem with h | h | h | h | h <;>
        first | exact Or.inl (by simpa using congrArg sw h)
              | exact Or.inr (Or.inl (by simpa using congrArg sw h))
              | exact Or.inr (Or.inr (Or.inl (by simpa using congrArg sw h)))
              | exact Or.inr (Or.inr (Or.inr (Or.inl (by simpa using congrArg sw h))))
              | exact Or.inr (Or.inr (Or.inr (Or.inr (by simpa using congrArg sw h))))
    have hp (z : Index (G := G) x y) : parent y x hT (centerEdge_symm hc) (sw z)=A.parent z :=
      parent_swap x y hT hc z
    obtain ⟨a',b',c',hR'',ha,hb',hcc⟩ := double_group_side_split y x hT (centerEdge_symm hc)
      (sw i) (sw j) (sw a) (sw b) (sw c) hR' (by simpa only [hp] using hij)
      (by simpa only [hp] using hi) (by rw [sideParents_swap]; exact hr) (by rw [sideParents_swap]; exact hl)
    have he' : (extras y x hT (centerEdge_symm hc)).card=0 := by rw [extras_swap]; exact he
    exact T16_iso_of_cover hT hn (system y x hT (centerEdge_symm hc)) (allIndices y x)
      y x (sw i) (sw j) a' b' c' (cover_of_zero_extras y x hT (centerEdge_symm hc) he')
      hR'' (by change parent y x hT (centerEdge_symm hc) (sw i)=parent y x hT (centerEdge_symm hc) (sw j)
               simpa only [hp] using hij) hc.1.symm
      (by change G.Adj (parent y x hT (centerEdge_symm hc) (sw i)) y
          simpa only [hp] using hi) ha hb' hcc

theorem sixteen_balanced_bound (hb : ((allIndices x y).image (parent x y hT hc)).card=4)
    (hk : (allIndices (G := G) x y).card=5) (he : (extras x y hT hc).card=0)
    (hl : (sideParents x y hT hc x).card=2)
    (hr : (sideParents x y hT hc y).card=2) : isolationNumber G ≤ 6 := by
  obtain ⟨e⟩ := sixteen_balanced_iso x y hT hc hb hk he hl hr
  exact isolation_bound_relabel Small.T16 G e.toEquiv (fun _ _ => e.map_rel_iff) Small.sixteen_six_moves

end DoubleRooted
end IsolationGame.DiameterSeven
