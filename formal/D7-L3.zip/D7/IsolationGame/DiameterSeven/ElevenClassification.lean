import IsolationGame.DiameterSeven.ZeroExtras

namespace IsolationGame.DiameterSeven

variable {V I : Type*} [Fintype V] [DecidableEq V] [DecidableEq I]
variable {G : SimpleGraph V}

def HLabel (r s p c l q d m t e n : V) (u : Fin 11) : V :=
  match u.val with
  | 0 => r | 1 => s | 2 => p | 3 => c | 4 => l | 5 => q
  | 6 => d | 7 => m | 8 => t | 9 => e | _ => n

set_option maxHeartbeats 2000000 in
/-- A covering by three length-three arms, with the fixed one-arm/two-arm
root assignment, gives the original labelled H. -/
theorem H_iso_of_cover (hT : G.IsTree) (hn : Fintype.card V=11)
    (A : StarSystem G I) (R : Finset I) (r s : V) (i j k : I)
    (hcover : insert s (A.countedVertices r R)=Finset.univ)
    (hR : R={i,j,k}) (hrs : G.Adj r s)
    (hi : G.Adj (A.parent i) r) (hj : G.Adj (A.parent j) s)
    (hk : G.Adj (A.parent k) s) : Nonempty (Small.H ≃g G) := by
  classical
  let f := HLabel r s (A.parent i) (A.center i) (A.chosenLeaf i)
    (A.parent j) (A.center j) (A.chosenLeaf j)
    (A.parent k) (A.center k) (A.chosenLeaf k)
  have hsurj : Function.Surjective f := by
    intro v
    have hv : v∈insert s (A.countedVertices r R) := by rw [hcover]; simp
    simp only [StarSystem.countedVertices,hR,Finset.image_insert,Finset.image_singleton,
      Finset.mem_insert,Finset.mem_singleton,Finset.mem_union] at hv
    rcases hv with rfl | rfl | (rfl | rfl | rfl) | (rfl | rfl | rfl) | (rfl | rfl | rfl)
    all_goals first
      | exact ⟨0,rfl⟩ | exact ⟨1,rfl⟩ | exact ⟨2,rfl⟩ | exact ⟨3,rfl⟩
      | exact ⟨4,rfl⟩ | exact ⟨5,rfl⟩ | exact ⟨6,rfl⟩ | exact ⟨7,rfl⟩
      | exact ⟨8,rfl⟩ | exact ⟨9,rfl⟩ | exact ⟨10,rfl⟩
  have hbij : Function.Bijective f :=
    (Fintype.bijective_iff_surjective_and_card f).mpr ⟨hsurj,by simp [hn]⟩
  have pc (a : I) : G.Adj (A.parent a) (A.center a) :=
    (A.adj_iff a _ (A.center_mem a) _).mpr (Or.inr (Or.inr ⟨rfl,rfl⟩))
  have cl (a : I) : G.Adj (A.center a) (A.chosenLeaf a) :=
    (A.adj_chosenLeaf a _).mpr rfl
  have he : ∀ u v, Small.H.Adj u v → G.Adj (f u) (f v) := by
    intro u v
    fin_cases u <;> fin_cases v <;>
      norm_num [Small.H,edgeGraph,SimpleGraph.fromRel_adj,f,HLabel]
    all_goals first
      | exact hrs | exact hrs.symm | exact hi | exact hi.symm
      | exact hj | exact hj.symm | exact hk | exact hk.symm
      | exact pc _ | exact (pc _).symm | exact cl _ | exact (cl _).symm
  exact ⟨treeIsoOfHom hT Small.H_connected (Equiv.ofBijective f hbij) he⟩

namespace DoubleRooted

variable (x y : V) (hT : G.IsTree) (hc : CenterEdge G x y)

/-- The whole eleven-vertex zero-surplus, three-star parameter class is H.
The isomorphism always maps H.x to the single-arm root. -/
theorem eleven_H_iso (hd : G.diam=7) (hn : Fintype.card V=11)
    (hk : (allIndices (G := G) x y).card=3)
    (he : (extras x y hT hc).card=0) : Nonempty (Small.H ≃g G) := by
  classical
  let A := system x y hT hc
  let R := allIndices (G := G) x y
  have hcover : insert y (A.countedVertices x R)=Finset.univ :=
    cover_of_zero_extras x y hT hc he
  obtain ⟨i,j,k,hR,hs⟩ := three_stars_side_split x y hT hc hd hk
  rcases hs with ⟨hi,hj,hk⟩ | ⟨hi,hj,hk⟩
  · exact H_iso_of_cover hT hn A R x y i j k hcover hR hc.1 hi hj hk
  · have hcover' : insert x (A.countedVertices y R)=Finset.univ := by
      simpa only [StarSystem.countedVertices,Finset.insert_comm] using hcover
    exact H_iso_of_cover hT hn A R y x i j k hcover' hR hc.1.symm hi hj hk

theorem eleven_H_bound (hd : G.diam=7) (hn : Fintype.card V=11)
    (hk : (allIndices (G := G) x y).card=3)
    (he : (extras x y hT hc).card=0) : isolationNumber G ≤ 4 := by
  obtain ⟨e⟩ := eleven_H_iso x y hT hc hd hn hk he
  exact isolation_bound_relabel Small.H G e.toEquiv
    (fun _ _ => e.map_rel_iff) Small.H_four_moves

end DoubleRooted

end IsolationGame.DiameterSeven
