import IsolationGame.DiameterSeven.SparseExtras

namespace IsolationGame.DiameterSeven.DoubleRooted

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V} (x y : V) (hT : G.IsTree) (hc : CenterEdge G x y)

theorem no_shallow_one_extra (he : (extras x y hT hc).card ≤ 1) (r : V) :
    ¬ ShallowOn x y hT hc r := by
  classical
  intro hsh
  obtain ⟨q,w,_,hq,_,hw,hqe,hwe⟩ := shallow_cost x y hT hc hsh
  have hqw : q=w := Finset.card_le_one.mp he q hqe w hwe
  rw [hqw] at hq
  omega

set_option maxHeartbeats 2000000 in
/-- The three-group/five-star transition. A short-only gate is allowed:
after its selection the two remaining groups have Staller bound three. -/
theorem five_stars_one_opposite (hd : G.diam=7)
    (hb : ((allIndices x y).image (parent x y hT hc)).card=3)
    (hk : (allIndices (G := G) x y).card=5)
    (hsh : ¬ ShallowOn x y hT hc y)
    (hone : (sideParents x y hT hc y).card ≤ 1) : isolationNumber G ≤ 6 := by
  classical
  let A := system x y hT hc
  let R := allIndices (G := G) x y
  change (A.groups R).card=3 at hb
  change R.card=5 at hk
  obtain ⟨j,hj⟩ := sideParents_unique x y hT hc y (Or.inr rfl) hd hone
  let q := A.parent j
  have hgate {X : Finset V} (hx : x∈X) :
      ∀ u, G.Adj y u → White G X u → u=q := by
    intro u hyu hu
    obtain ⟨i,hi⟩ := white_gate_parent x y hT hc hsh hx hyu hu
    exact hi.symm.trans (hj i (hi ▸ hyu.symm))
  have hxlegal : Legal G ∅ x := by
    refine ⟨x,Or.inl rfl,?_,y,hc.1,?_⟩ <;> simp [Undominated,Dominated]
  apply (isolationNumber_le_iff G 6).mpr
  refine Or.inr ⟨x,hxlegal,Or.inr ?_⟩
  intro v hv
  let X : Finset V := {v,x}
  have hxX : x∈X := by simp [X]
  have hQ : survivors x y X = A.remainingAfter R v := by
    rw [show X=insert v {x} from rfl,survivors_after x y hT hc,survivors_first x y hT hc]
  by_cases hvy : v=y
  · subst v
    have hrep : A.Represents R {y,x} := by
      simpa only [Finset.pair_comm] using both_roots_represents x y hT hc
    apply (A.strategy_equivalence hrep 4 .dominator).mpr
    have hh := A.dominator_saved R (by omega)
    simpa [hk] using hh
  · by_cases hhit : ∃ i∈R, Closed G v (A.center i)
    · have hQcard : (survivors (G := G) x y X).card ≤ 4 := by
        rw [hQ]
        have hh := A.hit_card_drop hhit
        omega
      by_cases hy : Legal G X y
      · obtain ⟨hql,hyno⟩ := unique_gate_reply y ⟨x,hxX,Or.inr hc.1⟩ hy (hgate hxX)
        refine Or.inr ⟨q,hql,?_⟩
        have hrep := represents_survivors x y hT hc
          (selected_not_legal G (Finset.mem_insert_of_mem hxX)) hyno
        have hbnd := parent_selected_bounds x y hT hc j (Finset.mem_insert_self q X)
        have hgc : (A.groups (survivors x y (insert q X))).card ≤ 2 := by
          have hh : (A.groups (survivors x y (insert q X))).card ≤ (A.groups R).card-1 := hbnd.1
          omega
        have hkc : (survivors (G := G) x y (insert q X)).card ≤ 4 :=
          (Finset.card_le_card (survivors_mono x y (Finset.subset_insert q X))).trans hQcard
        apply (A.strategy_equivalence hrep 3 .staller).mpr
        have hh := A.staller_survival hgc hkc
        simpa [sBound] using hh
      · have hrep := represents_survivors x y hT hc (selected_not_legal G hxX) hy
        apply (A.strategy_equivalence hrep 4 .dominator).mpr
        exact A.wins_of_controlled_bound _ _ _ (fun _ ht => (ht.units_bound A).trans hQcard)
    · have hhit' : ¬ ∃ i : Index (G := G) x y, Closed G v i.val := by
        rintro ⟨i,hi⟩
        exact hhit ⟨i,by simp [R,allIndices],hi⟩
      obtain ⟨w,hyw,hw,hvw⟩ := zero_hit_opens_gate x y hT hc hsh hv hvy hhit'
      have hwq := hgate (X := {x}) (by simp) w hyw hw
      have hy : ¬ Legal G X y := by
        rintro ⟨u,hu,huw⟩
        have hyd : Dominated G X y := ⟨x,hxX,Or.inr hc.1⟩
        have hyu := hu.resolve_left (fun h => huw.1 (h ▸ hyd))
        have huq := hgate hxX u hyu huw
        exact huw.1 ⟨v,by simp [X],(huq.trans hwq.symm) ▸ hvw⟩
      have hQR : survivors x y X=R := by
        rw [hQ]
        ext i
        simp only [StarSystem.remainingAfter,Finset.mem_filter]
        exact ⟨And.left,fun hi => ⟨hi,fun hclose => hhit ⟨i,hi,hclose⟩⟩⟩
      have hrep := represents_survivors x y hT hc (selected_not_legal G hxX) hy
      rw [hQR] at hrep
      apply (A.strategy_equivalence hrep 4 .dominator).mpr
      have hh := A.dominator_saved R (by omega)
      simpa [hk] using hh

/-- The (3,5,1) exceptional parameter family, for arbitrary vertex labels. -/
theorem three_groups_five_stars_one_extra (hd : G.diam=7)
    (hb : ((allIndices x y).image (parent x y hT hc)).card=3)
    (hk : (allIndices (G := G) x y).card=5)
    (he : (extras x y hT hc).card ≤ 1) : isolationNumber G ≤ 6 := by
  have hsum := sideParents_partition x y hT hc
  have hpos := sideParents_pos x y hT hc hd
  have hone : (sideParents x y hT hc x).card ≤ 1 ∨ (sideParents x y hT hc y).card ≤ 1 := by omega
  rcases hone with hx | hy
  · apply five_stars_one_opposite y x hT (centerEdge_symm hc) hd
    · rw [groups_swap x y hT hc]; exact hb
    · rw [stars_swap x y]; exact hk
    · apply no_shallow_one_extra y x hT (centerEdge_symm hc) _ x
      rw [extras_swap x y hT hc]; exact he
    · rw [sideParents_swap x y hT hc]; exact hx
  · exact five_stars_one_opposite x y hT hc hd hb hk (no_shallow_one_extra x y hT hc he y) hy

end IsolationGame.DiameterSeven.DoubleRooted
