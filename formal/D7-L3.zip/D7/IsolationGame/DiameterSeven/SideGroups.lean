import IsolationGame.DiameterSeven.Swap

namespace IsolationGame.DiameterSeven.DoubleRooted

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V} (x y : V) (hT : G.IsTree) (hc : CenterEdge G x y)

noncomputable def sideParents (r : V) : Finset V := by
  classical
  exact ((allIndices x y).image (parent x y hT hc)).filter (G.Adj r)

theorem sideParents_partition :
    (sideParents x y hT hc x).card+(sideParents x y hT hc y).card =
      ((allIndices x y).image (parent x y hT hc)).card := by
  classical
  have hu : sideParents x y hT hc x ∪ sideParents x y hT hc y =
      (allIndices x y).image (parent x y hT hc) := by
    ext q
    simp only [sideParents,Finset.mem_union,Finset.mem_filter]
    constructor
    · tauto
    · intro hq
      obtain ⟨i,hi,rfl⟩ := Finset.mem_image.mp hq
      have hmem : parent x y hT hc i∈(allIndices x y).image (parent x y hT hc) :=
        Finset.mem_image.mpr ⟨i,hi,rfl⟩
      rcases parent_adj_root x y hT hc i with hx | hy
      · exact Or.inl ⟨hmem,hx.symm⟩
      · exact Or.inr ⟨hmem,hy.symm⟩
  have hdis : Disjoint (sideParents x y hT hc x) (sideParents x y hT hc y) := by
    apply Finset.disjoint_left.mpr
    intro q hx hy
    obtain ⟨hq,hx⟩ := Finset.mem_filter.mp hx
    obtain ⟨_,hy⟩ := Finset.mem_filter.mp hy
    obtain ⟨i,_,rfl⟩ := Finset.mem_image.mp hq
    exact parent_not_both_roots x y hT hc i ⟨hx.symm,hy.symm⟩
  rw [← Finset.card_union_of_disjoint hdis,hu]

theorem sideParents_pos (hd : G.diam=7) :
    1 ≤ (sideParents x y hT hc x).card ∧ 1 ≤ (sideParents x y hT hc y).card := by
  classical
  obtain ⟨⟨i,hi⟩,⟨j,hj⟩⟩ := parent_side_witnesses x y hT hc hd
  constructor
  · apply Finset.card_pos.mpr
    exact ⟨parent x y hT hc i,Finset.mem_filter.mpr
      ⟨Finset.mem_image.mpr ⟨i,by simp [allIndices],rfl⟩,hi.symm⟩⟩
  · apply Finset.card_pos.mpr
    exact ⟨parent x y hT hc j,Finset.mem_filter.mpr
      ⟨Finset.mem_image.mpr ⟨j,by simp [allIndices],rfl⟩,hj.symm⟩⟩

theorem sideParents_unique (r : V) (hr : r=x ∨ r=y) (hd : G.diam=7)
    (hcard : (sideParents x y hT hc r).card ≤ 1) :
    ∃ j : Index (G := G) x y, ∀ i : Index (G := G) x y,
      G.Adj (parent x y hT hc i) r → parent x y hT hc i=parent x y hT hc j := by
  classical
  have hex : ∃ j : Index (G := G) x y, G.Adj (parent x y hT hc j) r := by
    rcases hr with rfl | rfl
    · exact (parent_side_witnesses _ _ hT hc hd).1
    · exact (parent_side_witnesses _ _ hT hc hd).2
  obtain ⟨j,hj⟩ := hex
  refine ⟨j,fun i hi => ?_⟩
  apply Finset.card_le_one.mp hcard
  · exact Finset.mem_filter.mpr ⟨Finset.mem_image.mpr ⟨i,by simp [allIndices],rfl⟩,hi.symm⟩
  · exact Finset.mem_filter.mpr ⟨Finset.mem_image.mpr ⟨j,by simp [allIndices],rfl⟩,hj.symm⟩

theorem sideParents_swap (r : V) :
    sideParents y x hT (centerEdge_symm hc) r=sideParents x y hT hc r := by
  unfold sideParents
  rw [groups_swap x y hT hc]

end IsolationGame.DiameterSeven.DoubleRooted
