import IsolationGame.DiameterSeven.Arithmetic
import IsolationGame.Game

namespace IsolationGame.DiameterSeven

variable {V : Type*} [DecidableEq V] (G : SimpleGraph V)

/-- A strategy tree whose entries are the actual decreases of a specified
star counter. All Staller moves are legal moves in the original game.
Credits are checked only at terminal leaves, once per recorded move. -/
inductive AccountingCertificate (rank : Finset V → Nat) : Player → Finset V → List Nat → Prop
  | done {p X xs} : Terminal G X → xs.sum ≤ 6 → zeros xs ≤ savings xs →
      AccountingCertificate rank p X xs
  | dominator {X xs v} : Legal G X v →
      AccountingCertificate rank .staller (insert v X) ((rank X-rank (insert v X))::xs) →
      AccountingCertificate rank .dominator X xs
  | staller {X xs} : ¬ Terminal G X →
      (∀ v, Legal G X v →
        AccountingCertificate rank .dominator (insert v X) ((rank X-rank (insert v X))::xs)) →
      AccountingCertificate rank .staller X xs

namespace AccountingCertificate

variable {G} {rank : Finset V → Nat}

theorem prefix_length {p X xs} (h : AccountingCertificate G rank p X xs) : xs.length ≤ 6 := by
  induction h with
  | done _ hs hp => have hh := six_stars_settled hs hp; omega
  | dominator hl h ih => simpa using Nat.le_of_succ_le ih
  | staller hn h ih =>
    obtain ⟨v,hv⟩ := exists_legal_of_not_terminal G hn
    have hh := ih v hv
    simpa using Nat.le_of_succ_le hh

/-- The numerical bound follows from the original zeros/savings accounting,
not from an assumed game length or a discarded blue boundary. -/
theorem wins {p X xs} (h : AccountingCertificate G rank p X xs) :
    WinsWithin G (6-xs.length) p X := by
  induction h with
  | done ht hs hp => exact terminal_wins G ht _ _
  | @dominator X xs v hl hc ih =>
    have hp := hc.prefix_length
    have heq : 6-xs.length=(6-((rank X-rank (insert v X))::xs).length)+1 := by
      simp only [List.length_cons] at *
      omega
    rw [heq]
    exact Or.inr ⟨v,hl,ih⟩
  | @staller X xs hn hc ih =>
    obtain ⟨v,hv⟩ := exists_legal_of_not_terminal G hn
    have hp := (hc v hv).prefix_length
    have hpos : xs.length < 6 := by simpa only [List.length_cons] using hp
    have heq : 6-xs.length=(5-xs.length)+1 := by omega
    rw [heq]
    refine Or.inr (fun w hw => ?_)
    have hh := ih w hw
    convert hh using 1 <;> simp only [List.length_cons] <;> omega

end AccountingCertificate

variable [Fintype V] [DecidableRel G.Adj]

/-- Executable checker for a specified strategy. Its soundness constructs
the preceding certificate with actual legal steps and actual star drops. -/
def accountingCheck (rank : Finset V → Nat) (reply : Finset V → V) :
    Nat → Player → Finset V → List Nat → Bool
  | 0, _, X, xs => decide (Terminal G X ∧ xs.sum ≤ 6 ∧ zeros xs ≤ savings xs)
  | m+1, .dominator, X, xs =>
    if Terminal G X then decide (xs.sum ≤ 6 ∧ zeros xs ≤ savings xs)
    else decide (Legal G X (reply X)) &&
      accountingCheck rank reply m .staller (insert (reply X) X)
        ((rank X-rank (insert (reply X) X))::xs)
  | m+1, .staller, X, xs =>
    if Terminal G X then decide (xs.sum ≤ 6 ∧ zeros xs ≤ savings xs)
    else decide (∀ v, Legal G X v → accountingCheck rank reply m .dominator
      (insert v X) ((rank X-rank (insert v X))::xs)=true)

theorem accountingCheck_sound (rank : Finset V → Nat) (reply : Finset V → V)
    (m : Nat) (p : Player) (X : Finset V) (xs : List Nat)
    (h : accountingCheck G rank reply m p X xs=true) :
    AccountingCertificate G rank p X xs := by
  induction m generalizing p X xs with
  | zero =>
    have hh : Terminal G X ∧ xs.sum ≤ 6 ∧ zeros xs ≤ savings xs := of_decide_eq_true h
    exact .done hh.1 hh.2.1 hh.2.2
  | succ m ih =>
    cases p <;> simp only [accountingCheck] at h
    · split_ifs at h with ht
      · have hh : xs.sum ≤ 6 ∧ zeros xs ≤ savings xs := of_decide_eq_true h
        exact .done ht hh.1 hh.2
      · obtain ⟨hl,hc⟩ := Bool.and_eq_true_iff.mp h
        exact .dominator (of_decide_eq_true hl) (ih _ _ _ hc)
    · split_ifs at h with ht
      · have hh : xs.sum ≤ 6 ∧ zeros xs ≤ savings xs := of_decide_eq_true h
        exact .done ht hh.1 hh.2
      · have hh : ∀ v, Legal G X v → accountingCheck G rank reply m .dominator
            (insert v X) ((rank X-rank (insert v X))::xs)=true := of_decide_eq_true h
        exact .staller ht (fun v hv => ih _ _ _ (hh v hv))

end IsolationGame.DiameterSeven
