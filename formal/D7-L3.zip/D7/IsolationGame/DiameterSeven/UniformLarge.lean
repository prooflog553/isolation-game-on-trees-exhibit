import IsolationGame.DiameterSeven.Transition

namespace IsolationGame.StarSystem

open DiameterSeven

variable {V I : Type*} [Fintype V] [DecidableEq V] [DecidableEq I]
variable {G : SimpleGraph V} (A : StarSystem G I)

theorem remainingAfter_subset (R : Finset I) (v : V) : A.remainingAfter R v ⊆ R := by
  intro i hi
  simp only [remainingAfter,Finset.mem_filter] at hi
  exact hi.1

theorem hit_card_drop {R : Finset I} {v : V}
    (hhit : ∃ i∈R, Closed G v (A.center i)) : (A.remainingAfter R v).card < R.card := by
  classical
  obtain ⟨i,hi,hc⟩ := hhit
  apply Finset.card_lt_card
  refine ⟨A.remainingAfter_subset R v,?_⟩
  intro hback
  have h := hback hi
  simp only [remainingAfter,Finset.mem_filter] at h
  exact h.2 hc

/-- Close the transition on the next Dominator turn, including the illegal
second-root branch. The survivor bounds apply before this turn. -/
theorem after_root_reply {R : Finset I} {r s v : V}
    (hbase : A.Represents R {r,s}) {b k : Nat}
    (hb : (A.groups (A.remainingAfter R v)).card ≤ b)
    (hk : (A.remainingAfter R v).card ≤ k) :
    gameValue G .dominator {v,r} ≤ 1+sBound b k := by
  classical
  let Q := A.remainingAfter R v
  have boundS {P : Finset I} {X : Finset V} (hsub : P ⊆ Q) (hrep : A.Represents P X) :
      IsolationGame.WinsWithin G (sBound b k) .staller X := by
    apply (A.strategy_equivalence hrep _ _).mpr
    exact A.staller_survival
      ((Finset.card_le_card (A.groups_mono hsub)).trans hb)
      ((Finset.card_le_card hsub).trans hk)
  have hclosed : A.Represents Q {s,v,r} := by
    have h := A.represents_after hbase v
    have heq : ({v,r,s} : Finset V) = {s,v,r} := by ext u; simp; tauto
    rw [heq] at h
    exact h
  have hw : IsolationGame.WinsWithin G (sBound b k+1) .dominator {v,r} := by
    by_cases ht : Terminal G {v,r}
    · exact terminal_wins G ht _ _
    · by_cases hs : Legal G {v,r} s
      · exact Or.inr ⟨s,hs,boundS (Finset.Subset.refl Q) hclosed⟩
      · have hcurrent : A.Represents Q {v,r} := by
          intro u
          rw [← DoubleRooted.white_insert_of_illegal hs u]
          exact hclosed u
        obtain ⟨w,hw⟩ := exists_legal_of_not_terminal G ht
        exact Or.inr ⟨w,hw,boundS (A.remainingAfter_subset Q w) (A.represents_after hcurrent w)⟩
  have h := (gameValue_le_iff G .dominator {v,r} _).mpr hw
  omega

/-- A verified assembly of the sharper G and U responses on a fixed
two-root star system. All Staller choices use the real legality predicate. -/
theorem oriented_strategy {R : Finset I} {r s : V}
    (hbase : A.Represents R {r,s}) (hfirst : Legal G ∅ r)
    (hresponses : ∀ v, Legal G {r} v → v=s ∨ ∃ i∈R, Closed G v (A.center i))
    {N : Nat} (hN : 3 ≤ N)
    (hg : gBound (A.groups R).card R.card ≤ N)
    (hu : uBound (A.groups R).card R.card ≤ N) : isolationNumber G ≤ N := by
  classical
  have hw : IsolationGame.WinsWithin G ((N-2)+2) .dominator ∅ := by
    refine Or.inr ⟨r,hfirst,Or.inr ?_⟩
    intro v hv
    apply (gameValue_le_iff G .dominator {v,r} (N-2)).mp
    rcases hresponses v (by simpa using hv) with hvs | hhit
    · subst v
      have hbase' : A.Represents R {s,r} := by
        have heq : ({r,s} : Finset V) = {s,r} := by ext u; simp [or_comm]
        rw [heq] at hbase
        exact hbase
      have h := A.represented_g_bound hbase'
      omega
    · have hdrop := A.hit_card_drop hhit
      have hsub := A.remainingAfter_subset R v
      have hgroups := Finset.card_le_card (A.groups_mono hsub)
      have hcard : (A.groups (A.remainingAfter R v)).card ≤ (A.remainingAfter R v).card :=
        Finset.card_image_le
      have h := A.after_root_reply hbase
        (show (A.groups (A.remainingAfter R v)).card ≤ min (A.groups R).card (R.card-1) by omega)
        (show (A.remainingAfter R v).card ≤ R.card-1 by omega)
      unfold uBound at hu
      omega
  apply (isolationNumber_le_iff G N).mpr
  convert hw using 1 <;> omega

end IsolationGame.StarSystem

namespace IsolationGame.DiameterSeven

/-- All orders at least nineteen, with no additional structural assumption.
This is an actual game theorem. The remaining finite-order obligation is
not asserted here. -/
theorem diameter_seven_large {V : Type*} [Fintype V] (T : SimpleGraph V)
    (hT : T.IsTree) (hd : T.diam=7) (hn : 19 ≤ Fintype.card V) :
    gameIsolationNumber T ≤ 3*Fintype.card V/7 := by
  classical
  obtain ⟨x,y,hc⟩ := exists_centerEdge hT hd
  let A := DoubleRooted.system x y hT hc
  let R := DoubleRooted.allIndices (G := T) x y
  let e := (DoubleRooted.extras x y hT hc).card
  let N := 3*Fintype.card V/7
  have hb : 2 ≤ (A.groups R).card := DoubleRooted.two_groups x y hT hc hd
  have hk : (A.groups R).card ≤ R.card := Finset.card_image_le
  have hcount : Fintype.card V = 2+(A.groups R).card+2*R.card+e :=
    DoubleRooted.exact_count x y hT hc
  change isolationNumber T ≤ N
  by_cases he : 2 ≤ e
  · exact DoubleRooted.large_with_two_extras x y hT hc hd hn he
  · have hg : gBound (A.groups R).card R.card ≤ N :=
      uniform_arithmetic hb hk hcount hn (Or.inl (Nat.le_refl _))
    have hu : uBound (A.groups R).card R.card ≤ N :=
      uniform_arithmetic hb hk hcount hn (Or.inr (Or.inl (Nat.le_refl _)))
    have hN : 3 ≤ N := by dsimp [N]; omega
    have hbase : A.Represents R {x,y} := DoubleRooted.both_roots_represents x y hT hc
    have hx : Legal T ∅ x := by
      refine ⟨x,Or.inl rfl,?_,y,hc.1,?_⟩ <;> simp [Undominated,Dominated]
    have hy : Legal T ∅ y := by
      refine ⟨y,Or.inl rfl,?_,x,hc.1.symm,?_⟩ <;> simp [Undominated,Dominated]
    rcases DoubleRooted.orientation x y hT hc (by change e ≤ 1; omega) with hleft | hright
    · apply A.oriented_strategy hbase hx _ hN hg hu
      intro v hv
      rcases hleft v hv with h | ⟨i,hi⟩
      · exact Or.inl h
      · exact Or.inr ⟨i,by simp [R,DoubleRooted.allIndices],hi⟩
    · have hbase' : A.Represents R {y,x} := by
        have heq : ({x,y} : Finset V) = {y,x} := by ext u; simp [or_comm]
        rw [heq] at hbase
        exact hbase
      apply A.oriented_strategy hbase' hy _ hN hg hu
      intro v hv
      rcases hright v hv with h | ⟨i,hi⟩
      · exact Or.inl h
      · exact Or.inr ⟨i,by simp [R,DoubleRooted.allIndices],hi⟩

end IsolationGame.DiameterSeven
