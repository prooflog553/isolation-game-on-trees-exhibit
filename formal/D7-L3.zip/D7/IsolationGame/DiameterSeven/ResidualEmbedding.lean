import IsolationGame.DiameterSeven.Marked

namespace IsolationGame.DiameterSeven

variable {V W : Type*} [DecidableEq V] [DecidableEq W]

/-- A marked residual graph embedded in the original board. Vertices outside
the image may remain, but must have no neighbor in the initial white set.
This condition retains all legal blue boundary moves inside the image. -/
structure ResidualEmbedding (G : SimpleGraph V) (H : SimpleGraph W) (M : Finset W) where
  toFun : W → V
  injective : Function.Injective toFun
  adj_iff : ∀ u v, G.Adj (toFun u) (toFun v) ↔ H.Adj u v
  external : ∀ u, Marked.White H M ∅ u → ∀ v, G.Adj v (toFun u) →
    ∃ w, toFun w=v

namespace ResidualEmbedding

variable {G : SimpleGraph V} {H : SimpleGraph W} {M : Finset W}
variable (E : ResidualEmbedding G H M)

def Represents (X : Finset V) (Y : Finset W) : Prop :=
  ∀ v, White G X v ↔ ∃ u, Marked.White H M Y u ∧ E.toFun u=v

theorem closed_iff (u v : W) : Closed G (E.toFun u) (E.toFun v) ↔ Closed H u v := by
  simp only [Closed, E.adj_iff, E.injective.eq_iff]

theorem white_image {X : Finset V} {Y : Finset W} (hr : E.Represents X Y) (u : W) :
    White G X (E.toFun u) ↔ Marked.White H M Y u := by
  constructor
  · intro h
    obtain ⟨w, hw, heq⟩ := (hr _).mp h
    exact E.injective heq ▸ hw
  · intro h
    exact (hr _).mpr ⟨u,h,rfl⟩

theorem after_move {X : Finset V} {Y : Finset W} (hr : E.Represents X Y) (w : W) :
    E.Represents (insert (E.toFun w) X) (insert w Y) := by
  intro v
  constructor
  · intro hv
    obtain ⟨hv, hcv, z, hvz, hz, hcz⟩ :=
      (white_insert_iff G X (E.toFun w) v).mp hv
    obtain ⟨u, hu, rfl⟩ := (hr v).mp hv
    obtain ⟨a, ha, rfl⟩ := (hr z).mp hz
    refine ⟨u, ?_, rfl⟩
    apply (Marked.white_insert H M Y w u).mpr
    exact ⟨hu, fun h => hcv ((E.closed_iff w u).mpr h), a,
      (E.adj_iff u a).mp hvz, ha, fun h => hcz ((E.closed_iff w a).mpr h)⟩
  · rintro ⟨u, hu, rfl⟩
    obtain ⟨hu,hcu,a,hua,ha,hca⟩ := (Marked.white_insert H M Y w u).mp hu
    apply (white_insert_iff G X (E.toFun w) (E.toFun u)).mpr
    exact ⟨(E.white_image hr u).mpr hu, fun h => hcu ((E.closed_iff w u).mp h),
      E.toFun a, (E.adj_iff u a).mpr hua, (E.white_image hr a).mpr ha,
      fun h => hca ((E.closed_iff w a).mp h)⟩

theorem legal_image {X : Finset V} {Y : Finset W} (hr : E.Represents X Y) (w : W) :
    Legal G X (E.toFun w) ↔ Marked.Legal H M Y w := by
  constructor
  · rintro ⟨v,hc,hv⟩
    obtain ⟨u,hu,rfl⟩ := (hr v).mp hv
    exact ⟨u,(E.closed_iff w u).mp hc,hu⟩
  · rintro ⟨u,hc,hu⟩
    exact ⟨E.toFun u,(E.closed_iff w u).mpr hc,(E.white_image hr u).mpr hu⟩

/-- Exhaustiveness of move transport: every real legal vertex is in the
embedded board, including dominated vertices that remain legal. -/
theorem legal_preimage {X : Finset V} {Y : Finset W} (hr : E.Represents X Y)
    {v : V} (hv : Legal G X v) :
    ∃ w, E.toFun w=v ∧ Marked.Legal H M Y w := by
  obtain ⟨u,hc,hu⟩ := hv
  obtain ⟨a,ha,rfl⟩ := (hr u).mp hu
  have hex : ∃ w, E.toFun w=v := by
    rcases hc with heq | hadj
    · exact ⟨a,heq⟩
    · exact E.external a
        (Marked.white_antitone_selected H (Finset.empty_subset Y) a ha) v hadj
  obtain ⟨w,rfl⟩ := hex
  exact ⟨w,rfl,(E.legal_image hr w).mp ⟨E.toFun a,hc,hu⟩⟩

theorem terminal_iff {X : Finset V} {Y : Finset W} (hr : E.Represents X Y) :
    Terminal G X ↔ Marked.Terminal H M Y := by
  constructor
  · intro ht u hu
    exact ht (E.toFun u) ((E.white_image hr u).mpr hu)
  · intro ht v hv
    obtain ⟨u,hu,_⟩ := (hr v).mp hv
    exact ht u hu

/-- Exact, turn-preserving and horizon-preserving residual simulation.
The proof includes both existential Dominator and universal Staller moves. -/
theorem wins_iff {X : Finset V} {Y : Finset W} (hr : E.Represents X Y)
    (m : Nat) (p : Player) :
    WinsWithin G m p X ↔ Marked.WinsWithin H M m p Y := by
  induction m generalizing p X Y with
  | zero => exact E.terminal_iff hr
  | succ m ih =>
    cases p with
    | dominator =>
      constructor
      · rintro (ht | ⟨v,hv,hw⟩)
        · exact Or.inl ((E.terminal_iff hr).mp ht)
        · obtain ⟨w,rfl,hl⟩ := E.legal_preimage hr hv
          exact Or.inr ⟨w,hl,(ih (E.after_move hr w) _).mp hw⟩
      · rintro (ht | ⟨w,hw,hwin⟩)
        · exact Or.inl ((E.terminal_iff hr).mpr ht)
        · exact Or.inr ⟨E.toFun w,(E.legal_image hr w).mpr hw,
            (ih (E.after_move hr w) _).mpr hwin⟩
    | staller =>
      constructor
      · rintro (ht | hw)
        · exact Or.inl ((E.terminal_iff hr).mp ht)
        · exact Or.inr (fun w hl => (ih (E.after_move hr w) _).mp
            (hw (E.toFun w) ((E.legal_image hr w).mpr hl)))
      · rintro (ht | hw)
        · exact Or.inl ((E.terminal_iff hr).mpr ht)
        · apply Or.inr
          intro v hv
          obtain ⟨w,rfl,hl⟩ := E.legal_preimage hr hv
          exact (ih (E.after_move hr w) _).mpr (hw w hl)

theorem value_eq [Fintype V] [Fintype W] {X : Finset V} {Y : Finset W}
    (hr : E.Represents X Y) (p : Player) :
    gameValue G p X = Marked.gameValue H M p Y := by
  apply Nat.le_antisymm
  · apply (gameValue_le_iff G p X _).mpr
    apply (E.wins_iff hr _ p).mpr
    exact (Marked.gameValue_le_iff H M p Y _).mp (Nat.le_refl _)
  · apply (Marked.gameValue_le_iff H M p Y _).mpr
    apply (E.wins_iff hr _ p).mp
    exact (gameValue_le_iff G p X _).mp (Nat.le_refl _)

end ResidualEmbedding
end IsolationGame.DiameterSeven
