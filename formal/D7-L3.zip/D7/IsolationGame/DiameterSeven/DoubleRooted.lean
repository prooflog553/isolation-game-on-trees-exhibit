import IsolationGame.DiameterSeven.CenterEdge
import IsolationGame.VertexCount

namespace IsolationGame.DiameterSeven.DoubleRooted

variable {V : Type*} {G : SimpleGraph V} (x y : V)

noncomputable def depth (u : V) : Nat := min (G.dist u x) (G.dist u y)

theorem depth_x : depth (G := G) x y x=0 := by simp [depth]
theorem depth_y : depth (G := G) x y y=0 := by simp [depth]

theorem depth_left {u : V} (hu : LeftSide G x y u) :
    depth (G := G) x y u = G.dist u x := by
  unfold depth LeftSide at *
  omega

theorem depth_right {u : V} (hu : LeftSide G y x u) :
    depth (G := G) x y u = G.dist u y := by
  unfold depth LeftSide at *
  omega

theorem depth_le_three (hc : CenterEdge G x y) (u : V) : depth (G := G) x y u ≤ 3 := by
  have h := hc.2 u
  simp only [G.dist_comm (u := x) (v := u),G.dist_comm (u := y) (v := u)] at h
  unfold depth
  omega

theorem depth_zero_iff (hT : G.IsTree) (u : V) :
    depth (G := G) x y u=0 ↔ u=x ∨ u=y := by
  have hx := hT.isConnected.dist_eq_zero_iff (u := u) (v := x)
  have hy := hT.isConnected.dist_eq_zero_iff (u := u) (v := y)
  rw [depth,Nat.min_eq_zero_iff,hx,hy]

theorem adj_depths (hT : G.IsTree) (hc : CenterEdge G x y) {u v : V}
    (hu : 0 < depth (G := G) x y u) (huv : G.Adj u v) :
    depth (G := G) x y u = depth (G := G) x y v+1 ∨
      depth (G := G) x y v = depth (G := G) x y u+1 := by
  have hne : u≠x ∧ u≠y := by
    constructor
    · intro h; rw [h,depth_x] at hu; omega
    · intro h; rw [h,depth_y] at hu; omega
  rcases (sides_partition hT hc.1 u).1 with hs | hs
  · have hv := nonroot_neighbor_same_side hT hc.1 hs hne.1 huv
    rw [depth_left x y hs,depth_left x y hv]
    exact tree_adj_levels hT x huv
  · have hv := nonroot_neighbor_same_side hT hc.1.symm hs hne.2 huv
    rw [depth_right x y hs,depth_right x y hv]
    exact tree_adj_levels hT y huv

theorem unique_lower (hT : G.IsTree) (hc : CenterEdge G x y) {u v w : V}
    (hu : 0 < depth (G := G) x y u) (hv : G.Adj u v) (hw : G.Adj u w)
    (hdv : depth (G := G) x y v+1=depth (G := G) x y u)
    (hdw : depth (G := G) x y w+1=depth (G := G) x y u) : v=w := by
  have hne : u≠x ∧ u≠y := by
    constructor
    · intro h; rw [h,depth_x] at hu; omega
    · intro h; rw [h,depth_y] at hu; omega
  rcases (sides_partition hT hc.1 u).1 with hs | hs
  · have hvs := nonroot_neighbor_same_side hT hc.1 hs hne.1 hv
    have hws := nonroot_neighbor_same_side hT hc.1 hs hne.1 hw
    rw [depth_left x y hs,depth_left x y hvs] at hdv
    rw [depth_left x y hs,depth_left x y hws] at hdw
    exact unique_lower_neighbor hT x hv hw hdv hdw
  · have hvs := nonroot_neighbor_same_side hT hc.1.symm hs hne.2 hv
    have hws := nonroot_neighbor_same_side hT hc.1.symm hs hne.2 hw
    rw [depth_right x y hs,depth_right x y hvs] at hdv
    rw [depth_right x y hs,depth_right x y hws] at hdw
    exact unique_lower_neighbor hT y hv hw hdv hdw

theorem exists_lower (hT : G.IsTree) (hc : CenterEdge G x y) {u : V}
    (hu : 0 < depth (G := G) x y u) :
    ∃ v, G.Adj u v ∧ depth (G := G) x y v+1=depth (G := G) x y u := by
  have hne : u≠x ∧ u≠y := by
    constructor
    · intro h; rw [h,depth_x] at hu; omega
    · intro h; rw [h,depth_y] at hu; omega
  rcases (sides_partition hT hc.1 u).1 with hs | hs
  · obtain ⟨v,hv,_⟩ := exists_unique_parent hT x hne.1
    have hvs := nonroot_neighbor_same_side hT hc.1 hs hne.1 hv.1
    exact ⟨v,hv.1,by rw [depth_left x y hs,depth_left x y hvs]; exact hv.2⟩
  · obtain ⟨v,hv,_⟩ := exists_unique_parent hT y hne.2
    have hvs := nonroot_neighbor_same_side hT hc.1.symm hs hne.2 hv.1
    exact ⟨v,hv.1,by rw [depth_right x y hs,depth_right x y hvs]; exact hv.2⟩

theorem depth_three_unique (hT : G.IsTree) (hc : CenterEdge G x y) {u v w : V}
    (hu : depth (G := G) x y u=3) (hv : G.Adj u v) (hw : G.Adj u w) : v=w := by
  have hdv := adj_depths x y hT hc (by omega) hv
  have hdw := adj_depths x y hT hc (by omega) hw
  have hvl := depth_le_three x y hc v
  have hwl := depth_le_three x y hc w
  exact unique_lower x y hT hc (by omega) hv hw (by omega) (by omega)

variable [Fintype V] [DecidableEq V]

abbrev Index := {u : V // depth (G := G) x y u=2 ∧
  ∃ z, G.Adj u z ∧ depth (G := G) x y z=3}

noncomputable def parent (hT : G.IsTree) (hc : CenterEdge G x y)
    (i : Index (G := G) x y) : V :=
  (exists_lower x y hT hc (show 0 < depth (G := G) x y i.val by
    have := i.property.1; omega)).choose

theorem parent_spec (hT : G.IsTree) (hc : CenterEdge G x y)
    (i : Index (G := G) x y) :
    G.Adj i.val (parent x y hT hc i) ∧ depth (G := G) x y (parent x y hT hc i)=1 := by
  have h := (exists_lower x y hT hc (show 0 < depth (G := G) x y i.val by
    have := i.property.1; omega)).choose_spec
  change G.Adj i.val (parent x y hT hc i) ∧
    depth (G := G) x y (parent x y hT hc i)+1=depth (G := G) x y i.val at h
  exact ⟨h.1,by have := i.property.1; omega⟩

noncomputable def leaves (i : Index (G := G) x y) : Finset V := by
  classical
  exact Finset.univ.filter (fun z => G.Adj i.val z ∧ depth (G := G) x y z=3)

theorem mem_leaves (i : Index (G := G) x y) (z : V) :
    z ∈ leaves x y i ↔ G.Adj i.val z ∧ depth (G := G) x y z=3 := by
  classical
  simp [leaves]

theorem mem_vertices_depth (i : Index (G := G) x y) {u : V}
    (hu : u ∈ insert i.val (leaves x y i)) :
    depth (G := G) x y u=2 ∨ depth (G := G) x y u=3 := by
  rcases Finset.mem_insert.mp hu with rfl | hu
  · exact Or.inl i.property.1
  · exact Or.inr ((mem_leaves x y i u).mp hu).2

theorem vertices_disjoint (hT : G.IsTree) (hc : CenterEdge G x y)
    (i j : Index (G := G) x y) (hij : i≠j) :
    Disjoint (insert i.val (leaves x y i)) (insert j.val (leaves x y j)) := by
  apply Finset.disjoint_left.mpr
  intro u hui huj
  apply hij
  apply Subtype.ext
  rcases Finset.mem_insert.mp hui with hi | hi <;>
    rcases Finset.mem_insert.mp huj with hj | hj
  · exact hi.symm.trans hj
  · have hd := ((mem_leaves x y j u).mp hj).2
    have hi2 := i.property.1
    rw [hi] at hd
    omega
  · have hd := ((mem_leaves x y i u).mp hi).2
    have hj2 := j.property.1
    rw [hj] at hd
    omega
  · have hi' := (mem_leaves x y i u).mp hi
    have hj' := (mem_leaves x y j u).mp hj
    exact unique_lower x y hT hc (by have := hi'.2; omega) hi'.1.symm hj'.1.symm
      (by have := i.property.1; omega) (by have := j.property.1; omega)

theorem star_adjacency (hT : G.IsTree) (hc : CenterEdge G x y)
    (i : Index (G := G) x y) (u : V) (hu : u ∈ insert i.val (leaves x y i)) (v : V) :
    G.Adj v u ↔ (v=i.val ∧ u∈leaves x y i) ∨
      (v∈leaves x y i ∧ u=i.val) ∨ (v=parent x y hT hc i ∧ u=i.val) := by
  constructor
  · intro hvu
    rcases Finset.mem_insert.mp hu with rfl | hu
    · have hi := i.property.1
      have hd := adj_depths x y hT hc (by omega) hvu.symm
      rcases hd with hd | hd
      · have hp := parent_spec x y hT hc i
        have heq := unique_lower x y hT hc (by omega) hvu.symm hp.1 (by omega) (by omega)
        exact Or.inr (Or.inr ⟨heq,rfl⟩)
      · exact Or.inr (Or.inl ⟨(mem_leaves x y i v).mpr ⟨hvu.symm,by omega⟩,rfl⟩)
    · have hl := (mem_leaves x y i u).mp hu
      have heq := depth_three_unique x y hT hc hl.2 hvu.symm hl.1.symm
      exact Or.inl ⟨heq,hu⟩
  · rintro (⟨rfl,hu⟩ | ⟨hv,rfl⟩ | ⟨rfl,rfl⟩)
    · exact ((mem_leaves x y i u).mp hu).1
    · exact ((mem_leaves x y i v).mp hv).1.symm
    · exact (parent_spec x y hT hc i).1.symm

/-- The combined deep-star system on BOTH sides of the center edge.
The adjacency field describes all neighbors in the original graph. -/
noncomputable def system (hT : G.IsTree) (hc : CenterEdge G x y) :
    StarSystem G (Index (G := G) x y) := by
  classical
  exact {
    center := Subtype.val
    parent := parent x y hT hc
    leaves := leaves x y
    leaves_nonempty := fun i => by
      obtain ⟨z,hz⟩ := i.property.2
      exact ⟨z,(mem_leaves x y i z).mpr hz⟩
    center_not_leaf := fun i h => by
      have := ((mem_leaves x y i i.val).mp h).2
      have := i.property.1
      omega
    disjoint := vertices_disjoint x y hT hc
    parent_outside := fun i j h => by
      have := mem_vertices_depth x y j h
      have := (parent_spec x y hT hc i).2
      omega
    adj_iff := star_adjacency x y hT hc }

noncomputable def allIndices : Finset (Index (G := G) x y) := by
  classical
  exact Finset.univ

theorem undominated_both (hT : G.IsTree) (u : V) :
    Undominated G {x,y} u ↔ 2 ≤ depth (G := G) x y u := by
  have hs : Undominated G {x,y} u ↔ Undominated G {x} u ∧ Undominated G {y} u := by
    simp [Undominated,Dominated]
  have hx : Undominated G {x} u ↔ 2 ≤ G.dist u x := undominated_root_iff hT x u
  have hy : Undominated G {y} u ↔ 2 ≤ G.dist u y := undominated_root_iff hT y u
  rw [hs,hx,hy,depth]
  omega

/-- Selecting both roots reaches the original, already verified star-game
semantics on the combined collection. No component-additivity rule is used. -/
theorem both_roots_represents (hT : G.IsTree) (hc : CenterEdge G x y) :
    (system x y hT hc).Represents (allIndices x y) {x,y} := by
  classical
  intro u
  have hU := undominated_both x y hT
  constructor
  · rintro ⟨hu,w,huw,hw⟩
    have hdu := (hU u).mp hu
    have hdw := (hU w).mp hw
    have hbu := depth_le_three x y hc u
    have hbw := depth_le_three x y hc w
    rcases adj_depths x y hT hc (by omega) huw with hd | hd
    · let i : Index (G := G) x y := ⟨w,by omega,u,huw.symm,by omega⟩
      refine ⟨i,by simp [allIndices],?_⟩
      apply Finset.mem_insert_of_mem
      exact (mem_leaves x y i u).mpr ⟨huw.symm,by omega⟩
    · let i : Index (G := G) x y := ⟨u,by omega,w,huw,by omega⟩
      exact ⟨i,by simp [allIndices],Finset.mem_insert_self _ _⟩
  · rintro ⟨i,_,hui⟩
    obtain ⟨w,hwi,huw⟩ := (system x y hT hc).internal_neighbor hui
    have hdu := mem_vertices_depth x y i hui
    have hdw := mem_vertices_depth x y i hwi
    exact ⟨(hU u).mpr (by omega),w,huw,(hU w).mpr (by omega)⟩

/-- The intervening Staller move is represented exactly, because the
white set depends on the selected set, not on its insertion order. -/
theorem transition_represents (hT : G.IsTree) (hc : CenterEdge G x y) (v : V) :
    (system x y hT hc).Represents
      ((system x y hT hc).remainingAfter (allIndices x y) v) {y,v,x} := by
  have h := (system x y hT hc).represents_after (both_roots_represents x y hT hc) v
  have hs : ({v,x,y} : Finset V) = {y,v,x} := by
    ext z
    simp only [Finset.mem_insert,Finset.mem_singleton]
    tauto
  rw [hs] at h
  exact h

theorem white_insert_of_illegal {X : Finset V} {v : V} (hv : ¬ Legal G X v) (u : V) :
    White G (insert v X) u ↔ White G X u := by
  rw [white_insert_iff]
  constructor
  · exact fun h => h.1
  · intro hu
    have hu' := hu.1
    obtain ⟨w,huw,hw⟩ := hu.2
    have hw' : White G X w := ⟨hw,u,huw.symm,hu'⟩
    exact ⟨hu,fun h => hv ⟨u,h,hu⟩,w,huw,hw',fun h => hv ⟨w,h,hw'⟩⟩

/-- If the second center is illegal, the current real position already
has the grouped-star representation; no fictitious move is counted. -/
theorem illegal_second_root_represents (hT : G.IsTree) (hc : CenterEdge G x y)
    (v : V) (hy : ¬ Legal G {v,x} y) :
    (system x y hT hc).Represents
      ((system x y hT hc).remainingAfter (allIndices x y) v) {v,x} := by
  intro u
  rw [← white_insert_of_illegal hy u]
  exact transition_represents x y hT hc v u

theorem root_outside (hT : G.IsTree) (hc : CenterEdge G x y)
    (r : V) (hr : r=x ∨ r=y) (i : Index (G := G) x y) :
    r ∉ (system x y hT hc).vertices i ∧ r ≠ parent x y hT hc i := by
  have hd : depth (G := G) x y r=0 := (depth_zero_iff x y hT r).mpr hr
  constructor
  · intro h
    have := mem_vertices_depth x y i h
    omega
  · intro h
    have hp := (parent_spec x y hT hc i).2
    rw [← h] at hp
    omega

noncomputable def counted (hT : G.IsTree) (hc : CenterEdge G x y) : Finset V :=
  insert y ((system x y hT hc).countedVertices x (allIndices x y))

noncomputable def extras (hT : G.IsTree) (hc : CenterEdge G x y) : Finset V :=
  Finset.univ \ counted x y hT hc

theorem counted_card (hT : G.IsTree) (hc : CenterEdge G x y) :
    (counted x y hT hc).card =
      2 + ((allIndices x y).image (parent x y hT hc)).card + 2*(allIndices (G := G) x y).card := by
  classical
  let A := system x y hT hc
  let R := allIndices (G := G) x y
  have hx := root_outside x y hT hc x (Or.inl rfl)
  have hy := root_outside x y hT hc y (Or.inr rfl)
  have hyx : y≠x := hc.1.ne.symm
  have hyNot : y ∉ A.countedVertices x R := by
    intro h
    rcases Finset.mem_insert.mp h with h | h
    · exact hyx h
    · rcases Finset.mem_union.mp h with h | h
      · obtain ⟨i,_,hi⟩ := Finset.mem_image.mp h
        exact (hy i).2 hi.symm
      · rcases Finset.mem_union.mp h with h | h
        · obtain ⟨i,_,hi⟩ := Finset.mem_image.mp h
          exact (hy i).1 (Eq.mp (congrArg (fun z => z ∈ A.vertices i) hi) (A.center_mem i))
        · obtain ⟨i,_,hi⟩ := Finset.mem_image.mp h
          exact (hy i).1 (Eq.mp (congrArg (fun z => z ∈ A.vertices i) hi)
            (A.leaf_mem (A.chosenLeaf_mem i)))
  have hcard := A.countedVertices_card x R (fun i => (hx i).1) (fun i => (hx i).2)
  have hi := Finset.card_insert_of_not_mem hyNot
  change (insert y (A.countedVertices x R)).card = _
  rw [hi]
  change (A.countedVertices x R).card+1 = 2+(R.image A.parent).card+2*R.card
  omega

/-- Exact disjoint count. The surplus is the actual complement of the two
roots, all group parents, centers, and one chosen leaf per star. -/
theorem exact_count (hT : G.IsTree) (hc : CenterEdge G x y) :
    Fintype.card V = 2 + ((allIndices x y).image (parent x y hT hc)).card +
      2*(allIndices (G := G) x y).card + (extras x y hT hc).card := by
  have h := Finset.card_sdiff_add_card_eq_card
    (Finset.subset_univ (counted x y hT hc))
  rw [Finset.card_univ,counted_card x y hT hc] at h
  change (extras x y hT hc).card + _ = _ at h
  omega

theorem two_groups (hT : G.IsTree) (hc : CenterEdge G x y) (hd : G.diam=7) :
    2 ≤ ((allIndices x y).image (parent x y hT hc)).card := by
  classical
  obtain ⟨u,hu,hud⟩ := left_depth_three_exists hT hd hc
  obtain ⟨v,hv,hvd⟩ := right_depth_three_exists hT hd hc
  have hud' : depth (G := G) x y u=3 := (depth_left x y hu).trans hud
  have hvd' : depth (G := G) x y v=3 := (depth_right x y hv).trans hvd
  obtain ⟨c,huc,hcd⟩ := exists_lower x y hT hc (by omega : 0 < depth (G := G) x y u)
  obtain ⟨d,hvdj,hdd⟩ := exists_lower x y hT hc (by omega : 0 < depth (G := G) x y v)
  let i : Index (G := G) x y := ⟨c,by omega,u,huc.symm,hud'⟩
  let j : Index (G := G) x y := ⟨d,by omega,v,hvdj.symm,hvd'⟩
  have hune : u≠x := by intro h; rw [h,G.dist_self] at hud; omega
  have hvne : v≠y := by intro h; rw [h,G.dist_self] at hvd; omega
  have hcs := nonroot_neighbor_same_side hT hc.1 hu hune huc
  have hds := nonroot_neighbor_same_side hT hc.1.symm hv hvne hvdj
  have hcne : c≠x := by intro h; rw [h,depth_x] at hcd; omega
  have hdne : d≠y := by intro h; rw [h,depth_y] at hdd; omega
  have hpi := nonroot_neighbor_same_side hT hc.1 hcs hcne (parent_spec x y hT hc i).1
  have hpj := nonroot_neighbor_same_side hT hc.1.symm hds hdne (parent_spec x y hT hc j).1
  have hneq : parent x y hT hc i ≠ parent x y hT hc j := by
    intro h
    rw [h] at hpi
    exact ((sides_partition hT hc.1 _).2) ⟨hpi,hpj⟩
  have hi : parent x y hT hc i ∈ (allIndices x y).image (parent x y hT hc) :=
    Finset.mem_image.mpr ⟨i,by simp [allIndices],rfl⟩
  have hj : parent x y hT hc j ∈ (allIndices x y).image (parent x y hT hc) :=
    Finset.mem_image.mpr ⟨j,by simp [allIndices],rfl⟩
  by_contra h
  have hsmall : ((allIndices x y).image (parent x y hT hc)).card ≤ 1 := by omega
  exact hneq (Finset.card_le_one.mp hsmall _ hi _ hj)

theorem groups_le_stars (hT : G.IsTree) (hc : CenterEdge G x y) :
    ((allIndices x y).image (parent x y hT hc)).card ≤ (allIndices (G := G) x y).card :=
  Finset.card_image_le

theorem white_first_same_side (hT : G.IsTree) (hc : CenterEdge G x y)
    {u : V} (hu : LeftSide G x y u) (hw : White G {x} u) : White G {x,y} u := by
  have hdu : 2 ≤ G.dist u x := (undominated_root_iff hT x u).mp hw.1
  have hune : u≠x := by intro h; rw [h,G.dist_self] at hdu; omega
  obtain ⟨w,huw,hwU⟩ := hw.2
  have hws := nonroot_neighbor_same_side hT hc.1 hu hune huw
  have hdw : 2 ≤ G.dist w x := (undominated_root_iff hT x w).mp hwU
  exact ⟨(undominated_both x y hT u).mpr (by rw [depth_left x y hu]; exact hdu),
    w,huw,(undominated_both x y hT w).mpr (by rw [depth_left x y hws]; exact hdw)⟩

/-- Every legal move on the already-opened side deletes a deep star.
This also includes legal dominated group parents. -/
theorem legal_left_hits_star (hT : G.IsTree) (hc : CenterEdge G x y)
    {v : V} (hv : Legal G {x} v) (hs : LeftSide G x y v) :
    ∃ i : Index (G := G) x y, Closed G v i.val := by
  have hne : v≠x := by
    intro h
    exact selected_not_legal G (X := {x}) (by simpa [h]) hv
  obtain ⟨u,hvu,hu⟩ := hv
  have hus : LeftSide G x y u := by
    rcases hvu with h | h
    · exact h ▸ hs
    · exact nonroot_neighbor_same_side hT hc.1 hs hne h
  have huBoth := white_first_same_side x y hT hc hus hu
  obtain ⟨i,_,hui⟩ := (both_roots_represents x y hT hc u).mp huBoth
  refine ⟨i,?_⟩
  exact ((system x y hT hc).closed_center_iff i v).mpr
    ((system x y hT hc).closed_star_implies hui hvu)

theorem legal_right_hits_star (hT : G.IsTree) (hc : CenterEdge G x y)
    {v : V} (hv : Legal G {y} v) (hs : LeftSide G y x v) :
    ∃ i : Index (G := G) x y, Closed G v i.val := by
  have hne : v≠y := by
    intro h
    exact selected_not_legal G (X := {y}) (by simpa [h]) hv
  obtain ⟨u,hvu,hu⟩ := hv
  have hus : LeftSide G y x u := by
    rcases hvu with h | h
    · exact h ▸ hs
    · exact nonroot_neighbor_same_side hT hc.1.symm hs hne h
  have huBoth : White G {x,y} u := by
    have h := white_first_same_side y x hT (centerEdge_symm hc) hus hu
    have heq : ({y,x} : Finset V) = {x,y} := by ext z; simp [or_comm]
    rw [heq] at h
    exact h
  obtain ⟨i,_,hui⟩ := (both_roots_represents x y hT hc u).mp huBoth
  exact ⟨i,((system x y hT hc).closed_center_iff i v).mpr
    ((system x y hT hc).closed_star_implies hui hvu)⟩

/-- Outside the two roots, a zero-star move is an actual surplus vertex. -/
theorem no_star_hit_mem_extras (hT : G.IsTree) (hc : CenterEdge G x y)
    {v : V} (hvx : v≠x) (hvy : v≠y)
    (hz : ¬ ∃ i : Index (G := G) x y, Closed G v i.val) : v∈extras x y hT hc := by
  classical
  apply Finset.mem_sdiff.mpr
  refine ⟨Finset.mem_univ v,?_⟩
  intro h
  rcases Finset.mem_insert.mp h with h | h
  · exact hvy h
  · rcases Finset.mem_insert.mp h with h | h
    · exact hvx h
    · rcases Finset.mem_union.mp h with h | h
      · obtain ⟨i,_,hi⟩ := Finset.mem_image.mp h
        apply hz
        refine ⟨i,((system x y hT hc).closed_center_iff i v).mpr (Or.inr hi.symm)⟩
      · rcases Finset.mem_union.mp h with h | h
        · obtain ⟨i,_,hi⟩ := Finset.mem_image.mp h
          exact hz ⟨i,Or.inl hi⟩
        · obtain ⟨i,_,hi⟩ := Finset.mem_image.mp h
          apply hz
          refine ⟨i,((system x y hT hc).closed_center_iff i v).mpr (Or.inl ?_)⟩
          exact Eq.mp (congrArg (fun z => z ∈ (system x y hT hc).vertices i) hi)
            ((system x y hT hc).leaf_mem ((system x y hT hc).chosenLeaf_mem i))

/-- With at most one actual surplus vertex, choose the endpoint on its
side. For every legal Staller response, the other endpoint or a star hit
is the exhaustive dichotomy. The star system remains fixed under this choice. -/
theorem orientation (hT : G.IsTree) (hc : CenterEdge G x y)
    (he : (extras x y hT hc).card ≤ 1) :
    (∀ v, Legal G {x} v → v=y ∨ ∃ i : Index (G := G) x y, Closed G v i.val) ∨
    (∀ v, Legal G {y} v → v=x ∨ ∃ i : Index (G := G) x y, Closed G v i.val) := by
  classical
  by_cases hleft : ∀ z∈extras x y hT hc, LeftSide G x y z
  · apply Or.inl
    intro v hv
    by_cases hvy : v=y
    · exact Or.inl hvy
    · apply Or.inr
      by_contra hz
      have hvx : v≠x := by
        intro h
        exact selected_not_legal G (X := {x}) (by simpa [h]) hv
      have hmem := no_star_hit_mem_extras x y hT hc hvx hvy hz
      exact hz (legal_left_hits_star x y hT hc hv (hleft v hmem))
  · push_neg at hleft
    obtain ⟨z,hz,hzs⟩ := hleft
    have hright : LeftSide G y x z := ((sides_partition hT hc.1 z).1).resolve_left hzs
    apply Or.inr
    intro v hv
    by_cases hvx : v=x
    · exact Or.inl hvx
    · apply Or.inr
      by_contra hhit
      have hvy : v≠y := by
        intro h
        exact selected_not_legal G (X := {y}) (by simpa [h]) hv
      have hmem := no_star_hit_mem_extras x y hT hc hvx hvy hhit
      have heq : v=z := Finset.card_le_one.mp he v hmem z hz
      exact hhit (legal_right_hits_star x y hT hc hv (heq ▸ hright))

end IsolationGame.DiameterSeven.DoubleRooted
