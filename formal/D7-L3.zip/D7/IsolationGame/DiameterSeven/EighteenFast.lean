import IsolationGame.DiameterSeven.EighteenPolicy

namespace IsolationGame.DiameterSeven.Small

/-- Closed neighborhoods of the three fixed graphs, including the vertex
itself. The following theorem checks this table against the original graph. -/
def E18Neighborhood (t : Fin 3) (v : Fin 18) : Finset (Fin 18) :=
  match t.val, v.val with
  | 0, 0 => {0,1,2,3}
  | 0, 1 => {0,1,4,5}
  | 0, 2 => {0,2,6,8,10}
  | 0, 3 => {0,3,12}
  | 0, 4 => {1,4,14}
  | 0, 5 => {1,5,16}
  | 0, 6 => {2,6,7}
  | 0, 7 => {6,7}
  | 0, 8 => {2,8,9}
  | 0, 9 => {8,9}
  | 0, 10 => {2,10,11}
  | 0, 11 => {10,11}
  | 0, 12 => {3,12,13}
  | 0, 13 => {12,13}
  | 0, 14 => {4,14,15}
  | 0, 15 => {14,15}
  | 0, 16 => {5,16,17}
  | 0, 17 => {16,17}
  | 1, 0 => {0,1,2,3}
  | 1, 1 => {0,1,4,5}
  | 1, 2 => {0,2,6,8}
  | 1, 3 => {0,3,10,12}
  | 1, 4 => {1,4,14}
  | 1, 5 => {1,5,16}
  | 1, 6 => {2,6,7}
  | 1, 7 => {6,7}
  | 1, 8 => {2,8,9}
  | 1, 9 => {8,9}
  | 1, 10 => {3,10,11}
  | 1, 11 => {10,11}
  | 1, 12 => {3,12,13}
  | 1, 13 => {12,13}
  | 1, 14 => {4,14,15}
  | 1, 15 => {14,15}
  | 1, 16 => {5,16,17}
  | 1, 17 => {16,17}
  | 2, 0 => {0,1,2,3}
  | 2, 1 => {0,1,4,5}
  | 2, 2 => {0,2,6,8}
  | 2, 3 => {0,3,10}
  | 2, 4 => {1,4,12,14}
  | 2, 5 => {1,5,16}
  | 2, 6 => {2,6,7}
  | 2, 7 => {6,7}
  | 2, 8 => {2,8,9}
  | 2, 9 => {8,9}
  | 2, 10 => {3,10,11}
  | 2, 11 => {10,11}
  | 2, 12 => {4,12,13}
  | 2, 13 => {12,13}
  | 2, 14 => {4,14,15}
  | 2, 15 => {14,15}
  | 2, 16 => {5,16,17}
  | 2, 17 => {16,17}
  | _, _ => ∅

set_option maxRecDepth 8192 in
set_option maxHeartbeats 0 in
theorem E18_neighborhood_spec : ∀ t : Fin 3, ∀ v u : Fin 18,
    u∈E18Neighborhood t v ↔ Closed (E18 t) v u := by decide +kernel

def E18DominatedSet (t : Fin 3) (X : Finset (Fin 18)) : Finset (Fin 18) :=
  X.biUnion (E18Neighborhood t)

def E18UndominatedSet (t : Fin 3) (X : Finset (Fin 18)) : Finset (Fin 18) :=
  Finset.univ \ E18DominatedSet t X

def E18WhiteSet (t : Fin 3) (X : Finset (Fin 18)) : Finset (Fin 18) :=
  (E18UndominatedSet t X).filter (fun u =>
    (((E18Neighborhood t u).erase u) ∩ E18UndominatedSet t X).Nonempty)

def E18LegalSet (t : Fin 3) (X : Finset (Fin 18)) : Finset (Fin 18) :=
  (E18WhiteSet t X).biUnion (E18Neighborhood t)

theorem E18_dominated_mem (t : Fin 3) (X : Finset (Fin 18)) (u : Fin 18) :
    u∈E18DominatedSet t X ↔ Dominated (E18 t) X u := by
  simp only [E18DominatedSet,Finset.mem_biUnion,E18_neighborhood_spec,Dominated]

theorem E18_undominated_mem (t : Fin 3) (X : Finset (Fin 18)) (u : Fin 18) :
    u∈E18UndominatedSet t X ↔ Undominated (E18 t) X u := by
  simp only [E18UndominatedSet,Finset.mem_sdiff,Finset.mem_univ,true_and,
    E18_dominated_mem,Undominated]

theorem E18_white_mem (t : Fin 3) (X : Finset (Fin 18)) (u : Fin 18) :
    u∈E18WhiteSet t X ↔ White (E18 t) X u := by
  simp only [E18WhiteSet,Finset.mem_filter,E18_undominated_mem]
  constructor
  · rintro ⟨hu,w,hw⟩
    have hh := Finset.mem_inter.mp hw
    have hn := Finset.mem_erase.mp hh.1
    have hc := (E18_neighborhood_spec t u w).mp hn.2
    exact ⟨hu,w,hc.resolve_left hn.1,(E18_undominated_mem t X w).mp hh.2⟩
  · rintro ⟨hu,w,huw,hw⟩
    exact ⟨hu,w,Finset.mem_inter.mpr ⟨Finset.mem_erase.mpr
      ⟨huw.ne.symm,(E18_neighborhood_spec t u w).mpr (Or.inr huw)⟩,
      (E18_undominated_mem t X w).mpr hw⟩⟩

theorem E18_legal_mem (t : Fin 3) (X : Finset (Fin 18)) (v : Fin 18) :
    v∈E18LegalSet t X ↔ Legal (E18 t) X v := by
  simp only [E18LegalSet,Finset.mem_biUnion,E18_white_mem,E18_neighborhood_spec]
  constructor
  · rintro ⟨u,hu,hc⟩
    refine ⟨u,?_,hu⟩
    exact hc.elim (fun h => Or.inl h.symm) (fun h => Or.inr h.symm)
  · rintro ⟨u,hc,hu⟩
    refine ⟨u,hu,?_⟩
    exact hc.elim (fun h => Or.inl h.symm) (fun h => Or.inr h.symm)

theorem E18_white_empty (t : Fin 3) (X : Finset (Fin 18)) :
    E18WhiteSet t X=∅ ↔ Terminal (E18 t) X := by
  simp only [Finset.eq_empty_iff_forall_not_mem,E18_white_mem,Terminal]

def E18FastRank (t : Fin 3) (X : Finset (Fin 18)) : Nat :=
  (Finset.univ.filter (fun i : Fin 6 => E18Center i∈E18UndominatedSet t X)).card

def E18FastCount (t : Fin 3) (X : Finset (Fin 18)) (q : Fin 18) : Nat :=
  (Finset.univ.filter (fun i : Fin 6 => E18Group t i=q ∧ E18Center i∈E18UndominatedSet t X)).card

theorem E18_fast_rank_eq (t : Fin 3) (X : Finset (Fin 18)) : E18FastRank t X=E18Rank t X := by
  simp only [E18FastRank,E18Rank,E18_undominated_mem]

theorem E18_fast_count_eq (t : Fin 3) (X : Finset (Fin 18)) (q : Fin 18) :
    E18FastCount t X q=E18Count t X q := by
  simp only [E18FastCount,E18Count,E18_undominated_mem]

def E18FastLargest (t : Fin 3) (X : Finset (Fin 18)) : Fin 18 :=
  let a := E18FastCount t X 2
  let b := E18FastCount t X 3
  let c := E18FastCount t X 4
  let d := E18FastCount t X 5
  if b ≤ a ∧ c ≤ a ∧ d ≤ a then 2
  else if c ≤ b ∧ d ≤ b then 3
  else if d ≤ c then 4 else 5

def E18FastReply (t : Fin 3) (X : Finset (Fin 18)) : Fin 18 :=
  if t.val=2 ∧ X.card=2 ∧ (E18FastCount t X 4=2 ∨ 13∈X ∨ 15∈X) then 4
  else if t.val=2 ∧ (13∈X ∨ 15∈X) ∧ 4∈X ∧ E18FastCount t X 2=1 ∧ E18FastCount t X 5=1 then 5
  else E18FastLargest t X

theorem E18_fast_reply_eq (t : Fin 3) (X : Finset (Fin 18)) : E18FastReply t X=E18Reply t X := by
  simp only [E18FastReply,E18Reply,E18FastLargest,E18Largest,E18_fast_count_eq]

/-- Efficient checking with proved-equivalent finite sets. This uses exactly
E18Reply and exactly the real undominated-center counter, by the above lemmas. -/
def E18FastCheck (t : Fin 3) : Nat → Player → Finset (Fin 18) → List Nat → Bool
  | 0, _, X, xs => decide (E18WhiteSet t X=∅ ∧ xs.sum ≤ 6 ∧ zeros xs ≤ savings xs)
  | m+1, .dominator, X, xs =>
    if E18WhiteSet t X=∅ then decide (xs.sum ≤ 6 ∧ zeros xs ≤ savings xs)
    else decide (E18FastReply t X∈E18LegalSet t X) &&
      E18FastCheck t m .staller (insert (E18FastReply t X) X)
        ((E18FastRank t X-E18FastRank t (insert (E18FastReply t X) X))::xs)
  | m+1, .staller, X, xs =>
    if E18WhiteSet t X=∅ then decide (xs.sum ≤ 6 ∧ zeros xs ≤ savings xs)
    else decide (∀ v : Fin 18, v∈E18LegalSet t X → E18FastCheck t m .dominator
      (insert v X) ((E18FastRank t X-E18FastRank t (insert v X))::xs)=true)

theorem E18_fast_check_eq (t : Fin 3) (m : Nat) (p : Player) (X : Finset (Fin 18)) (xs : List Nat) :
    E18FastCheck t m p X xs=accountingCheck (E18 t) (E18Rank t) (E18Reply t) m p X xs := by
  induction m generalizing p X xs with
  | zero => simp only [E18FastCheck,accountingCheck,E18_white_empty]
  | succ m ih =>
    cases p <;> simp only [E18FastCheck,accountingCheck,E18_white_empty,E18_legal_mem,
      E18_fast_reply_eq,E18_fast_rank_eq,ih]
    all_goals split_ifs <;> apply decide_eq_decide.mpr <;> rfl

theorem E18_fast_check_after {t : Fin 3} {m : Nat} {p : Player}
    {X Y : Finset (Fin 18)} {v : Fin 18} {xs : List Nat} {d : Nat}
    (hset : insert v X=Y) (hdrop : E18FastRank t X-E18FastRank t Y=d)
    (h : E18FastCheck t m p Y (d::xs)=true) :
    E18FastCheck t m p (insert v X) ((E18FastRank t X-E18FastRank t (insert v X))::xs)=true := by
  rewrite [hset,hdrop]
  exact h

end IsolationGame.DiameterSeven.Small
