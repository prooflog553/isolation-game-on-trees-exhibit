import IsolationGame.Game
import IsolationGame.Decidable

/-!
Predomination marks individual vertices, not their closed neighborhoods.
This conservative extension of the existing selected-set game is needed for
the marked single-arm root of H. `wins_empty_marks` and `value_empty_marks`
prove the connection to the existing game, without changing its definitions.
-/
namespace IsolationGame.Marked

variable {V : Type*} [DecidableEq V] (G : SimpleGraph V)

def Undominated (M X : Finset V) (u : V) : Prop :=
  u ∉ M ∧ IsolationGame.Undominated G X u

def White (M X : Finset V) (u : V) : Prop :=
  Undominated G M X u ∧ ∃ w, G.Adj u w ∧ Undominated G M X w

def Legal (M X : Finset V) (v : V) : Prop :=
  ∃ u, Closed G v u ∧ White G M X u

def Terminal (M X : Finset V) : Prop := ∀ u, ¬ White G M X u

def WinsWithin (M : Finset V) : Nat → Player → Finset V → Prop
  | 0, _, X => Terminal G M X
  | m + 1, .dominator, X => Terminal G M X ∨
      ∃ v, Legal G M X v ∧ WinsWithin M m .staller (insert v X)
  | m + 1, .staller, X => Terminal G M X ∨
      ∀ v, Legal G M X v → WinsWithin M m .dominator (insert v X)

theorem white_empty_marks (X : Finset V) (u : V) :
    White G ∅ X u ↔ IsolationGame.White G X u := by
  simp [White, Undominated, IsolationGame.White]

theorem legal_empty_marks (X : Finset V) (v : V) :
    Legal G ∅ X v ↔ IsolationGame.Legal G X v := by
  simp only [Legal, IsolationGame.Legal, white_empty_marks]

theorem terminal_empty_marks (X : Finset V) :
    Terminal G ∅ X ↔ IsolationGame.Terminal G X := by
  simp only [Terminal, IsolationGame.Terminal, white_empty_marks]

theorem wins_empty_marks (m : Nat) (p : Player) (X : Finset V) :
    WinsWithin G ∅ m p X ↔ IsolationGame.WinsWithin G m p X := by
  induction m generalizing p X with
  | zero => exact terminal_empty_marks G X
  | succ m ih =>
    cases p <;> simp only [WinsWithin, IsolationGame.WinsWithin,
      terminal_empty_marks, legal_empty_marks, ih]

theorem white_neighbor {M X : Finset V} {u : V} (hu : White G M X u) :
    ∃ w, G.Adj u w ∧ White G M X w := by
  obtain ⟨hu, w, huw, hw⟩ := hu
  exact ⟨w, huw, hw, u, huw.symm, hu⟩

theorem undominated_insert (M X : Finset V) (v u : V) :
    Undominated G M (insert v X) u ↔
      Undominated G M X u ∧ ¬ Closed G v u := by
  simp only [Undominated, IsolationGame.undominated_insert, and_assoc]

theorem white_insert (M X : Finset V) (v u : V) :
    White G M (insert v X) u ↔
      White G M X u ∧ ¬ Closed G v u ∧
        ∃ w, G.Adj u w ∧ White G M X w ∧ ¬ Closed G v w := by
  constructor
  · rintro ⟨hu, w, huw, hw⟩
    have hu' := (undominated_insert G M X v u).mp hu
    have hw' := (undominated_insert G M X v w).mp hw
    exact ⟨⟨hu'.1, w, huw, hw'.1⟩, hu'.2,
      w, huw, ⟨hw'.1, u, huw.symm, hu'.1⟩, hw'.2⟩
  · rintro ⟨hu, hcu, w, huw, hw, hcw⟩
    exact ⟨(undominated_insert G M X v u).mpr ⟨hu.1, hcu⟩,
      w, huw, (undominated_insert G M X v w).mpr ⟨hw.1, hcw⟩⟩

theorem white_after_subset {M X : Finset V} (v : V) :
    ∀ u, White G M (insert v X) u → White G M X u :=
  fun u h => ((white_insert G M X v u).mp h).1

theorem white_insert_mono {M N X Y : Finset V}
    (h : ∀ u, White G M X u → White G N Y u) (v : V) :
    ∀ u, White G M (insert v X) u → White G N (insert v Y) u := by
  intro u hu
  obtain ⟨hu, hcu, w, huw, hw, hcw⟩ := (white_insert G M X v u).mp hu
  exact (white_insert G N Y v u).mpr ⟨h u hu, hcu, w, huw, h w hw, hcw⟩

/-- An imagined move that is illegal in the real position cannot remove
any real white vertex, including either endpoint of a real white edge. -/
theorem white_survives_imagined_illegal {M N X Y : Finset V}
    (h : ∀ u, White G M X u → White G N Y u) {v : V}
    (hv : ¬ Legal G M X v) :
    ∀ u, White G M X u → White G N (insert v Y) u := by
  intro u hu
  obtain ⟨w, huw, hw⟩ := white_neighbor G hu
  exact (white_insert G N Y v u).mpr
    ⟨h u hu, fun hc => hv ⟨u, hc, hu⟩,
      w, huw, h w hw, fun hc => hv ⟨w, hc, hw⟩⟩

theorem terminal_wins {M X : Finset V} (h : Terminal G M X)
    (m : Nat) (p : Player) : WinsWithin G M m p X := by
  cases m with
  | zero => exact h
  | succ m => cases p <;> exact Or.inl h

theorem exists_legal {M X : Finset V} (h : ¬ Terminal G M X) :
    ∃ v, Legal G M X v := by
  classical
  obtain ⟨u, hu⟩ := not_forall.mp h
  exact ⟨u, u, Or.inl rfl, not_not.mp hu⟩

/-- The full Continuation Principle, with the same player to move, proved
by strategy simulation. Arbitrary marks and selected sets are allowed. -/
theorem wins_of_white_subset (m : Nat) (p : Player) {M N X Y : Finset V}
    (hsub : ∀ u, White G M X u → White G N Y u)
    (hw : WinsWithin G N m p Y) : WinsWithin G M m p X := by
  induction m generalizing p M N X Y with
  | zero => exact fun u hu => hw u (hsub u hu)
  | succ m ih =>
    classical
    by_cases ht : Terminal G M X
    · exact terminal_wins G ht _ _
    · cases p with
      | dominator =>
        rcases hw with hw | ⟨v, hv, hw⟩
        · exact False.elim (ht (fun u hu => hw u (hsub u hu)))
        · by_cases hvr : Legal G M X v
          · exact Or.inr ⟨v, hvr, ih _ (white_insert_mono G hsub v) hw⟩
          · obtain ⟨w, hwl⟩ := exists_legal G ht
            refine Or.inr ⟨w, hwl, ih _ ?_ hw⟩
            intro u hu
            exact white_survives_imagined_illegal G hsub hvr u
              (white_after_subset G w u hu)
      | staller =>
        rcases hw with hw | hw
        · exact False.elim (ht (fun u hu => hw u (hsub u hu)))
        · apply Or.inr
          intro v hv
          have hvi : Legal G N Y v := by
            obtain ⟨u, hc, hu⟩ := hv
            exact ⟨u, hc, hsub u hu⟩
          exact ih _ (white_insert_mono G hsub v) (hw v hvi)

theorem white_antitone_marks {M N X : Finset V} (hMN : M ⊆ N) :
    ∀ u, White G N X u → White G M X u := by
  rintro u ⟨⟨hu, hu'⟩, w, huw, hw, hw'⟩
  exact ⟨⟨fun hm => hu (hMN hm), hu'⟩, w, huw, fun hm => hw (hMN hm), hw'⟩

theorem white_antitone_selected {M X Y : Finset V} (hXY : X ⊆ Y) :
    ∀ u, White G M Y u → White G M X u := by
  rintro u ⟨⟨hu, hu'⟩, w, huw, hw, hw'⟩
  exact ⟨⟨hu, IsolationGame.undominated_anti G hXY hu'⟩,
    w, huw, hw, IsolationGame.undominated_anti G hXY hw'⟩

theorem continuation {M N X : Finset V} (hMN : M ⊆ N) {m : Nat} {p : Player}
    (h : WinsWithin G M m p X) : WinsWithin G N m p X :=
  wins_of_white_subset G m p (white_antitone_marks G hMN) h

theorem staller_le_dominator_succ {M X : Finset V} {m : Nat}
    (h : WinsWithin G M m .dominator X) : WinsWithin G M (m+1) .staller X := by
  apply Or.inr
  intro v _
  exact wins_of_white_subset G m .dominator (white_after_subset G v) h

theorem wins_mono {M X : Finset V} {m n : Nat} {p : Player}
    (hmn : m ≤ n) (h : WinsWithin G M m p X) : WinsWithin G M n p X := by
  have step : ∀ m p X, WinsWithin G M m p X → WinsWithin G M (m+1) p X := by
    intro m
    induction m with
    | zero => intro p X h; exact terminal_wins G h _ _
    | succ m ih =>
      intro p X h
      cases p with
      | dominator =>
        rcases h with h | ⟨v, hv, hw⟩
        · exact Or.inl h
        · exact Or.inr ⟨v, hv, ih _ _ hw⟩
      | staller =>
        rcases h with h | h
        · exact Or.inl h
        · exact Or.inr (fun v hv => ih _ _ (h v hv))
  induction hmn with
  | refl => exact h
  | step _ ih => exact step _ _ _ ih

variable [Fintype V]

instance [DecidableRel G.Adj] (M X : Finset V) (u : V) :
    Decidable (Undominated G M X u) := by unfold Undominated; infer_instance

instance [DecidableRel G.Adj] (M X : Finset V) (u : V) :
    Decidable (White G M X u) := by unfold White; infer_instance

instance [DecidableRel G.Adj] (M X : Finset V) (v : V) :
    Decidable (Legal G M X v) := by unfold Legal; infer_instance

instance [DecidableRel G.Adj] (M X : Finset V) :
    Decidable (Terminal G M X) := by unfold Terminal; infer_instance

theorem exists_wins (M : Finset V) (p : Player) (X : Finset V) :
    ∃ m, WinsWithin G M m p X := by
  obtain ⟨m, hm⟩ := IsolationGame.exists_wins G p X
  exact ⟨m, continuation G (Finset.empty_subset M) ((wins_empty_marks G m p X).mpr hm)⟩

noncomputable def gameValue (M : Finset V) (p : Player) (X : Finset V) : Nat := by
  classical
  exact Nat.find (exists_wins G M p X)

theorem gameValue_le_iff (M : Finset V) (p : Player) (X : Finset V) (m : Nat) :
    gameValue G M p X ≤ m ↔ WinsWithin G M m p X := by
  classical
  constructor
  · intro h
    exact wins_mono G h (Nat.find_spec (exists_wins G M p X))
  · intro h
    exact Nat.find_min' (exists_wins G M p X) h

theorem value_empty_marks (p : Player) (X : Finset V) :
    gameValue G ∅ p X = IsolationGame.gameValue G p X := by
  apply Nat.le_antisymm
  · apply (gameValue_le_iff G ∅ p X _).mpr
    apply (wins_empty_marks G _ p X).mpr
    exact (IsolationGame.gameValue_le_iff G p X _).mp (Nat.le_refl _)
  · apply (IsolationGame.gameValue_le_iff G p X _).mpr
    apply (wins_empty_marks G _ p X).mp
    exact (gameValue_le_iff G ∅ p X _).mp (Nat.le_refl _)

theorem value_continuation {M N : Finset V} (hMN : M ⊆ N)
    (p : Player) (X : Finset V) : gameValue G N p X ≤ gameValue G M p X := by
  apply (gameValue_le_iff G N p X _).mpr
  exact continuation G hMN ((gameValue_le_iff G M p X _).mp (Nat.le_refl _))

theorem starting_player_inequality (M X : Finset V) :
    gameValue G M .staller X ≤ gameValue G M .dominator X + 1 := by
  apply (gameValue_le_iff G M .staller X _).mpr
  exact staller_le_dominator_succ G
    ((gameValue_le_iff G M .dominator X _).mp (Nat.le_refl _))

end IsolationGame.Marked
