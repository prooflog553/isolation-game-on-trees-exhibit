import IsolationGame.DiameterSeven.ZeroExtras

namespace IsolationGame.DiameterSeven.DoubleRooted

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V} (x y : V) (hT : G.IsTree) (hc : CenterEdge G x y)

theorem counted_depth_one {u : V} (hu : u∈counted x y hT hc)
    (hd : depth (G := G) x y u=1) : ∃ i : Index (G := G) x y, parent x y hT hc i=u := by
  classical
  let A := system x y hT hc
  rcases Finset.mem_insert.mp hu with h | hu
  · rw [h,depth_y] at hd; omega
  · rcases Finset.mem_insert.mp hu with h | hu
    · rw [h,depth_x] at hd; omega
    · rcases Finset.mem_union.mp hu with hu | hu
      · obtain ⟨i,_,hi⟩ := Finset.mem_image.mp hu
        exact ⟨i,hi⟩
      · rcases Finset.mem_union.mp hu with hu | hu
        · obtain ⟨i,_,hi⟩ := Finset.mem_image.mp hu
          have hd2 := i.property.1
          change i.val=u at hi
          rw [hi] at hd2; omega
        · obtain ⟨i,_,hi⟩ := Finset.mem_image.mp hu
          have hd3 := ((mem_leaves x y i (A.chosenLeaf i)).mp (A.chosenLeaf_mem i)).2
          rw [hi] at hd3; omega

theorem counted_depth_two {u : V} (hu : u∈counted x y hT hc)
    (hd : depth (G := G) x y u=2) : ∃ i : Index (G := G) x y, i.val=u := by
  classical
  let A := system x y hT hc
  rcases Finset.mem_insert.mp hu with h | hu
  · rw [h,depth_y] at hd; omega
  · rcases Finset.mem_insert.mp hu with h | hu
    · rw [h,depth_x] at hd; omega
    · rcases Finset.mem_union.mp hu with hu | hu
      · obtain ⟨i,_,hi⟩ := Finset.mem_image.mp hu
        have hd1 := (parent_spec x y hT hc i).2
        change parent x y hT hc i=u at hi
        rw [hi] at hd1; omega
      · rcases Finset.mem_union.mp hu with hu | hu
        · obtain ⟨i,_,hi⟩ := Finset.mem_image.mp hu
          exact ⟨i,hi⟩
        · obtain ⟨i,_,hi⟩ := Finset.mem_image.mp hu
          have hd3 := ((mem_leaves x y i (A.chosenLeaf i)).mp (A.chosenLeaf_mem i)).2
          rw [hi] at hd3; omega

/-- A depth-one branch without a deep star, and with a depth-two child. -/
def ShallowOn (r : V) : Prop :=
  ∃ q w, G.Adj r q ∧ depth (G := G) x y q=1 ∧ G.Adj q w ∧
    depth (G := G) x y w=2 ∧ ¬ ∃ i : Index (G := G) x y, parent x y hT hc i=q

theorem shallow_cost {r : V} (h : ShallowOn x y hT hc r) :
    ∃ q w, G.Adj r q ∧ depth (G := G) x y q=1 ∧ G.Adj q w ∧
      depth (G := G) x y w=2 ∧ q∈extras x y hT hc ∧ w∈extras x y hT hc := by
  classical
  obtain ⟨q,w,hrq,hq,hqw,hw,hn⟩ := h
  refine ⟨q,w,hrq,hq,hqw,hw,?_,?_⟩
  · apply Finset.mem_sdiff.mpr
    exact ⟨Finset.mem_univ _,fun hq' => hn (counted_depth_one x y hT hc hq' hq)⟩
  · apply Finset.mem_sdiff.mpr
    refine ⟨Finset.mem_univ _,?_⟩
    intro hw'
    obtain ⟨i,hi⟩ := counted_depth_two x y hT hc hw' hw
    have hpi := parent_spec x y hT hc i
    apply hn
    refine ⟨i,?_⟩
    apply unique_lower x y hT hc (u := i.val) (by have := i.property.1; omega) hpi.1
      (by rw [hi]; exact hqw.symm)
    · have := i.property.1; omega
    · have := i.property.1; omega

/-- At most three extras cannot support shallow branches on both sides. -/
theorem shallow_orientation (he : (extras x y hT hc).card ≤ 3) :
    ¬ ShallowOn x y hT hc x ∨ ¬ ShallowOn x y hT hc y := by
  classical
  by_contra h
  push_neg at h
  obtain ⟨q,w,hxq,hq,hqw,hw,hqe,hwe⟩ := shallow_cost x y hT hc h.1
  obtain ⟨r,s,hyr,hr,hrs,hs,hre,hse⟩ := shallow_cost x y hT hc h.2
  have hqx : G.dist q x=1 := SimpleGraph.dist_eq_one_iff_adj.mpr hxq.symm
  have hry : G.dist r y=1 := SimpleGraph.dist_eq_one_iff_adj.mpr hyr.symm
  have hqside : LeftSide G x y q := by
    have := endpoint_distance_step hT hc.1 q
    unfold depth at hq
    unfold LeftSide
    omega
  have hrside : LeftSide G y x r := by
    have := endpoint_distance_step hT hc.1 r
    unfold depth at hr
    unfold LeftSide
    omega
  have hqne : q≠x := by intro hh; rw [hh,depth_x] at hq; omega
  have hrne : r≠y := by intro hh; rw [hh,depth_y] at hr; omega
  have hwside := nonroot_neighbor_same_side hT hc.1 hqside hqne hqw
  have hsside := nonroot_neighbor_same_side hT hc.1.symm hrside hrne hrs
  have hqr : q≠r := by intro hh; rw [hh] at hqside; exact (sides_partition hT hc.1 r).2 ⟨hqside,hrside⟩
  have hws : w≠s := by intro hh; rw [hh] at hwside; exact (sides_partition hT hc.1 s).2 ⟨hwside,hsside⟩
  have hqw' : q≠w := by intro hh; rw [hh] at hq; omega
  have hqs : q≠s := by intro hh; rw [hh] at hq; omega
  have hwr : w≠r := by intro hh; rw [hh] at hw; omega
  have hrs' : r≠s := by intro hh; rw [hh] at hr; omega
  have hsub : ({q,w,r,s} : Finset V) ⊆ extras x y hT hc := by
    intro u hu
    simp only [Finset.mem_insert,Finset.mem_singleton] at hu
    rcases hu with rfl | rfl | rfl | rfl <;> assumption
  have hcard := Finset.card_le_card hsub
  simp [hqw',hqr,hqs,hwr,hws,hrs'] at hcard
  omega

include hT hc in
/-- Any white neighbor of the opposite root has depth one and an
undominated depth-two child. This includes short-only gates. -/
theorem white_gate_levels {X : Finset V} (hx : x∈X) {q : V}
    (hyq : G.Adj y q) (hq : White G X q) :
    depth (G := G) x y q=1 ∧
      ∃ w, G.Adj q w ∧ Undominated G X w ∧ depth (G := G) x y w=2 := by
  have root_dom {u : V} (hu : u=x ∨ u=y) : Dominated G X u := by
    refine ⟨x,hx,?_⟩
    rcases hu with rfl | rfl
    · exact Or.inl rfl
    · exact Or.inr hc.1
  have hqpos : 0 < depth (G := G) x y q := by
    by_contra h
    have hq0 : depth (G := G) x y q=0 := Nat.eq_zero_of_not_pos h
    exact hq.1 (root_dom ((depth_zero_iff x y hT q).mp hq0))
  have hstep := adj_depths x y hT hc hqpos hyq.symm
  rw [depth_y] at hstep
  have hq1 : depth (G := G) x y q=1 := by omega
  obtain ⟨w,hqw,hw⟩ := hq.2
  have hwpos : 0 < depth (G := G) x y w := by
    by_contra h
    have hw0 : depth (G := G) x y w=0 := Nat.eq_zero_of_not_pos h
    exact hw (root_dom ((depth_zero_iff x y hT w).mp hw0))
  have hstep2 := adj_depths x y hT hc hqpos hqw
  exact ⟨hq1,w,hqw,hw,by omega⟩

theorem white_gate_parent (hsh : ¬ ShallowOn x y hT hc y)
    {X : Finset V} (hx : x∈X) {q : V} (hyq : G.Adj y q) (hq : White G X q) :
    ∃ i : Index (G := G) x y, parent x y hT hc i=q := by
  obtain ⟨hdq,w,hqw,_,hdw⟩ := white_gate_levels x y hT hc hx hyq hq
  by_contra hn
  exact hsh ⟨q,w,hyq,hdq,hqw,hdw,hn⟩

include hT hc in
theorem adjacent_right_side {q : V} (hyq : G.Adj y q)
    (hq : depth (G := G) x y q=1) : LeftSide G y x q := by
  have hdist := SimpleGraph.dist_eq_one_iff_adj.mpr hyq.symm
  have hstep := endpoint_distance_step hT hc.1 q
  unfold depth at hq
  unfold LeftSide
  omega

theorem extras_orientation (he : (extras x y hT hc).card ≤ 1) :
    (∀ z∈extras x y hT hc, LeftSide G x y z) ∨
    (∀ z∈extras x y hT hc, LeftSide G y x z) := by
  classical
  by_cases hl : ∀ z∈extras x y hT hc, LeftSide G x y z
  · exact Or.inl hl
  · push_neg at hl
    obtain ⟨z,hz,hnot⟩ := hl
    have hr := ((sides_partition hT hc.1 z).1).resolve_left hnot
    refine Or.inr (fun w hw => ?_)
    have heq := Finset.card_le_one.mp he w hw z hz
    exact heq ▸ hr

theorem no_shallow_of_extras_left
    (he : ∀ z∈extras x y hT hc, LeftSide G x y z) : ¬ ShallowOn x y hT hc y := by
  intro h
  obtain ⟨q,_,hyq,hq,_,_,hqe,_⟩ := shallow_cost x y hT hc h
  exact (sides_partition hT hc.1 q).2 ⟨he q hqe,adjacent_right_side x y hT hc hyq hq⟩

end IsolationGame.DiameterSeven.DoubleRooted
