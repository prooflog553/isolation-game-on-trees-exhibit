import IsolationGame.DiameterSeven.OneGate

namespace IsolationGame.DiameterSeven.DoubleRooted

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V} (x y : V) (hT : G.IsTree) (hc : CenterEdge G x y)

/-- With no shallow branch opposite the first root, a non-root legal move
that hits no deep star necessarily dominates an opposite white gate. -/
theorem zero_hit_opens_gate (hsh : ¬ ShallowOn x y hT hc y)
    {v : V} (hv : Legal G {x} v) (hvy : v≠y)
    (hz : ¬ ∃ i : Index (G := G) x y, Closed G v i.val) :
    ∃ q, G.Adj y q ∧ White G {x} q ∧ Closed G v q := by
  classical
  have hvx : v≠x := by intro hh; subst v; exact selected_not_legal G (by simp) hv
  have hside : LeftSide G y x v := by
    rcases (sides_partition hT hc.1 v).1 with hl | hr
    · exact False.elim (hz (legal_left_hits_star x y hT hc hv hl))
    · exact hr
  have hpos : 0 < depth (G := G) x y v := by
    by_contra h
    have h0 := Nat.eq_zero_of_not_pos h
    exact ((depth_zero_iff x y hT v).mp h0).elim hvx hvy
  have hmax := depth_le_three x y hc v
  have hnotparent : ¬ ∃ i : Index (G := G) x y, parent x y hT hc i=v := by
    rintro ⟨i,hi⟩
    apply hz
    exact ⟨i,((system x y hT hc).closed_center_iff i v).mpr (Or.inr hi.symm)⟩
  have root_dom {u : V} (hu : u=x ∨ u=y) : Dominated G {x} u := by
    refine ⟨x,by simp,?_⟩
    rcases hu with rfl | rfl
    · exact Or.inl rfl
    · exact Or.inr hc.1
  have hdnot1 : depth (G := G) x y v≠1 := by
    intro hd1
    have hyv : G.Adj y v := by
      have hdv : G.dist v y=1 := (depth_right x y hside).symm.trans hd1
      exact (SimpleGraph.dist_eq_one_iff_adj.mp hdv).symm
    obtain ⟨u,hu,huw⟩ := hv
    rcases hu with hu | hu
    · have hvw : White G {x} v := hu ▸ huw
      obtain ⟨_,w,hvw,_,hdw⟩ := white_gate_levels x y hT hc (by simp) hyv hvw
      exact hsh ⟨v,w,hyv,hd1,hvw,hdw,hnotparent⟩
    · have hdu := adj_depths x y hT hc hpos hu
      have hup : 0 < depth (G := G) x y u := by
        by_contra h
        exact huw.1 (root_dom ((depth_zero_iff x y hT u).mp (Nat.eq_zero_of_not_pos h)))
      exact hsh ⟨v,u,hyv,hd1,hu,by omega,hnotparent⟩
  have hdnot3 : depth (G := G) x y v≠3 := by
    intro hd3
    obtain ⟨c,hvc,hdc⟩ := exists_lower x y hT hc hpos
    let i : Index (G := G) x y := ⟨c,by omega,v,hvc.symm,hd3⟩
    exact hz ⟨i,Or.inr hvc⟩
  have hd2 : depth (G := G) x y v=2 := by omega
  have neighbor_depth {q : V} (hvq : G.Adj v q) : depth (G := G) x y q=1 := by
    have hqd := adj_depths x y hT hc hpos hvq
    by_contra hh
    have hq3 : depth (G := G) x y q=3 := by omega
    let i : Index (G := G) x y := ⟨v,hd2,q,hvq,hq3⟩
    exact hz ⟨i,Or.inl rfl⟩
  have gate_neighbor {q : V} (hvq : G.Adj v q) (hq : White G {x} q) :
      G.Adj y q ∧ White G {x} q ∧ Closed G v q := by
    have hqd := neighbor_depth hvq
    have hqs := nonroot_neighbor_same_side hT hc.1.symm hside hvy hvq
    have hdist : G.dist q y=1 := (depth_right x y hqs).symm.trans hqd
    exact ⟨(SimpleGraph.dist_eq_one_iff_adj.mp hdist).symm,hq,Or.inr hvq⟩
  obtain ⟨u,hu,huw⟩ := hv
  rcases hu with hu | hu
  · have hvw : White G {x} v := hu ▸ huw
    obtain ⟨q,hvq,hq⟩ := hvw.2
    exact ⟨q,gate_neighbor hvq ⟨hq,v,hvq.symm,hvw.1⟩⟩
  · exact ⟨u,gate_neighbor hu huw⟩

set_option maxHeartbeats 2000000 in
/-- The small transition argument for at most two opposite deep groups.
Zero-star replies open one gate; Dominator closes the only remaining gate. -/
theorem two_opposite_groups_bound (hd : G.diam=7)
    (hsh : ¬ ShallowOn x y hT hc y)
    (hside : (sideParents x y hT hc y).card ≤ 2) :
    isolationNumber G ≤ (allIndices (G := G) x y).card+2 := by
  classical
  let A := system x y hT hc
  let R := allIndices (G := G) x y
  let m := R.card-1
  have hbk : 2 ≤ (A.groups R).card := two_groups x y hT hc hd
  have hkl : (A.groups R).card ≤ R.card := Finset.card_image_le
  have hkmin : 2 ≤ R.card := by omega
  have hbase : A.Represents R {x,y} := both_roots_represents x y hT hc
  have hxlegal : Legal G ∅ x := by
    refine ⟨x,Or.inl rfl,?_,y,hc.1,?_⟩ <;> simp [Undominated,Dominated]
  have hw : WinsWithin G (m+3) .dominator ∅ := by
    refine Or.inr ⟨x,hxlegal,Or.inr ?_⟩
    intro v hv
    by_cases hvy : v=y
    · subst v
      have hrep : A.Represents R {y,x} := by simpa only [Finset.pair_comm] using hbase
      apply (A.strategy_equivalence hrep (m+1) .dominator).mpr
      convert A.dominator_units R using 1 <;> dsimp [m] <;> omega
    · by_cases hhit : ∃ i∈R, Closed G v (A.center i)
      · have hdrop := A.hit_card_drop hhit
        have hQk : (A.remainingAfter R v).card ≤ R.card-1 := by omega
        have hQg : (A.groups (A.remainingAfter R v)).card ≤ R.card-1 :=
          Finset.card_image_le.trans hQk
        have hh := A.after_root_reply hbase hQg hQk
        apply (gameValue_le_iff G .dominator {v,x} (m+1)).mp
        dsimp [m]
        unfold sBound at hh
        split at hh <;> omega
      · have hhit' : ¬ ∃ i : Index (G := G) x y, Closed G v i.val := by
          rintro ⟨i,hi⟩
          exact hhit ⟨i,by simp [R,allIndices],hi⟩
        obtain ⟨q,hyq,hq,hvq⟩ := zero_hit_opens_gate x y hT hc hsh hv hvy hhit'
        obtain ⟨j,hj⟩ := white_gate_parent x y hT hc hsh (by simp) hyq hq
        have hqP : q∈sideParents x y hT hc y :=
          Finset.mem_filter.mpr ⟨Finset.mem_image.mpr ⟨j,by simp [allIndices],hj⟩,hyq⟩
        let X : Finset V := {v,x}
        let P := (sideParents x y hT hc y).erase q
        have hPcard : P.card ≤ 1 := by
          dsimp [P]
          rw [Finset.card_erase_of_mem hqP]
          omega
        have hxX : x∈X := by simp [X]
        have hyd : Dominated G X y := ⟨x,hxX,Or.inr hc.1⟩
        have hgate_mem {w : V} (hyw : G.Adj y w) (hw : White G X w) : w∈P := by
          obtain ⟨i,hi⟩ := white_gate_parent x y hT hc hsh hxX hyw hw
          apply Finset.mem_erase.mpr
          refine ⟨?_,Finset.mem_filter.mpr ⟨Finset.mem_image.mpr ⟨i,by simp [allIndices],hi⟩,hyw⟩⟩
          intro hwq
          exact hw.1 ⟨v,by simp [X],hwq ▸ hvq⟩
        by_cases hy : Legal G X y
        · obtain ⟨w,hyw,hw⟩ := hy
          have hyw' := hyw.resolve_left (fun hh => hw.1 (hh ▸ hyd))
          have hwP := hgate_mem hyw' hw
          have hgate : ∀ u, G.Adj y u → White G X u → u=w := by
            intro u hyu hu
            exact Finset.card_le_one.mp hPcard u (hgate_mem hyu hu) w hwP
          obtain ⟨hwl,hyno⟩ := unique_gate_reply y hyd ⟨w,hyw,hw⟩ hgate
          refine Or.inr ⟨w,hwl,?_⟩
          obtain ⟨i,hi⟩ := white_gate_parent x y hT hc hsh hxX hyw' hw
          have himem : parent x y hT hc i∈insert w X := by rw [hi]; simp
          have hbound := (parent_selected_bounds x y hT hc i himem).2
          have hrep := represents_survivors x y hT hc
            (selected_not_legal G (Finset.mem_insert_of_mem hxX)) hyno
          apply (A.strategy_equivalence hrep m .staller).mpr
          exact A.wins_of_controlled_bound _ _ _ (fun _ ht => (ht.units_bound A).trans hbound)
        · have hrep := represents_survivors x y hT hc (selected_not_legal G hxX) hy
          have hcount : (survivors (G := G) x y X).card ≤ R.card :=
            Finset.card_le_card (survivors_subset x y X)
          apply (A.strategy_equivalence hrep (m+1) .dominator).mpr
          exact A.wins_of_controlled_bound _ _ _
            (fun _ ht => by have hh := ht.units_bound A; dsimp [m]; omega)
  have hh := (isolationNumber_le_iff G (m+3)).mpr hw
  change isolationNumber G ≤ R.card+2
  dsimp [m] at hh
  omega

end IsolationGame.DiameterSeven.DoubleRooted
