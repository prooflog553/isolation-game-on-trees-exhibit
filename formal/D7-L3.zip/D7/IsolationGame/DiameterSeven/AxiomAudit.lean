import IsolationGame.DiameterSeven.SmallOrders
import IsolationGame.DiameterSeven.Sixteen
import IsolationGame.DiameterSeven.NineAndPath

#eval "DIAMETER SEVEN: unconditional small-order and full-theorem audit"

#print IsolationGame.DiameterSeven.FullDiameterSevenBound
#check IsolationGame.DiameterSeven.diameter_seven_large
#check IsolationGame.DiameterSeven.full_bound_of_small_orders

#print axioms IsolationGame.tree_diameter_six_bound
#print axioms IsolationGame.Marked.wins_empty_marks
#print axioms IsolationGame.Marked.wins_of_white_subset
#print axioms IsolationGame.Marked.value_empty_marks
#print axioms IsolationGame.Marked.starting_player_inequality
#print axioms IsolationGame.DiameterSeven.exists_centerEdge
#print axioms IsolationGame.DiameterSeven.only_cross_edge
#print axioms IsolationGame.DiameterSeven.DoubleRooted.system
#print axioms IsolationGame.DiameterSeven.DoubleRooted.exact_count
#print axioms IsolationGame.DiameterSeven.DoubleRooted.two_groups
#print axioms IsolationGame.DiameterSeven.DoubleRooted.orientation
#print axioms IsolationGame.DiameterSeven.DoubleRooted.transition_represents
#print axioms IsolationGame.DiameterSeven.DoubleRooted.illegal_second_root_represents
#print axioms IsolationGame.StarSystem.staller_survival
#print axioms IsolationGame.DiameterSeven.uniform_arithmetic
#print axioms IsolationGame.DiameterSeven.exception_partition
#print axioms IsolationGame.DiameterSeven.accounting
#print axioms IsolationGame.DiameterSeven.Small.delete_x_iso
#print axioms IsolationGame.DiameterSeven.Small.delete_y_iso
#print axioms IsolationGame.DiameterSeven.Small.H_four_moves
#print axioms IsolationGame.DiameterSeven.Small.H_marked_x_chain
#print axioms IsolationGame.DiameterSeven.ResidualEmbedding.wins_iff
#print axioms IsolationGame.DiameterSeven.Small.sixteen_residual_value
#print axioms IsolationGame.DiameterSeven.Small.sixteen_six_moves
#print axioms IsolationGame.DiameterSeven.Small.nine_three_moves
#print axioms IsolationGame.DiameterSeven.Small.P8_three_moves
#print axioms IsolationGame.DiameterSeven.diameter_seven_large

/- The original assembly helper retains its interface; the following
unconditional theorems supply its premise inside the proof term. -/
#print axioms IsolationGame.DiameterSeven.full_bound_of_small_orders

#print IsolationGame.DiameterSeven.smallOrderBound
#print IsolationGame.DiameterSeven.fullDiameterSevenBound
#print IsolationGame.DiameterSeven.tree_diameter_seven_bound
#print axioms IsolationGame.DiameterSeven.order_nine_iso
#print axioms IsolationGame.DiameterSeven.DoubleRooted.eleven_H_iso
#print axioms IsolationGame.DiameterSeven.DoubleRooted.sixteen_balanced_iso
#print axioms IsolationGame.DiameterSeven.DoubleRooted.eighteen_balanced_iso
#print axioms IsolationGame.DiameterSeven.AccountingCertificate.wins
#print axioms IsolationGame.DiameterSeven.Small.E18_fast_check_eq
#print axioms IsolationGame.DiameterSeven.Small.E18_accounting
#print axioms IsolationGame.DiameterSeven.Small.eighteen_seven_moves
#print axioms IsolationGame.DiameterSeven.smallOrderBound
#print axioms IsolationGame.DiameterSeven.fullDiameterSevenBound
#print axioms IsolationGame.DiameterSeven.tree_diameter_seven_bound
