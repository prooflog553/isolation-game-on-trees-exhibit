import IsolationGame.DiameterSeven.ExtraStructure

namespace IsolationGame.DiameterSeven.DoubleRooted

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V} (x y : V) (hT : G.IsTree) (hc : CenterEdge G x y)

def swapIndex : Index (G := G) x y ≃ Index (G := G) y x where
  toFun i := ⟨i.val,by simpa only [depth,Nat.min_comm] using i.property⟩
  invFun i := ⟨i.val,by simpa only [depth,Nat.min_comm] using i.property⟩
  left_inv := by intro i; rfl
  right_inv := by intro i; rfl

theorem parent_swap (i : Index (G := G) x y) :
    parent y x hT (centerEdge_symm hc) (swapIndex x y i)=parent x y hT hc i := by
  have ha := parent_spec x y hT hc i
  have hb := parent_spec y x hT (centerEdge_symm hc) (swapIndex x y i)
  have hb' : depth (G := G) x y (parent y x hT (centerEdge_symm hc) (swapIndex x y i))=1 := by
    simpa only [depth,Nat.min_comm] using hb.2
  exact unique_lower x y hT hc (u := i.val) (by have := i.property.1; omega) hb.1 ha.1
    (by have := i.property.1; omega) (by have := i.property.1; omega)

theorem hasParent_swap (q : V) :
    (∃ i : Index (G := G) x y, parent x y hT hc i=q) ↔
    (∃ i : Index (G := G) y x, parent y x hT (centerEdge_symm hc) i=q) := by
  constructor
  · rintro ⟨i,hi⟩
    exact ⟨swapIndex x y i,(parent_swap x y hT hc i).trans hi⟩
  · rintro ⟨i,hi⟩
    obtain ⟨j,rfl⟩ := (swapIndex (G := G) x y).surjective i
    exact ⟨j,(parent_swap x y hT hc j).symm.trans hi⟩

theorem groups_swap :
    (allIndices y x).image (parent y x hT (centerEdge_symm hc)) =
    (allIndices x y).image (parent x y hT hc) := by
  classical
  ext q
  simp only [Finset.mem_image,allIndices,Finset.mem_univ,true_and]
  exact (hasParent_swap x y hT hc q).symm

theorem stars_swap :
    (allIndices (G := G) y x).card=(allIndices (G := G) x y).card := by
  classical
  simp only [allIndices,Finset.card_univ]
  exact Fintype.card_congr (swapIndex (G := G) x y).symm

theorem extras_swap :
    (extras y x hT (centerEdge_symm hc)).card=(extras x y hT hc).card := by
  have ha := exact_count x y hT hc
  have hb := exact_count y x hT (centerEdge_symm hc)
  rw [groups_swap x y hT hc,stars_swap x y] at hb
  omega

theorem shallow_swap (r : V) :
    ShallowOn y x hT (centerEdge_symm hc) r ↔ ShallowOn x y hT hc r := by
  simp only [ShallowOn]
  simp_rw [← hasParent_swap x y hT hc]
  simp only [depth,Nat.min_comm]

theorem chosenLeaf_swap (i : Index (G := G) x y) :
    (system y x hT (centerEdge_symm hc)).chosenLeaf (swapIndex x y i) =
      (system x y hT hc).chosenLeaf i := by
  classical
  simp only [StarSystem.chosenLeaf,system,leaves,depth,swapIndex,Nat.min_comm]

theorem counted_swap : counted y x hT (centerEdge_symm hc)=counted x y hT hc := by
  classical
  have hcenters :
      (allIndices (G := G) y x).image (system y x hT (centerEdge_symm hc)).center =
        (allIndices (G := G) x y).image (system x y hT hc).center := by
    ext u
    simp only [Finset.mem_image,allIndices,Finset.mem_univ,true_and]
    constructor
    · rintro ⟨i,hi⟩
      obtain ⟨j,rfl⟩ := (swapIndex (G := G) x y).surjective i
      exact ⟨j,hi⟩
    · rintro ⟨i,hi⟩
      exact ⟨swapIndex x y i,hi⟩
  have hleaves :
      (allIndices (G := G) y x).image (system y x hT (centerEdge_symm hc)).chosenLeaf =
        (allIndices (G := G) x y).image (system x y hT hc).chosenLeaf := by
    ext u
    simp only [Finset.mem_image,allIndices,Finset.mem_univ,true_and]
    constructor
    · rintro ⟨i,hi⟩
      obtain ⟨j,rfl⟩ := (swapIndex (G := G) x y).surjective i
      exact ⟨j,(chosenLeaf_swap x y hT hc j).symm.trans hi⟩
    · rintro ⟨i,hi⟩
      exact ⟨swapIndex x y i,(chosenLeaf_swap x y hT hc i).trans hi⟩
  unfold counted StarSystem.countedVertices
  rw [hcenters,hleaves]
  change insert x (insert y (((allIndices y x).image (parent y x hT (centerEdge_symm hc))) ∪ _)) = _
  rw [groups_swap x y hT hc,Finset.insert_comm]
  rfl

theorem extras_swap_set : extras y x hT (centerEdge_symm hc)=extras x y hT hc := by
  unfold extras
  rw [counted_swap x y hT hc]

end IsolationGame.DiameterSeven.DoubleRooted
