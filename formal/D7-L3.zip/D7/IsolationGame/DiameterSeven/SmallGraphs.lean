import IsolationGame.DiameterSeven.Marked
import IsolationGame.Relabel
import Mathlib.Tactic.FinCases
import Mathlib.Data.Fintype.Sum
import Mathlib.Combinatorics.SimpleGraph.Maps

namespace IsolationGame.DiameterSeven

open SimpleGraph

/-- A finite explicit graph, retaining every vertex as a possible blue move. -/
def edgeGraph {n : Nat} (es : List (Nat × Nat)) : SimpleGraph (Fin n) :=
  SimpleGraph.fromRel (fun u v => (u.val, v.val) ∈ es)

instance {n : Nat} (es : List (Nat × Nat)) : DecidableRel (edgeGraph (n := n) es).Adj :=
  fun u v => inferInstanceAs (Decidable (u ≠ v ∧ (_ ∨ _)))

def pathGraph (n : Nat) : SimpleGraph (Fin n) where
  Adj u v := u.val+1=v.val ∨ v.val+1=u.val
  symm := by intro u v h; exact h.symm
  loopless := by intro u h; omega

instance (n : Nat) : DecidableRel (pathGraph n).Adj :=
  fun _ _ => inferInstanceAs (Decidable (_ ∨ _))

/-- Disjoint union as a graph construction only; no additivity of game values. -/
def graphSum {A B : Type*} (G : SimpleGraph A) (H : SimpleGraph B) :
    SimpleGraph (A ⊕ B) where
  Adj u v := match u, v with
    | .inl a, .inl b => G.Adj a b
    | .inr a, .inr b => H.Adj a b
    | _, _ => False
  symm := by intro u v; cases u <;> cases v <;> simp_all [G.adj_comm, H.adj_comm]
  loopless := by intro u; cases u <;> simp [G.loopless, H.loopless]

instance {A B : Type*} (G : SimpleGraph A) (H : SimpleGraph B)
    [DecidableRel G.Adj] [DecidableRel H.Adj] : DecidableRel (graphSum G H).Adj := by
  intro u v
  cases u <;> cases v <;> dsimp [graphSum] <;> infer_instance

namespace Small

/-- Labels fixed by the paper: x=0 has one arm 2-3-4;
y=1 has two arms 5-6-7 and 8-9-10. -/
def H : SimpleGraph (Fin 11) := edgeGraph
  [(0,1),(0,2),(2,3),(3,4),(1,5),(5,6),(6,7),(1,8),(8,9),(9,10)]

abbrev x : Fin 11 := 0
abbrev y : Fin 11 := 1

instance : DecidableRel H.Adj := inferInstanceAs (DecidableRel (edgeGraph _).Adj)

theorem roots_distinguished :
    (∀ u : Fin 11, H.Adj x u ↔ u=y ∨ u=2) ∧
    (∀ u : Fin 11, H.Adj y u ↔ u=x ∨ u=5 ∨ u=8) := by decide

def deletionXMap : Fin 7 ⊕ Fin 3 → Fin 11
  | .inl i => if i=0 then 7 else if i=1 then 6 else if i=2 then 5
      else if i=3 then 1 else if i=4 then 8 else if i=5 then 9 else 10
  | .inr i => if i=0 then 2 else if i=1 then 3 else 4

def deletionYMap : Fin 4 ⊕ (Fin 3 ⊕ Fin 3) → Fin 11
  | .inl i => if i=0 then 0 else if i=1 then 2 else if i=2 then 3 else 4
  | .inr (.inl i) => if i=0 then 5 else if i=1 then 6 else 7
  | .inr (.inr i) => if i=0 then 8 else if i=1 then 9 else 10

theorem deletionX_avoids : ∀ i, deletionXMap i ≠ x := by decide
theorem deletionY_avoids : ∀ i, deletionYMap i ≠ y := by decide

def deletionXEmbedding (i : Fin 7 ⊕ Fin 3) : {u : Fin 11 // u ≠ x} :=
  ⟨deletionXMap i, deletionX_avoids i⟩

def deletionYEmbedding (i : Fin 4 ⊕ (Fin 3 ⊕ Fin 3)) : {u : Fin 11 // u ≠ y} :=
  ⟨deletionYMap i, deletionY_avoids i⟩

theorem deletionX_bijective : Function.Bijective deletionXEmbedding := by decide
theorem deletionY_bijective : Function.Bijective deletionYEmbedding := by decide

/-- H minus its SINGLE-arm root is P7 disjoint union P3. -/
noncomputable def delete_x_iso :
    graphSum (pathGraph 7) (pathGraph 3) ≃g H.induce {u | u ≠ x} where
  toEquiv := Equiv.ofBijective deletionXEmbedding deletionX_bijective
  map_rel_iff' := by decide

/-- H minus its DOUBLE-arm root is P4 disjoint union P3 disjoint union P3. -/
noncomputable def delete_y_iso :
    graphSum (pathGraph 4) (graphSum (pathGraph 3) (pathGraph 3)) ≃g
      H.induce {u | u ≠ y} where
  toEquiv := Equiv.ofBijective deletionYEmbedding deletionY_bijective
  map_rel_iff' := by decide

theorem H_first_legal : Legal H ∅ 5 := by decide

theorem H_first_legal_moves : ∀ v : Fin 11, Legal H {5} v ↔
    v=0 ∨ v=1 ∨ v=2 ∨ v=3 ∨ v=4 ∨ v=8 ∨ v=9 ∨ v=10 := by decide

/-- Fixed replies from Section 7: clear the untouched path, including
the special blue-root move y. -/
def H_reply (v : Fin 11) : Fin 11 :=
  if v=1 then 3 else if v=8 ∨ v=9 ∨ v=10 then 2 else 9

set_option maxRecDepth 8192 in
set_option maxHeartbeats 4000000 in
theorem H_reply_certificate : ∀ v : Fin 11, Legal H {5} v →
    Legal H {v,5} (H_reply v) ∧
      (Terminal H {H_reply v,v,5} ∨
        ∀ w : Fin 11, Legal H {H_reply v,v,5} w →
          Terminal H {w,H_reply v,v,5}) := by decide

theorem H_four_moves : isolationNumber H ≤ 4 := by
  apply (isolationNumber_le_iff H 4).mpr
  refine Or.inr ⟨5, H_first_legal, Or.inr ?_⟩
  intro v hv
  obtain ⟨hl, ht⟩ := H_reply_certificate v (by simpa using hv)
  refine Or.inr ⟨H_reply v, by simpa using hl, ?_⟩
  rcases ht with ht | ht
  · exact terminal_wins H (by simpa using ht) _ _
  · exact Or.inr (fun w hw => by simpa [WinsWithin] using ht w (by simpa using hw))

/-- The precise corrected chain; all values use the marked extension
proved equivalent to the original game for empty marks. -/
theorem H_marked_x_chain :
    Marked.gameValue H {x} .staller ∅ ≤ gameValue H .staller ∅ ∧
    gameValue H .staller ∅ ≤ isolationNumber H + 1 ∧
    isolationNumber H + 1 ≤ 5 := by
  have hcont := Marked.value_continuation H (Finset.empty_subset {x}) .staller ∅
  rw [Marked.value_empty_marks] at hcont
  have hstart := Marked.starting_player_inequality H ∅ ∅
  rw [Marked.value_empty_marks, Marked.value_empty_marks] at hstart
  exact ⟨hcont, hstart, by have := H_four_moves; omega⟩

theorem H_marked_x_five : Marked.gameValue H {x} .staller ∅ ≤ 5 := by
  obtain ⟨h₁,h₂,h₃⟩ := H_marked_x_chain
  omega

end Small
end IsolationGame.DiameterSeven
