import IsolationGame.DiameterSeven.NineAndPath
import IsolationGame.TreeCenter
import Mathlib.Data.Fintype.EquivFin

namespace IsolationGame.DiameterSeven

open SimpleGraph

variable {V : Type*} [Fintype V] {G : SimpleGraph V}

/-- A path in a tree has its index as distance from its initial vertex. -/
theorem path_index_dist (hT : G.IsTree) {a b : V} (p : G.Walk a b)
    (hp : p.IsPath) {i : Nat} (hi : i ≤ p.length) :
    G.dist (p.getVert i) a = i := by
  classical
  have h := tree_path_length_eq_dist hT
    (p.takeUntil (p.getVert i) (p.getVert_mem_support i))
    (hp.takeUntil (p.getVert_mem_support i))
  rw [prefix_length_at_index p hp i hi, G.dist_comm] at h
  exact h.symm

/-- No chord can join nonconsecutive vertices of a tree path. -/
theorem path_index_adj (hT : G.IsTree) {a b : V} (p : G.Walk a b)
    (hp : p.IsPath) {i j : Nat} (hi : i ≤ p.length) (hj : j ≤ p.length) :
    G.Adj (p.getVert i) (p.getVert j) ↔ i+1=j ∨ j+1=i := by
  constructor
  · intro h
    have hh := tree_adj_levels hT a h
    rw [path_index_dist hT p hp hi, path_index_dist hT p hp hj] at hh
    omega
  · rintro (h | h)
    · subst j
      exact p.adj_getVert_succ (by omega)
    · subst i
      exact (p.adj_getVert_succ (by omega)).symm

/-- An outside vertex adjacent to a path vertex lies one level farther
from the path's start. A second lower neighbor would violate tree uniqueness. -/
theorem outside_neighbor_dist (hT : G.IsTree) {a b z : V} (p : G.Walk a b)
    (hp : p.IsPath) (hz : z ∉ p.support) {i : Nat} (hi : i ≤ p.length)
    (hadj : G.Adj z (p.getVert i)) : G.dist z a = i+1 := by
  have hl := tree_adj_levels hT a hadj
  rw [path_index_dist hT p hp hi] at hl
  rcases hl with h | h
  · exact h
  · have hip : 0 < i := by omega
    have hpred : G.Adj (p.getVert i) (p.getVert (i-1)) := by
      apply (path_index_adj hT p hp hi (by omega)).mpr
      omega
    have hd := path_index_dist hT p hp (show i-1 ≤ p.length by omega)
    have heq : z = p.getVert (i-1) :=
      unique_lower_neighbor hT a hadj.symm hpred
        (by rw [path_index_dist hT p hp hi]; omega)
        (by rw [path_index_dist hT p hp hi]; omega)
    exact False.elim (hz (heq ▸ p.getVert_mem_support (i-1)))

/-- Diameter seven forces at least eight vertices, independently of labels. -/
theorem diameter_seven_card_min (hT : G.IsTree) (hd : G.diam=7) :
    8 ≤ Fintype.card V := by
  classical
  letI : Nonempty V := hT.isConnected.nonempty
  obtain ⟨a,b,hab⟩ := G.exists_dist_eq_diam
  obtain ⟨p,hp,hlen⟩ := hT.isConnected.exists_path_of_dist a b
  have hcard := hp.length_lt
  omega

/-- The entire order-eight class is the already verified path. -/
theorem order_eight_iso (hT : G.IsTree) (hd : G.diam=7)
    (hn : Fintype.card V=8) : Nonempty (Small.P8 ≃g G) := by
  classical
  letI : Nonempty V := hT.isConnected.nonempty
  obtain ⟨a,b,hab⟩ := G.exists_dist_eq_diam
  obtain ⟨p,hp,hlen⟩ := hT.isConnected.exists_path_of_dist a b
  have hlen7 : p.length=7 := by omega
  let f : Fin 8 → V := fun i => p.getVert i.val
  have hinj : Function.Injective f := by
    intro i j hij
    apply Fin.ext
    exact hp.getVert_injOn (show i.val ≤ p.length by have := i.isLt; omega)
      (show j.val ≤ p.length by have := j.isLt; omega) hij
  have hbij : Function.Bijective f :=
    (Fintype.bijective_iff_injective_and_card f).mpr ⟨hinj,by simp [hn]⟩
  refine ⟨{toEquiv := Equiv.ofBijective f hbij, map_rel_iff' := ?_}⟩
  intro i j
  exact path_index_adj hT p hp (by have := i.isLt; omega) (by have := j.isLt; omega)

theorem order_eight_bound [DecidableEq V] (hT : G.IsTree) (hd : G.diam=7)
    (hn : Fintype.card V=8) : isolationNumber G ≤ 3 := by
  obtain ⟨e⟩ := order_eight_iso hT hd hn
  exact isolation_bound_relabel Small.P8 G e.toEquiv
    (fun _ _ => e.map_rel_iff) Small.P8_three_moves

/-- Append one vertex to the labels of an eight-vertex path. -/
def extendPath (f : Fin 8 → V) (z : V) (i : Fin 9) : V :=
  if h : i.val<8 then f ⟨i.val,h⟩ else z

/-- A path with one leaf attached at an arbitrary path index. -/
def attachedPath (j : Fin 8) : SimpleGraph (Fin 9) where
  Adj u v := (u.val<8 ∧ v.val<8 ∧ (u.val+1=v.val ∨ v.val+1=u.val)) ∨
    (u.val=8 ∧ v.val=j.val) ∨ (v.val=8 ∧ u.val=j.val)
  symm := by intro u v; aesop
  loopless := by intro u h; have := j.isLt; rcases h with h | h | h <;> omega

instance (j : Fin 8) : DecidableRel (attachedPath j).Adj :=
  fun _ _ => inferInstanceAs (Decidable (_ ∨ _ ∨ _))

/-- Exhaustive structural classification before reflecting the path:
the ninth vertex is a leaf at one of the six internal path vertices. -/
theorem order_nine_attached (hT : G.IsTree) (hd : G.diam=7)
    (hn : Fintype.card V=9) :
    ∃ j : Fin 8, 1 ≤ j.val ∧ j.val ≤ 6 ∧ Nonempty (attachedPath j ≃g G) := by
  classical
  letI : Nonempty V := hT.isConnected.nonempty
  obtain ⟨a,b,hab⟩ := G.exists_dist_eq_diam
  obtain ⟨p,hp,hlen⟩ := hT.isConnected.exists_path_of_dist a b
  have hlen7 : p.length=7 := by omega
  let f : Fin 8 → V := fun i => p.getVert i.val
  have hinj : Function.Injective f := by
    intro i j hij
    apply Fin.ext
    exact hp.getVert_injOn (show i.val ≤ p.length by have := i.isLt; omega)
      (show j.val ≤ p.length by have := j.isLt; omega) hij
  let S : Finset V := Finset.univ.image f
  have hScard : S.card=8 := by simp [S,Finset.card_image_of_injective _ hinj]
  have hcompl : (Finset.univ \ S).card=1 := by
    rw [Finset.card_sdiff (Finset.subset_univ S),Finset.card_univ,hn,hScard]
  obtain ⟨z,hz⟩ := Finset.card_eq_one.mp hcompl
  have hzout : z ∉ S := by
    have : z∈Finset.univ \ S := by rw [hz]; simp
    exact (Finset.mem_sdiff.mp this).2
  have hzpath : z ∉ p.support := by
    intro h
    obtain ⟨i,hi,hib⟩ := Walk.mem_support_iff_exists_getVert.mp h
    exact hzout (Finset.mem_image.mpr ⟨⟨i,by omega⟩,Finset.mem_univ _,hi⟩)
  have hcover (v : V) : v=z ∨ ∃ i : Fin 8, f i=v := by
    by_cases hv : v∈S
    · obtain ⟨i,_,hi⟩ := Finset.mem_image.mp hv
      exact Or.inr ⟨i,hi⟩
    · left
      have : v∈Finset.univ \ S := Finset.mem_sdiff.mpr ⟨Finset.mem_univ _,hv⟩
      simpa [hz] using this
  have hza : z≠a := by intro h; exact hzpath (h ▸ p.start_mem_support)
  obtain ⟨w,hw,_⟩ := exists_unique_parent hT a hza
  obtain hwz | ⟨j,hj⟩ := hcover w
  · exact False.elim (hw.1.ne hwz.symm)
  have hjadj : G.Adj z (f j) := by rw [hj]; exact hw.1
  have hdist := outside_neighbor_dist hT p hp hzpath
    (show j.val ≤ p.length by have := j.isLt; omega) hjadj
  have hfinite : G.ediam≠⊤ := connected_iff_ediam_ne_top.mp hT.isConnected
  have hbound : G.dist z a ≤ 7 := by simpa [hd] using G.dist_le_diam (u := z) (v := a) hfinite
  have hjmax : j.val ≤ 6 := by omega
  have hjmin : 1 ≤ j.val := by
    by_contra h
    have hj0 : j.val=0 := Nat.eq_zero_of_not_pos h
    have hza' : G.Adj z a := by simpa [f,hj0] using hjadj
    have hlong := tree_path_length_eq_dist hT (p.cons hza') (hp.cons hzpath)
    have hmax : G.dist z b ≤ 7 := by simpa [hd] using G.dist_le_diam (u := z) (v := b) hfinite
    simp only [Walk.length_cons] at hlong
    omega
  have hzadj (i : Fin 8) : G.Adj z (f i) ↔ i=j := by
    constructor
    · intro h
      have hd' := outside_neighbor_dist hT p hp hzpath
        (show i.val ≤ p.length by have := i.isLt; omega) h
      apply Fin.ext
      omega
    · rintro rfl; exact hjadj
  let g := extendPath f z
  have hsurj : Function.Surjective g := by
    intro v
    rcases hcover v with rfl | ⟨i,rfl⟩
    · exact ⟨⟨8,by decide⟩,dif_neg (Nat.lt_irrefl 8)⟩
    · refine ⟨⟨i.val,by have := i.isLt; omega⟩,?_⟩
      simp [g,extendPath,i.isLt]
  have hbij : Function.Bijective g :=
    (Fintype.bijective_iff_surjective_and_card g).mpr ⟨hsurj,by simp [hn]⟩
  refine ⟨j,hjmin,hjmax,⟨{toEquiv := Equiv.ofBijective g hbij, map_rel_iff' := ?_}⟩⟩
  intro u v
  change G.Adj (g u) (g v) ↔ _
  by_cases hu : u.val<8 <;> by_cases hv : v.val<8
  · have hh := path_index_adj hT p hp
      (show u.val ≤ p.length by omega) (show v.val ≤ p.length by omega)
    simpa [g,extendPath,hu,hv,f,attachedPath,Nat.ne_of_lt hu,Nat.ne_of_lt hv] using hh
  · have hv8 : v.val=8 := by have := v.isLt; omega
    have hh := (G.adj_comm _ _).trans (hzadj ⟨u.val,hu⟩)
    simpa [g,extendPath,hu,hv,attachedPath,hv8,Fin.ext_iff,Nat.ne_of_lt hu] using hh
  · have hu8 : u.val=8 := by have := u.isLt; omega
    simpa [g,extendPath,hu,hv,attachedPath,hu8,Fin.ext_iff,Nat.ne_of_lt hv] using (hzadj ⟨v.val,hv⟩)
  · have hu8 : u.val=8 := by have := u.isLt; omega
    have hv8 : v.val=8 := by have := v.isLt; omega
    have hj8 : j.val≠8 := by omega
    simp [g,extendPath,hu,hv,attachedPath,hu8,hv8,hj8,Ne.symm hj8]

/-- Reverse only the path and keep the extra leaf fixed. -/
def reverseNine : Fin 9 ≃ Fin 9 where
  toFun i := if i.val<8 then ⟨7-i.val,by omega⟩ else i
  invFun i := if i.val<8 then ⟨7-i.val,by omega⟩ else i
  left_inv := by decide
  right_inv := by decide

def normalizeNine (j : Fin 8) : Fin 9 ≃ Fin 9 :=
  if j.val<4 then reverseNine else Equiv.refl _

/- Finite relabeling identities for the six internal attachment sites.
The preceding theorem supplies the classification of arbitrary trees. -/
set_option maxRecDepth 8192 in
set_option maxHeartbeats 2000000 in
theorem attached_normalized : ∀ j : Fin 8, 1 ≤ j.val → j.val ≤ 6 →
    ∃ t : Fin 3, ∀ u v : Fin 9,
      (attachedPath j).Adj (normalizeNine j u) (normalizeNine j v) ↔
        (Small.nineGraph t).Adj u v := by decide

theorem order_nine_iso (hT : G.IsTree) (hd : G.diam=7)
    (hn : Fintype.card V=9) :
    ∃ t : Fin 3, Nonempty (Small.nineGraph t ≃g G) := by
  obtain ⟨j,hj1,hj6,⟨e⟩⟩ := order_nine_attached hT hd hn
  obtain ⟨t,ht⟩ := attached_normalized j hj1 hj6
  let d : Small.nineGraph t ≃g attachedPath j :=
    {toEquiv := normalizeNine j, map_rel_iff' := ht _ _}
  exact ⟨t,⟨d.trans e⟩⟩

theorem order_nine_bound [DecidableEq V] (hT : G.IsTree) (hd : G.diam=7)
    (hn : Fintype.card V=9) : isolationNumber G ≤ 3 := by
  obtain ⟨t,⟨e⟩⟩ := order_nine_iso hT hd hn
  exact isolation_bound_relabel (Small.nineGraph t) G e.toEquiv
    (fun _ _ => e.map_rel_iff) (Small.nine_three_moves t)

end IsolationGame.DiameterSeven
