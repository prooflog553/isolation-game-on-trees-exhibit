import IsolationGame.DiameterSeven.RemainingSmall
import IsolationGame.DiameterSeven.EighteenClassification
import IsolationGame.DiameterSeven.EighteenStrategy

namespace IsolationGame.DiameterSeven

universe u

theorem order18_460Balanced : Order18_460Balanced.{u} := by
  intro V inst instD G hT x y hc hd hb hk he hl hr
  obtain ⟨t,⟨e⟩⟩ := DoubleRooted.eighteen_balanced_iso x y hT hc hb hk he hl hr
  exact isolation_bound_relabel (Small.E18 t) G e.toEquiv
    (fun _ _ => e.map_rel_iff) (Small.eighteen_seven_moves t)

/-- All eight residual parameter bounds are now theorems. -/
theorem remainingSmallProofs : RemainingSmallProofs.{u} :=
  ⟨order13_332,order15_342,order16_343,order16_351,order16_442,
    order16_450Balanced,order18_452,order18_460Balanced⟩

/-- Unconditional small-order coverage for the original game on arbitrary
finite trees. No external general-tree bound is a hypothesis. -/
theorem smallOrderBound : SmallOrderBound.{u} :=
  small_bound_of_remaining remainingSmallProofs

/-- The unchanged complete diameter-seven target, without parameters. -/
theorem fullDiameterSevenBound : FullDiameterSevenBound.{u} :=
  full_bound_of_small_orders smallOrderBound

/-- Explicit form of the complete theorem. -/
theorem tree_diameter_seven_bound {V : Type u} [Fintype V] (T : SimpleGraph V)
    (hT : T.IsTree) (hn : 3 ≤ Fintype.card V) (hd : T.diam ≤ 7) :
    gameIsolationNumber T ≤ 3*Fintype.card V/7 :=
  fullDiameterSevenBound T hT hn hd

end IsolationGame.DiameterSeven
