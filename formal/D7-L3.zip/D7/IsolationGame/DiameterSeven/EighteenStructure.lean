import IsolationGame.DiameterSeven.FiveStars
import IsolationGame.DiameterSeven.StructuralTransport

namespace IsolationGame.DiameterSeven

variable {V I : Type*} [Fintype V] [DecidableEq V] [DecidableEq I]
variable {G : SimpleGraph V}

namespace DoubleRooted
variable (x y : V) (hT : G.IsTree) (hc : CenterEdge G x y)

/-- Choose one star from each of the two groups on each side. The other
exactly two stars lie in these four groups. This is a structural cover
of an arbitrary tree, not an enumeration of labelled graphs. -/
theorem six_stars_balanced_cover
    (hb : ((allIndices x y).image (parent x y hT hc)).card=4)
    (hk : (allIndices (G := G) x y).card=6)
    (hl : (sideParents x y hT hc x).card=2)
    (hr : (sideParents x y hT hc y).card=2) :
    ∃ a b c d j k : Index (G := G) x y,
      allIndices x y={a,b,c,d,j,k} ∧
      G.Adj (parent x y hT hc a) x ∧ G.Adj (parent x y hT hc b) x ∧
      G.Adj (parent x y hT hc c) y ∧ G.Adj (parent x y hT hc d) y ∧
      (parent x y hT hc j=parent x y hT hc a ∨ parent x y hT hc j=parent x y hT hc b ∨
       parent x y hT hc j=parent x y hT hc c ∨ parent x y hT hc j=parent x y hT hc d) ∧
      (parent x y hT hc k=parent x y hT hc a ∨ parent x y hT hc k=parent x y hT hc b ∨
       parent x y hT hc k=parent x y hT hc c ∨ parent x y hT hc k=parent x y hT hc d) := by
  classical
  let R := allIndices (G := G) x y
  let f := parent x y hT hc
  obtain ⟨p,q,hpq,hleft⟩ := Finset.card_eq_two.mp hl
  obtain ⟨r,s,hrs,hright⟩ := Finset.card_eq_two.mp hr
  have hpm : p∈sideParents x y hT hc x := by simp [hleft]
  have hqm : q∈sideParents x y hT hc x := by simp [hleft]
  have hrm : r∈sideParents x y hT hc y := by simp [hright]
  have hsm : s∈sideParents x y hT hc y := by simp [hright]
  obtain ⟨a,ha,hap⟩ := Finset.mem_image.mp (Finset.mem_filter.mp hpm).1
  obtain ⟨b,hb',hbq⟩ := Finset.mem_image.mp (Finset.mem_filter.mp hqm).1
  obtain ⟨c,hc',hcr⟩ := Finset.mem_image.mp (Finset.mem_filter.mp hrm).1
  obtain ⟨d,hd,hds⟩ := Finset.mem_image.mp (Finset.mem_filter.mp hsm).1
  have hfa : G.Adj (f a) x := by simpa only [f,hap] using (Finset.mem_filter.mp hpm).2.symm
  have hfb : G.Adj (f b) x := by simpa only [f,hbq] using (Finset.mem_filter.mp hqm).2.symm
  have hfc : G.Adj (f c) y := by simpa only [f,hcr] using (Finset.mem_filter.mp hrm).2.symm
  have hfd : G.Adj (f d) y := by simpa only [f,hds] using (Finset.mem_filter.mp hsm).2.symm
  have hvals (i : Index (G := G) x y) : f i=f a ∨ f i=f b ∨ f i=f c ∨ f i=f d := by
    rcases parent_adj_root x y hT hc i with hix | hiy
    · have hm : f i∈sideParents x y hT hc x := Finset.mem_filter.mpr
        ⟨Finset.mem_image.mpr ⟨i,by simp [allIndices],rfl⟩,hix.symm⟩
      rw [hleft] at hm
      simp only [Finset.mem_insert,Finset.mem_singleton] at hm
      rcases hm with h | h
      · exact Or.inl (h.trans hap.symm)
      · exact Or.inr (Or.inl (h.trans hbq.symm))
    · have hm : f i∈sideParents x y hT hc y := Finset.mem_filter.mpr
        ⟨Finset.mem_image.mpr ⟨i,by simp [allIndices],rfl⟩,hiy.symm⟩
      rw [hright] at hm
      simp only [Finset.mem_insert,Finset.mem_singleton] at hm
      rcases hm with h | h
      · exact Or.inr (Or.inr (Or.inl (h.trans hcr.symm)))
      · exact Or.inr (Or.inr (Or.inr (h.trans hds.symm)))
  let B : Finset (Index (G := G) x y) := {a,b,c,d}
  have hsub : B⊆R := by simp [B,R,allIndices,Finset.subset_univ]
  have himg : B.image f=R.image f := by
    apply Finset.Subset.antisymm (Finset.image_subset_image hsub)
    intro z hz
    obtain ⟨i,hi,rfl⟩ := Finset.mem_image.mp hz
    simpa [B] using hvals i
  have hBcard : B.card=4 := by
    have hh : (B.image f).card ≤ B.card := Finset.card_image_le
    rw [himg] at hh
    have hB := Finset.card_le_four (a := a) (b := b) (c := c) (d := d)
    change (R.image f).card=4 at hb
    change B.card ≤ 4 at hB
    omega
  have hrest : (R \ B).card=2 := by rw [Finset.card_sdiff hsub,hBcard]; exact hk ▸ rfl
  obtain ⟨j,k,_,hjk⟩ := Finset.card_eq_two.mp hrest
  refine ⟨a,b,c,d,j,k,?_,hfa,hfb,hfc,hfd,hvals j,hvals k⟩
  have hU := Finset.union_sdiff_of_subset hsub
  rw [hjk] at hU
  calc
    R=B ∪ {j,k} := hU.symm
    _={a,b,c,d,j,k} := by ext z; simp [B,or_assoc,or_comm,or_left_comm]

end DoubleRooted

namespace Small

/-- Four parent labels 2,3 on root 0 and 4,5 on root 1. Star labels
are the pairs (6,7),...,(16,17). -/
def E18 (t : Fin 3) : SimpleGraph (Fin 18) := edgeGraph
  ([(0,1),(0,2),(0,3),(1,4),(1,5),(6,7),(8,9),(10,11),(12,13),(14,15),(16,17)] ++
    if t.val=0 then [(2,6),(2,8),(2,10),(3,12),(4,14),(5,16)]
    else if t.val=1 then [(2,6),(2,8),(3,10),(3,12),(4,14),(5,16)]
    else [(2,6),(2,8),(3,10),(4,12),(4,14),(5,16)])

instance (t : Fin 3) : DecidableRel (E18 t).Adj := inferInstanceAs (DecidableRel (edgeGraph _).Adj)

theorem E18_connected (t : Fin 3) : (E18 t).Connected := by
  apply connected_of_lower_labels (by decide)
  fin_cases t <;> decide

end Small

/-- Vertex labels for the three canonical eighteen-vertex structures. -/
def E18Label (r s p q t u c0 l0 c1 l1 c2 l2 c3 l3 c4 l4 c5 l5 : V) (z : Fin 18) : V :=
  match z.val with
  | 0 => r | 1 => s | 2 => p | 3 => q | 4 => t | 5 => u
  | 6 => c0 | 7 => l0 | 8 => c1 | 9 => l1 | 10 => c2 | 11 => l2
  | 12 => c3 | 13 => l3 | 14 => c4 | 15 => l4 | 16 => c5 | _ => l5

set_option maxRecDepth 8192 in
set_option maxHeartbeats 6000000 in
theorem E18_iso_0_of_cover (hT : G.IsTree) (hn : Fintype.card V=18)
    (A : StarSystem G I) (R : Finset I) (r s : V) (a b c d e f : I)
    (hcover : insert s (A.countedVertices r R)=Finset.univ)
    (hR : R={a,b,c,d,e,f}) (hrs : G.Adj r s)
    (hp0 : G.Adj (A.parent a) r)
    (hp1 : G.Adj (A.parent d) r)
    (hp2 : G.Adj (A.parent e) s)
    (hp3 : G.Adj (A.parent f) s)
    (h1 : A.parent b=A.parent a)
    (h2 : A.parent c=A.parent a)
    : Nonempty (Small.E18 0 ≃g G) := by
  classical
  let label := E18Label r s (A.parent a) (A.parent d) (A.parent e) (A.parent f)
    (A.center a) (A.chosenLeaf a) (A.center b) (A.chosenLeaf b) (A.center c) (A.chosenLeaf c) (A.center d) (A.chosenLeaf d) (A.center e) (A.chosenLeaf e) (A.center f) (A.chosenLeaf f)
  have hsurj : Function.Surjective label := by
    intro v
    have hv : v∈insert s (A.countedVertices r R) := by rw [hcover]; simp
    simp only [StarSystem.countedVertices,hR,Finset.image_insert,Finset.image_singleton,
      Finset.mem_insert,Finset.mem_singleton,Finset.mem_union,h1,h2] at hv
    rcases hv with rfl | rfl | (rfl | rfl | rfl | rfl | rfl | rfl) |
      (rfl | rfl | rfl | rfl | rfl | rfl) | (rfl | rfl | rfl | rfl | rfl | rfl)
    all_goals first
      | exact ⟨0,rfl⟩ | exact ⟨1,rfl⟩ | exact ⟨2,rfl⟩ | exact ⟨3,rfl⟩
      | exact ⟨4,rfl⟩ | exact ⟨5,rfl⟩ | exact ⟨6,rfl⟩ | exact ⟨7,rfl⟩
      | exact ⟨8,rfl⟩ | exact ⟨9,rfl⟩ | exact ⟨10,rfl⟩ | exact ⟨11,rfl⟩
      | exact ⟨12,rfl⟩ | exact ⟨13,rfl⟩ | exact ⟨14,rfl⟩ | exact ⟨15,rfl⟩
      | exact ⟨16,rfl⟩ | exact ⟨17,rfl⟩
  have hbij : Function.Bijective label :=
    (Fintype.bijective_iff_surjective_and_card label).mpr ⟨hsurj,by simp [hn]⟩
  have pc (z : I) : G.Adj (A.parent z) (A.center z) :=
    (A.adj_iff z _ (A.center_mem z) _).mpr (Or.inr (Or.inr ⟨rfl,rfl⟩))
  have cl (z : I) : G.Adj (A.center z) (A.chosenLeaf z) :=
    (A.adj_chosenLeaf z _).mpr rfl
  have edge_b : G.Adj (A.parent a) (A.center b) := h1 ▸ pc b
  have edge_c : G.Adj (A.parent a) (A.center c) := h2 ▸ pc c
  have he : ∀ u v, (Small.E18 0).Adj u v → G.Adj (label u) (label v) := by
    intro u v
    fin_cases u <;> fin_cases v <;>
      norm_num [Small.E18,edgeGraph,SimpleGraph.fromRel_adj,label,E18Label]
    all_goals first
      | exact hrs | exact hrs.symm | exact hp0 | exact hp0.symm | exact hp1 | exact hp1.symm
      | exact hp2 | exact hp2.symm | exact hp3 | exact hp3.symm
      | exact pc _ | exact (pc _).symm | exact cl _ | exact (cl _).symm
      | exact edge_b | exact edge_b.symm
      | exact edge_c | exact edge_c.symm
  exact ⟨treeIsoOfHom hT (Small.E18_connected 0) (Equiv.ofBijective label hbij) he⟩

set_option maxRecDepth 8192 in
set_option maxHeartbeats 6000000 in
theorem E18_iso_1_of_cover (hT : G.IsTree) (hn : Fintype.card V=18)
    (A : StarSystem G I) (R : Finset I) (r s : V) (a b c d e f : I)
    (hcover : insert s (A.countedVertices r R)=Finset.univ)
    (hR : R={a,b,c,d,e,f}) (hrs : G.Adj r s)
    (hp0 : G.Adj (A.parent a) r)
    (hp1 : G.Adj (A.parent c) r)
    (hp2 : G.Adj (A.parent e) s)
    (hp3 : G.Adj (A.parent f) s)
    (h1 : A.parent b=A.parent a)
    (h3 : A.parent d=A.parent c)
    : Nonempty (Small.E18 1 ≃g G) := by
  classical
  let label := E18Label r s (A.parent a) (A.parent c) (A.parent e) (A.parent f)
    (A.center a) (A.chosenLeaf a) (A.center b) (A.chosenLeaf b) (A.center c) (A.chosenLeaf c) (A.center d) (A.chosenLeaf d) (A.center e) (A.chosenLeaf e) (A.center f) (A.chosenLeaf f)
  have hsurj : Function.Surjective label := by
    intro v
    have hv : v∈insert s (A.countedVertices r R) := by rw [hcover]; simp
    simp only [StarSystem.countedVertices,hR,Finset.image_insert,Finset.image_singleton,
      Finset.mem_insert,Finset.mem_singleton,Finset.mem_union,h1,h3] at hv
    rcases hv with rfl | rfl | (rfl | rfl | rfl | rfl | rfl | rfl) |
      (rfl | rfl | rfl | rfl | rfl | rfl) | (rfl | rfl | rfl | rfl | rfl | rfl)
    all_goals first
      | exact ⟨0,rfl⟩ | exact ⟨1,rfl⟩ | exact ⟨2,rfl⟩ | exact ⟨3,rfl⟩
      | exact ⟨4,rfl⟩ | exact ⟨5,rfl⟩ | exact ⟨6,rfl⟩ | exact ⟨7,rfl⟩
      | exact ⟨8,rfl⟩ | exact ⟨9,rfl⟩ | exact ⟨10,rfl⟩ | exact ⟨11,rfl⟩
      | exact ⟨12,rfl⟩ | exact ⟨13,rfl⟩ | exact ⟨14,rfl⟩ | exact ⟨15,rfl⟩
      | exact ⟨16,rfl⟩ | exact ⟨17,rfl⟩
  have hbij : Function.Bijective label :=
    (Fintype.bijective_iff_surjective_and_card label).mpr ⟨hsurj,by simp [hn]⟩
  have pc (z : I) : G.Adj (A.parent z) (A.center z) :=
    (A.adj_iff z _ (A.center_mem z) _).mpr (Or.inr (Or.inr ⟨rfl,rfl⟩))
  have cl (z : I) : G.Adj (A.center z) (A.chosenLeaf z) :=
    (A.adj_chosenLeaf z _).mpr rfl
  have edge_b : G.Adj (A.parent a) (A.center b) := h1 ▸ pc b
  have edge_d : G.Adj (A.parent c) (A.center d) := h3 ▸ pc d
  have he : ∀ u v, (Small.E18 1).Adj u v → G.Adj (label u) (label v) := by
    intro u v
    fin_cases u <;> fin_cases v <;>
      norm_num [Small.E18,edgeGraph,SimpleGraph.fromRel_adj,label,E18Label]
    all_goals first
      | exact hrs | exact hrs.symm | exact hp0 | exact hp0.symm | exact hp1 | exact hp1.symm
      | exact hp2 | exact hp2.symm | exact hp3 | exact hp3.symm
      | exact pc _ | exact (pc _).symm | exact cl _ | exact (cl _).symm
      | exact edge_b | exact edge_b.symm
      | exact edge_d | exact edge_d.symm
  exact ⟨treeIsoOfHom hT (Small.E18_connected 1) (Equiv.ofBijective label hbij) he⟩

set_option maxRecDepth 8192 in
set_option maxHeartbeats 6000000 in
theorem E18_iso_2_of_cover (hT : G.IsTree) (hn : Fintype.card V=18)
    (A : StarSystem G I) (R : Finset I) (r s : V) (a b c d e f : I)
    (hcover : insert s (A.countedVertices r R)=Finset.univ)
    (hR : R={a,b,c,d,e,f}) (hrs : G.Adj r s)
    (hp0 : G.Adj (A.parent a) r)
    (hp1 : G.Adj (A.parent c) r)
    (hp2 : G.Adj (A.parent d) s)
    (hp3 : G.Adj (A.parent f) s)
    (h1 : A.parent b=A.parent a)
    (h4 : A.parent e=A.parent d)
    : Nonempty (Small.E18 2 ≃g G) := by
  classical
  let label := E18Label r s (A.parent a) (A.parent c) (A.parent d) (A.parent f)
    (A.center a) (A.chosenLeaf a) (A.center b) (A.chosenLeaf b) (A.center c) (A.chosenLeaf c) (A.center d) (A.chosenLeaf d) (A.center e) (A.chosenLeaf e) (A.center f) (A.chosenLeaf f)
  have hsurj : Function.Surjective label := by
    intro v
    have hv : v∈insert s (A.countedVertices r R) := by rw [hcover]; simp
    simp only [StarSystem.countedVertices,hR,Finset.image_insert,Finset.image_singleton,
      Finset.mem_insert,Finset.mem_singleton,Finset.mem_union,h1,h4] at hv
    rcases hv with rfl | rfl | (rfl | rfl | rfl | rfl | rfl | rfl) |
      (rfl | rfl | rfl | rfl | rfl | rfl) | (rfl | rfl | rfl | rfl | rfl | rfl)
    all_goals first
      | exact ⟨0,rfl⟩ | exact ⟨1,rfl⟩ | exact ⟨2,rfl⟩ | exact ⟨3,rfl⟩
      | exact ⟨4,rfl⟩ | exact ⟨5,rfl⟩ | exact ⟨6,rfl⟩ | exact ⟨7,rfl⟩
      | exact ⟨8,rfl⟩ | exact ⟨9,rfl⟩ | exact ⟨10,rfl⟩ | exact ⟨11,rfl⟩
      | exact ⟨12,rfl⟩ | exact ⟨13,rfl⟩ | exact ⟨14,rfl⟩ | exact ⟨15,rfl⟩
      | exact ⟨16,rfl⟩ | exact ⟨17,rfl⟩
  have hbij : Function.Bijective label :=
    (Fintype.bijective_iff_surjective_and_card label).mpr ⟨hsurj,by simp [hn]⟩
  have pc (z : I) : G.Adj (A.parent z) (A.center z) :=
    (A.adj_iff z _ (A.center_mem z) _).mpr (Or.inr (Or.inr ⟨rfl,rfl⟩))
  have cl (z : I) : G.Adj (A.center z) (A.chosenLeaf z) :=
    (A.adj_chosenLeaf z _).mpr rfl
  have edge_b : G.Adj (A.parent a) (A.center b) := h1 ▸ pc b
  have edge_e : G.Adj (A.parent d) (A.center e) := h4 ▸ pc e
  have he : ∀ u v, (Small.E18 2).Adj u v → G.Adj (label u) (label v) := by
    intro u v
    fin_cases u <;> fin_cases v <;>
      norm_num [Small.E18,edgeGraph,SimpleGraph.fromRel_adj,label,E18Label]
    all_goals first
      | exact hrs | exact hrs.symm | exact hp0 | exact hp0.symm | exact hp1 | exact hp1.symm
      | exact hp2 | exact hp2.symm | exact hp3 | exact hp3.symm
      | exact pc _ | exact (pc _).symm | exact cl _ | exact (cl _).symm
      | exact edge_b | exact edge_b.symm
      | exact edge_e | exact edge_e.symm
  exact ⟨treeIsoOfHom hT (Small.E18_connected 2) (Equiv.ofBijective label hbij) he⟩

end IsolationGame.DiameterSeven
