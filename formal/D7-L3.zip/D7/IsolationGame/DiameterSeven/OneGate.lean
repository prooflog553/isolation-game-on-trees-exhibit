import IsolationGame.DiameterSeven.TwoGroups
import IsolationGame.DiameterSeven.SideGroups

namespace IsolationGame.DiameterSeven.DoubleRooted

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V} (x y : V) (hT : G.IsTree) (hc : CenterEdge G x y)

set_option maxHeartbeats 2000000 in
/-- The one-opposite-group shortcut with all extras on the first side.
For zero extras this covers the one-versus-three side splits as well. -/
theorem one_opposite_group_oriented (hd : G.diam=7)
    (hmore : ((allIndices x y).image (parent x y hT hc)).card <
      (allIndices (G := G) x y).card)
    (huniq : ∃ j : Index (G := G) x y, ∀ i : Index (G := G) x y,
      G.Adj (parent x y hT hc i) y → parent x y hT hc i=parent x y hT hc j)
    (he : ∀ z∈extras x y hT hc, LeftSide G x y z) :
    isolationNumber G ≤ (allIndices (G := G) x y).card+1 := by
  classical
  let A := system x y hT hc
  let R := allIndices (G := G) x y
  change (A.groups R).card < R.card at hmore
  have hbk : 2 ≤ (A.groups R).card := two_groups x y hT hc hd
  have hkmin : 3 ≤ R.card := by omega
  let m := R.card-2
  have hsh := no_shallow_of_extras_left x y hT hc he
  obtain ⟨j,hj⟩ := huniq
  let q := A.parent j
  have hxlegal : Legal G ∅ x := by
    refine ⟨x,Or.inl rfl,?_,y,hc.1,?_⟩ <;> simp [Undominated,Dominated]
  have hw : WinsWithin G (m+3) .dominator ∅ := by
    refine Or.inr ⟨x,hxlegal,Or.inr ?_⟩
    intro v hv
    have hresponse : v=y ∨ ∃ i∈R, Closed G v (A.center i) := by
      by_cases hvy : v=y
      · exact Or.inl hvy
      · right
        by_contra hhit
        have hhit' : ¬ ∃ i : Index (G := G) x y, Closed G v i.val := by
          rintro ⟨i,hi⟩
          exact hhit ⟨i,by simp [R,allIndices],hi⟩
        have hvx : v≠x := by intro h; subst v; exact selected_not_legal G (by simp) hv
        have hve := no_star_hit_mem_extras x y hT hc hvx hvy hhit'
        exact hhit' (legal_left_hits_star x y hT hc hv (he v hve))
    rcases hresponse with hvs | hhit
    · subst v
      have hrep : A.Represents R {y,x} := by
        have h := both_roots_represents x y hT hc
        simpa only [Finset.pair_comm] using h
      exact (A.strategy_equivalence hrep (m+1) .dominator).mpr
        (by convert A.dominator_saved R hmore using 1 <;> dsimp [m] <;> omega)
    · let X : Finset V := {v,x}
      have hxX : x∈X := by simp [X]
      have hQ : survivors x y X = A.remainingAfter R v := by
        rw [show X=insert v {x} from rfl,survivors_after x y hT hc,survivors_first x y hT hc]
      have hQcard : (survivors (G := G) x y X).card ≤ R.card-1 := by
        rw [hQ]
        have hdrop := A.hit_card_drop hhit
        dsimp [m] at *
        omega
      by_cases hy : Legal G X y
      · have hyd : Dominated G X y := ⟨x,hxX,Or.inr hc.1⟩
        have hgate : ∀ u, G.Adj y u → White G X u → u=q := by
          intro u hyu hu
          obtain ⟨i,hi⟩ := white_gate_parent x y hT hc hsh hxX hyu hu
          exact hi.symm.trans (hj i (hi ▸ hyu.symm))
        obtain ⟨hql,hyno⟩ := unique_gate_reply y hyd hy hgate
        refine Or.inr ⟨q,hql,?_⟩
        obtain ⟨u,hu,huw⟩ := hy
        have huy := hu.resolve_left (fun hh => huw.1 (hh ▸ hyd))
        obtain ⟨i,hi,hip⟩ := gate_has_live_star x y hT hc he hxX huy huw
        have hiq : A.parent i=q := hip.trans (hgate u huy huw)
        have hdrop := A.hit_card_drop (R := survivors x y X)
          ⟨i,hi,(A.closed_center_iff i q).mpr (Or.inr hiq.symm)⟩
        have hrep := represents_survivors x y hT hc
          (selected_not_legal G (Finset.mem_insert_of_mem hxX)) hyno
        apply (A.strategy_equivalence hrep m .staller).mpr
        have hcard : (survivors (G := G) x y (insert q X)).card ≤ m := by
          rw [survivors_after x y hT hc]
          change (A.remainingAfter (survivors x y X) q).card ≤ m
          dsimp [m]
          omega
        exact A.wins_of_controlled_bound _ _ _ (fun _ ht => (ht.units_bound A).trans hcard)
      · have hrep := represents_survivors x y hT hc (selected_not_legal G hxX) hy
        apply (A.strategy_equivalence hrep (m+1) .dominator).mpr
        exact A.wins_of_controlled_bound _ _ _ (fun _ ht => by have htcard := ht.units_bound A; dsimp [m]; omega)
  
  have hh := (isolationNumber_le_iff G (m+3)).mpr hw
  dsimp [m] at hh
  change isolationNumber G ≤ R.card+1
  omega

/-- The original one-versus-three shortcut, stated for arbitrary labels. -/
theorem one_opposite_group_zero_extras (hd : G.diam=7)
    (hmore : ((allIndices x y).image (parent x y hT hc)).card <
      (allIndices (G := G) x y).card)
    (hone : (sideParents x y hT hc y).card ≤ 1)
    (he : (extras x y hT hc).card=0) :
    isolationNumber G ≤ (allIndices (G := G) x y).card+1 := by
  apply one_opposite_group_oriented x y hT hc hd hmore
    (sideParents_unique x y hT hc y (Or.inr rfl) hd hone)
  intro z hz
  have hempty := Finset.card_eq_zero.mp he
  rw [hempty] at hz
  exact False.elim (Finset.not_mem_empty z hz)

/-- With at most three groups both nonempty sides force a singleton side.
This discharges the zero-extra exceptional cases at orders thirteen/fifteen. -/
theorem few_groups_zero_extras (hd : G.diam=7)
    (hb : ((allIndices x y).image (parent x y hT hc)).card ≤ 3)
    (hmore : ((allIndices x y).image (parent x y hT hc)).card <
      (allIndices (G := G) x y).card)
    (he : (extras x y hT hc).card=0) :
    isolationNumber G ≤ (allIndices (G := G) x y).card+1 := by
  have hsum := sideParents_partition x y hT hc
  have hpos := sideParents_pos x y hT hc hd
  have hone : (sideParents x y hT hc x).card ≤ 1 ∨ (sideParents x y hT hc y).card ≤ 1 := by omega
  rcases hone with hx | hy
  · have hmore' : ((allIndices y x).image (parent y x hT (centerEdge_symm hc))).card <
        (allIndices (G := G) y x).card := by
      rw [groups_swap x y hT hc,stars_swap x y]; exact hmore
    have hx' : (sideParents y x hT (centerEdge_symm hc) x).card ≤ 1 := by
      rw [sideParents_swap x y hT hc]; exact hx
    have he' : (extras y x hT (centerEdge_symm hc)).card=0 := by rw [extras_swap x y hT hc]; exact he
    have hh := one_opposite_group_zero_extras y x hT (centerEdge_symm hc) hd hmore' hx' he'
    simpa only [stars_swap x y] using hh
  · exact one_opposite_group_zero_extras x y hT hc hd hmore hy he

end IsolationGame.DiameterSeven.DoubleRooted
