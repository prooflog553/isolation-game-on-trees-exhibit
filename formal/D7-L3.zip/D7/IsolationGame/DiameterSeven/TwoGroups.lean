import IsolationGame.DiameterSeven.Gates
import IsolationGame.DiameterSeven.Swap

namespace IsolationGame.DiameterSeven.DoubleRooted

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V} (x y : V) (hT : G.IsTree) (hc : CenterEdge G x y)

/-- All two-group structures with at most three extras: no assumption on
the number of leaves, labels, or the initially chosen center. -/
theorem two_groups_bound (hd : G.diam=7)
    (hb : ((allIndices x y).image (parent x y hT hc)).card=2)
    (he : (extras x y hT hc).card ≤ 3) :
    isolationNumber G ≤ 3+min 2 ((allIndices (G := G) x y).card-1) := by
  rcases shallow_orientation x y hT hc he with hx | hy
  · have hb' : ((allIndices y x).image (parent y x hT (centerEdge_symm hc))).card=2 := by
      rw [groups_swap x y hT hc]; exact hb
    have hh := two_groups_oriented_bound y x hT (centerEdge_symm hc) hd hb'
      (fun h => hx ((shallow_swap x y hT hc x).mp h))
    simpa only [stars_swap x y] using hh
  · exact two_groups_oriented_bound x y hT hc hd hb hy

theorem two_groups_three_stars (hd : G.diam=7)
    (hb : ((allIndices x y).image (parent x y hT hc)).card=2)
    (hk : (allIndices (G := G) x y).card=3)
    (he : (extras x y hT hc).card ≤ 1) : isolationNumber G ≤ 4 := by
  rcases extras_orientation x y hT hc he with hl | hr
  · exact two_groups_three_stars_oriented x y hT hc hd hb hk hl
  · have hb' : ((allIndices y x).image (parent y x hT (centerEdge_symm hc))).card=2 := by
      rw [groups_swap x y hT hc]; exact hb
    have hk' : (allIndices (G := G) y x).card=3 := by rw [stars_swap x y]; exact hk
    have he' : ∀ z∈extras y x hT (centerEdge_symm hc), LeftSide G y x z := by
      simpa only [extras_swap_set x y hT hc] using hr
    exact two_groups_three_stars_oriented y x hT (centerEdge_symm hc) hd hb' hk' he'

end IsolationGame.DiameterSeven.DoubleRooted
