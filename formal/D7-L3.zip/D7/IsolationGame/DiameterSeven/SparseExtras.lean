import IsolationGame.DiameterSeven.ZeroMove

namespace IsolationGame.DiameterSeven.DoubleRooted

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V} (x y : V) (hT : G.IsTree) (hc : CenterEdge G x y)

theorem three_groups_sparse_extras (hd : G.diam=7)
    (hb : ((allIndices x y).image (parent x y hT hc)).card ≤ 3)
    (he : (extras x y hT hc).card ≤ 3) :
    isolationNumber G ≤ (allIndices (G := G) x y).card+2 := by
  have hsum := sideParents_partition x y hT hc
  have hpos := sideParents_pos x y hT hc hd
  rcases shallow_orientation x y hT hc he with hx | hy
  · have hsh : ¬ ShallowOn y x hT (centerEdge_symm hc) x :=
      fun h => hx ((shallow_swap x y hT hc x).mp h)
    have hside : (sideParents y x hT (centerEdge_symm hc) x).card ≤ 2 := by
      rw [sideParents_swap x y hT hc]
      omega
    have hh := two_opposite_groups_bound y x hT (centerEdge_symm hc) hd hsh hside
    simpa only [stars_swap x y] using hh
  · exact two_opposite_groups_bound x y hT hc hd hy (by omega)

theorem shallow_two_extras_left (he : (extras x y hT hc).card=2)
    (hsh : ShallowOn x y hT hc x) :
    ∀ z∈extras x y hT hc, LeftSide G x y z := by
  classical
  obtain ⟨q,w,hxq,hq,hqw,hw,hqe,hwe⟩ := shallow_cost x y hT hc hsh
  have hdist := SimpleGraph.dist_eq_one_iff_adj.mpr hxq.symm
  have hqside : LeftSide G x y q := by
    have := endpoint_distance_step hT hc.1 q
    unfold depth at hq
    unfold LeftSide
    omega
  have hqne : q≠x := by intro h; rw [h,depth_x] at hq; omega
  have hwside := nonroot_neighbor_same_side hT hc.1 hqside hqne hqw
  have hqwne : q≠w := by intro h; rw [h] at hq; omega
  have hsub : ({q,w} : Finset V) ⊆ extras x y hT hc := by
    simp only [Finset.insert_subset_iff,Finset.singleton_subset_iff]
    exact ⟨hqe,hwe⟩
  have hset : extras x y hT hc={q,w} :=
    (Finset.eq_of_subset_of_card_le hsub (by simp [he,hqwne])).symm
  intro z hz
  rw [hset] at hz
  simp only [Finset.mem_insert,Finset.mem_singleton] at hz
  rcases hz with rfl | rfl <;> assumption

theorem all_extras_left_bound (hd : G.diam=7)
    (he : ∀ z∈extras x y hT hc, LeftSide G x y z) :
    isolationNumber G ≤ (allIndices (G := G) x y).card+2 := by
  classical
  let A := system x y hT hc
  let R := allIndices (G := G) x y
  have hb : 2 ≤ (A.groups R).card := two_groups x y hT hc hd
  have hk : (A.groups R).card ≤ R.card := Finset.card_image_le
  have hbase : A.Represents R {x,y} := both_roots_represents x y hT hc
  have hx : Legal G ∅ x := by
    refine ⟨x,Or.inl rfl,?_,y,hc.1,?_⟩ <;> simp [Undominated,Dominated]
  change isolationNumber G ≤ R.card+2
  refine A.oriented_strategy hbase hx ?_ (by omega) ?_ ?_
  · intro v hv
    by_cases hvy : v=y
    · exact Or.inl hvy
    · right
      by_contra hhit
      have hhit' : ¬ ∃ i : Index (G := G) x y, Closed G v i.val := by
        rintro ⟨i,hi⟩
        exact hhit ⟨i,by simp [R,allIndices],hi⟩
      have hvx : v≠x := by intro h; subst v; exact selected_not_legal G (by simp) hv
      have hve := no_star_hit_mem_extras x y hT hc hvx hvy hhit'
      exact hhit' (legal_left_hits_star x y hT hc hv (he v hve))
  · unfold gBound
    split <;> omega
  · unfold uBound sBound
    split <;> omega

/-- Both four-group/two-extra families in the paper, with real gate
responses and without a finite graph enumeration. -/
theorem four_groups_two_extras (hd : G.diam=7)
    (hb : ((allIndices x y).image (parent x y hT hc)).card=4)
    (he : (extras x y hT hc).card=2) :
    isolationNumber G ≤ (allIndices (G := G) x y).card+2 := by
  classical
  by_cases hshx : ShallowOn x y hT hc x
  · exact all_extras_left_bound x y hT hc hd (shallow_two_extras_left x y hT hc he hshx)
  · by_cases hshy : ShallowOn x y hT hc y
    · have he' : (extras y x hT (centerEdge_symm hc)).card=2 := by rw [extras_swap x y hT hc]; exact he
      have hsh' : ShallowOn y x hT (centerEdge_symm hc) y := (shallow_swap x y hT hc y).mpr hshy
      have hh := all_extras_left_bound y x hT (centerEdge_symm hc) hd
        (shallow_two_extras_left y x hT (centerEdge_symm hc) he' hsh')
      simpa only [stars_swap x y] using hh
    · have hsum := sideParents_partition x y hT hc
      have hone : (sideParents x y hT hc x).card ≤ 2 ∨ (sideParents x y hT hc y).card ≤ 2 := by omega
      rcases hone with hx | hy
      · have hsh' : ¬ ShallowOn y x hT (centerEdge_symm hc) x :=
          fun h => hshx ((shallow_swap x y hT hc x).mp h)
        have hx' : (sideParents y x hT (centerEdge_symm hc) x).card ≤ 2 := by
          rw [sideParents_swap x y hT hc]; exact hx
        have hh := two_opposite_groups_bound y x hT (centerEdge_symm hc) hd hsh' hx'
        simpa only [stars_swap x y] using hh
      · exact two_opposite_groups_bound x y hT hc hd hshy hy

end IsolationGame.DiameterSeven.DoubleRooted
