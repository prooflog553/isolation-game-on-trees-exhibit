import IsolationGame.DiameterSeven.SmallGraphs

namespace IsolationGame.DiameterSeven.Small

/-- The path uses labels c=0,b=1,a=2,x=3,y=4,d=5,e=6,f=7. -/
abbrev P8 := pathGraph 8

def pathReply (v : Fin 8) : Fin 8 := if v=7 then 5 else 6

theorem P8_first_legal : Legal P8 ∅ 2 := by decide

set_option maxRecDepth 8192 in
theorem P8_certificate : ∀ v : Fin 8, Legal P8 {2} v →
    Terminal P8 {v,2} ∨
      (Legal P8 {v,2} (pathReply v) ∧ Terminal P8 {pathReply v,v,2}) := by decide

theorem P8_three_moves : isolationNumber P8 ≤ 3 := by
  apply (isolationNumber_le_iff P8 3).mpr
  refine Or.inr ⟨2,P8_first_legal,Or.inr ?_⟩
  intro v hv
  rcases P8_certificate v (by simpa using hv) with ht | ⟨hl,ht⟩
  · exact terminal_wins P8 (by simpa using ht) _ _
  · exact Or.inr ⟨pathReply v,by simpa using hl,by simpa [WinsWithin] using ht⟩

/-- The unconditional two-center transition can take four moves on P8.
This is a legal trace, not a lower bound on the optimal center-first game. -/
theorem P8_two_center_trace :
    Legal P8 ∅ 3 ∧ Legal P8 {3} 0 ∧ Legal P8 {0,3} 4 ∧
    Legal P8 {4,0,3} 6 ∧ Terminal P8 {6,4,0,3} := by decide

/-- z=8 is attached at y,d,e according as t=0,1,2. -/
def nineGraph (t : Fin 3) : SimpleGraph (Fin 9) := edgeGraph
  [(0,1),(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(4+t.val,8)]

instance (t : Fin 3) : DecidableRel (nineGraph t).Adj :=
  inferInstanceAs (DecidableRel (edgeGraph _).Adj)

/-- Exactly the finishing responses in the paper's three-column table.
Values on already terminal branches are immaterial and never used. -/
def nineReply (t : Fin 3) (v : Fin 9) : Fin 9 :=
  if v=7 then 5 else if v=6 then 4 else if v=8 ∧ t=2 then 5 else 6

theorem nine_first_legal : ∀ t : Fin 3, Legal (nineGraph t) ∅ 2 := by decide

theorem nine_legal_moves : ∀ t : Fin 3, ∀ v : Fin 9,
    Legal (nineGraph t) {2} v ↔ v=3 ∨ v=4 ∨ v=5 ∨ v=6 ∨ v=7 ∨ v=8 := by decide

set_option maxRecDepth 8192 in
set_option maxHeartbeats 1000000 in
theorem nine_certificate : ∀ t : Fin 3, ∀ v : Fin 9, Legal (nineGraph t) {2} v →
    Terminal (nineGraph t) {v,2} ∨
      (Legal (nineGraph t) {v,2} (nineReply t v) ∧
        Terminal (nineGraph t) {nineReply t v,v,2}) := by decide

theorem nine_three_moves (t : Fin 3) : isolationNumber (nineGraph t) ≤ 3 := by
  apply (isolationNumber_le_iff (nineGraph t) 3).mpr
  refine Or.inr ⟨2,nine_first_legal t,Or.inr ?_⟩
  intro v hv
  rcases nine_certificate t v (by simpa using hv) with ht | ⟨hl,ht⟩
  · exact terminal_wins (nineGraph t) (by simpa using ht) _ _
  · exact Or.inr ⟨nineReply t v,by simpa using hl,by simpa [WinsWithin] using ht⟩

end IsolationGame.DiameterSeven.Small
