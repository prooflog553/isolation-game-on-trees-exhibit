import IsolationGame.DiameterSeven.TwoGroups
import IsolationGame.DiameterSeven.ElevenClassification
import IsolationGame.DiameterSeven.PathClassification

namespace IsolationGame.DiameterSeven

/-- The already proved G/U/Z policies, without an order restriction. -/
def envelope (b k e : Nat) : Nat :=
  if 2 ≤ e then zBound b k else max (gBound b k) (uBound b k)

namespace DoubleRooted

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V} (x y : V) (hT : G.IsTree) (hc : CenterEdge G x y)

theorem envelope_bound (hd : G.diam=7) : isolationNumber G ≤
    envelope ((allIndices x y).image (parent x y hT hc)).card
      (allIndices (G := G) x y).card (extras x y hT hc).card := by
  classical
  let A := system x y hT hc
  let R := allIndices (G := G) x y
  let e := (extras x y hT hc).card
  change isolationNumber G ≤ envelope (A.groups R).card R.card e
  by_cases he : 2 ≤ e
  · simpa only [envelope,if_pos he,zBound] using coarse_transition x y hT hc
  · rw [envelope,if_neg he]
    have hb : 2 ≤ (A.groups R).card := two_groups x y hT hc hd
    have hk : (A.groups R).card ≤ R.card := Finset.card_image_le
    have hN : 3 ≤ max (gBound (A.groups R).card R.card) (uBound (A.groups R).card R.card) := by
      unfold uBound
      omega
    have hbase : A.Represents R {x,y} := both_roots_represents x y hT hc
    have hx : Legal G ∅ x := by
      refine ⟨x,Or.inl rfl,?_,y,hc.1,?_⟩ <;> simp [Undominated,Dominated]
    have hy : Legal G ∅ y := by
      refine ⟨y,Or.inl rfl,?_,x,hc.1.symm,?_⟩ <;> simp [Undominated,Dominated]
    rcases orientation x y hT hc (by change e ≤ 1; omega) with hl | hr
    · apply A.oriented_strategy hbase hx _ hN (Nat.le_max_left _ _) (Nat.le_max_right _ _)
      intro v hv
      rcases hl v hv with hv | ⟨i,hi⟩
      · exact Or.inl hv
      · exact Or.inr ⟨i,by simp [R,allIndices],hi⟩
    · have hbase' : A.Represents R {y,x} := by simpa only [Finset.pair_comm] using hbase
      apply A.oriented_strategy hbase' hy _ hN (Nat.le_max_left _ _) (Nat.le_max_right _ _)
      intro v hv
      rcases hr v hv with hv | ⟨i,hi⟩
      · exact Or.inl hv
      · exact Or.inr ⟨i,by simp [R,allIndices],hi⟩

end DoubleRooted

set_option maxHeartbeats 2000000 in
/-- These two formerly external-theorem orders are covered outright by
the existing G/U/Z bounds. -/
theorem fourteen_seventeen_arithmetic {b k e n : Nat}
    (hb : 2 ≤ b) (hk : b ≤ k) (hn : n=2+b+2*k+e)
    (ho : n=14 ∨ n=17) : envelope b k e ≤ 3*n/7 := by
  have hbmax : b ≤ 5 := by omega
  have hkmax : k ≤ 7 := by omega
  interval_cases b <;> interval_cases k <;>
    norm_num [envelope,gBound,uBound,zBound,sBound] <;> (try split_ifs) <;> omega

/-- A complete order-ten proof using the two small two-group policies. -/
theorem order_ten_bound {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V)
    (hT : G.IsTree) (hd : G.diam=7) (hn : Fintype.card V=10) : isolationNumber G ≤ 4 := by
  classical
  obtain ⟨x,y,hc⟩ := exists_centerEdge hT hd
  let b := ((DoubleRooted.allIndices x y).image (DoubleRooted.parent x y hT hc)).card
  let k := (DoubleRooted.allIndices (G := G) x y).card
  let e := (DoubleRooted.extras x y hT hc).card
  have hb : 2 ≤ b := DoubleRooted.two_groups x y hT hc hd
  have hk : b ≤ k := DoubleRooted.groups_le_stars x y hT hc
  have hcount : 10=2+b+2*k+e := hn ▸ DoubleRooted.exact_count x y hT hc
  have hb2 : b=2 := by omega
  by_cases hk2 : k=2
  · have he : e ≤ 3 := by omega
    have h := DoubleRooted.two_groups_bound x y hT hc hd hb2 he
    change isolationNumber G ≤ 3+min 2 (k-1) at h
    omega
  · exact DoubleRooted.two_groups_three_stars x y hT hc hd hb2 (by omega) (by omega)

/-- All eleven-vertex trees: both nonzero-surplus families and H. -/
theorem order_eleven_bound {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V)
    (hT : G.IsTree) (hd : G.diam=7) (hn : Fintype.card V=11) : isolationNumber G ≤ 4 := by
  classical
  obtain ⟨x,y,hc⟩ := exists_centerEdge hT hd
  let b := ((DoubleRooted.allIndices x y).image (DoubleRooted.parent x y hT hc)).card
  let k := (DoubleRooted.allIndices (G := G) x y).card
  let e := (DoubleRooted.extras x y hT hc).card
  have hb : 2 ≤ b := DoubleRooted.two_groups x y hT hc hd
  have hk : b ≤ k := DoubleRooted.groups_le_stars x y hT hc
  have hcount : 11=2+b+2*k+e := hn ▸ DoubleRooted.exact_count x y hT hc
  by_cases hb2 : b=2
  · by_cases hk2 : k=2
    · have he : e ≤ 3 := by omega
      have h := DoubleRooted.two_groups_bound x y hT hc hd hb2 he
      change isolationNumber G ≤ 3+min 2 (k-1) at h
      omega
    · exact DoubleRooted.two_groups_three_stars x y hT hc hd hb2 (by omega) (by omega)
  · exact DoubleRooted.eleven_H_bound x y hT hc hd hn (by omega) (by omega)

theorem order_fourteen_seventeen_bound {V : Type*} [Fintype V] [DecidableEq V]
    (G : SimpleGraph V) (hT : G.IsTree) (hd : G.diam=7)
    (hn : Fintype.card V=14 ∨ Fintype.card V=17) :
    isolationNumber G ≤ 3*Fintype.card V/7 := by
  classical
  obtain ⟨x,y,hc⟩ := exists_centerEdge hT hd
  exact (DoubleRooted.envelope_bound x y hT hc hd).trans
    (fourteen_seventeen_arithmetic (DoubleRooted.two_groups x y hT hc hd)
      (DoubleRooted.groups_le_stars x y hT hc) (DoubleRooted.exact_count x y hT hc) hn)

set_option maxHeartbeats 2000000 in
theorem twelve_arithmetic {b k e L : Nat} (hb : 2 ≤ b) (hk : b ≤ k)
    (hn : 12=2+b+2*k+e) (hL : L ≤ envelope b k e)
    (htwo : b=2 → e ≤ 3 → L ≤ 3+min 2 (k-1)) : L ≤ 5 := by
  have hbmax : b ≤ 3 := by omega
  have hkmax : k ≤ 4 := by omega
  interval_cases b <;> interval_cases k <;>
    norm_num [envelope,gBound,uBound,zBound,sBound] at hL htwo ⊢ <;>
    (try split_ifs at hL) <;> omega

theorem order_twelve_bound {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V)
    (hT : G.IsTree) (hd : G.diam=7) (hn : Fintype.card V=12) : isolationNumber G ≤ 5 := by
  classical
  obtain ⟨x,y,hc⟩ := exists_centerEdge hT hd
  apply twelve_arithmetic (DoubleRooted.two_groups x y hT hc hd)
    (DoubleRooted.groups_le_stars x y hT hc) (hn ▸ DoubleRooted.exact_count x y hT hc)
    (DoubleRooted.envelope_bound x y hT hc hd)
  exact fun hb he => DoubleRooted.two_groups_bound x y hT hc hd hb he

/-- Unconditional small-order coverage completed in this continuation. -/
theorem covered_small_orders {V : Type*} [Fintype V] (G : SimpleGraph V)
    (hT : G.IsTree) (hd : G.diam=7)
    (hn : Fintype.card V ≤ 12 ∨ Fintype.card V=14 ∨ Fintype.card V=17) :
    gameIsolationNumber G ≤ 3*Fintype.card V/7 := by
  classical
  change isolationNumber G ≤ _
  have hmin := diameter_seven_card_min hT hd
  rcases hn with hsmall | h14 | h17
  · have hcases : Fintype.card V=8 ∨ Fintype.card V=9 ∨ Fintype.card V=10 ∨
        Fintype.card V=11 ∨ Fintype.card V=12 := by omega
    rcases hcases with h | h | h | h | h
    · have hh := order_eight_bound hT hd h; omega
    · have hh := order_nine_bound hT hd h; omega
    · have hh := order_ten_bound G hT hd h; omega
    · have hh := order_eleven_bound G hT hd h; omega
    · have hh := order_twelve_bound G hT hd h; omega
  · exact order_fourteen_seventeen_bound G hT hd (Or.inl h14)
  · exact order_fourteen_seventeen_bound G hT hd (Or.inr h17)

end IsolationGame.DiameterSeven
