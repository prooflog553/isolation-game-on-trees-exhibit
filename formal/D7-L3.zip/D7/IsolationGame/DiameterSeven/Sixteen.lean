import IsolationGame.DiameterSeven.SmallGraphs
import IsolationGame.DiameterSeven.ResidualEmbedding

namespace IsolationGame.DiameterSeven.Small

/-- The special order-sixteen graph: retain the fixed H labels 0,...,10
and add the double group at x=0, with parent 11 and edges 12-13, 14-15. -/
def T16 : SimpleGraph (Fin 16) := edgeGraph
  [(0,1),(0,2),(2,3),(3,4),(1,5),(5,6),(6,7),(1,8),(8,9),(9,10),
   (0,11),(11,12),(12,13),(11,14),(14,15)]

instance : DecidableRel T16.Adj := inferInstanceAs (DecidableRel (edgeGraph _).Adj)

def retainH : Fin 11 → Fin 16 := Fin.castLE (by decide)

/-- The premarked root of the residual graph is literally the image of x. -/
theorem retained_single_arm_root : retainH x = 0 := rfl

def sixteenEmbedding : ResidualEmbedding T16 H {x} where
  toFun := retainH
  injective := by decide
  adj_iff := by decide
  external := by decide

/-- Exact initial white-set equivalence, not a fresh-game bound substituted
for a residual position. The five omitted vertices supply no legal move. -/
theorem sixteen_represents : sixteenEmbedding.Represents {11} ∅ := by
  unfold ResidualEmbedding.Represents
  decide

theorem sixteen_residual_value :
    gameValue T16 .staller {11} = Marked.gameValue H {x} .staller ∅ :=
  sixteenEmbedding.value_eq sixteen_represents .staller

theorem sixteen_first_legal : Legal T16 ∅ 11 := by decide

theorem sixteen_six_moves : isolationNumber T16 ≤ 6 := by
  apply (isolationNumber_le_iff T16 6).mpr
  refine Or.inr ⟨11,sixteen_first_legal,?_⟩
  apply (gameValue_le_iff T16 .staller {11} 5).mp
  rw [sixteen_residual_value]
  exact H_marked_x_five

/-- Correct floor bound for this labelled configuration. Classification of
arbitrary trees with the corresponding parameters is a separate obligation. -/
theorem sixteen_floor_bound : isolationNumber T16 ≤ 3*Fintype.card (Fin 16)/7 := by
  simpa using sixteen_six_moves

end IsolationGame.DiameterSeven.Small
