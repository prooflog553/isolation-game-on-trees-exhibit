import IsolationGame.DiameterSeven.DoubleRooted
import IsolationGame.DiameterSeven.StructuralTransport

namespace IsolationGame.DiameterSeven.DoubleRooted

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V} (x y : V) (hT : G.IsTree) (hc : CenterEdge G x y)

theorem parent_adj_root (i : Index (G := G) x y) :
    G.Adj (parent x y hT hc i) x ∨ G.Adj (parent x y hT hc i) y := by
  have hd := (parent_spec x y hT hc i).2
  unfold depth at hd
  have hh : G.dist (parent x y hT hc i) x=1 ∨
      G.dist (parent x y hT hc i) y=1 := by omega
  exact hh.imp SimpleGraph.dist_eq_one_iff_adj.mp SimpleGraph.dist_eq_one_iff_adj.mp

theorem parent_not_both_roots (i : Index (G := G) x y) :
    ¬ (G.Adj (parent x y hT hc i) x ∧ G.Adj (parent x y hT hc i) y) := by
  rintro ⟨hx,hy⟩
  have hx' := SimpleGraph.dist_eq_one_iff_adj.mpr hx
  have hy' := SimpleGraph.dist_eq_one_iff_adj.mpr hy
  have hh := endpoint_distance_step hT hc.1 (parent x y hT hc i)
  omega

theorem parent_side_witnesses (hd : G.diam=7) :
    (∃ i : Index (G := G) x y, G.Adj (parent x y hT hc i) x) ∧
    (∃ i : Index (G := G) x y, G.Adj (parent x y hT hc i) y) := by
  have side (r s : V) (hrs : r=x ∧ s=y ∨ r=y ∧ s=x)
      (hside : ∃ u, LeftSide G r s u ∧ G.dist u r=3) :
      ∃ i : Index (G := G) x y, G.Adj (parent x y hT hc i) r := by
    obtain ⟨u,hu,hud⟩ := hside
    have hrsadj : G.Adj r s := by rcases hrs with ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩; exact hc.1; exact hc.1.symm
    have hud' : depth (G := G) x y u=3 := by
      rcases hrs with ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩
      · exact (depth_left _ _ hu).trans hud
      · exact (depth_right _ _ hu).trans hud
    obtain ⟨c,huc,hcd⟩ := exists_lower x y hT hc (by omega : 0 < depth (G := G) x y u)
    let i : Index (G := G) x y := ⟨c,by omega,u,huc.symm,hud'⟩
    have hune : u≠r := by intro h; rw [h,G.dist_self] at hud; omega
    have hcs := nonroot_neighbor_same_side hT hrsadj hu hune huc
    have hdroot : depth (G := G) x y r=0 := by
      rcases hrs with ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩; exact depth_x _ _; exact depth_y _ _
    have hcne : c≠r := by intro h; rw [h,hdroot] at hcd; omega
    have hps := nonroot_neighbor_same_side hT hrsadj hcs hcne (parent_spec x y hT hc i).1
    have hpd := (parent_spec x y hT hc i).2
    have hdist : G.dist (parent x y hT hc i) r=1 := by
      rcases hrs with ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩
      · rwa [depth_left _ _ hps] at hpd
      · rwa [depth_right _ _ hps] at hpd
    exact ⟨i,SimpleGraph.dist_eq_one_iff_adj.mp hdist⟩
  exact ⟨side x y (Or.inl ⟨rfl,rfl⟩) (left_depth_three_exists hT hd hc),
    side y x (Or.inr ⟨rfl,rfl⟩) (right_depth_three_exists hT hd hc)⟩

/-- Zero surplus is an actual covering statement, not just an arithmetic
equality: every vertex is a root, parent, center or chosen leaf. -/
theorem cover_of_zero_extras (he : (extras x y hT hc).card=0) :
    counted x y hT hc=Finset.univ := by
  have heq := exact_count x y hT hc
  apply Finset.eq_univ_of_card
  rw [counted_card x y hT hc]
  omega

set_option maxHeartbeats 2000000 in
/-- Three stars meeting both sides can be ordered as one arm against two.
This is a structural partition of arbitrary tree indices. -/
theorem three_stars_side_split (hd : G.diam=7)
    (hk : (allIndices (G := G) x y).card=3) :
    ∃ i j k : Index (G := G) x y, allIndices x y={i,j,k} ∧
      ((G.Adj (parent x y hT hc i) x ∧ G.Adj (parent x y hT hc j) y ∧
        G.Adj (parent x y hT hc k) y) ∨
       (G.Adj (parent x y hT hc i) y ∧ G.Adj (parent x y hT hc j) x ∧
        G.Adj (parent x y hT hc k) x)) := by
  classical
  obtain ⟨i,j,k,_,_,_,hR⟩ := Finset.card_eq_three.mp hk
  obtain ⟨⟨l,hl⟩,⟨r,hr⟩⟩ := parent_side_witnesses x y hT hc hd
  have hleft : G.Adj (parent x y hT hc i) x ∨
      G.Adj (parent x y hT hc j) x ∨ G.Adj (parent x y hT hc k) x := by
    have hm : l∈allIndices (G := G) x y := by simp [allIndices]
    simp only [hR,Finset.mem_insert,Finset.mem_singleton] at hm
    rcases hm with rfl | rfl | rfl <;> tauto
  have hright : G.Adj (parent x y hT hc i) y ∨
      G.Adj (parent x y hT hc j) y ∨ G.Adj (parent x y hT hc k) y := by
    have hm : r∈allIndices (G := G) x y := by simp [allIndices]
    simp only [hR,Finset.mem_insert,Finset.mem_singleton] at hm
    rcases hm with rfl | rfl | rfl <;> tauto
  have hi := parent_adj_root x y hT hc i
  have hj := parent_adj_root x y hT hc j
  have hk' := parent_adj_root x y hT hc k
  have hni := parent_not_both_roots x y hT hc i
  have hnj := parent_not_both_roots x y hT hc j
  have hnk := parent_not_both_roots x y hT hc k
  have hsplit :
      (G.Adj (parent x y hT hc i) x ∧ G.Adj (parent x y hT hc j) y ∧ G.Adj (parent x y hT hc k) y) ∨
      (G.Adj (parent x y hT hc j) x ∧ G.Adj (parent x y hT hc i) y ∧ G.Adj (parent x y hT hc k) y) ∨
      (G.Adj (parent x y hT hc k) x ∧ G.Adj (parent x y hT hc i) y ∧ G.Adj (parent x y hT hc j) y) ∨
      (G.Adj (parent x y hT hc i) y ∧ G.Adj (parent x y hT hc j) x ∧ G.Adj (parent x y hT hc k) x) ∨
      (G.Adj (parent x y hT hc j) y ∧ G.Adj (parent x y hT hc i) x ∧ G.Adj (parent x y hT hc k) x) ∨
      (G.Adj (parent x y hT hc k) y ∧ G.Adj (parent x y hT hc i) x ∧ G.Adj (parent x y hT hc j) x) := by tauto
  have hRj : allIndices x y={j,i,k} := by ext z; simp [hR,or_comm,or_left_comm,or_assoc]
  have hRk : allIndices x y={k,i,j} := by ext z; simp [hR,or_comm,or_left_comm,or_assoc]
  rcases hsplit with h | h | h | h | h | h
  · exact ⟨i,j,k,hR,Or.inl h⟩
  · exact ⟨j,i,k,hRj,Or.inl h⟩
  · exact ⟨k,i,j,hRk,Or.inl h⟩
  · exact ⟨i,j,k,hR,Or.inr h⟩
  · exact ⟨j,i,k,hRj,Or.inr h⟩
  · exact ⟨k,i,j,hRk,Or.inr h⟩

end IsolationGame.DiameterSeven.DoubleRooted
