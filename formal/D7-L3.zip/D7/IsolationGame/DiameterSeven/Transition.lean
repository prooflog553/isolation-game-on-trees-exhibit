import IsolationGame.DiameterSeven.DoubleRooted
import IsolationGame.DiameterSeven.GroupBounds

namespace IsolationGame.DiameterSeven.DoubleRooted

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V} (x y : V) (hT : G.IsTree) (hc : CenterEdge G x y)

/-- The complete three-move transition, with arbitrary intervening Staller
reply. If the second root is illegal, a real legal move is used instead.
The bound is the unrestricted Z envelope; the sharper G/U envelopes need
additional response classification. -/
theorem coarse_transition :
    isolationNumber G ≤
      3+sBound ((allIndices x y).image (parent x y hT hc)).card
        (allIndices (G := G) x y).card := by
  classical
  let A := system x y hT hc
  let R := allIndices (G := G) x y
  let s := sBound (A.groups R).card R.card
  have subset_after (Q : Finset (Index (G := G) x y)) (v : V) :
      A.remainingAfter Q v ⊆ Q := by
    intro i hi
    simp only [StarSystem.remainingAfter,Finset.mem_filter] at hi
    exact hi.1
  have boundS {Q : Finset (Index (G := G) x y)} {X : Finset V}
      (hsub : Q ⊆ R) (hrep : A.Represents Q X) :
      WinsWithin G s .staller X := by
    apply (A.strategy_equivalence hrep s .staller).mpr
    exact A.staller_survival (Finset.card_le_card (A.groups_mono hsub))
      (Finset.card_le_card hsub)
  have hx : Legal G ∅ x := by
    refine ⟨x,Or.inl rfl,?_,y,hc.1,?_⟩ <;> simp [Undominated,Dominated]
  have hw : WinsWithin G (s+3) .dominator ∅ := by
    refine Or.inr ⟨x,hx,Or.inr ?_⟩
    intro v _
    by_cases ht : Terminal G {v,x}
    · exact terminal_wins G ht _ _
    · by_cases hy : Legal G {v,x} y
      · refine Or.inr ⟨y,hy,?_⟩
        exact boundS (subset_after R v) (transition_represents x y hT hc v)
      · have hr : A.Represents (A.remainingAfter R v) {v,x} :=
          illegal_second_root_represents x y hT hc v hy
        obtain ⟨w,hw⟩ := exists_legal_of_not_terminal G ht
        refine Or.inr ⟨w,hw,?_⟩
        exact boundS ((subset_after (A.remainingAfter R v) w).trans (subset_after R v))
          (A.represents_after hr w)
  have hval := (isolationNumber_le_iff G (s+3)).mpr hw
  change isolationNumber G ≤ 3+s
  omega

/-- A proved unbounded part of the diameter-seven target, under an explicit
surplus condition. This auxiliary result is not the full main theorem. -/
theorem large_with_two_extras (hd : G.diam=7) (hn : 19 ≤ Fintype.card V)
    (he : 2 ≤ (extras x y hT hc).card) :
    isolationNumber G ≤ 3*Fintype.card V/7 := by
  have hb := two_groups x y hT hc hd
  have hk := groups_le_stars x y hT hc
  have hcount := exact_count x y hT hc
  have hL := coarse_transition x y hT hc
  exact uniform_arithmetic hb hk hcount hn (Or.inr (Or.inr ⟨he,hL⟩))

end IsolationGame.DiameterSeven.DoubleRooted
