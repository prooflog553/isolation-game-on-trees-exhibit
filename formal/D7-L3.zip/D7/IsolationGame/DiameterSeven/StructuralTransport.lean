import IsolationGame.DiameterSeven.SmallGraphs
import IsolationGame.TreeLevels

namespace IsolationGame.DiameterSeven

open SimpleGraph

/-- An injective homomorphism from a connected graph into a tree reflects
edges: a missing edge would give a second path in the tree. -/
theorem tree_hom_reflects {V W : Type*} {G : SimpleGraph V} {H : SimpleGraph W}
    (hT : G.IsTree) (hH : H.Connected) (f : H →g G) (hf : Function.Injective f)
    (u v : W) : G.Adj (f u) (f v) ↔ H.Adj u v := by
  constructor
  · intro hadj
    obtain ⟨p,hp⟩ := hH.exists_isPath u v
    have hlen := tree_path_length_eq_dist hT (p.map f)
      (Walk.map_isPath_of_injective hf hp)
    rw [Walk.length_map,dist_eq_one_iff_adj.mpr hadj] at hlen
    exact Walk.adj_of_length_eq_one hlen
  · exact f.map_adj

/-- A vertex bijection preserving the displayed connected pattern is a
graph isomorphism into a tree. No finite graph enumeration is needed. -/
noncomputable def treeIsoOfHom {V W : Type*} {G : SimpleGraph V} {H : SimpleGraph W}
    (hT : G.IsTree) (hH : H.Connected) (e : W ≃ V)
    (he : ∀ u v, H.Adj u v → G.Adj (e u) (e v)) : H ≃g G where
  toEquiv := e
  map_rel_iff' := tree_hom_reflects hT hH ⟨e,he _ _⟩ e.injective _ _

/-- Connectivity certificate for a labelled tree pattern: every nonzero
label has a neighbor with a smaller label. -/
theorem connected_of_lower_labels {n : Nat} (hn : 0<n) (G : SimpleGraph (Fin n))
    (h : ∀ i : Fin n, i.val≠0 → ∃ j : Fin n, j.val < i.val ∧ G.Adj i j) :
    G.Connected := by
  let r : Fin n := ⟨0,hn⟩
  have reaches : ∀ k (hk : k<n), G.Reachable ⟨k,hk⟩ r := by
    intro k
    induction k using Nat.strong_induction_on with
    | h k ih =>
      intro hk
      by_cases hz : k=0
      · subst k
        exact Reachable.rfl
      · obtain ⟨j,hj,hadj⟩ := h ⟨k,hk⟩ hz
        exact hadj.reachable.trans (ih j.val hj j.isLt)
  exact (connected_iff_exists_forall_reachable G).mpr
    ⟨r,fun i => (reaches i.val i.isLt).symm⟩

namespace Small

theorem H_connected : H.Connected :=
  connected_of_lower_labels (by decide) H (by decide)

end Small
end IsolationGame.DiameterSeven
