import IsolationGame.DiameterSeven.EighteenStructure

namespace IsolationGame.DiameterSeven.DoubleRooted

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V} (x y : V) (hT : G.IsTree) (hc : CenterEdge G x y)

set_option maxHeartbeats 4000000 in
/-- The balanced (4,6,0) family is exhausted by the paper's three
positive group-size patterns. Each of the two surplus stars belongs to
one of four actual groups; the sixteen alternatives are reorganized
using side symmetry and the order of stars within a group. -/
theorem eighteen_balanced_iso
    (hb : ((allIndices x y).image (parent x y hT hc)).card=4)
    (hk : (allIndices (G := G) x y).card=6) (he : (extras x y hT hc).card=0)
    (hl : (sideParents x y hT hc x).card=2)
    (hr : (sideParents x y hT hc y).card=2) :
    ∃ t : Fin 3, Nonempty (Small.E18 t ≃g G) := by
  classical
  let A := system x y hT hc
  let R := allIndices (G := G) x y
  have hn : Fintype.card V=18 := by have hh := exact_count x y hT hc; omega
  have hcover : insert y (A.countedVertices x R)=Finset.univ := cover_of_zero_extras x y hT hc he
  have hcover' : insert x (A.countedVertices y R)=Finset.univ := by
    simpa only [StarSystem.countedVertices,Finset.insert_comm] using hcover
  obtain ⟨a,b,c,d,j,k,hR,ha,hb',hc',hd,hj,hk'⟩ := six_stars_balanced_cover x y hT hc hb hk hl hr
  rcases hj with hj | hj | hj | hj <;> rcases hk' with hk' | hk' | hk' | hk'
  · refine ⟨0,?_⟩
    have horder : R={a,j,k,b,c,d} := by
      ext z; simp [R,hR,or_assoc,or_comm,or_left_comm]
    exact E18_iso_0_of_cover hT hn A R x y a j k b c d
      hcover horder hc.1 ha hb' hc' hd hj hk'
  · refine ⟨1,?_⟩
    have horder : R={a,j,b,k,c,d} := by
      ext z; simp [R,hR,or_assoc,or_comm,or_left_comm]
    exact E18_iso_1_of_cover hT hn A R x y a j b k c d
      hcover horder hc.1 ha hb' hc' hd hj hk'
  · refine ⟨2,?_⟩
    have horder : R={a,j,b,c,k,d} := by
      ext z; simp [R,hR,or_assoc,or_comm,or_left_comm]
    exact E18_iso_2_of_cover hT hn A R x y a j b c k d
      hcover horder hc.1 ha hb' hc' hd hj hk'
  · refine ⟨2,?_⟩
    have horder : R={a,j,b,d,k,c} := by
      ext z; simp [R,hR,or_assoc,or_comm,or_left_comm]
    exact E18_iso_2_of_cover hT hn A R x y a j b d k c
      hcover horder hc.1 ha hb' hd hc' hj hk'
  · refine ⟨1,?_⟩
    have horder : R={b,j,a,k,c,d} := by
      ext z; simp [R,hR,or_assoc,or_comm,or_left_comm]
    exact E18_iso_1_of_cover hT hn A R x y b j a k c d
      hcover horder hc.1 hb' ha hc' hd hj hk'
  · refine ⟨0,?_⟩
    have horder : R={b,j,k,a,c,d} := by
      ext z; simp [R,hR,or_assoc,or_comm,or_left_comm]
    exact E18_iso_0_of_cover hT hn A R x y b j k a c d
      hcover horder hc.1 hb' ha hc' hd hj hk'
  · refine ⟨2,?_⟩
    have horder : R={b,j,a,c,k,d} := by
      ext z; simp [R,hR,or_assoc,or_comm,or_left_comm]
    exact E18_iso_2_of_cover hT hn A R x y b j a c k d
      hcover horder hc.1 hb' ha hc' hd hj hk'
  · refine ⟨2,?_⟩
    have horder : R={b,j,a,d,k,c} := by
      ext z; simp [R,hR,or_assoc,or_comm,or_left_comm]
    exact E18_iso_2_of_cover hT hn A R x y b j a d k c
      hcover horder hc.1 hb' ha hd hc' hj hk'
  · refine ⟨2,?_⟩
    have horder : R={c,j,d,a,k,b} := by
      ext z; simp [R,hR,or_assoc,or_comm,or_left_comm]
    exact E18_iso_2_of_cover hT hn A R y x c j d a k b
      hcover' horder hc.1.symm hc' hd ha hb' hj hk'
  · refine ⟨2,?_⟩
    have horder : R={c,j,d,b,k,a} := by
      ext z; simp [R,hR,or_assoc,or_comm,or_left_comm]
    exact E18_iso_2_of_cover hT hn A R y x c j d b k a
      hcover' horder hc.1.symm hc' hd hb' ha hj hk'
  · refine ⟨0,?_⟩
    have horder : R={c,j,k,d,a,b} := by
      ext z; simp [R,hR,or_assoc,or_comm,or_left_comm]
    exact E18_iso_0_of_cover hT hn A R y x c j k d a b
      hcover' horder hc.1.symm hc' hd ha hb' hj hk'
  · refine ⟨1,?_⟩
    have horder : R={c,j,d,k,a,b} := by
      ext z; simp [R,hR,or_assoc,or_comm,or_left_comm]
    exact E18_iso_1_of_cover hT hn A R y x c j d k a b
      hcover' horder hc.1.symm hc' hd ha hb' hj hk'
  · refine ⟨2,?_⟩
    have horder : R={d,j,c,a,k,b} := by
      ext z; simp [R,hR,or_assoc,or_comm,or_left_comm]
    exact E18_iso_2_of_cover hT hn A R y x d j c a k b
      hcover' horder hc.1.symm hd hc' ha hb' hj hk'
  · refine ⟨2,?_⟩
    have horder : R={d,j,c,b,k,a} := by
      ext z; simp [R,hR,or_assoc,or_comm,or_left_comm]
    exact E18_iso_2_of_cover hT hn A R y x d j c b k a
      hcover' horder hc.1.symm hd hc' hb' ha hj hk'
  · refine ⟨1,?_⟩
    have horder : R={d,j,c,k,a,b} := by
      ext z; simp [R,hR,or_assoc,or_comm,or_left_comm]
    exact E18_iso_1_of_cover hT hn A R y x d j c k a b
      hcover' horder hc.1.symm hd hc' ha hb' hj hk'
  · refine ⟨0,?_⟩
    have horder : R={d,j,k,c,a,b} := by
      ext z; simp [R,hR,or_assoc,or_comm,or_left_comm]
    exact E18_iso_0_of_cover hT hn A R y x d j k c a b
      hcover' horder hc.1.symm hd hc' ha hb' hj hk'

end IsolationGame.DiameterSeven.DoubleRooted
