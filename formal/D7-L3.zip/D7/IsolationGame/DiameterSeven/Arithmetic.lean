import IsolationGame.MainTheorem
import Mathlib.Tactic.IntervalCases

namespace IsolationGame.DiameterSeven

/-- The paper's S-game envelope, with its conditional third entry. -/
def sBound (b k : Nat) : Nat :=
  min (min k (2*b)) (if b+2 ≤ k then k-1 else k)

/-- A weaker consequence of (3), sufficient for the arithmetic partition.
Its connection to the group strategy is proved in `GroupBounds.lean`. -/
def gBound (b k : Nat) : Nat :=
  if k = b then b+2 else min (k+1) (2*b+1)

def uBound (b k : Nat) : Nat := 3 + sBound (min b (k-1)) (k-1)
def zBound (b k : Nat) : Nat := 3 + sBound b k

theorem floor_bound_iff (g n : Nat) : g ≤ 3*n/7 ↔ 7*g ≤ 3*n := by
  omega

/-- Reuses the completed L3 theorem; this is not a new proof of diameter six. -/
theorem diameter_six_case {V : Type*} [Fintype V] (T : SimpleGraph V)
    (hT : T.IsTree) (hn : 3 ≤ Fintype.card V) (hd : T.diam ≤ 6) :
    gameIsolationNumber T ≤ 3 * Fintype.card V / 7 := by
  obtain ⟨h₁, h₂⟩ := tree_diameter_six_bound T hT hn hd
  omega

theorem g_arithmetic {b k e n L : Nat} (hb : 2 ≤ b) (hk : b ≤ k)
    (hn : n = 2+b+2*k+e) (hL : L ≤ gBound b k) :
    7*L ≤ 3*n ∨ (k = b ∧ 2*b+3*e < 8 ∧ n ≤ 18) := by
  unfold gBound at hL
  split at hL <;> omega

theorem u_arithmetic {b k e n L : Nat} (hb : 2 ≤ b) (hk : b ≤ k)
    (hn : n = 2+b+2*k+e) (hL : L ≤ uBound b k) :
    7*L ≤ 3*n ∨ n ≤ 18 := by
  unfold uBound sBound at hL
  split at hL <;> omega

theorem z_arithmetic {b k e n L : Nat} (hb : 2 ≤ b) (hk : b ≤ k)
    (he : 2 ≤ e) (hn : n = 2+b+2*k+e) (hL : L ≤ zBound b k) :
    7*L ≤ 3*n ∨ n ≤ 18 := by
  unfold zBound sBound at hL
  split at hL <;> omega

theorem uniform_arithmetic {b k e n L : Nat} (hb : 2 ≤ b) (hk : b ≤ k)
    (hn : n = 2+b+2*k+e) (hn19 : 19 ≤ n)
    (hL : L ≤ gBound b k ∨ L ≤ uBound b k ∨ (2 ≤ e ∧ L ≤ zBound b k)) :
    L ≤ 3*n/7 := by
  rcases hL with h | h | ⟨he, h⟩
  · have := g_arithmetic hb hk hn h; omega
  · have := u_arithmetic hb hk hn h; omega
  · have := z_arithmetic hb hk he hn h; omega

/-- Exactly the twelve parameter triples displayed in Section 5. -/
def Exceptional (b k e : Nat) : Prop :=
  (b=2 ∧ k=2 ∧ e=1) ∨
  (b=2 ∧ k=2 ∧ e=3) ∨ (b=2 ∧ k=3 ∧ e=1) ∨ (b=3 ∧ k=3 ∧ e=0) ∨
  (b=2 ∧ k=5 ∧ e=2) ∨ (b=2 ∧ k=6 ∧ e=0) ∨
  (b=3 ∧ k=4 ∧ e=3) ∨ (b=3 ∧ k=5 ∧ e=1) ∨
  (b=4 ∧ k=4 ∧ e=2) ∨ (b=4 ∧ k=5 ∧ e=0) ∨
  (b=4 ∧ k=5 ∧ e=2) ∨ (b=4 ∧ k=6 ∧ e=0)

set_option maxHeartbeats 2000000 in
theorem exception_partition {b k e n L : Nat} (hb : 2 ≤ b) (hk : b ≤ k)
    (hn : n = 2+b+2*k+e) (horder : n=9 ∨ n=11 ∨ n=16 ∨ n=18)
    (hL : L ≤ gBound b k ∨ L ≤ uBound b k ∨ (2 ≤ e ∧ L ≤ zBound b k))
    (hfail : ¬ L ≤ 3*n/7) : Exceptional b k e := by
  have hbmax : b ≤ 5 := by omega
  have hkmax : k ≤ 8 := by omega
  interval_cases b <;> interval_cases k <;>
    norm_num [Exceptional, gBound, uBound, zBound, sBound] at hL ⊢ <;> omega

/-- This is only the arithmetic implication, not the external 5n/11 theorem. -/
theorem published_bound_small_order {n g : Nat}
    (hn : n=8 ∨ n=10 ∨ n=12 ∨ n=13 ∨ n=14 ∨ n=15 ∨ n=17)
    (hpublished : 11*g ≤ 5*n) : g ≤ 3*n/7 := by
  omega

/-- Section 8's saving accounting on an actual finite list of star deletions.
Each entry is charged once. Zero entries count opening moves. -/
def zeros : List Nat → Nat
  | [] => 0
  | a::as => (if a=0 then 1 else 0) + zeros as

def savings : List Nat → Nat
  | [] => 0
  | a::as => (a-1) + savings as

theorem accounting (xs : List Nat) :
    xs.length + savings xs = xs.sum + zeros xs := by
  induction xs with
  | nil => simp [zeros, savings]
  | cons a xs ih =>
    simp only [List.length_cons, List.sum_cons, zeros, savings]
    split <;> omega

theorem six_stars_settled {xs : List Nat} (hstars : xs.sum ≤ 6)
    (hcredit : zeros xs ≤ savings xs) : 1+xs.length ≤ 7 := by
  have := accounting xs
  omega

theorem initial_two_single_deletions (xs : List Nat) :
    savings (1::1::xs) = savings xs ∧ zeros (1::1::xs) = zeros xs := by
  simp [savings, zeros]

end IsolationGame.DiameterSeven
