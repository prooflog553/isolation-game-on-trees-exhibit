import IsolationGame.DiameterSeven.UniformLarge
import IsolationGame.DiameterSeven.ExtraStructure

namespace IsolationGame.DiameterSeven.DoubleRooted

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V} (x y : V) (hT : G.IsTree) (hc : CenterEdge G x y)

/-- Deep stars still present in a real selected-set position. -/
noncomputable def survivors (X : Finset V) : Finset (Index (G := G) x y) := by
  classical
  exact (allIndices x y).filter (fun i => Undominated G X i.val)

theorem survivors_subset (X : Finset V) :
    survivors (G := G) x y X ⊆ allIndices x y := by
  classical
  exact Finset.filter_subset _ _

theorem survivors_after (X : Finset V) (v : V) :
    survivors (G := G) x y (insert v X) =
      (system x y hT hc).remainingAfter (survivors x y X) v := by
  classical
  ext i
  simp [survivors,StarSystem.remainingAfter,undominated_insert, and_assoc,system]

theorem surviving_vertices_white {X : Finset V} {i : Index (G := G) x y}
    (hi : i∈survivors x y X) {u : V}
    (hu : u∈(system x y hT hc).vertices i) : White G X u := by
  classical
  let A := system x y hT hc
  have hic : Undominated G X (A.center i) := (Finset.mem_filter.mp hi).2
  have hund (z : V) (hz : z∈A.vertices i) : Undominated G X z := by
    rintro ⟨v,hv,hvz⟩
    exact hic ⟨v,hv,(A.closed_center_iff i v).mpr (A.closed_star_implies hz hvz)⟩
  obtain ⟨w,hw,huw⟩ := A.internal_neighbor hu
  exact ⟨hund u hu,w,huw,hund w hw⟩

/-- When neither root can hit a white vertex, the actual position is
exactly the grouped-star position of its surviving stars. -/
theorem represents_survivors {X : Finset V}
    (hx : ¬ Legal G X x) (hy : ¬ Legal G X y) :
    (system x y hT hc).Represents (survivors x y X) X := by
  classical
  let A := system x y hT hc
  intro u
  constructor
  · intro hu
    have hnot (z : V) (hz : White G X z) : Undominated G {x,y} z := by
      rintro ⟨v,hv,hvz⟩
      simp only [Finset.mem_insert,Finset.mem_singleton] at hv
      rcases hv with rfl | rfl
      · exact hx ⟨z,hvz,hz⟩
      · exact hy ⟨z,hvz,hz⟩
    obtain ⟨w,huw,hw⟩ := hu.2
    have hw' : White G X w := ⟨hw,u,huw.symm,hu.1⟩
    have hu' : White G {x,y} u := ⟨hnot u hu,w,huw,hnot w hw'⟩
    obtain ⟨i,hi,hui⟩ := (both_roots_represents x y hT hc u).mp hu'
    refine ⟨i,Finset.mem_filter.mpr ⟨hi,?_⟩,hui⟩
    change Undominated G X (A.center i)
    rcases Finset.mem_insert.mp hui with heq | hleaf
    · exact heq ▸ hu.1
    · have hwc := A.leaf_neighbor hleaf huw
      exact hwc ▸ hw
  · rintro ⟨i,hi,hui⟩
    exact surviving_vertices_white x y hT hc hi hui

/-- The unique white neighbor of an already dominated root is a legal
gate move, and selecting it makes that root permanently illegal. -/
theorem unique_gate_reply {X : Finset V} {q : V}
    (hdom : Dominated G X y) (hlegal : Legal G X y)
    (hgate : ∀ u, G.Adj y u → White G X u → u=q) :
    Legal G X q ∧ ¬ Legal G (insert q X) y := by
  obtain ⟨u,hu,huw⟩ := hlegal
  have huy : G.Adj y u := hu.resolve_left (fun h => huw.1 (h ▸ hdom))
  have heq := hgate u huy huw
  constructor
  · exact ⟨q,Or.inl rfl,heq ▸ huw⟩
  · rintro ⟨w,hw,hww⟩
    have hold := white_anti G (Finset.subset_insert q X) hww
    have hwy : G.Adj y w := hw.resolve_left (fun h => hold.1 (h ▸ hdom))
    have hwq := hgate w hwy hold
    exact hww.1 ⟨q,Finset.mem_insert_self _ _,Or.inl hwq⟩

theorem survivors_mono {X Y : Finset V} (hXY : X⊆Y) :
    survivors (G := G) x y Y ⊆ survivors x y X := by
  classical
  intro i hi
  exact Finset.mem_filter.mpr ⟨(Finset.mem_filter.mp hi).1,
    undominated_anti G hXY (Finset.mem_filter.mp hi).2⟩

include hT hc in
theorem survivors_first : survivors (G := G) x y {x}=allIndices x y := by
  classical
  ext i
  simp only [survivors,Finset.mem_filter]
  constructor
  · exact And.left
  · intro hi
    refine ⟨hi,?_⟩
    rintro ⟨v,hv,hclose⟩
    have hvx : v=x := by simpa using hv
    subst v
    have hh := ((system x y hT hc).closed_center_iff i x).mp hclose
    have hout := root_outside x y hT hc x (Or.inl rfl) i
    exact hh.elim hout.1 hout.2

theorem one_opposite_parent (hd : G.diam=7)
    (hb : ((allIndices x y).image (parent x y hT hc)).card=2) :
    ∃ j : Index (G := G) x y, ∀ i : Index (G := G) x y,
      G.Adj (parent x y hT hc i) y → parent x y hT hc i=parent x y hT hc j := by
  classical
  obtain ⟨⟨l,hl⟩,⟨r,hr⟩⟩ := parent_side_witnesses x y hT hc hd
  let P := (allIndices x y).image (parent x y hT hc)
  have hlmem : parent x y hT hc l∈P := Finset.mem_image.mpr ⟨l,by simp [allIndices],rfl⟩
  have hrmem : parent x y hT hc r∈P := Finset.mem_image.mpr ⟨r,by simp [allIndices],rfl⟩
  have hne : parent x y hT hc l≠parent x y hT hc r := by
    intro heq
    exact parent_not_both_roots x y hT hc l ⟨hl,heq ▸ hr⟩
  have hsub : ({parent x y hT hc l,parent x y hT hc r} : Finset V) ⊆ P := by
    simp only [Finset.insert_subset_iff,Finset.singleton_subset_iff]
    exact ⟨hlmem,hrmem⟩
  have hP : P={parent x y hT hc l,parent x y hT hc r} :=
    (Finset.eq_of_subset_of_card_le hsub (by simpa [P,hne] using hb.le)).symm
  refine ⟨r,fun i hi => ?_⟩
  have himem : parent x y hT hc i∈P := Finset.mem_image.mpr ⟨i,by simp [allIndices],rfl⟩
  rw [hP] at himem
  simp only [Finset.mem_insert,Finset.mem_singleton] at himem
  rcases himem with hi' | hi'
  · exact False.elim (parent_not_both_roots x y hT hc l ⟨hl,hi' ▸ hi⟩)
  · exact hi'

theorem parent_selected_bounds {X : Finset V} (j : Index (G := G) x y)
    (hj : parent x y hT hc j∈X) :
    ((system x y hT hc).groups (survivors x y X)).card ≤
      ((allIndices x y).image (parent x y hT hc)).card-1 ∧
    (survivors (G := G) x y X).card ≤ (allIndices (G := G) x y).card-1 := by
  classical
  let A := system x y hT hc
  let R := allIndices (G := G) x y
  have hsub : survivors x y X ⊆ R.erase j := by
    intro i hi
    have hmem := Finset.mem_filter.mp hi
    refine Finset.mem_erase.mpr ⟨?_,hmem.1⟩
    intro hij
    subst i
    exact hmem.2 ⟨A.parent j,hj,(A.closed_center_iff j _).mpr (Or.inr rfl)⟩
  have hgsub : A.groups (survivors x y X) ⊆ (A.groups R).erase (A.parent j) := by
    intro u hu
    obtain ⟨i,hi,hiu⟩ := Finset.mem_image.mp hu
    refine Finset.mem_erase.mpr ⟨?_,Finset.mem_image.mpr ⟨i,(survivors_subset x y X) hi,hiu⟩⟩
    intro huj
    have hic := (Finset.mem_filter.mp hi).2
    exact hic ⟨A.parent j,hj,(A.closed_center_iff i _).mpr (Or.inr (hiu.trans huj).symm)⟩
  have hjR : j∈R := by simp [R,allIndices]
  have hjg : A.parent j∈A.groups R := Finset.mem_image.mpr ⟨j,hjR,rfl⟩
  have hgc := Finset.card_le_card hgsub
  have hkc := Finset.card_le_card hsub
  rw [Finset.card_erase_of_mem hjg] at hgc
  rw [Finset.card_erase_of_mem hjR] at hkc
  exact ⟨hgc,hkc⟩

set_option maxHeartbeats 2000000 in
/-- The paper's two-group shortcut, including a gate whose sole deep
star has already gone. For two stars this gives four moves; in general five. -/
theorem two_groups_oriented_bound (hd : G.diam=7)
    (hb : ((allIndices x y).image (parent x y hT hc)).card=2)
    (hsh : ¬ ShallowOn x y hT hc y) :
    isolationNumber G ≤ 3+min 2 ((allIndices (G := G) x y).card-1) := by
  classical
  let A := system x y hT hc
  let R := allIndices (G := G) x y
  let s := min 2 (R.card-1)
  change (A.groups R).card=2 at hb
  have hbk : 2 ≤ R.card := by
    have hh : (A.groups R).card ≤ R.card := Finset.card_image_le
    omega
  obtain ⟨j,hj⟩ := one_opposite_parent x y hT hc hd hb
  let q := A.parent j
  have hgate {X : Finset V} (hx : x∈X) :
      ∀ u, G.Adj y u → White G X u → u=q := by
    intro u hyu hu
    obtain ⟨i,hi⟩ := white_gate_parent x y hT hc hsh hx hyu hu
    exact hi.symm.trans (hj i (hi ▸ hyu.symm))
  have hxlegal : Legal G ∅ x := by
    refine ⟨x,Or.inl rfl,?_,y,hc.1,?_⟩ <;> simp [Undominated,Dominated]
  have hw : WinsWithin G (s+3) .dominator ∅ := by
    refine Or.inr ⟨x,hxlegal,Or.inr ?_⟩
    intro v hv
    let X : Finset V := {v,x}
    have hxX : x∈X := by simp [X]
    have hxno : ¬ Legal G X x := selected_not_legal G hxX
    by_cases hy : Legal G X y
    · have hyd : Dominated G X y := ⟨x,hxX,Or.inr hc.1⟩
      obtain ⟨hql,hyno⟩ := unique_gate_reply y hyd hy (hgate hxX)
      refine Or.inr ⟨q,hql,?_⟩
      have hrep := represents_survivors x y hT hc
        (selected_not_legal G (Finset.mem_insert_of_mem hxX)) hyno
      apply (A.strategy_equivalence hrep _ _).mpr
      have hbnd := parent_selected_bounds x y hT hc j (Finset.mem_insert_self q X)
      have hbg : (A.groups (survivors x y (insert q X))).card ≤ (A.groups R).card-1 := hbnd.1
      have hgb : (A.groups (survivors x y (insert q X))).card ≤ 1 := by omega
      have hsbound := A.staller_survival hgb hbnd.2
      have heq : sBound 1 (R.card-1)=s := by
        dsimp [s]
        unfold sBound
        split <;> omega
      rw [heq] at hsbound
      exact hsbound
    · have hrep := represents_survivors x y hT hc hxno hy
      have hsub := survivors_subset (G := G) x y X
      have hkQ : (survivors (G := G) x y X).card ≤ R.card := Finset.card_le_card hsub
      have hbQ : (A.groups (survivors x y X)).card ≤ (A.groups R).card := Finset.card_le_card (A.groups_mono hsub)
      have hu := (A.value_le_iff hrep _ _).mpr (A.dominator_units (survivors x y X))
      have hg := (A.value_le_iff hrep _ _).mpr (A.dominator_groups (survivors x y X))
      apply (gameValue_le_iff G .dominator X (s+1)).mp
      change (A.groups R).card=2 at hb
      dsimp [s]
      omega
  have hh := (isolationNumber_le_iff G (s+3)).mpr hw
  change isolationNumber G ≤ 3+s
  omega

/-- If every surplus vertex is on the first side, a surviving opposite
gate contains a genuinely surviving deep star; it cannot be short-only. -/
theorem gate_has_live_star
    (he : ∀ z∈extras x y hT hc, LeftSide G x y z)
    {X : Finset V} (hx : x∈X) {q : V} (hyq : G.Adj y q) (hq : White G X q) :
    ∃ i∈survivors x y X, parent x y hT hc i=q := by
  classical
  obtain ⟨hdq,w,hqw,hw,hdw⟩ := white_gate_levels x y hT hc hx hyq hq
  have hqside := adjacent_right_side x y hT hc hyq hdq
  have hqne : q≠y := by intro h; rw [h,depth_y] at hdq; omega
  have hwside := nonroot_neighbor_same_side hT hc.1.symm hqside hqne hqw
  have hwcounted : w∈counted x y hT hc := by
    by_contra h
    have hwe : w∈extras x y hT hc := Finset.mem_sdiff.mpr ⟨Finset.mem_univ _,h⟩
    exact (sides_partition hT hc.1 w).2 ⟨he w hwe,hwside⟩
  obtain ⟨i,hi⟩ := counted_depth_two x y hT hc hwcounted hdw
  refine ⟨i,Finset.mem_filter.mpr ⟨by simp [allIndices],hi ▸ hw⟩,?_⟩
  have hpi := parent_spec x y hT hc i
  exact unique_lower x y hT hc (u := i.val) (by have := i.property.1; omega) hpi.1
    (by rw [hi]; exact hqw.symm)
    (by have := i.property.1; omega) (by have := i.property.1; omega)

set_option maxHeartbeats 2000000 in
/-- The sharper two-group/three-star strategy with all extras on the
chosen first side. It handles the other eleven-vertex parameter family. -/
theorem two_groups_three_stars_oriented (hd : G.diam=7)
    (hb : ((allIndices x y).image (parent x y hT hc)).card=2)
    (hk : (allIndices (G := G) x y).card=3)
    (he : ∀ z∈extras x y hT hc, LeftSide G x y z) : isolationNumber G ≤ 4 := by
  classical
  let A := system x y hT hc
  let R := allIndices (G := G) x y
  change (A.groups R).card=2 at hb
  change R.card=3 at hk
  have hsh := no_shallow_of_extras_left x y hT hc he
  obtain ⟨j,hj⟩ := one_opposite_parent x y hT hc hd hb
  let q := A.parent j
  have hxlegal : Legal G ∅ x := by
    refine ⟨x,Or.inl rfl,?_,y,hc.1,?_⟩ <;> simp [Undominated,Dominated]
  apply (isolationNumber_le_iff G 4).mpr
  refine Or.inr ⟨x,hxlegal,Or.inr ?_⟩
  intro v hv
  have hresponse : v=y ∨ ∃ i∈R, Closed G v (A.center i) := by
    by_cases hvy : v=y
    · exact Or.inl hvy
    · right
      by_contra hhit
      have hhit' : ¬ ∃ i : Index (G := G) x y, Closed G v i.val := by
        rintro ⟨i,hi⟩
        exact hhit ⟨i,by simp [R,allIndices],hi⟩
      have hvx : v≠x := by intro h; subst v; exact selected_not_legal G (by simp) hv
      have hve := no_star_hit_mem_extras x y hT hc hvx hvy hhit'
      exact hhit' (legal_left_hits_star x y hT hc hv (he v hve))
  rcases hresponse with hvs | hhit
  · subst v
    have hrep : A.Represents R {y,x} := by
      have h := both_roots_represents x y hT hc
      simpa only [Finset.pair_comm] using h
    exact (A.strategy_equivalence hrep 2 .dominator).mpr
      (by have h := A.dominator_saved R (by omega); simpa [hk] using h)
  · let X : Finset V := {v,x}
    have hxX : x∈X := by simp [X]
    have hQ : survivors x y X = A.remainingAfter R v := by
      rw [show X=insert v {x} from rfl,survivors_after x y hT hc,survivors_first x y hT hc]
    have hQcard : (survivors (G := G) x y X).card ≤ 2 := by
      rw [hQ]
      have hdrop := A.hit_card_drop hhit
      omega
    by_cases hy : Legal G X y
    · have hyd : Dominated G X y := ⟨x,hxX,Or.inr hc.1⟩
      have hgate : ∀ u, G.Adj y u → White G X u → u=q := by
        intro u hyu hu
        obtain ⟨i,hi⟩ := white_gate_parent x y hT hc hsh hxX hyu hu
        exact hi.symm.trans (hj i (hi ▸ hyu.symm))
      obtain ⟨hql,hyno⟩ := unique_gate_reply y hyd hy hgate
      refine Or.inr ⟨q,hql,?_⟩
      obtain ⟨u,hu,huw⟩ := hy
      have huy := hu.resolve_left (fun hh => huw.1 (hh ▸ hyd))
      obtain ⟨i,hi,hip⟩ := gate_has_live_star x y hT hc he hxX huy huw
      have hiq : A.parent i=q := hip.trans (hgate u huy huw)
      have hdrop := A.hit_card_drop (R := survivors x y X)
        ⟨i,hi,(A.closed_center_iff i q).mpr (Or.inr hiq.symm)⟩
      have hrep := represents_survivors x y hT hc
        (selected_not_legal G (Finset.mem_insert_of_mem hxX)) hyno
      apply (A.strategy_equivalence hrep 1 .staller).mpr
      have hcard : (survivors (G := G) x y (insert q X)).card ≤ 1 := by
        rw [survivors_after x y hT hc]
        change (A.remainingAfter (survivors x y X) q).card ≤ 1
        omega
      exact A.wins_of_controlled_bound _ _ _ (fun _ ht => (ht.units_bound A).trans hcard)
    · have hrep := represents_survivors x y hT hc (selected_not_legal G hxX) hy
      apply (A.strategy_equivalence hrep 2 .dominator).mpr
      exact A.wins_of_controlled_bound _ _ _ (fun _ ht => (ht.units_bound A).trans hQcard)

end IsolationGame.DiameterSeven.DoubleRooted
