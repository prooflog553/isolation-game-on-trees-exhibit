import IsolationGame.TreeCenter

namespace IsolationGame.DiameterSeven

open SimpleGraph

variable {V : Type*} {G : SimpleGraph V}

/-- The radius-three cover by an adjacent pair, before choosing an orientation. -/
def CenterEdge (G : SimpleGraph V) (x y : V) : Prop :=
  G.Adj x y ∧ ∀ u, G.dist x u ≤ 3 ∨ G.dist y u ≤ 3

/-- The two centers are adjacent midpoints of a longest path of length seven.
The proof reuses the base project's unique-path lemmas. -/
theorem exists_centerEdge [Fintype V] (hT : G.IsTree) (hd : G.diam = 7) :
    ∃ x y, CenterEdge G x y := by
  classical
  letI : Nonempty V := hT.isConnected.nonempty
  have hfinite : G.ediam ≠ ⊤ := connected_iff_ediam_ne_top.mp hT.isConnected
  obtain ⟨a, b, hab⟩ := G.exists_dist_eq_diam
  obtain ⟨p, hp, hplen⟩ := hT.isConnected.exists_path_of_dist a b
  have hp7 : p.length = 7 := hplen.trans (hab.trans hd)
  let x := p.getVert 3
  have hxmem : x ∈ p.support := p.getVert_mem_support 3
  let pre := p.takeUntil x hxmem
  let post := p.dropUntil x hxmem
  let left := pre.reverse
  have hpre : pre.IsPath := hp.takeUntil hxmem
  have hpost : post.IsPath := hp.dropUntil hxmem
  have hleft : left.IsPath := hpre.reverse
  have hprelen : pre.length = 3 := prefix_length_at_index p hp 3 (by omega)
  have hleftlen : left.length = 3 := by simpa [left] using hprelen
  have hsplit : pre.length + post.length = p.length := by
    have h := congrArg Walk.length (p.take_spec hxmem)
    simpa only [Walk.length_append] using h
  have hpostlen : post.length = 4 := by omega
  have hpostnil : ¬ post.Nil := by rw [Walk.not_nil_iff_lt_length]; omega
  have hwhole : (left.reverse.append post).IsPath := by
    simpa only [left, pre, post, Walk.reverse_reverse, Walk.take_spec] using hp
  have hfirst := first_distinct_of_reverse_append left post (by omega) hwhole
  refine ⟨x, post.snd, post.adj_snd hpostnil, ?_⟩
  intro u
  obtain ⟨q, hq, hqlen⟩ := hT.isConnected.exists_path_of_dist x u
  by_cases hqsmall : q.length ≤ 3
  · exact Or.inl (by omega)
  · have hqlong : ¬ q.Nil := by rw [Walk.not_nil_iff_lt_length]; omega
    by_cases hy : q.snd = post.snd
    · have hneq : q.snd ≠ left.snd := fun h => hfirst (h.symm.trans hy)
      have hpq := reverse_append_path_of_distinct_first hT q left hq hleft hneq
      have hdist := tree_path_length_eq_dist hT (q.reverse.append left) hpq
      have hbound : G.dist u a ≤ G.diam := G.dist_le_diam hfinite
      simp only [Walk.length_append, Walk.length_reverse] at hdist
      have htail := q.length_tail_add_one hqlong
      have htaildist := tree_path_length_eq_dist hT q.tail hq.tail
      have hyDist : G.dist q.snd u = G.dist post.snd u :=
        congrArg (fun z => G.dist z u) hy
      exact Or.inr (by omega)
    · have hpq := reverse_append_path_of_distinct_first hT q post hq hpost hy
      have hdist := tree_path_length_eq_dist hT (q.reverse.append post) hpq
      have hbound : G.dist u b ≤ G.diam := G.dist_le_diam hfinite
      simp only [Walk.length_append, Walk.length_reverse] at hdist
      exact False.elim (by omega)

/-- Assign each vertex to the closer endpoint of the edge. In a tree the
two distances differ by exactly one, so there are no ties. -/
def LeftSide (G : SimpleGraph V) (x y u : V) : Prop := G.dist u x < G.dist u y

theorem endpoint_distance_step (hT : G.IsTree) {x y : V} (hxy : G.Adj x y) (u : V) :
    G.dist u x + 1 = G.dist u y ∨ G.dist u y + 1 = G.dist u x := by
  have h := tree_adj_levels hT u hxy
  simp only [G.dist_comm (u := x) (v := u), G.dist_comm (u := y) (v := u)] at h
  omega

theorem sides_partition (hT : G.IsTree) {x y : V} (hxy : G.Adj x y) (u : V) :
    (LeftSide G x y u ∨ LeftSide G y x u) ∧
      ¬ (LeftSide G x y u ∧ LeftSide G y x u) := by
  have := endpoint_distance_step hT hxy u
  unfold LeftSide
  omega

theorem left_depth_le_three (hT : G.IsTree) {x y u : V}
    (hxy : CenterEdge G x y) (hu : LeftSide G x y u) : G.dist u x ≤ 3 := by
  have h := hxy.2 u
  simp only [G.dist_comm (u := x) (v := u), G.dist_comm (u := y) (v := u)] at h
  unfold LeftSide at hu
  omega

theorem centerEdge_symm {x y : V} (hxy : CenterEdge G x y) : CenterEdge G y x :=
  ⟨hxy.1.symm, fun u => (hxy.2 u).symm⟩

theorem right_depth_le_three (hT : G.IsTree) {x y u : V}
    (hxy : CenterEdge G x y) (hu : LeftSide G y x u) : G.dist u y ≤ 3 :=
  left_depth_le_three hT (centerEdge_symm hxy) hu

/-- The center edge is the only edge joining the two sides. This is the
structural fact required before claiming a lack of cross-side blue moves. -/
theorem only_cross_edge (hT : G.IsTree) {x y u v : V} (hxy : G.Adj x y)
    (hu : LeftSide G x y u) (hv : LeftSide G y x v) (huv : G.Adj u v) :
    u=x ∧ v=y := by
  have huStep := endpoint_distance_step hT hxy u
  have hvStep := endpoint_distance_step hT hxy v
  have hadjx := tree_adj_levels hT x huv
  have hadjy := tree_adj_levels hT y huv
  have hd : G.dist u x = G.dist v y := by unfold LeftSide at *; omega
  have hux : u=x := by
    by_contra hne
    obtain ⟨w, hw, _⟩ := exists_unique_parent hT x hne
    have hwStep := endpoint_distance_step hT hxy w
    have hadjwy := tree_adj_levels hT y hw.1
    have hwlow : G.dist w y + 1 = G.dist u y := by unfold LeftSide at *; omega
    have hvlow : G.dist v y + 1 = G.dist u y := by unfold LeftSide at *; omega
    have heq := unique_lower_neighbor hT y hw.1 huv hwlow hvlow
    rw [heq] at hw
    unfold LeftSide at *
    omega
  refine ⟨hux, ?_⟩
  rw [hux, G.dist_self] at hd
  exact (hT.isConnected.dist_eq_zero_iff (u := v) (v := y)).mp hd.symm

theorem nonroot_neighbor_same_side (hT : G.IsTree) {x y u v : V}
    (hxy : G.Adj x y) (hu : LeftSide G x y u) (hne : u ≠ x) (huv : G.Adj u v) :
    LeftSide G x y v := by
  rcases (sides_partition hT hxy v).1 with hv | hv
  · exact hv
  · exact False.elim (hne (only_cross_edge hT hxy hu hv huv).1)

/-- Every depth-three vertex is a leaf in the whole tree, not merely in
its induced side. In particular there is no omitted blue boundary there. -/
theorem depth_three_leaf (hT : G.IsTree) {x y u v w : V}
    (hxy : CenterEdge G x y) (hu : LeftSide G x y u) (hd : G.dist u x=3)
    (huv : G.Adj u v) (huw : G.Adj u w) : v=w := by
  have hne : u ≠ x := by intro h; rw [h, G.dist_self] at hd; omega
  have hv := nonroot_neighbor_same_side hT hxy.1 hu hne huv
  have hw := nonroot_neighbor_same_side hT hxy.1 hu hne huw
  have hvb := left_depth_le_three hT hxy hv
  have hwb := left_depth_le_three hT hxy hw
  have hvl := tree_adj_levels hT x huv
  have hwl := tree_adj_levels hT x huw
  exact unique_lower_neighbor hT x huv huw (by omega) (by omega)

theorem left_depth_three_exists [Fintype V] (hT : G.IsTree) (hd : G.diam=7)
    {x y : V} (hc : CenterEdge G x y) :
    ∃ u, LeftSide G x y u ∧ G.dist u x=3 := by
  classical
  by_contra hn
  have hyRadius (u : V) : G.dist u y ≤ 3 := by
    rcases (sides_partition hT hc.1 u).1 with hu | hu
    · have hdu := left_depth_le_three hT hc hu
      have hne : G.dist u x ≠ 3 := fun h => hn ⟨u,hu,h⟩
      have hstep := endpoint_distance_step hT hc.1 u
      unfold LeftSide at hu
      omega
    · exact right_depth_le_three hT hc hu
  letI : Nonempty V := hT.isConnected.nonempty
  obtain ⟨a,b,hab⟩ := G.exists_dist_eq_diam
  have ha := hyRadius a
  have hb := hyRadius b
  have ht := hT.isConnected.dist_triangle (u := a) (v := y) (w := b)
  rw [G.dist_comm (u := y) (v := b)] at ht
  omega

theorem right_depth_three_exists [Fintype V] (hT : G.IsTree) (hd : G.diam=7)
    {x y : V} (hc : CenterEdge G x y) :
    ∃ u, LeftSide G y x u ∧ G.dist u y=3 :=
  left_depth_three_exists hT hd (centerEdge_symm hc)

end IsolationGame.DiameterSeven
