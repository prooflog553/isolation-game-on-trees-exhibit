import IsolationGame.GroupGame
import IsolationGame.DiameterSeven.Arithmetic

namespace IsolationGame.StarSystem

open DiameterSeven

variable {V I : Type*} [DecidableEq V] [DecidableEq I]
variable {G : SimpleGraph V} (A : StarSystem G I)

theorem staller_sBound (R : Finset I) :
    A.WinsWithin (sBound (A.groups R).card R.card) .staller R := by
  have hbk : (A.groups R).card ≤ R.card := Finset.card_image_le
  have hzero := A.groups_zero_iff R
  by_cases hsmall : R.card ≤ 2
  · have heq : sBound (A.groups R).card R.card = R.card := by
      unfold sBound
      split <;> omega
    rw [heq]
    exact A.wins_of_controlled_bound _ _ _ (fun _ ht => ht.units_bound A)
  · apply A.wins_of_first_bound
    · unfold sBound
      split <;> omega
    · intro t ht
      have htk := (ht.toControlled A).units_bound A
      have htb := ((ht.toControlled A).pile_bound A).1
      have hs := ht.saved_move A
      unfold sBound
      split <;> omega

theorem staller_survival {R : Finset I} {b k : Nat}
    (hgroups : (A.groups R).card ≤ b) (hstars : R.card ≤ k) :
    A.WinsWithin (sBound b k) .staller R := by
  have hbk : (A.groups R).card ≤ R.card := Finset.card_image_le
  have hzero := A.groups_zero_iff R
  by_cases hm : 2 ≤ sBound b k
  · apply A.wins_of_first_bound _ hm
    intro t ht
    have htk := (ht.toControlled A).units_bound A
    have htb := ((ht.toControlled A).pile_bound A).1
    have hs := ht.saved_move A
    unfold sBound
    split <;> omega
  · apply A.wins_of_controlled_bound
    intro t ht
    have htk := ht.units_bound A
    have htb := (ht.pile_bound A).1
    unfold sBound at *
    split at hm <;> split <;> omega

theorem dominator_units (R : Finset I) : A.WinsWithin R.card .dominator R :=
  A.wins_of_controlled_bound _ _ _ (fun _ ht => ht.units_bound A)

theorem dominator_groups (R : Finset I) :
    A.WinsWithin (2*(A.groups R).card-1) .dominator R := by
  apply A.wins_of_controlled_bound
  intro t ht
  by_cases hr : R.Nonempty
  · have := (ht.pile_bound A).2 rfl hr
    omega
  · have := ht.units_bound A
    have : R.card = 0 := by simpa using hr
    omega

/-- The first maximum group supplies a saved move when there are more
stars than groups. This is a strategy statement, not an arithmetic axiom. -/
theorem dominator_saved (R : Finset I) (hmore : (A.groups R).card < R.card) :
    A.WinsWithin (R.card-1) .dominator R := by
  classical
  have hnonempty : R.Nonempty := Finset.card_pos.mp (by omega)
  obtain ⟨i, hi, hmax⟩ := R.exists_max_image (A.size R) hnonempty
  have htwo := A.maximum_size_ge_two hi hmax hmore
  have hsize := A.whole_size R i
  have hcard : 2 ≤ R.card := by omega
  have heq : R.card-1 = (R.card-2)+1 := by omega
  rw [heq]
  apply Or.inr
  refine ⟨A.whole R i, ⟨i, hi, Or.inr rfl⟩, ?_⟩
  apply A.wins_of_controlled_bound
  intro t ht
  have := ht.units_bound A
  omega

theorem represented_staller_bound [Fintype V] {R : Finset I} {X : Finset V}
    (hR : A.Represents R X) :
    gameValue G .staller X ≤ sBound (A.groups R).card R.card :=
  (A.value_le_iff hR _ _).mpr (A.staller_sBound R)

/-- Covers the G branch after the two center endpoints have been played. -/
theorem represented_g_bound [Fintype V] {R : Finset I} {X : Finset V}
    (hR : A.Represents R X) :
    2 + gameValue G .dominator X ≤ gBound (A.groups R).card R.card := by
  have hbk : (A.groups R).card ≤ R.card := Finset.card_image_le
  have hu := (A.value_le_iff hR _ _).mpr (A.dominator_units R)
  have hb := (A.value_le_iff hR _ _).mpr (A.dominator_groups R)
  unfold gBound
  split
  · omega
  · have hs := (A.value_le_iff hR _ _).mpr (A.dominator_saved R (by omega))
    have hz := A.groups_zero_iff R
    omega

end IsolationGame.StarSystem
