import IsolationGame.Basic
import Mathlib.Data.Fintype.Card
import Mathlib.Data.Nat.Find

namespace IsolationGame

inductive Player | dominator | staller
  deriving DecidableEq

def Player.other : Player → Player
  | .dominator => .staller
  | .staller => .dominator

variable {V : Type*} [DecidableEq V] (G : SimpleGraph V)

/-- Finite-horizon strategy semantics. Dominator chooses a legal move;
    at a Staller turn every legal response must meet the bound. -/
def WinsWithin : Nat → Player → Finset V → Prop
  | 0, _, X => Terminal G X
  | m + 1, .dominator, X => Terminal G X ∨
      ∃ v, Legal G X v ∧ WinsWithin m .staller (insert v X)
  | m + 1, .staller, X => Terminal G X ∨
      ∀ v, Legal G X v → WinsWithin m .dominator (insert v X)

theorem terminal_wins {X : Finset V} (h : Terminal G X) (m : Nat) (p : Player) :
    WinsWithin G m p X := by
  cases m with
  | zero => exact h
  | succ m => cases p <;> exact Or.inl h

theorem wins_succ {m : Nat} {p : Player} {X : Finset V}
    (h : WinsWithin G m p X) : WinsWithin G (m + 1) p X := by
  induction m generalizing p X with
  | zero => exact terminal_wins G h _ _
  | succ m ih =>
    cases p with
    | dominator =>
      rcases h with h | ⟨v, hv, hw⟩
      · exact Or.inl h
      · exact Or.inr ⟨v, hv, ih hw⟩
    | staller =>
      rcases h with h | h
      · exact Or.inl h
      · exact Or.inr (fun v hv => ih (h v hv))

theorem wins_mono {m n : Nat} (hmn : m ≤ n) {p : Player} {X : Finset V}
    (h : WinsWithin G m p X) : WinsWithin G n p X := by
  induction hmn with
  | refl => exact h
  | step _ ih => exact wins_succ G ih

variable [Fintype V]

/-- No legal play can exceed the number of unselected vertices. This
    proves totality of the game value, independently of the tree bound. -/
theorem wins_of_remaining_le (m : Nat) (p : Player) (X : Finset V)
    (hm : Fintype.card V - X.card ≤ m) : WinsWithin G m p X := by
  induction m generalizing p X with
  | zero =>
    have heq : X.card = Fintype.card V := by
      have := X.card_le_univ
      omega
    have hX := X.eq_univ_of_card heq
    apply terminal_wins G (m := 0)
    intro u hu
    exact hu.1 ⟨u, by simp [hX], Or.inl rfl⟩
  | succ m ih =>
    classical
    by_cases ht : Terminal G X
    · exact terminal_wins G ht _ _
    · have hnext (v : V) (hv : Legal G X v) :
          WinsWithin G m p.other (insert v X) := by
        apply ih
        have hc := Finset.card_insert_of_not_mem (legal_not_selected G hv)
        have hc' := (insert v X).card_le_univ
        omega
      cases p with
      | dominator =>
        obtain ⟨v, hv⟩ := exists_legal_of_not_terminal G ht
        exact Or.inr ⟨v, hv, hnext v hv⟩
      | staller => exact Or.inr hnext

theorem exists_wins (p : Player) (X : Finset V) :
    ∃ m, WinsWithin G m p X :=
  ⟨Fintype.card V - X.card, wins_of_remaining_le G _ _ _ (Nat.le_refl _)⟩

/-- The least worst-case move bound. Since `WinsWithin` uses existential
    Dominator choices and universal Staller responses, this is the finite
    perfect-information minimax value in numbers of remaining moves. -/
noncomputable def gameValue (p : Player) (X : Finset V) : Nat := by
  classical
  exact Nat.find (exists_wins G p X)

theorem gameValue_le_iff (p : Player) (X : Finset V) (m : Nat) :
    gameValue G p X ≤ m ↔ WinsWithin G m p X := by
  classical
  constructor
  · intro h
    exact wins_mono G h (Nat.find_spec (exists_wins G p X))
  · intro h
    exact Nat.find_min' (exists_wins G p X) h

/-- The actual Dominator-start isolation game number. -/
noncomputable def isolationNumber : Nat := gameValue G .dominator ∅

theorem isolationNumber_le_iff (m : Nat) :
    isolationNumber G ≤ m ↔ WinsWithin G m .dominator ∅ :=
  gameValue_le_iff G .dominator ∅ m

theorem dominator_value_step (X : Finset V) (m : Nat) :
    gameValue G .dominator X ≤ m + 1 ↔ Terminal G X ∨
      ∃ v, Legal G X v ∧ gameValue G .staller (insert v X) ≤ m := by
  simp only [gameValue_le_iff, WinsWithin]

theorem staller_value_step (X : Finset V) (m : Nat) :
    gameValue G .staller X ≤ m + 1 ↔ Terminal G X ∨
      ∀ v, Legal G X v → gameValue G .dominator (insert v X) ≤ m := by
  simp only [gameValue_le_iff, WinsWithin]

end IsolationGame
