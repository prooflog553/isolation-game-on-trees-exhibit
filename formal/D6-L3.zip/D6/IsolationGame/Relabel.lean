import IsolationGame.Game

namespace IsolationGame

variable {V W : Type*} [DecidableEq V] [DecidableEq W]
variable (G : SimpleGraph V) (H : SimpleGraph W) (e : V ≃ W)
variable (he : ∀ u v, H.Adj (e u) (e v) ↔ G.Adj u v)
include he

theorem closed_relabel (v u : V) : Closed H (e v) (e u) ↔ Closed G v u := by
  simp only [Closed, e.injective.eq_iff, he]

theorem undominated_relabel (X : Finset V) (u : V) :
    Undominated H (X.image e) (e u) ↔ Undominated G X u := by
  apply not_congr
  constructor
  · rintro ⟨v, hv, hclose⟩
    obtain ⟨w, hw, rfl⟩ := Finset.mem_image.mp hv
    exact ⟨w, hw, (closed_relabel G H e he w u).mp hclose⟩
  · rintro ⟨v, hv, hclose⟩
    exact ⟨e v, Finset.mem_image.mpr ⟨v, hv, rfl⟩,
      (closed_relabel G H e he v u).mpr hclose⟩

theorem white_relabel (X : Finset V) (u : V) :
    White H (X.image e) (e u) ↔ White G X u := by
  constructor
  · rintro ⟨hu, w, huw, hw⟩
    obtain ⟨v, rfl⟩ := e.surjective w
    exact ⟨(undominated_relabel G H e he X u).mp hu, v,
      (he u v).mp huw, (undominated_relabel G H e he X v).mp hw⟩
  · rintro ⟨hu, v, huv, hv⟩
    exact ⟨(undominated_relabel G H e he X u).mpr hu, e v,
      (he u v).mpr huv, (undominated_relabel G H e he X v).mpr hv⟩

theorem legal_relabel (X : Finset V) (v : V) :
    Legal H (X.image e) (e v) ↔ Legal G X v := by
  constructor
  · rintro ⟨w, hvw, hw⟩
    obtain ⟨u, rfl⟩ := e.surjective w
    exact ⟨u, (closed_relabel G H e he v u).mp hvw, (white_relabel G H e he X u).mp hw⟩
  · rintro ⟨u, hvu, hu⟩
    exact ⟨e u, (closed_relabel G H e he v u).mpr hvu, (white_relabel G H e he X u).mpr hu⟩

theorem terminal_relabel (X : Finset V) (h : Terminal G X) : Terminal H (X.image e) := by
  intro w hw
  obtain ⟨u, rfl⟩ := e.surjective w
  exact h u ((white_relabel G H e he X u).mp hw)

theorem wins_relabel {m p X} (h : WinsWithin G m p X) :
    WinsWithin H m p (X.image e) := by
  induction m generalizing p X with
  | zero => exact terminal_relabel G H e he X h
  | succ m ih =>
    cases p with
    | dominator =>
      rcases h with ht | ⟨v, hv, hw⟩
      · exact Or.inl (terminal_relabel G H e he X ht)
      · exact Or.inr ⟨e v, (legal_relabel G H e he X v).mpr hv,
          by simpa using ih hw⟩
    | staller =>
      rcases h with ht | hw
      · exact Or.inl (terminal_relabel G H e he X ht)
      · apply Or.inr
        intro w hw'
        obtain ⟨v, rfl⟩ := e.surjective w
        have hv := (legal_relabel G H e he X v).mp hw'
        simpa using ih (hw v hv)

theorem isolation_bound_relabel [Fintype V] [Fintype W] {m : Nat}
    (h : isolationNumber G ≤ m) : isolationNumber H ≤ m := by
  apply (isolationNumber_le_iff H m).mpr
  simpa using wins_relabel G H e he ((isolationNumber_le_iff G m).mp h)

end IsolationGame
