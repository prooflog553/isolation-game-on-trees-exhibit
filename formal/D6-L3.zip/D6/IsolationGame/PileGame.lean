import Lean.Elab.Tactic.Omega

namespace IsolationGame.Pile

/-- Piles keep their positions in the list. Zero means an exhausted pile. -/
abbrev State := List Nat

def units : State → Nat
  | [] => 0
  | a :: s => a + units s

def occupied : State → Nat
  | [] => 0
  | a :: s => (if a = 0 then 0 else 1) + occupied s

def largest : State → Nat
  | [] => 0
  | a :: s => max a (largest s)

/-- Either player may remove one unit or a whole nonempty pile. -/
inductive Move : State → State → Prop
  | one (a : Nat) (s : State) : Move ((a + 1) :: s) (a :: s)
  | all (a : Nat) (s : State) : Move ((a + 1) :: s) (0 :: s)
  | tail (a : Nat) {s q : State} : Move s q → Move (a :: s) (a :: q)

/-- The moves used by Dominator's specified strategy. -/
inductive Whole : State → State → Prop
  | head (a : Nat) (s : State) : Whole ((a + 1) :: s) (0 :: s)
  | tail (a : Nat) {s q : State} : Whole s q → Whole (a :: s) (a :: q)

theorem Whole.toMove {s q : State} (h : Whole s q) : Move s q := by
  induction h with
  | head a s => exact .all a s
  | tail a h ih => exact .tail a ih

theorem Move.units_lt {s q : State} (h : Move s q) : units q < units s := by
  induction h with
  | one a s => simp only [units]; omega
  | all a s => simp only [units]; omega
  | tail a h ih => simp only [units]; omega

theorem Move.occupied_le {s q : State} (h : Move s q) : occupied q ≤ occupied s := by
  induction h with
  | one a s => simp only [occupied]; split <;> split <;> omega
  | all a s => simp [occupied]
  | tail a h ih => simp only [occupied]; omega

theorem Whole.occupied_drop {s q : State} (h : Whole s q) :
    occupied q + 1 = occupied s := by
  induction h with
  | head a s => simp [occupied, Nat.add_comm]
  | tail a h ih => simp only [occupied]; omega

theorem occupied_le_units (s : State) : occupied s ≤ units s := by
  induction s with
  | nil => simp [occupied, units]
  | cons a s ih => simp only [occupied, units]; split <;> omega

theorem units_zero_iff (s : State) : units s = 0 ↔ occupied s = 0 := by
  induction s with
  | nil => simp [occupied, units]
  | cons a s ih => simp only [occupied, units]; split <;> omega

theorem largest_le_one (s : State) (h : largest s ≤ 1) : units s ≤ occupied s := by
  induction s with
  | nil => simp [units, occupied]
  | cons a s ih =>
    simp only [largest, Nat.max_le] at h
    have hs := ih h.2
    simp only [units, occupied]
    split <;> omega

/-- The first Dominator move removes a largest current pile. -/
def MaximumWhole (s q : State) : Prop :=
  Whole s q ∧ units q + largest s = units s

theorem largest_zero_iff (s : State) : largest s = 0 ↔ units s = 0 := by
  induction s with
  | nil => simp [largest, units]
  | cons a s ih => simp only [largest, units]; omega

theorem exists_maximumWhole {s : State} (hs : 0 < units s) :
    ∃ q, MaximumWhole s q := by
  induction s with
  | nil => simp [units] at hs
  | cons a s ih =>
    by_cases ha : largest s ≤ a
    · have ha0 : 0 < a := by
        apply Nat.pos_of_ne_zero
        intro hz
        have hl : largest s = 0 := by omega
        have hu := (largest_zero_iff s).mp hl
        simp only [units] at hs
        omega
      obtain ⟨a', rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : a ≠ 0)
      refine ⟨0 :: s, .head a' s, ?_⟩
      simp only [units, largest, Nat.max_eq_left ha]
      omega
    · have hu : 0 < units s := by
        apply Nat.pos_of_ne_zero
        intro hz
        have hl := (largest_zero_iff s).mpr hz
        omega
      obtain ⟨q, hq, heq⟩ := ih hu
      refine ⟨a :: q, .tail a hq, ?_⟩
      simp only [units, largest, Nat.max_eq_right (by omega : a ≤ largest s)]
      omega

/-- Complete alternating plays. `true` means Dominator to play. -/
inductive Play : Bool → State → Nat → Prop
  | done (p : Bool) (s : State) : units s = 0 → Play p s 0
  | staller {s q : State} {t : Nat} : Move s q → Play true q t → Play false s (t + 1)
  | dominator {s q : State} {t : Nat} : Whole s q → Play false q t → Play true s (t + 1)

theorem Play.units_bound {p s t} (h : Play p s t) : t ≤ units s := by
  induction h with
  | done p s hs => omega
  | staller hm hp ih => have := hm.units_lt; omega
  | dominator hm hp ih => have := hm.toMove.units_lt; omega

/-- Simultaneous induction gives the stronger odd bound on a nonempty
    Dominator-turn position. -/
theorem Play.pile_bound {p s t} (h : Play p s t) :
    t ≤ 2 * occupied s ∧ (p = true → 0 < units s → t + 1 ≤ 2 * occupied s) := by
  induction h with
  | done p s hs => constructor; omega; intro _ hp; omega
  | @staller s q t hm hp ih =>
    constructor
    · by_cases hq : 0 < units q
      · have hh := ih.2 rfl hq
        have hh' := hm.occupied_le
        omega
      · have hh := hp.units_bound
        have hh' := hm.units_lt
        have hh'' := units_zero_iff s
        omega
    · intro heq
      cases heq
  | dominator hm hp ih =>
    have hh := hm.occupied_drop
    constructor
    · omega
    · intro _ _; omega

/-- Staller starts; the first Dominator move, if present, removes a
    largest current pile. The remainder obeys `Play`. -/
inductive FirstPlay : State → Nat → Prop
  | done (s : State) : units s = 0 → FirstPlay s 0
  | last {s q : State} : Move s q → units q = 0 → FirstPlay s 1
  | pair {s q r : State} {t : Nat} :
      Move s q → MaximumWhole q r → Play false r t → FirstPlay s (t + 2)

theorem FirstPlay.toPlay {s t} (h : FirstPlay s t) : Play false s t := by
  cases h with
  | done hs => exact .done false _ hs
  | last hm hq => exact .staller hm (.done true _ hq)
  | pair hm hmax hp => exact .staller hm (.dominator hmax.1 hp)

theorem FirstPlay.bounds {s t} (h : FirstPlay s t) :
    t ≤ units s ∧ t ≤ 2 * occupied s :=
  ⟨h.toPlay.units_bound, h.toPlay.pile_bound.1⟩

theorem FirstPlay.saved_move {s t} (h : FirstPlay s t)
    (hs : occupied s + 2 ≤ units s) : t ≤ units s - 1 := by
  cases h with
  | done hz => omega
  | last hm hq => omega
  | @pair q r t hm hmax hp =>
    have hlt := hm.units_lt
    have hle := hp.units_bound
    have hwhole := hmax.1.toMove.units_lt
    by_cases htwo : units q + 2 ≤ units s
    · omega
    · have hocc := hm.occupied_le
      have hlarge : 2 ≤ largest q := by
        have hh := largest_le_one q
        omega
      have heq := hmax.2
      omega

end IsolationGame.Pile
