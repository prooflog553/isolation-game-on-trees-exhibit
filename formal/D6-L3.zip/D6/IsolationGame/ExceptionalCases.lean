import IsolationGame.Game
import IsolationGame.Decidable

namespace IsolationGame.Exceptional

/-- The small configurations use the labels from the paper. These
    definitions do not classify arbitrary trees of the same order. -/
def four : SimpleGraph (Fin 4) where
  Adj u v := u.val + 1 = v.val ∨ v.val + 1 = u.val
  symm := by intro u v h; exact h.symm
  loopless := by intro u h; omega

instance : DecidableRel four.Adj := fun _ _ => inferInstanceAs (Decidable (_ ∨ _))

theorem four_first_legal : Legal four ∅ 1 := by decide
theorem four_after_first : Terminal four {1} := by decide

theorem four_one_move : isolationNumber four ≤ 1 := by
  apply (isolationNumber_le_iff four 1).mpr
  exact Or.inr ⟨1, four_first_legal, by simpa [WinsWithin] using four_after_first⟩

def six : SimpleGraph (Fin 6) where
  Adj u v :=
    (u = 1 ∧ (v = 0 ∨ v = 2 ∨ v = 4)) ∨
    (v = 1 ∧ (u = 0 ∨ u = 2 ∨ u = 4)) ∨
    (u = 2 ∧ v = 3) ∨ (v = 2 ∧ u = 3) ∨
    (u = 4 ∧ v = 5) ∨ (v = 4 ∧ u = 5)
  symm := by intro u v h; rcases h with h | h | h | h | h | h <;> tauto
  loopless := by intro u h; rcases h with h | h | h | h | h | h <;> omega

instance : DecidableRel six.Adj := fun _ _ => inferInstanceAs (Decidable (_ ∨ _))

theorem six_first_legal : Legal six ∅ 1 := by decide
theorem six_after_first : Terminal six {1} := by decide

theorem six_one_move : isolationNumber six ≤ 1 := by
  apply (isolationNumber_le_iff six 1).mpr
  exact Or.inr ⟨1, six_first_legal, by simpa [WinsWithin] using six_after_first⟩

/-- Labels: r=0, a=1, q=2, u=3, v=4, w=5, x=6, y=7, z=8. -/
def nine : SimpleGraph (Fin 9) where
  Adj u v :=
    (u = 0 ∧ (v = 1 ∨ v = 2)) ∨ (v = 0 ∧ (u = 1 ∨ u = 2)) ∨
    (u = 1 ∧ (v = 3 ∨ v = 4)) ∨ (v = 1 ∧ (u = 3 ∨ u = 4)) ∨
    (u = 3 ∧ v = 6) ∨ (v = 3 ∧ u = 6) ∨
    (u = 4 ∧ v = 7) ∨ (v = 4 ∧ u = 7) ∨
    (u = 2 ∧ v = 5) ∨ (v = 2 ∧ u = 5) ∨
    (u = 5 ∧ v = 8) ∨ (v = 5 ∧ u = 8)
  symm := by
    intro u v h
    rcases h with h | h | h | h | h | h | h | h | h | h | h | h
    · exact (Or.inr (Or.inl h))
    · exact (Or.inl h)
    · exact (Or.inr (Or.inr (Or.inr (Or.inl h))))
    · exact (Or.inr (Or.inr (Or.inl h)))
    · exact (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl h))))))
    · exact (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl h)))))
    · exact (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl h))))))))
    · exact (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl h)))))))
    · exact (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl h))))))))))
    · exact (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl h)))))))))
    · exact (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr h)))))))))))
    · exact (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl h)))))))))))
  loopless := by
    intro u h
    rcases h with h | h | h | h | h | h | h | h | h | h | h | h <;> omega

instance : DecidableRel nine.Adj := fun _ _ => inferInstanceAs (Decidable (_ ∨ _))

theorem nine_first_legal : Legal nine ∅ 1 := by decide

theorem nine_white_after_first : ∀ u : Fin 9, White nine {1} u ↔ u = 2 ∨ u = 5 ∨ u = 8 :=
  by decide

theorem nine_legal_after_first :
    ∀ v : Fin 9, Legal nine {1} v ↔ v = 0 ∨ v = 2 ∨ v = 5 ∨ v = 8 := by decide

theorem nine_after_q : Terminal nine {2, 1} := by decide
theorem nine_after_w : Terminal nine {5, 1} := by decide
theorem nine_after_z : Terminal nine {8, 1} := by decide
theorem nine_w_legal_after_r : Legal nine {0, 1} 5 := by decide
theorem nine_after_r_w : Terminal nine {5, 0, 1} := by decide

/-- The blue root is a legal Staller response. All four legal responses
    are handled explicitly, using the exact isolation-game predicates. -/
theorem nine_three_moves : isolationNumber nine ≤ 3 := by
  apply (isolationNumber_le_iff nine 3).mpr
  apply Or.inr
  refine ⟨1, nine_first_legal, ?_⟩
  apply Or.inr
  intro v hv
  have hv' : v = 0 ∨ v = 2 ∨ v = 5 ∨ v = 8 :=
    (nine_legal_after_first v).mp (by simpa using hv)
  rcases hv' with rfl | rfl | rfl | rfl
  · apply Or.inr
    refine ⟨5, by simpa using nine_w_legal_after_r, ?_⟩
    simpa [WinsWithin] using nine_after_r_w
  · exact terminal_wins nine (by simpa using nine_after_q) _ _
  · exact terminal_wins nine (by simpa using nine_after_w) _ _
  · exact terminal_wins nine (by simpa using nine_after_z) _ _

end IsolationGame.Exceptional
