import IsolationGame.RootedStars
import IsolationGame.GroupGame
import IsolationGame.VertexCount

namespace IsolationGame.Rooted

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V} (hT : G.IsTree) (r : V)

theorem root_outside_stars (hr : RadiusThree G r) (i : Index (G := G) r) :
    r ∉ (system hT r hr).vertices i := by
  intro h
  have hd := mem_vertices_depth r i h
  rw [SimpleGraph.dist_self] at hd
  omega

theorem root_ne_parent (hr : RadiusThree G r) (i : Index (G := G) r) :
    r ≠ (system hT r hr).parent i := by
  intro h
  have hp := (parent_spec hT r i).2
  change r = parent hT r i at h
  rw [← h, SimpleGraph.dist_self] at hp
  omega

theorem count (hr : RadiusThree G r) :
    1 + ((allIndices (G := G) r).image (system hT r hr).parent).card +
      2 * (allIndices (G := G) r).card ≤ Fintype.card V := by
  classical
  exact (system hT r hr).vertex_count r (allIndices (G := G) r)
    (root_outside_stars hT r hr) (root_ne_parent hT r hr)

include hT in
theorem initial_legal (hn : 2 ≤ Fintype.card V) : Legal G ∅ r := by
  obtain ⟨x, _, hxr⟩ := Finset.exists_mem_not_mem_of_card_lt_card
    (show ({r} : Finset V).card < (Finset.univ : Finset V).card by simp; omega)
  have hne : r ≠ x := by intro h; exact hxr (by simp [h])
  obtain ⟨p, hp, hlen⟩ := hT.isConnected.exists_path_of_dist r x
  cases p with
  | nil => exact False.elim (hne rfl)
  | @cons r v x hrv p =>
    exact ⟨r, Or.inl rfl, by simp [Undominated, Dominated],
      v, hrv, by simp [Undominated, Dominated]⟩

theorem bound_from_root_strategy (hr : RadiusThree G r) (hn : 2 ≤ Fintype.card V)
    (t : Nat) (hs : (system hT r hr).WinsWithin t .staller (allIndices (G := G) r)) :
    isolationNumber G ≤ t + 1 := by
  classical
  apply (isolationNumber_le_iff G (t + 1)).mpr
  refine Or.inr ⟨r, initial_legal hT r hn, ?_⟩
  have h := ((system hT r hr).strategy_equivalence (initial_represents hT r hr) t .staller).mpr hs
  simpa using h

theorem nonexceptional_bound (hr : RadiusThree G r) (hn : 3 ≤ Fintype.card V)
    (hb : 1 ≤ ((allIndices (G := G) r).image (system hT r hr).parent).card)
    (h11 : ¬ (((allIndices (G := G) r).image (system hT r hr).parent).card = 1 ∧ (allIndices (G := G) r).card = 1))
    (h12 : ¬ (((allIndices (G := G) r).image (system hT r hr).parent).card = 1 ∧ (allIndices (G := G) r).card = 2))
    (h23 : ¬ (((allIndices (G := G) r).image (system hT r hr).parent).card = 2 ∧ (allIndices (G := G) r).card = 3)) :
    isolationNumber G ≤ (2 * Fintype.card V + 1) / 5 := by
  classical
  have hs := (system hT r hr).nonexceptional_strategy (allIndices (G := G) r) (Fintype.card V)
    hb (count hT r hr) h11 h12 h23
  have hbound := bound_from_root_strategy hT r hr (by omega) _ hs
  have hf := one_move_bound hn
  omega

include hT in
theorem coarse_bound (hr : RadiusThree G r) (hn : 2 ≤ Fintype.card V) :
    isolationNumber G ≤ (allIndices (G := G) r).card + 1 := by
  classical
  apply bound_from_root_strategy hT r hr hn
  apply (system hT r hr).wins_of_controlled_bound
  intro t ht
  exact StarSystem.Controlled.units_bound _ ht

theorem single_group_equality_bound (hr : RadiusThree G r) (hn : 2 ≤ Fintype.card V)
    (hb : ((allIndices (G := G) r).image (system hT r hr).parent).card = 1)
    (heq : Fintype.card V = 1 + ((allIndices (G := G) r).image (system hT r hr).parent).card +
      2 * (allIndices (G := G) r).card) : isolationNumber G ≤ 1 := by
  classical
  let A := system hT r hr
  let R := allIndices (G := G) r
  have hcover : A.countedVertices r R = Finset.univ :=
    A.countedVertices_eq_univ r R (root_outside_stars hT r hr) (root_ne_parent hT r hr) heq
  obtain ⟨a, ha⟩ := Finset.card_eq_one.mp hb
  have hpar : ∀ i ∈ R, A.parent i = a := by
    intro i hi
    have hm : A.parent i ∈ R.image A.parent := Finset.mem_image.mpr ⟨i, hi, rfl⟩
    rw [ha] at hm
    exact Finset.mem_singleton.mp hm
  have hma : a ∈ R.image A.parent := by rw [ha]; simp
  obtain ⟨i, hi, hia⟩ := Finset.mem_image.mp hma
  have hd : G.dist a r = 1 := by
    have h := (parent_spec hT r i).2
    change G.dist (A.parent i) r = 1 at h
    rwa [hia] at h
  have ht := A.single_parent_terminal r a R hcover hpar (SimpleGraph.dist_eq_one_iff_adj.mp hd)
  apply (isolationNumber_le_iff G 1).mpr
  exact Or.inr ⟨a, initial_legal hT a hn, by simpa [IsolationGame.WinsWithin] using ht⟩

end IsolationGame.Rooted
