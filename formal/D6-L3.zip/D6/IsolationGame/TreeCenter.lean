import IsolationGame.TreeLevels

namespace IsolationGame

open SimpleGraph

variable {V : Type*} {G : SimpleGraph V}

theorem path_start_not_mem_tail {r x : V} {p : G.Walk r x} (hp : p.IsPath) :
    r ∉ p.support.tail := by
  cases p with
  | nil => simp
  | cons h p => exact (Walk.cons_isPath_iff h p).mp hp |>.2

theorem path_append_of_intersection {a r b : V} (p : G.Walk a r) (q : G.Walk r b)
    (hp : p.IsPath) (hq : q.IsPath)
    (hi : ∀ z, z ∈ p.support → z ∈ q.support → z = r) :
    (p.append q).IsPath := by
  apply Walk.IsPath.mk'
  rw [Walk.support_append, List.nodup_append]
  refine ⟨hp.support_nodup, hq.support_nodup.tail, ?_⟩
  intro z hz hzq
  have heq := hi z hz (List.mem_of_mem_tail hzq)
  exact path_start_not_mem_tail hq (heq ▸ hzq)

theorem paths_intersect_only_at_start (hT : G.IsTree) {r a b : V}
    (p : G.Walk r a) (q : G.Walk r b) (hp : p.IsPath) (hq : q.IsPath)
    (hfirst : p.snd ≠ q.snd) :
    ∀ z, z ∈ p.support → z ∈ q.support → z = r := by
  classical
  intro z hz hzq
  by_contra hzr
  have heq := hT.IsAcyclic.path_unique
    ⟨p.takeUntil z hz, hp.takeUntil hz⟩ ⟨q.takeUntil z hzq, hq.takeUntil hzq⟩
  have h := congrArg (fun t : G.Path r z => t.val.snd) heq
  change (p.takeUntil z hz).snd = (q.takeUntil z hzq).snd at h
  rw [Walk.snd_takeUntil hzr p hz, Walk.snd_takeUntil hzr q hzq] at h
  exact hfirst h

theorem reverse_append_path_of_distinct_first (hT : G.IsTree) {r a b : V}
    (p : G.Walk r a) (q : G.Walk r b) (hp : p.IsPath) (hq : q.IsPath)
    (hfirst : p.snd ≠ q.snd) : (p.reverse.append q).IsPath := by
  apply path_append_of_intersection p.reverse q hp.reverse hq
  intro z hz hzq
  apply paths_intersect_only_at_start hT p q hp hq hfirst z
  · simpa only [Walk.support_reverse, List.mem_reverse] using hz
  · exact hzq

theorem snd_mem_tail {r x : V} (p : G.Walk r x) (hp : 0 < p.length) :
    p.snd ∈ p.support.tail := by
  cases p with
  | nil => simp at hp
  | cons h p => simpa using p.start_mem_support

theorem first_distinct_of_reverse_append {r a b : V}
    (p : G.Walk r a) (q : G.Walk r b) (hq : 0 < q.length)
    (hpq : (p.reverse.append q).IsPath) : p.snd ≠ q.snd := by
  intro heq
  have hd := hpq.support_nodup
  rw [Walk.support_append] at hd
  have hp : p.snd ∈ p.reverse.support := by
    simpa only [Walk.support_reverse, List.mem_reverse] using p.getVert_mem_support 1
  exact (List.disjoint_of_nodup_append hd) hp (heq ▸ snd_mem_tail q hq)

theorem prefix_length_at_index [DecidableEq V] {a b : V} (p : G.Walk a b) (hp : p.IsPath)
    (m : Nat) (hm : m ≤ p.length) :
    (p.takeUntil (p.getVert m) (p.getVert_mem_support m)).length = m := by
  classical
  let q := p.takeUntil (p.getVert m) (p.getVert_mem_support m)
  have hqle : q.length ≤ p.length := p.length_takeUntil_le _
  have hget : p.getVert q.length = p.getVert m := by
    rw [← p.getVert_takeUntil (p.getVert_mem_support m) (Nat.le_refl q.length)]
    exact q.getVert_length
  exact hp.getVert_injOn hqle hm hget

/-- Lemma 2.1. A midpoint of a diameter path has eccentricity at most
    three. The proof uses distinct first branches and unique paths. -/
theorem exists_radiusThree [Fintype V] (hT : G.IsTree) (hdiam : G.diam ≤ 6) :
    ∃ r, RadiusThree G r := by
  classical
  letI : Nonempty V := hT.isConnected.nonempty
  have hfinite : G.ediam ≠ ⊤ := SimpleGraph.connected_iff_ediam_ne_top.mp hT.isConnected
  obtain ⟨a, b, hab⟩ := G.exists_dist_eq_diam
  obtain ⟨p, hp, hplen⟩ := hT.isConnected.exists_path_of_dist a b
  have hd : p.length = G.diam := hplen.trans hab
  by_cases hsmall : G.diam ≤ 1
  · refine ⟨a, fun x => ?_⟩
    have hh : G.dist a x ≤ G.diam := G.dist_le_diam hfinite
    omega
  · let m := p.length / 2
    let r := p.getVert m
    have hrmem : r ∈ p.support := p.getVert_mem_support m
    let pre := p.takeUntil r hrmem
    let post := p.dropUntil r hrmem
    let left := pre.reverse
    have hpre : pre.IsPath := hp.takeUntil hrmem
    have hpost : post.IsPath := hp.dropUntil hrmem
    have hleft : left.IsPath := hpre.reverse
    have hprelen : pre.length = m := prefix_length_at_index p hp m (by dsimp [m]; omega)
    have hleftlen : left.length = m := by simpa [left] using hprelen
    have hsplit : pre.length + post.length = p.length := by
      have h := congrArg Walk.length (p.take_spec hrmem)
      simpa only [Walk.length_append] using h
    have hwhole : (left.reverse.append post).IsPath := by
      simpa only [left, pre, post, Walk.reverse_reverse, Walk.take_spec] using hp
    have hpostpos : 0 < post.length := by dsimp [m] at hprelen; omega
    have hfirst := first_distinct_of_reverse_append left post hpostpos hwhole
    refine ⟨r, fun x => ?_⟩
    obtain ⟨q, hq, hqlen⟩ := hT.isConnected.exists_path_of_dist r x
    by_cases hx : q.length ≤ 3
    · omega
    · by_cases hql : q.snd = left.snd
      · have hqp : q.snd ≠ post.snd := fun h => hfirst (hql.symm.trans h)
        have hh := reverse_append_path_of_distinct_first hT q post hq hpost hqp
        have hdist := tree_path_length_eq_dist hT (q.reverse.append post) hh
        have hbound : G.dist x b ≤ G.diam := G.dist_le_diam hfinite
        simp only [Walk.length_append, Walk.length_reverse] at hdist
        dsimp [m] at hprelen
        omega
      · have hh := reverse_append_path_of_distinct_first hT q left hq hleft hql
        have hdist := tree_path_length_eq_dist hT (q.reverse.append left) hh
        have hbound : G.dist x a ≤ G.diam := G.dist_le_diam hfinite
        simp only [Walk.length_append, Walk.length_reverse] at hdist
        dsimp [m] at hleftlen
        omega

end IsolationGame
