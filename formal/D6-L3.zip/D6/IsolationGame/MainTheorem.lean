import IsolationGame.TreeCenter
import IsolationGame.NineEquality

namespace IsolationGame

namespace Rooted

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V}

/-- All parameter cases, including all three equalities, with the actual
    Dominator-start game value. -/
theorem full_bound (hT : G.IsTree) (r : V) (hr : RadiusThree G r)
    (hn : 3 ≤ Fintype.card V) : isolationNumber G ≤ (2 * Fintype.card V + 1) / 5 := by
  classical
  let A := system hT r hr
  let R := allIndices (G := G) r
  let b := (R.image A.parent).card
  let k := R.card
  let n := Fintype.card V
  change isolationNumber G ≤ (2 * n + 1) / 5
  have hc : 1 + b + 2 * k ≤ n := count hT r hr
  have hcoarse : isolationNumber G ≤ k + 1 := coarse_bound hT r hr (by omega)
  have hone : 1 ≤ (2 * n + 1) / 5 := one_move_bound hn
  by_cases hb0 : b = 0
  · have hk0 : k = 0 := (A.groups_zero_iff R).mp hb0
    omega
  · have hb : 1 ≤ b := by omega
    by_cases h11 : b = 1 ∧ k = 1
    · by_cases hlarge : 5 ≤ n
      · have hf := exceptional_large_11 hlarge
        omega
      · have hs := single_group_equality_bound hT r hr (by omega) h11.1
          (show n = 1 + b + 2 * k by omega)
        omega
    · by_cases h12 : b = 1 ∧ k = 2
      · by_cases hlarge : 7 ≤ n
        · have hf := exceptional_large_12 hlarge
          omega
        · have hs := single_group_equality_bound hT r hr (by omega) h12.1
            (show n = 1 + b + 2 * k by omega)
          omega
      · by_cases h23 : b = 2 ∧ k = 3
        · by_cases hlarge : 10 ≤ n
          · have hf := exceptional_large_23 hlarge
            omega
          · have hn9 : Fintype.card V = 9 := by change n = 9; omega
            have hs := nine_equality_bound hT r hr hn9 h23.1 h23.2
            have hn9' : n = 9 := hn9
            omega
        · exact nonexceptional_bound hT r hr hn hb h11 h12 h23

end Rooted

/-- An instance-independent public name for the finite isolation-game
    minimax value. No decidable-adjacency or chosen-root assumption. -/
noncomputable def gameIsolationNumber {V : Type*} [Fintype V] (G : SimpleGraph V) : Nat := by
  classical
  exact isolationNumber G

/-- The paper's complete main theorem. Natural-number division is floor;
    the second conjunct is the exact integer form of comparison to 3n/7. -/
theorem tree_diameter_six_bound {V : Type*} [Fintype V] (T : SimpleGraph V)
    (hT : T.IsTree) (hn : 3 ≤ Fintype.card V) (hd : T.diam ≤ 6) :
    gameIsolationNumber T ≤ (2 * Fintype.card V + 1) / 5 ∧
      7 * ((2 * Fintype.card V + 1) / 5) ≤ 3 * Fintype.card V := by
  classical
  obtain ⟨r, hr⟩ := exists_radiusThree hT hd
  exact ⟨Rooted.full_bound hT r hr hn, floor_le_three_sevenths hn⟩

end IsolationGame
