import IsolationGame.StarSimulation
import IsolationGame.PileArithmetic
import Mathlib.Data.Finset.Max

namespace IsolationGame.StarSystem

variable {V I : Type*} [DecidableEq V] [DecidableEq I]
variable {G : SimpleGraph V} (A : StarSystem G I)

def groups (R : Finset I) : Finset V := R.image A.parent
def whole (R : Finset I) (i : I) : Finset I := R.filter (fun j => A.parent j ≠ A.parent i)
def size (R : Finset I) (i : I) : Nat := (R.filter (fun j => A.parent j = A.parent i)).card

theorem whole_subset (R : Finset I) (i : I) : A.whole R i ⊆ R := Finset.filter_subset _ _

theorem whole_card_lt {R : Finset I} {i : I} (hi : i ∈ R) : (A.whole R i).card < R.card := by
  apply Finset.card_lt_card
  refine ⟨A.whole_subset R i, ?_⟩
  intro h
  have hmem := h hi
  simp [whole] at hmem

theorem move_card_lt {R Q : Finset I} (h : A.Move R Q) : Q.card < R.card := by
  obtain ⟨i, hi, rfl | rfl⟩ := h
  · exact Finset.card_erase_lt_of_mem hi
  · exact A.whole_card_lt hi

theorem move_subset {R Q : Finset I} (h : A.Move R Q) : Q ⊆ R := by
  obtain ⟨i, _, rfl | rfl⟩ := h
  · exact Finset.erase_subset _ _
  · exact A.whole_subset _ _

theorem groups_mono {R Q : Finset I} (h : Q ⊆ R) : A.groups Q ⊆ A.groups R :=
  Finset.image_subset_image h

theorem whole_groups (R : Finset I) (i : I) :
    A.groups (A.whole R i) = (A.groups R).erase (A.parent i) := by
  ext v
  simp only [groups, whole, Finset.mem_image, Finset.mem_filter, Finset.mem_erase]
  constructor
  · rintro ⟨j, ⟨hj, hn⟩, rfl⟩
    exact ⟨hn, j, hj, rfl⟩
  · rintro ⟨hn, j, hj, rfl⟩
    exact ⟨j, ⟨hj, hn⟩, rfl⟩

theorem whole_group_drop {R : Finset I} {i : I} (hi : i ∈ R) :
    (A.groups (A.whole R i)).card + 1 = (A.groups R).card := by
  rw [A.whole_groups]
  exact Finset.card_erase_add_one (Finset.mem_image.mpr ⟨i, hi, rfl⟩)

theorem whole_size (R : Finset I) (i : I) :
    (A.whole R i).card + A.size R i = R.card := by
  simpa [whole, size] using Finset.filter_card_add_filter_neg_card_eq_card
    (s := R) (fun j => A.parent j ≠ A.parent i)

theorem groups_zero_iff (R : Finset I) : (A.groups R).card = 0 ↔ R.card = 0 := by
  simp [groups]

theorem maximum_size_ge_two {R : Finset I} {i : I} (hi : i ∈ R)
    (hmax : ∀ j ∈ R, A.size R j ≤ A.size R i)
    (hmore : (A.groups R).card < R.card) : 2 ≤ A.size R i := by
  by_contra hn
  have hinj : Set.InjOn A.parent R := by
    intro j hj k hk heq
    have hsmall : (R.filter (fun z => A.parent z = A.parent j)).card ≤ 1 := by
      have := hmax j hj
      change A.size R j ≤ 1
      omega
    exact Finset.card_le_one.mp hsmall j (Finset.mem_filter.mpr ⟨hj, rfl⟩)
      k (Finset.mem_filter.mpr ⟨hk, heq.symm⟩)
  have hcard := Finset.card_image_of_injOn hinj
  change (A.groups R).card = R.card at hcard
  omega

/-- Complete plays in the labelled-unit version of the pile game. -/
inductive Controlled : Player → Finset I → Nat → Prop
  | done (p : Player) (R : Finset I) : R = ∅ → Controlled p R 0
  | staller {R Q : Finset I} {t : Nat} :
      A.Move R Q → Controlled .dominator Q t → Controlled .staller R (t + 1)
  | dominator {R : Finset I} {i : I} {t : Nat} :
      i ∈ R → Controlled .staller (A.whole R i) t → Controlled .dominator R (t + 1)

theorem Controlled.units_bound {p R t} (h : A.Controlled p R t) : t ≤ R.card := by
  induction h with
  | done p R hR => omega
  | staller hm hp ih => have := A.move_card_lt hm; omega
  | dominator hi hp ih => have := A.whole_card_lt hi; omega

theorem Controlled.pile_bound {p R t} (h : A.Controlled p R t) :
    t ≤ 2 * (A.groups R).card ∧
      (p = .dominator → R.Nonempty → t + 1 ≤ 2 * (A.groups R).card) := by
  induction h with
  | done p R hR =>
    subst R
    simp [groups, Finset.not_nonempty_empty]
  | @staller R Q t hm hp ih =>
    constructor
    · by_cases hq : Q.Nonempty
      · have hh := ih.2 rfl hq
        have hh' := Finset.card_le_card (A.groups_mono (A.move_subset hm))
        omega
      · have hh := Controlled.units_bound A hp
        have hh' := A.move_card_lt hm
        have hzero : Q.card = 0 := by simpa using hq
        have hh'' := A.groups_zero_iff R
        omega
    · intro heq; cases heq
  | dominator hi hp ih =>
    have hh := A.whole_group_drop hi
    constructor
    · omega
    · intro _ _; omega

theorem exists_controlled (R : Finset I) (p : Player) : ∃ t, A.Controlled p R t := by
  classical
  refine Finset.strongInductionOn (p := fun R => ∀ p, ∃ t, A.Controlled p R t) R ?_ p
  intro R ih p
  by_cases hR : R = ∅
  · exact ⟨0, .done p R hR⟩
  · obtain ⟨i, hi⟩ := Finset.nonempty_iff_ne_empty.mpr hR
    have hsub : A.whole R i ⊂ R := by
      refine ⟨A.whole_subset R i, ?_⟩
      intro h
      have hc := Finset.card_le_card h
      have hl := A.whole_card_lt hi
      omega
    cases p with
    | dominator =>
      obtain ⟨t, ht⟩ := ih _ hsub .staller
      exact ⟨t + 1, .dominator hi ht⟩
    | staller =>
      obtain ⟨t, ht⟩ := ih _ hsub .dominator
      exact ⟨t + 1, .staller ⟨i, hi, Or.inr rfl⟩ ht⟩

theorem Controlled.empty_of_zero {p R t} (h : A.Controlled p R t) (ht : t = 0) : R = ∅ := by
  cases h <;> simp_all

/-- Convert a bound on every complete controlled play into an actual
    strategy with that move bound, including all Staller responses. -/
theorem wins_of_controlled_bound (m : Nat) (p : Player) (R : Finset I)
    (hb : ∀ t, A.Controlled p R t → t ≤ m) : A.WinsWithin m p R := by
  induction m generalizing p R with
  | zero =>
    obtain ⟨t, ht⟩ := A.exists_controlled R p
    exact Controlled.empty_of_zero A ht (by have := hb t ht; omega)
  | succ m ih =>
    classical
    by_cases hR : R = ∅
    · cases p <;> exact Or.inl hR
    · cases p with
      | dominator =>
        obtain ⟨i, hi⟩ := Finset.nonempty_iff_ne_empty.mpr hR
        refine Or.inr ⟨A.whole R i, ⟨i, hi, Or.inr rfl⟩, ?_⟩
        apply ih
        intro t ht
        have := hb (t + 1) (.dominator hi ht)
        omega
      | staller =>
        apply Or.inr
        intro Q hQ
        apply ih
        intro t ht
        have := hb (t + 1) (.staller hQ ht)
        omega

inductive FirstControlled : Finset I → Nat → Prop
  | done (R : Finset I) : R = ∅ → FirstControlled R 0
  | last {R Q : Finset I} : A.Move R Q → Q = ∅ → FirstControlled R 1
  | pair {R Q : Finset I} {i : I} {t : Nat} :
      A.Move R Q → i ∈ Q → (∀ j ∈ Q, A.size Q j ≤ A.size Q i) →
      A.Controlled .staller (A.whole Q i) t → FirstControlled R (t + 2)

theorem FirstControlled.toControlled {R t} (h : A.FirstControlled R t) :
    A.Controlled .staller R t := by
  cases h with
  | done hR => exact .done _ _ hR
  | last hm hQ => exact .staller hm (.done _ _ hQ)
  | pair hm hi hmax hp => exact .staller hm (.dominator hi hp)

theorem FirstControlled.saved_move {R t} (h : A.FirstControlled R t)
    (hs : (A.groups R).card + 2 ≤ R.card) : t ≤ R.card - 1 := by
  cases h with
  | done hR => simp [hR]
  | last hm hQ => omega
  | @pair Q i t hm hi hmax hp =>
    have hlt := A.move_card_lt hm
    have hle := Controlled.units_bound A hp
    have hwhole := A.whole_card_lt hi
    by_cases htwo : Q.card + 2 ≤ R.card
    · omega
    · have hocc := Finset.card_le_card (A.groups_mono (A.move_subset hm))
      have hlarge := A.maximum_size_ge_two hi hmax (by omega : (A.groups Q).card < Q.card)
      have heq := A.whole_size Q i
      omega

theorem wins_of_first_bound (m : Nat) (hm : 2 ≤ m) (R : Finset I)
    (hb : ∀ t, A.FirstControlled R t → t ≤ m) : A.WinsWithin m .staller R := by
  obtain ⟨m, rfl⟩ : ∃ k, m = k + 2 := ⟨m - 2, by omega⟩
  apply Or.inr
  intro Q hQ
  classical
  by_cases hq : Q = ∅
  · exact Or.inl hq
  · obtain ⟨i, hi, hmax⟩ := Q.exists_max_image (A.size Q) (Finset.nonempty_iff_ne_empty.mpr hq)
    refine Or.inr ⟨A.whole Q i, ⟨i, hi, Or.inr rfl⟩, ?_⟩
    apply A.wins_of_controlled_bound
    intro t ht
    have := hb (t + 2) (.pair hQ hi hmax ht)
    omega

theorem nonexceptional_strategy (R : Finset I) (n : Nat)
    (hb : 1 ≤ (A.groups R).card)
    (hn : 1 + (A.groups R).card + 2 * R.card ≤ n)
    (h11 : ¬ ((A.groups R).card = 1 ∧ R.card = 1))
    (h12 : ¬ ((A.groups R).card = 1 ∧ R.card = 2))
    (h23 : ¬ ((A.groups R).card = 2 ∧ R.card = 3)) :
    A.WinsWithin ((2 * n + 1) / 5 - 1) .staller R := by
  have hbk : (A.groups R).card ≤ R.card := Finset.card_image_le
  apply A.wins_of_first_bound
  · omega
  · intro t ht
    have htk := Controlled.units_bound A (FirstControlled.toControlled A ht)
    have htb := (Controlled.pile_bound A (FirstControlled.toControlled A ht)).1
    have hsave := FirstControlled.saved_move A ht
    have hc := pile_arithmetic hb hbk htk htb hsave h11 h12 h23
    have hf := nonexceptional_total hb hbk hc hn
    omega

end IsolationGame.StarSystem
