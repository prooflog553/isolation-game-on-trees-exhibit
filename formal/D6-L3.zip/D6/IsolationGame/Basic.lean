import Mathlib.Combinatorics.SimpleGraph.Basic
import Mathlib.Data.Finset.Card

namespace IsolationGame

variable {V : Type*} (G : SimpleGraph V)

/-- Membership in the closed neighborhood of a vertex. -/
def Closed (v u : V) : Prop := u = v ∨ G.Adj v u

/-- A vertex dominated by the selected vertices. -/
def Dominated (X : Finset V) (u : V) : Prop := ∃ v ∈ X, Closed G v u

/-- The undominated set, including isolated undominated vertices. -/
def Undominated (X : Finset V) (u : V) : Prop := ¬ Dominated G X u

/-- White vertices are precisely undominated vertices with an undominated neighbor. -/
def White (X : Finset V) (u : V) : Prop :=
  Undominated G X u ∧ ∃ w, G.Adj u w ∧ Undominated G X w

/-- This does not require the move vertex itself to be undominated. -/
def Legal (X : Finset V) (v : V) : Prop := ∃ u, Closed G v u ∧ White G X u

def Terminal (X : Finset V) : Prop := ∀ u, ¬ White G X u

theorem dominated_mono {X Y : Finset V} (h : X ⊆ Y) {u : V}
    (hu : Dominated G X u) : Dominated G Y u := by
  obtain ⟨v, hv, hclose⟩ := hu
  exact ⟨v, h hv, hclose⟩

theorem undominated_anti {X Y : Finset V} (h : X ⊆ Y) {u : V}
    (hu : Undominated G Y u) : Undominated G X u :=
  fun hx => hu (dominated_mono G h hx)

theorem white_anti {X Y : Finset V} (h : X ⊆ Y) {u : V}
    (hu : White G Y u) : White G X u := by
  obtain ⟨hu, w, huw, hw⟩ := hu
  exact ⟨undominated_anti G h hu, w, huw, undominated_anti G h hw⟩

theorem selected_not_legal {X : Finset V} {v : V} (hv : v ∈ X) : ¬ Legal G X v := by
  rintro ⟨u, hclose, hu, _⟩
  exact hu ⟨v, hv, hclose⟩

theorem legal_not_selected {X : Finset V} {v : V} (h : Legal G X v) : v ∉ X :=
  fun hv => selected_not_legal G hv h

theorem terminal_iff_no_legal (X : Finset V) :
    Terminal G X ↔ ∀ v, ¬ Legal G X v := by
  constructor
  · rintro h v ⟨u, _, hu⟩
    exact h u hu
  · intro h u hu
    exact h u ⟨u, Or.inl rfl, hu⟩

theorem exists_legal_of_not_terminal {X : Finset V} (h : ¬ Terminal G X) :
    ∃ v, Legal G X v := by
  classical
  by_contra hn
  apply h
  exact (terminal_iff_no_legal G X).mpr (by simpa using hn)

/-- Ending means no edge between undominated vertices, not that every
    vertex is dominated. -/
theorem terminal_iff_undominated_independent (X : Finset V) :
    Terminal G X ↔ ∀ u w, Undominated G X u → Undominated G X w → ¬ G.Adj u w := by
  constructor
  · intro h u w hu hw huw
    exact h u ⟨hu, w, huw, hw⟩
  · rintro h u ⟨hu, w, huw, hw⟩
    exact h u w hu hw huw

variable [DecidableEq V]

theorem undominated_insert (X : Finset V) (v u : V) :
    Undominated G (insert v X) u ↔ Undominated G X u ∧ ¬ Closed G v u := by
  constructor
  · intro h
    exact ⟨undominated_anti G (Finset.subset_insert v X) h,
      fun hc => h ⟨v, Finset.mem_insert_self v X, hc⟩⟩
  · rintro ⟨hu, hc⟩ ⟨x, hx, hclose⟩
    rcases Finset.mem_insert.mp hx with hx | hx
    · subst x
      exact hc hclose
    · exact hu ⟨x, hx, hclose⟩

theorem legal_removes_white {X : Finset V} {v : V} (h : Legal G X v) :
    ∃ u, White G X u ∧ ¬ White G (insert v X) u := by
  obtain ⟨u, hclose, hu⟩ := h
  refine ⟨u, hu, ?_⟩
  intro hnew
  exact hnew.1 ⟨v, Finset.mem_insert_self _ _, hclose⟩

/-- The next white set depends only on the present white set and the
    selected vertex. Isolated undominated vertices cannot re-enter it. -/
theorem white_insert_iff (X : Finset V) (v u : V) :
    White G (insert v X) u ↔
      White G X u ∧ ¬ Closed G v u ∧
        ∃ w, G.Adj u w ∧ White G X w ∧ ¬ Closed G v w := by
  constructor
  · rintro ⟨hu, w, huw, hw⟩
    have hu' := (undominated_insert G X v u).mp hu
    have hw' := (undominated_insert G X v w).mp hw
    exact ⟨⟨hu'.1, w, huw, hw'.1⟩, hu'.2,
      w, huw, ⟨hw'.1, u, huw.symm, hu'.1⟩, hw'.2⟩
  · rintro ⟨hu, hcu, w, huw, hw, hcw⟩
    exact ⟨(undominated_insert G X v u).mpr ⟨hu.1, hcu⟩,
      w, huw, (undominated_insert G X v w).mpr ⟨hw.1, hcw⟩⟩

end IsolationGame
