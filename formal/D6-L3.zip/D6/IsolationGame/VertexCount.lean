import IsolationGame.StarReduction
import Mathlib.Data.Fintype.Card

namespace IsolationGame.StarSystem

variable {V I : Type*} [DecidableEq V] [DecidableEq I]
variable {G : SimpleGraph V} (A : StarSystem G I)

noncomputable def chosenLeaf (i : I) : V := (A.leaves_nonempty i).choose

theorem chosenLeaf_mem (i : I) : A.chosenLeaf i ∈ A.leaves i :=
  (A.leaves_nonempty i).choose_spec

theorem center_injective : Function.Injective A.center := by
  intro i j h
  exact A.member_unique (A.center_mem i) (h ▸ A.center_mem j)

theorem chosenLeaf_injective : Function.Injective A.chosenLeaf := by
  intro i j h
  exact A.member_unique (A.leaf_mem (A.chosenLeaf_mem i))
    (h ▸ A.leaf_mem (A.chosenLeaf_mem j))

noncomputable def countedVertices (r : V) (R : Finset I) : Finset V :=
  insert r ((R.image A.parent) ∪ ((R.image A.center) ∪ (R.image A.chosenLeaf)))

theorem countedVertices_card (r : V) (R : Finset I)
    (hrs : ∀ i, r ∉ A.vertices i) (hrp : ∀ i, r ≠ A.parent i) :
    (A.countedVertices r R).card = 1 + (R.image A.parent).card + 2 * R.card := by
  classical
  have hCL : Disjoint (R.image A.center) (R.image A.chosenLeaf) := by
    apply Finset.disjoint_left.mpr
    intro u hu hv
    obtain ⟨i, _, rfl⟩ := Finset.mem_image.mp hu
    obtain ⟨j, _, hj⟩ := Finset.mem_image.mp hv
    have hjmem : A.center i ∈ A.vertices j := hj ▸ A.leaf_mem (A.chosenLeaf_mem j)
    have heq := A.member_unique (A.center_mem i) hjmem
    subst j
    exact A.center_not_leaf i (hj ▸ A.chosenLeaf_mem i)
  have hP : Disjoint (R.image A.parent) ((R.image A.center) ∪ (R.image A.chosenLeaf)) := by
    apply Finset.disjoint_left.mpr
    intro u hu hv
    obtain ⟨i, _, rfl⟩ := Finset.mem_image.mp hu
    rcases Finset.mem_union.mp hv with hc | hl
    · obtain ⟨j, _, hj⟩ := Finset.mem_image.mp hc
      exact A.parent_outside i j (hj ▸ A.center_mem j)
    · obtain ⟨j, _, hj⟩ := Finset.mem_image.mp hl
      exact A.parent_outside i j (hj ▸ A.leaf_mem (A.chosenLeaf_mem j))
  have hr : r ∉ (R.image A.parent) ∪ ((R.image A.center) ∪ (R.image A.chosenLeaf)) := by
    intro h
    rcases Finset.mem_union.mp h with hp | h
    · obtain ⟨i, _, hi⟩ := Finset.mem_image.mp hp
      exact hrp i hi.symm
    · rcases Finset.mem_union.mp h with hc | hl
      · obtain ⟨i, _, hi⟩ := Finset.mem_image.mp hc
        exact hrs i (hi ▸ A.center_mem i)
      · obtain ⟨i, _, hi⟩ := Finset.mem_image.mp hl
        exact hrs i (hi ▸ A.leaf_mem (A.chosenLeaf_mem i))
  rw [countedVertices, Finset.card_insert_of_not_mem hr,
    Finset.card_union_of_disjoint hP, Finset.card_union_of_disjoint hCL,
    Finset.card_image_of_injective R A.center_injective,
    Finset.card_image_of_injective R A.chosenLeaf_injective]
  omega

theorem vertex_count [Fintype V] (r : V) (R : Finset I)
    (hrs : ∀ i, r ∉ A.vertices i) (hrp : ∀ i, r ≠ A.parent i) :
    1 + (R.image A.parent).card + 2 * R.card ≤ Fintype.card V := by
  rw [← A.countedVertices_card r R hrs hrp]
  exact Finset.card_le_univ _

/-- Equality in the count leaves no vertex outside the displayed root,
    parents, centers and one chosen leaf per star. -/
theorem countedVertices_eq_univ [Fintype V] (r : V) (R : Finset I)
    (hrs : ∀ i, r ∉ A.vertices i) (hrp : ∀ i, r ≠ A.parent i)
    (heq : Fintype.card V = 1 + (R.image A.parent).card + 2 * R.card) :
    A.countedVertices r R = Finset.univ := by
  apply Finset.eq_univ_of_card
  rw [A.countedVertices_card r R hrs hrp, heq]

theorem chosenLeaves_independent (i j : I) : ¬ G.Adj (A.chosenLeaf i) (A.chosenLeaf j) := by
  intro h
  have heq := A.leaf_neighbor (A.chosenLeaf_mem i) h
  have hsame := A.member_unique (A.center_mem i) (heq ▸ A.leaf_mem (A.chosenLeaf_mem j))
  subst j
  exact A.center_not_leaf i (heq ▸ A.chosenLeaf_mem i)

/-- Equality in the vertex count plus a single common parent gives a
    one-move isolating strategy, independently of the number of stars. -/
theorem single_parent_terminal [Fintype V] (r a : V) (R : Finset I)
    (hcover : A.countedVertices r R = Finset.univ)
    (hpar : ∀ i ∈ R, A.parent i = a) (hra : G.Adj a r) : Terminal G {a} := by
  have hleaf (u : V) (hu : Undominated G {a} u) : ∃ i ∈ R, u = A.chosenLeaf i := by
    have hmem : u ∈ A.countedVertices r R := by rw [hcover]; exact Finset.mem_univ u
    rcases Finset.mem_insert.mp hmem with rfl | hm
    · exact False.elim (hu ⟨a, by simp, Or.inr hra⟩)
    · rcases Finset.mem_union.mp hm with hm | hm
      · obtain ⟨i, hi, rfl⟩ := Finset.mem_image.mp hm
        exact False.elim (hu ⟨a, by simp, Or.inl (hpar i hi)⟩)
      · rcases Finset.mem_union.mp hm with hm | hm
        · obtain ⟨i, hi, rfl⟩ := Finset.mem_image.mp hm
          exact False.elim (hu ⟨a, by simp,
            (A.closed_center_iff i a).mpr (Or.inr (hpar i hi).symm)⟩)
        · obtain ⟨i, hi, heq⟩ := Finset.mem_image.mp hm
          exact ⟨i, hi, heq.symm⟩
  apply (terminal_iff_undominated_independent G {a}).mpr
  intro u v hu hv huv
  obtain ⟨i, _, rfl⟩ := hleaf u hu
  obtain ⟨j, _, rfl⟩ := hleaf v hv
  exact A.chosenLeaves_independent i j huv

theorem leaves_singleton_of_cover [Fintype V] (r : V) (R : Finset I)
    (hrs : ∀ i, r ∉ A.vertices i) (hcover : A.countedVertices r R = Finset.univ)
    {i : I} (hi : i ∈ R) : A.leaves i = {A.chosenLeaf i} := by
  ext u
  constructor
  · intro hu
    have hmem : u ∈ A.countedVertices r R := by rw [hcover]; exact Finset.mem_univ u
    have hui := A.leaf_mem hu
    apply Finset.mem_singleton.mpr
    rcases Finset.mem_insert.mp hmem with rfl | hm
    · exact False.elim (hrs i hui)
    · rcases Finset.mem_union.mp hm with hm | hm
      · obtain ⟨j, _, rfl⟩ := Finset.mem_image.mp hm
        exact False.elim (A.parent_outside j i hui)
      · rcases Finset.mem_union.mp hm with hm | hm
        · obtain ⟨j, _, rfl⟩ := Finset.mem_image.mp hm
          have heq := A.member_unique hui (A.center_mem j)
          subst j
          exact False.elim (A.center_not_leaf i hu)
        · obtain ⟨j, _, rfl⟩ := Finset.mem_image.mp hm
          have heq := A.member_unique hui (A.leaf_mem (A.chosenLeaf_mem j))
          subst j
          rfl
  · intro hu
    have heq := Finset.mem_singleton.mp hu
    exact heq ▸ A.chosenLeaf_mem i

theorem adj_center_singleton (i : I) (hs : A.leaves i = {A.chosenLeaf i}) (v : V) :
    G.Adj v (A.center i) ↔ v = A.chosenLeaf i ∨ v = A.parent i := by
  have hne : A.center i ≠ A.chosenLeaf i := fun h => A.center_not_leaf i (h ▸ A.chosenLeaf_mem i)
  rw [A.adj_iff i _ (A.center_mem i) v]
  simp only [hs, Finset.mem_singleton, hne, and_false, false_or, and_true]

theorem adj_chosenLeaf (i : I) (v : V) : G.Adj v (A.chosenLeaf i) ↔ v = A.center i := by
  constructor
  · intro h
    exact A.leaf_neighbor (A.chosenLeaf_mem i) h.symm
  · rintro rfl
    exact (A.adj_iff i _ (A.leaf_mem (A.chosenLeaf_mem i)) _).mpr
      (Or.inl ⟨rfl, A.chosenLeaf_mem i⟩)

end IsolationGame.StarSystem
