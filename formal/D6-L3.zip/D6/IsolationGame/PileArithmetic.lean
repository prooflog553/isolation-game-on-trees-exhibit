import Lean.Elab.Tactic.Omega

namespace IsolationGame

/-- Corollary 3.2: pure arithmetic, with the three exceptional pairs explicit.
    Its hypotheses must still be supplied by the actual pile process. -/
theorem pile_arithmetic {b k t : Nat}
    (hb : 1 ≤ b) (hbk : b ≤ k)
    (htk : t ≤ k) (htb : t ≤ 2 * b)
    (hsave : b + 2 ≤ k → t ≤ k - 1)
    (h11 : ¬ (b = 1 ∧ k = 1))
    (h12 : ¬ (b = 1 ∧ k = 2))
    (h23 : ¬ (b = 2 ∧ k = 3)) :
    5 * t ≤ 2 * b + 4 * k - 2 := by
  omega

/-- Account for the initial root move and the vertex-count inequality. -/
theorem nonexceptional_total {b k t n : Nat}
    (hb : 1 ≤ b) (hbk : b ≤ k)
    (ht : 5 * t ≤ 2 * b + 4 * k - 2)
    (hn : 1 + b + 2 * k ≤ n) :
    1 + t ≤ (2 * n + 1) / 5 := by
  omega

/-- The paper's final comparison in an exact integer form. -/
theorem floor_le_three_sevenths {n : Nat} (hn : 3 ≤ n) :
    7 * ((2 * n + 1) / 5) ≤ 3 * n := by
  omega

theorem one_move_bound {n : Nat} (hn : 3 ≤ n) :
    1 ≤ (2 * n + 1) / 5 := by
  omega

/-- These cover only the arithmetic above the equality cases; they do
    not replace the required alternative first-move arguments. -/
theorem exceptional_large_11 {n : Nat} (hn : 5 ≤ n) :
    2 ≤ (2 * n + 1) / 5 := by omega

theorem exceptional_large_12 {n : Nat} (hn : 7 ≤ n) :
    3 ≤ (2 * n + 1) / 5 := by omega

theorem exceptional_large_23 {n : Nat} (hn : 10 ≤ n) :
    4 ≤ (2 * n + 1) / 5 := by omega

end IsolationGame
