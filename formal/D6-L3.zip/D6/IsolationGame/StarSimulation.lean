import IsolationGame.Game
import IsolationGame.StarReduction

namespace IsolationGame.StarSystem

variable {V I : Type*} [DecidableEq V] [DecidableEq I]
variable {G : SimpleGraph V} (A : StarSystem G I)

def WinsWithin : Nat → Player → Finset I → Prop
  | 0, _, R => R = ∅
  | m + 1, .dominator, R => R = ∅ ∨ ∃ Q, A.Move R Q ∧ WinsWithin m .staller Q
  | m + 1, .staller, R => R = ∅ ∨ ∀ Q, A.Move R Q → WinsWithin m .dominator Q

theorem terminal_iff {R : Finset I} {X : Finset V} (hR : A.Represents R X) :
    Terminal G X ↔ R = ∅ := by
  constructor
  · intro ht
    apply Finset.eq_empty_iff_forall_not_mem.mpr
    intro i hi
    exact ht (A.center i) ((hR _).mpr ⟨i, hi, A.center_mem i⟩)
  · rintro rfl u hu
    obtain ⟨i, hi, _⟩ := (hR u).mp hu
    exact Finset.not_mem_empty i hi

/-- A turn- and move-count-preserving quotient in both directions.
    No labelled-game-tree isomorphism is claimed. -/
theorem strategy_equivalence {R : Finset I} {X : Finset V}
    (hR : A.Represents R X) (m : Nat) (p : Player) :
    IsolationGame.WinsWithin G m p X ↔ A.WinsWithin m p R := by
  induction m generalizing R X p with
  | zero => exact A.terminal_iff hR
  | succ m ih =>
    cases p with
    | dominator =>
      constructor
      · rintro (ht | ⟨v, hv, hw⟩)
        · exact Or.inl ((A.terminal_iff hR).mp ht)
        · exact Or.inr ⟨A.remainingAfter R v, A.real_move_maps hR hv,
            (ih (A.represents_after hR v) .staller).mp hw⟩
      · rintro (ht | ⟨Q, hQ, hw⟩)
        · exact Or.inl ((A.terminal_iff hR).mpr ht)
        · obtain ⟨v, hv, hnext⟩ := A.operation_realized hR hQ
          exact Or.inr ⟨v, hv, (ih hnext .staller).mpr hw⟩
    | staller =>
      constructor
      · rintro (ht | hw)
        · exact Or.inl ((A.terminal_iff hR).mp ht)
        · apply Or.inr
          intro Q hQ
          obtain ⟨v, hv, hnext⟩ := A.operation_realized hR hQ
          exact (ih hnext .dominator).mp (hw v hv)
      · rintro (ht | hw)
        · exact Or.inl ((A.terminal_iff hR).mpr ht)
        · apply Or.inr
          intro v hv
          exact (ih (A.represents_after hR v) .dominator).mpr
            (hw _ (A.real_move_maps hR hv))

theorem value_le_iff [Fintype V] {R : Finset I} {X : Finset V}
    (hR : A.Represents R X) (m : Nat) (p : Player) :
    gameValue G p X ≤ m ↔ A.WinsWithin m p R :=
  (gameValue_le_iff G p X m).trans (A.strategy_equivalence hR m p)

end IsolationGame.StarSystem

namespace IsolationGame

variable {V : Type*} [DecidableEq V] (G : SimpleGraph V)

/-- Arbitrary histories of real legal moves, with the exact move count. -/
inductive LegalHistory (X₀ : Finset V) : Finset V → Nat → Prop
  | start : LegalHistory X₀ X₀ 0
  | step {X : Finset V} {t : Nat} {v : V} :
      LegalHistory X₀ X t → Legal G X v → LegalHistory X₀ (insert v X) (t + 1)

namespace StarSystem

variable {I : Type*} [DecidableEq I] {G}
variable (A : StarSystem G I)

/-- The star invariant holds after every legal history, without a
    restriction on which player's strategy produced the history. -/
theorem reachable_represents {R₀ : Finset I} {X₀ X : Finset V} {t : Nat}
    (hR : A.Represents R₀ X₀) (hh : LegalHistory G X₀ X t) :
    ∃ R ⊆ R₀, A.Represents R X := by
  induction hh with
  | start => exact ⟨R₀, Finset.Subset.refl _, hR⟩
  | @step X t v hh hv ih =>
    obtain ⟨R, hsub, hrep⟩ := ih
    refine ⟨A.remainingAfter R v, ?_, A.represents_after hrep v⟩
    classical
    exact Finset.Subset.trans (Finset.filter_subset _ _) hsub

end StarSystem
end IsolationGame
