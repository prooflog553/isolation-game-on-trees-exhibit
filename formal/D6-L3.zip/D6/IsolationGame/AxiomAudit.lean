import IsolationGame.MainTheorem
import IsolationGame.PileGame

#print axioms IsolationGame.tree_diameter_six_bound
#print axioms IsolationGame.exists_radiusThree
#print axioms IsolationGame.StarSystem.strategy_equivalence
#print axioms IsolationGame.Rooted.initial_represents
#print axioms IsolationGame.StarSystem.vertex_count
#print axioms IsolationGame.StarSystem.nonexceptional_strategy
#print axioms IsolationGame.Rooted.single_group_equality_bound
#print axioms IsolationGame.Rooted.nine_equality_bound
#print axioms IsolationGame.Exceptional.nine_three_moves
#print axioms IsolationGame.Pile.FirstPlay.saved_move

#check IsolationGame.tree_diameter_six_bound
