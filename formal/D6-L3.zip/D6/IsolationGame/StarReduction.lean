import IsolationGame.Basic

namespace IsolationGame

variable {V I : Type*} [DecidableEq V]

/-- Structural data for the stars after a root move. The neighborhood
    equation specifies every possible neighbor of every star vertex.
    Constructing these data from an arbitrary radius-three tree is a
    separate obligation; this structure does not assume a game bound. -/
structure StarSystem (G : SimpleGraph V) (I : Type*) where
  center : I → V
  parent : I → V
  leaves : I → Finset V
  leaves_nonempty : ∀ i, (leaves i).Nonempty
  center_not_leaf : ∀ i, center i ∉ leaves i
  disjoint : ∀ i j, i ≠ j →
    Disjoint (insert (center i) (leaves i)) (insert (center j) (leaves j))
  parent_outside : ∀ i j, parent i ∉ insert (center j) (leaves j)
  adj_iff : ∀ i u, u ∈ insert (center i) (leaves i) → ∀ v,
    G.Adj v u ↔
      (v = center i ∧ u ∈ leaves i) ∨
      (v ∈ leaves i ∧ u = center i) ∨
      (v = parent i ∧ u = center i)

namespace StarSystem

variable {G : SimpleGraph V} (A : StarSystem G I)

def vertices (i : I) : Finset V := insert (A.center i) (A.leaves i)

/-- The reachable-state invariant of Lemma 2.2. -/
def Represents (R : Finset I) (X : Finset V) : Prop :=
  ∀ u, White G X u ↔ ∃ i ∈ R, u ∈ A.vertices i

theorem center_mem (i : I) : A.center i ∈ A.vertices i := Finset.mem_insert_self _ _

theorem leaf_mem {i : I} {u : V} (h : u ∈ A.leaves i) : u ∈ A.vertices i :=
  Finset.mem_insert_of_mem h

theorem closed_center_iff (i : I) (v : V) :
    Closed G v (A.center i) ↔ v ∈ A.vertices i ∨ v = A.parent i := by
  rw [Closed, A.adj_iff i _ (A.center_mem i) v]
  simp [vertices, A.center_not_leaf, eq_comm, or_assoc]

theorem closed_star_implies {i : I} {u v : V} (hu : u ∈ A.vertices i)
    (h : Closed G v u) : v ∈ A.vertices i ∨ v = A.parent i := by
  rcases h with h | h
  · exact Or.inl (h ▸ hu)
  · rcases (A.adj_iff i u hu v).mp h with ⟨rfl, _⟩ | ⟨hv, _⟩ | ⟨hv, _⟩
    · exact Or.inl (A.center_mem i)
    · exact Or.inl (A.leaf_mem hv)
    · exact Or.inr hv

theorem internal_neighbor {i : I} {u : V} (hu : u ∈ A.vertices i) :
    ∃ w ∈ A.vertices i, G.Adj u w := by
  rcases Finset.mem_insert.mp hu with rfl | hu
  · obtain ⟨w, hw⟩ := A.leaves_nonempty i
    exact ⟨w, A.leaf_mem hw,
      (A.adj_iff i w (A.leaf_mem hw) (A.center i)).mpr (Or.inl ⟨rfl, hw⟩)⟩
  · exact ⟨A.center i, A.center_mem i,
      (A.adj_iff i _ (A.center_mem i) u).mpr (Or.inr (Or.inl ⟨hu, rfl⟩))⟩

theorem leaf_neighbor {i : I} {u w : V} (hu : u ∈ A.leaves i)
    (hw : G.Adj u w) : w = A.center i := by
  have hne : u ≠ A.center i := fun h => A.center_not_leaf i (h ▸ hu)
  rcases (A.adj_iff i u (A.leaf_mem hu) w).mp hw.symm with h | h | h
  · exact h.1
  · exact False.elim (hne h.2)
  · exact False.elim (hne h.2)

theorem legal_iff {R : Finset I} {X : Finset V} (hR : A.Represents R X) (v : V) :
    Legal G X v ↔ (∃ i ∈ R, v ∈ A.vertices i) ∨ (∃ i ∈ R, v = A.parent i) := by
  constructor
  · rintro ⟨u, hcu, hu⟩
    obtain ⟨i, hi, hui⟩ := (hR u).mp hu
    rcases A.closed_star_implies hui hcu with hv | hv
    · exact Or.inl ⟨i, hi, hv⟩
    · exact Or.inr ⟨i, hi, hv⟩
  · rintro (⟨i, hi, hv⟩ | ⟨i, hi, rfl⟩)
    · exact ⟨v, Or.inl rfl, (hR v).mpr ⟨i, hi, hv⟩⟩
    · exact ⟨A.center i, (A.closed_center_iff i _).mpr (Or.inr rfl),
        (hR _).mpr ⟨i, hi, A.center_mem i⟩⟩

/-- Full white-set update, including leaf moves that leave other leaves
    undominated but isolated. It holds at every represented state. -/
theorem white_after_move {R : Finset I} {X : Finset V}
    (hR : A.Represents R X) (v u : V) :
    White G (insert v X) u ↔
      ∃ i ∈ R, u ∈ A.vertices i ∧ ¬ Closed G v (A.center i) := by
  constructor
  · intro hu
    have hold := white_anti G (Finset.subset_insert v X) hu
    obtain ⟨i, hi, hui⟩ := (hR u).mp hold
    refine ⟨i, hi, hui, ?_⟩
    intro hc
    rcases Finset.mem_insert.mp hui with heq | hleaf
    · exact ((undominated_insert G X v u).mp hu.1).2 (heq ▸ hc)
    · obtain ⟨w, huw, hw⟩ := hu.2
      have heq := A.leaf_neighbor hleaf huw
      exact ((undominated_insert G X v w).mp hw).2 (heq ▸ hc)
  · rintro ⟨i, hi, hui, hc⟩
    have hnot (z : V) (hz : z ∈ A.vertices i) : ¬ Closed G v z := by
      intro hclose
      exact hc ((A.closed_center_iff i v).mpr (A.closed_star_implies hz hclose))
    obtain ⟨w, hwi, huw⟩ := A.internal_neighbor hui
    exact (white_insert_iff G X v u).mpr
      ⟨(hR u).mpr ⟨i, hi, hui⟩, hnot u hui,
        w, huw, (hR w).mpr ⟨i, hi, hwi⟩, hnot w hwi⟩

noncomputable def remainingAfter (R : Finset I) (v : V) : Finset I := by
  classical
  exact R.filter (fun i => ¬ Closed G v (A.center i))

theorem represents_after {R : Finset I} {X : Finset V}
    (hR : A.Represents R X) (v : V) :
    A.Represents (A.remainingAfter R v) (insert v X) := by
  classical
  intro u
  rw [A.white_after_move hR v u]
  simp only [remainingAfter, Finset.mem_filter]
  constructor
  · rintro ⟨i, hi, hui, hc⟩
    exact ⟨i, ⟨hi, hc⟩, hui⟩
  · rintro ⟨i, ⟨hi, hc⟩, hui⟩
    exact ⟨i, hi, hui, hc⟩

theorem member_unique {i j : I} {u : V}
    (hi : u ∈ A.vertices i) (hj : u ∈ A.vertices j) : i = j := by
  by_contra h
  exact (Finset.disjoint_left.mp (A.disjoint i j h)) hi hj

variable [DecidableEq I]

theorem remainingAfter_star {j : I} {v : V} (hv : v ∈ A.vertices j) (R : Finset I) :
    A.remainingAfter R v = R.erase j := by
  classical
  ext i
  simp only [remainingAfter, Finset.mem_filter, Finset.mem_erase, A.closed_center_iff]
  constructor
  · rintro ⟨hi, hn⟩
    refine ⟨?_, hi⟩
    intro heq
    exact hn (Or.inl (heq ▸ hv))
  · rintro ⟨hij, hi⟩
    refine ⟨hi, ?_⟩
    rintro (hvi | hpar)
    · exact hij (A.member_unique hvi hv)
    · exact A.parent_outside i j (hpar ▸ hv)

theorem remainingAfter_parent (j : I) (R : Finset I) :
    A.remainingAfter R (A.parent j) = R.filter (fun i => A.parent i ≠ A.parent j) := by
  classical
  ext i
  have hn : A.parent j ∉ A.vertices i := A.parent_outside j i
  simp only [remainingAfter, Finset.mem_filter, A.closed_center_iff,
    hn, false_or, ne_eq]
  exact and_congr_right (fun _ => not_congr eq_comm)

/-- Exact quotient operations: remove a unit or all units of its group. -/
def Move (R Q : Finset I) : Prop :=
  ∃ i ∈ R, Q = R.erase i ∨ Q = R.filter (fun j => A.parent j ≠ A.parent i)

theorem real_move_maps {R : Finset I} {X : Finset V} {v : V}
    (hR : A.Represents R X) (hv : Legal G X v) : A.Move R (A.remainingAfter R v) := by
  rcases (A.legal_iff hR v).mp hv with ⟨i, hi, hv⟩ | ⟨i, hi, rfl⟩
  · exact ⟨i, hi, Or.inl (A.remainingAfter_star hv R)⟩
  · exact ⟨i, hi, Or.inr (A.remainingAfter_parent i R)⟩

theorem operation_realized {R Q : Finset I} {X : Finset V}
    (hR : A.Represents R X) (hm : A.Move R Q) :
    ∃ v, Legal G X v ∧ A.Represents Q (insert v X) := by
  obtain ⟨i, hi, hq | hq⟩ := hm
  · refine ⟨A.center i, (A.legal_iff hR _).mpr (Or.inl ⟨i, hi, A.center_mem i⟩), ?_⟩
    have h := A.represents_after hR (A.center i)
    rwa [A.remainingAfter_star (A.center_mem i), ← hq] at h
  · refine ⟨A.parent i, (A.legal_iff hR _).mpr (Or.inr ⟨i, hi, rfl⟩), ?_⟩
    have h := A.represents_after hR (A.parent i)
    rwa [A.remainingAfter_parent, ← hq] at h

end StarSystem
end IsolationGame
