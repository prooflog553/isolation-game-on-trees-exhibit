import IsolationGame.Basic
import Mathlib.Data.Fintype.Basic

namespace IsolationGame

variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

instance closedDecidable (v u : V) : Decidable (Closed G v u) := by
  unfold Closed
  infer_instance

instance dominatedDecidable (X : Finset V) (u : V) : Decidable (Dominated G X u) := by
  unfold Dominated
  infer_instance

instance undominatedDecidable (X : Finset V) (u : V) : Decidable (Undominated G X u) := by
  unfold Undominated
  infer_instance

instance whiteDecidable (X : Finset V) (u : V) : Decidable (White G X u) := by
  unfold White
  infer_instance

instance legalDecidable (X : Finset V) (v : V) : Decidable (Legal G X v) := by
  unfold Legal
  infer_instance

instance terminalDecidable (X : Finset V) : Decidable (Terminal G X) := by
  unfold Terminal
  infer_instance

end IsolationGame
