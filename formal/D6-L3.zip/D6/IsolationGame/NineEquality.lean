import IsolationGame.RootedBound
import IsolationGame.ExceptionalCases
import IsolationGame.Relabel
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Tactic.FinCases

namespace IsolationGame

variable {V I : Type*} [DecidableEq V] [DecidableEq I]

theorem three_units_two_groups (R : Finset I) (f : I → V)
    (hk : R.card = 3) (hb : (R.image f).card = 2) :
    ∃ i j k, i ≠ j ∧ i ≠ k ∧ j ≠ k ∧ R = {i, j, k} ∧ f i = f j ∧ f i ≠ f k := by
  obtain ⟨i, j, k, hij, hik, hjk, hR⟩ := Finset.card_eq_three.mp hk
  by_cases h₁ : f i = f j
  · have h₂ : f i ≠ f k := by
      intro h₂
      simp [hR, h₁, ← h₂] at hb
    exact ⟨i, j, k, hij, hik, hjk, hR, h₁, h₂⟩
  · by_cases h₂ : f i = f k
    · refine ⟨i, k, j, hik, hij, hjk.symm, ?_, h₂, h₁⟩
      ext x
      simp [hR, or_left_comm, or_assoc, or_comm]
    · have h₃ : f j = f k := by
        by_contra h₃
        simp [hR, h₁, h₂, h₃] at hb
      refine ⟨j, k, i, hjk, hij.symm, hik.symm, ?_, h₃, fun h => h₁ h.symm⟩
      ext x
      simp [hR, or_left_comm, or_assoc, or_comm]

def nineLabel (r a q u v w x y z : V) (s : Fin 9) : V :=
  match s.val with
  | 0 => r
  | 1 => a
  | 2 => q
  | 3 => u
  | 4 => v
  | 5 => w
  | 6 => x
  | 7 => y
  | _ => z

namespace Rooted

variable [Fintype V] {G : SimpleGraph V} (hT : G.IsTree) (r : V)

theorem nine_label_surjective (hr : RadiusThree G r)
    (i j k : Index (G := G) r)
    (hR : allIndices (G := G) r = {i, j, k})
    (hpar : parent hT r i = parent hT r j)
    (hcover : (system hT r hr).countedVertices r (allIndices (G := G) r) = Finset.univ) :
    Function.Surjective (nineLabel r (parent hT r i) (parent hT r k)
      i.val j.val k.val ((system hT r hr).chosenLeaf i)
      ((system hT r hr).chosenLeaf j) ((system hT r hr).chosenLeaf k)) := by
  intro v
  have hv : v ∈ (system hT r hr).countedVertices r (allIndices (G := G) r) := by
    rw [hcover]
    exact Finset.mem_univ v
  simp only [StarSystem.countedVertices, hR, Finset.image_insert, Finset.image_singleton,
    Finset.mem_insert, Finset.mem_singleton, Finset.mem_union] at hv
  change v = r ∨ (v = parent hT r i ∨ v = parent hT r j ∨ v = parent hT r k) ∨
    (v = i.val ∨ v = j.val ∨ v = k.val) ∨
    (v = (system hT r hr).chosenLeaf i ∨ v = (system hT r hr).chosenLeaf j ∨
      v = (system hT r hr).chosenLeaf k) at hv
  rcases hv with rfl | (rfl | rfl | rfl) | (rfl | rfl | rfl) | (rfl | rfl | rfl)
  all_goals first
    | exact ⟨0, rfl⟩
    | exact ⟨1, rfl⟩
    | exact ⟨1, hpar⟩
    | exact ⟨2, rfl⟩
    | exact ⟨3, rfl⟩
    | exact ⟨4, rfl⟩
    | exact ⟨5, rfl⟩
    | exact ⟨6, rfl⟩
    | exact ⟨7, rfl⟩
    | exact ⟨8, rfl⟩

set_option maxHeartbeats 2000000 in
theorem nine_adjacency (hr : RadiusThree G r) (i j k : Index (G := G) r)
    (hpar : parent hT r i = parent hT r j)
    (hsi : (system hT r hr).leaves i = {(system hT r hr).chosenLeaf i})
    (hsj : (system hT r hr).leaves j = {(system hT r hr).chosenLeaf j})
    (hsk : (system hT r hr).leaves k = {(system hT r hr).chosenLeaf k})
    (hf : Function.Injective (nineLabel r (parent hT r i) (parent hT r k)
      i.val j.val k.val ((system hT r hr).chosenLeaf i)
      ((system hT r hr).chosenLeaf j) ((system hT r hr).chosenLeaf k))) :
    ∀ s t, G.Adj
      (nineLabel r (parent hT r i) (parent hT r k) i.val j.val k.val
        ((system hT r hr).chosenLeaf i) ((system hT r hr).chosenLeaf j) ((system hT r hr).chosenLeaf k) s)
      (nineLabel r (parent hT r i) (parent hT r k) i.val j.val k.val
        ((system hT r hr).chosenLeaf i) ((system hT r hr).chosenLeaf j) ((system hT r hr).chosenLeaf k) t)
      ↔ Exceptional.nine.Adj s t := by
  let A := system hT r hr
  let f := nineLabel r (parent hT r i) (parent hT r k) i.val j.val k.val
    (A.chosenLeaf i) (A.chosenLeaf j) (A.chosenLeaf k)
  change Function.Injective f at hf
  change ∀ s t, G.Adj (f s) (f t) ↔ Exceptional.nine.Adj s t
  have hpi := (parent_spec hT r i).2
  have hpk := (parent_spec hT r k).2
  have hli := ((mem_leaves r i (A.chosenLeaf i)).mp (A.chosenLeaf_mem i)).2
  have hlj := ((mem_leaves r j (A.chosenLeaf j)).mp (A.chosenLeaf_mem j)).2
  have hlk := ((mem_leaves r k (A.chosenLeaf k)).mp (A.chosenLeaf_mem k)).2
  have row0 (s : Fin 9) : G.Adj (f s) (f 0) ↔ s = 1 ∨ s = 2 := by
    change G.Adj (f s) r ↔ _
    rw [← SimpleGraph.dist_eq_one_iff_adj]
    fin_cases s <;> simp [f, nineLabel, hpi, hpk, i.property.1, j.property.1, k.property.1, hli, hlj, hlk]
  have row3 (s : Fin 9) : G.Adj (f s) (f 3) ↔ s = 6 ∨ s = 1 := by
    change G.Adj (f s) (A.center i) ↔ _
    rw [A.adj_center_singleton i hsi]
    change (f s = f 6 ∨ f s = f 1) ↔ _
    simp only [hf.eq_iff]
  have row4 (s : Fin 9) : G.Adj (f s) (f 4) ↔ s = 7 ∨ s = 1 := by
    change G.Adj (f s) (A.center j) ↔ _
    rw [A.adj_center_singleton j hsj]
    change (f s = A.chosenLeaf j ∨ f s = parent hT r j) ↔ _
    rw [← hpar]
    change (f s = f 7 ∨ f s = f 1) ↔ _
    simp only [hf.eq_iff]
  have row5 (s : Fin 9) : G.Adj (f s) (f 5) ↔ s = 8 ∨ s = 2 := by
    change G.Adj (f s) (A.center k) ↔ _
    rw [A.adj_center_singleton k hsk]
    change (f s = f 8 ∨ f s = f 2) ↔ _
    simp only [hf.eq_iff]
  have row6 (s : Fin 9) : G.Adj (f s) (f 6) ↔ s = 3 := by
    change G.Adj (f s) (A.chosenLeaf i) ↔ _
    rw [A.adj_chosenLeaf i]
    change (f s = f 3) ↔ _
    exact hf.eq_iff
  have row7 (s : Fin 9) : G.Adj (f s) (f 7) ↔ s = 4 := by
    change G.Adj (f s) (A.chosenLeaf j) ↔ _
    rw [A.adj_chosenLeaf j]
    change (f s = f 4) ↔ _
    exact hf.eq_iff
  have row8 (s : Fin 9) : G.Adj (f s) (f 8) ↔ s = 5 := by
    change G.Adj (f s) (A.chosenLeaf k) ↔ _
    rw [A.adj_chosenLeaf k]
    change (f s = f 5) ↔ _
    exact hf.eq_iff
  have col0 (s : Fin 9) : G.Adj (f 0) (f s) ↔ s = 1 ∨ s = 2 :=
    (G.adj_comm _ _).trans (row0 s)
  have col3 (s : Fin 9) : G.Adj (f 3) (f s) ↔ s = 6 ∨ s = 1 :=
    (G.adj_comm _ _).trans (row3 s)
  have col4 (s : Fin 9) : G.Adj (f 4) (f s) ↔ s = 7 ∨ s = 1 :=
    (G.adj_comm _ _).trans (row4 s)
  have col5 (s : Fin 9) : G.Adj (f 5) (f s) ↔ s = 8 ∨ s = 2 :=
    (G.adj_comm _ _).trans (row5 s)
  have col6 (s : Fin 9) : G.Adj (f 6) (f s) ↔ s = 3 :=
    (G.adj_comm _ _).trans (row6 s)
  have col7 (s : Fin 9) : G.Adj (f 7) (f s) ↔ s = 4 :=
    (G.adj_comm _ _).trans (row7 s)
  have col8 (s : Fin 9) : G.Adj (f 8) (f s) ↔ s = 5 :=
    (G.adj_comm _ _).trans (row8 s)
  have hn12 : ¬ G.Adj (f 1) (f 2) := by
    intro h
    have hh := tree_adj_levels hT r h
    change G.dist (parent hT r i) r = G.dist (parent hT r k) r + 1 ∨
      G.dist (parent hT r k) r = G.dist (parent hT r i) r + 1 at hh
    omega
  have hn21 : ¬ G.Adj (f 2) (f 1) := fun h => hn12 h.symm
  intro s t
  fin_cases s <;> fin_cases t <;>
    simp [row0, row3, row4, row5, row6, row7, row8,
      col0, col3, col4, col5, col6, col7, col8, hn12, hn21, Exceptional.nine]

theorem nine_equality_bound (hr : RadiusThree G r)
    (hn : Fintype.card V = 9)
    (hb : ((allIndices (G := G) r).image (system hT r hr).parent).card = 2)
    (hk : (allIndices (G := G) r).card = 3) : isolationNumber G ≤ 3 := by
  classical
  let A := system hT r hr
  let R := allIndices (G := G) r
  have hcover : A.countedVertices r R = Finset.univ :=
    A.countedVertices_eq_univ r R (root_outside_stars hT r hr) (root_ne_parent hT r hr)
      (by dsimp [A, R]; omega)
  obtain ⟨i, j, k, hij, hik, hjk, hR, hpar, hneq⟩ := three_units_two_groups R A.parent hk hb
  let f := nineLabel r (parent hT r i) (parent hT r k) i.val j.val k.val
    (A.chosenLeaf i) (A.chosenLeaf j) (A.chosenLeaf k)
  have hsurj : Function.Surjective f := nine_label_surjective hT r hr i j k hR hpar hcover
  have hbij : Function.Bijective f := (Fintype.bijective_iff_surjective_and_card f).mpr
    ⟨hsurj, by simp [hn]⟩
  have hsi := A.leaves_singleton_of_cover r R (root_outside_stars hT r hr) hcover
    (show i ∈ R by simp [hR])
  have hsj := A.leaves_singleton_of_cover r R (root_outside_stars hT r hr) hcover
    (show j ∈ R by simp [hR])
  have hsk := A.leaves_singleton_of_cover r R (root_outside_stars hT r hr) hcover
    (show k ∈ R by simp [hR])
  let e : Fin 9 ≃ V := Equiv.ofBijective f hbij
  have hadj : ∀ s t, G.Adj (e s) (e t) ↔ Exceptional.nine.Adj s t :=
    nine_adjacency hT r hr i j k hpar hsi hsj hsk hbij.1
  exact isolation_bound_relabel Exceptional.nine G e hadj Exceptional.nine_three_moves

end Rooted
end IsolationGame
