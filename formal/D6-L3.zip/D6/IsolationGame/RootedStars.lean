import IsolationGame.TreeLevels
import IsolationGame.StarReduction
import Mathlib.Data.Fintype.Card

namespace IsolationGame.Rooted

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {G : SimpleGraph V} (hT : G.IsTree) (r : V)

abbrev Index := {u : V // G.dist u r = 2 ∧ ∃ z, G.Adj u z ∧ G.dist z r = 3}

theorem index_ne_root (i : Index (G := G) r) : i.val ≠ r := by
  intro heq
  have hi := i.property.1
  rw [heq, SimpleGraph.dist_self] at hi
  omega

noncomputable def parent (i : Index (G := G) r) : V :=
  Classical.choose (exists_unique_parent hT r (index_ne_root r i)).exists

theorem parent_spec (i : Index (G := G) r) :
    G.Adj i.val (parent hT r i) ∧ G.dist (parent hT r i) r = 1 := by
  have h := Classical.choose_spec (exists_unique_parent hT r (index_ne_root r i)).exists
  change G.Adj i.val (parent hT r i) ∧
    G.dist (parent hT r i) r + 1 = G.dist i.val r at h
  exact ⟨h.1, by have := i.property.1; omega⟩

noncomputable def leaves (i : Index (G := G) r) : Finset V := by
  classical
  exact Finset.univ.filter (fun z => G.Adj i.val z ∧ G.dist z r = 3)

theorem mem_leaves (i : Index (G := G) r) (z : V) :
    z ∈ leaves r i ↔ G.Adj i.val z ∧ G.dist z r = 3 := by
  classical
  simp [leaves]

theorem mem_vertices_depth (i : Index (G := G) r) {u : V}
    (hu : u ∈ insert i.val (leaves r i)) : G.dist u r = 2 ∨ G.dist u r = 3 := by
  rcases Finset.mem_insert.mp hu with rfl | hu
  · exact Or.inl i.property.1
  · exact Or.inr ((mem_leaves r i u).mp hu).2

include hT in
theorem vertices_disjoint (i j : Index (G := G) r) (hij : i ≠ j) :
    Disjoint (insert i.val (leaves r i)) (insert j.val (leaves r j)) := by
  apply Finset.disjoint_left.mpr
  intro u hui huj
  apply hij
  apply Subtype.ext
  rcases Finset.mem_insert.mp hui with hi | hi <;>
    rcases Finset.mem_insert.mp huj with hj | hj
  · exact hi.symm.trans hj
  · have hd := ((mem_leaves r j u).mp hj).2
    have hi2 := i.property.1
    rw [hi] at hd
    omega
  · have hd := ((mem_leaves r i u).mp hi).2
    have hj2 := j.property.1
    rw [hj] at hd
    omega
  · have hi' := (mem_leaves r i u).mp hi
    have hj' := (mem_leaves r j u).mp hj
    exact unique_lower_neighbor hT r hi'.1.symm hj'.1.symm
      (by have := i.property.1; omega) (by have := j.property.1; omega)

theorem star_adjacency (hr : RadiusThree G r) (i : Index (G := G) r)
    (u : V) (hu : u ∈ insert i.val (leaves r i)) (v : V) :
    G.Adj v u ↔ (v = i.val ∧ u ∈ leaves r i) ∨
      (v ∈ leaves r i ∧ u = i.val) ∨ (v = parent hT r i ∧ u = i.val) := by
  constructor
  · intro hvu
    rcases Finset.mem_insert.mp hu with rfl | hu
    · have hd := tree_adj_levels hT r hvu
      have hi := i.property.1
      rcases hd with hd | hd
      · exact Or.inr (Or.inl ⟨(mem_leaves r i v).mpr ⟨hvu.symm, by omega⟩, rfl⟩)
      · have hpar := parent_spec hT r i
        have heq := unique_lower_neighbor hT r hvu.symm hpar.1
          (by omega) (by omega)
        exact Or.inr (Or.inr ⟨heq, rfl⟩)
    · have hleaf := (mem_leaves r i u).mp hu
      have heq := depth_three_unique_neighbor hT hr hleaf.2 hvu.symm hleaf.1.symm
      exact Or.inl ⟨heq, hu⟩
  · rintro (⟨rfl, hu⟩ | ⟨hv, rfl⟩ | ⟨rfl, rfl⟩)
    · exact ((mem_leaves r i u).mp hu).1
    · exact ((mem_leaves r i v).mp hv).1.symm
    · exact (parent_spec hT r i).1.symm

/-- Construct the precise star-neighborhood structure from a rooted tree
    whose root has eccentricity at most three. -/
noncomputable def system (hr : RadiusThree G r) : StarSystem G (Index (G := G) r) := by
  classical
  exact {
    center := Subtype.val
    parent := parent hT r
    leaves := leaves r
    leaves_nonempty := fun i => by
      obtain ⟨z, hz⟩ := i.property.2
      exact ⟨z, (mem_leaves r i z).mpr hz⟩
    center_not_leaf := fun i h => by
      have hd := ((mem_leaves r i i.val).mp h).2
      have hi := i.property.1
      omega
    disjoint := vertices_disjoint hT r
    parent_outside := fun i j h => by
      have hd := mem_vertices_depth r j h
      have hp := (parent_spec hT r i).2
      omega
    adj_iff := star_adjacency hT r hr }

noncomputable def allIndices : Finset (Index (G := G) r) := by
  classical
  letI : Fintype (Index (G := G) r) := by unfold Index; infer_instance
  exact Finset.univ

theorem initial_represents (hr : RadiusThree G r) :
    (system hT r hr).Represents (allIndices r) {r} := by
  classical
  intro u
  have hU (z : V) : Undominated G {r} z ↔ 2 ≤ G.dist z r :=
    undominated_root_iff hT r z
  constructor
  · rintro ⟨hu, w, huw, hw⟩
    have hdu := (hU u).mp hu
    have hdw := (hU w).mp hw
    have hbu := radiusThree_reverse hr u
    have hbw := radiusThree_reverse hr w
    rcases tree_adj_levels hT r huw with hd | hd
    · let i : Index (G := G) r := ⟨w, by omega, u, huw.symm, by omega⟩
      refine ⟨i, by simp [allIndices], ?_⟩
      apply Finset.mem_insert_of_mem
      exact (mem_leaves r i u).mpr ⟨huw.symm, by omega⟩
    · let i : Index (G := G) r := ⟨u, by omega, w, huw, by omega⟩
      exact ⟨i, by simp [allIndices], Finset.mem_insert_self _ _⟩
  · rintro ⟨i, _, hui⟩
    obtain ⟨w, hwi, huw⟩ := (system hT r hr).internal_neighbor hui
    have hdu := mem_vertices_depth r i hui
    have hdw := mem_vertices_depth r i hwi
    exact ⟨(hU u).mpr (by omega), w, huw, (hU w).mpr (by omega)⟩

end IsolationGame.Rooted
