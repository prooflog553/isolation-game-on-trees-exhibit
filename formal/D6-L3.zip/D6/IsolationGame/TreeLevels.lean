import Mathlib.Combinatorics.SimpleGraph.Acyclic
import Mathlib.Combinatorics.SimpleGraph.Diam

namespace IsolationGame

variable {V : Type*} {G : SimpleGraph V}

/-- Every simple path in a tree is the unique shortest path. -/
theorem tree_path_length_eq_dist (hT : G.IsTree) {u v : V}
    (p : G.Walk u v) (hp : p.IsPath) : p.length = G.dist u v := by
  obtain ⟨q, hq, hlen⟩ := hT.isConnected.exists_path_of_dist u v
  have heq := hT.IsAcyclic.path_unique ⟨p, hp⟩ ⟨q, hq⟩
  have hpq : p = q := congrArg Subtype.val heq
  exact hpq ▸ hlen

def Level (G : SimpleGraph V) (r : V) (i : Nat) : Set V :=
  {v | G.dist r v = i}

def RadiusThree (G : SimpleGraph V) (r : V) : Prop := ∀ v, G.dist r v ≤ 3

theorem level_zero (hT : G.IsTree) (r : V) : Level G r 0 = {r} := by
  ext v
  simp only [Level, Set.mem_setOf_eq, Set.mem_singleton_iff]
  rw [(hT.isConnected r v).dist_eq_zero_iff]
  exact eq_comm

/-- Every edge joins successive distance levels in a tree. -/
theorem tree_adj_levels (hT : G.IsTree) (r : V) {u v : V} (h : G.Adj u v) :
    G.dist u r = G.dist v r + 1 ∨ G.dist v r = G.dist u r + 1 := by
  classical
  obtain ⟨p, hp, hlen⟩ := hT.isConnected.exists_path_of_dist u r
  by_cases hv : v ∈ p.support
  · have hpre := tree_path_length_eq_dist hT (p.takeUntil v hv) (hp.takeUntil hv)
    have hpost := tree_path_length_eq_dist hT (p.dropUntil v hv) (hp.dropUntil hv)
    have hadj := SimpleGraph.dist_eq_one_iff_adj.mpr h
    have hsplit := congrArg SimpleGraph.Walk.length (p.take_spec hv)
    simp only [SimpleGraph.Walk.length_append] at hsplit
    exact Or.inl (by omega)
  · have hnew := tree_path_length_eq_dist hT (p.cons h.symm) (hp.cons hv)
    simp only [SimpleGraph.Walk.length_cons] at hnew
    exact Or.inr (by omega)

theorem unique_lower_neighbor (hT : G.IsTree) (r : V) {u v w : V}
    (hv : G.Adj u v) (hw : G.Adj u w)
    (hdv : G.dist v r + 1 = G.dist u r)
    (hdw : G.dist w r + 1 = G.dist u r) : v = w := by
  classical
  obtain ⟨p, hp, hplen⟩ := hT.isConnected.exists_path_of_dist v r
  obtain ⟨q, hq, hqlen⟩ := hT.isConnected.exists_path_of_dist w r
  have hpu : u ∉ p.support := by
    intro hu
    have h₁ := SimpleGraph.dist_le (p.dropUntil u hu)
    have h₂ := p.length_dropUntil_le hu
    omega
  have hqu : u ∉ q.support := by
    intro hu
    have h₁ := SimpleGraph.dist_le (q.dropUntil u hu)
    have h₂ := q.length_dropUntil_le hu
    omega
  have heq := hT.IsAcyclic.path_unique ⟨p.cons hv, hp.cons hpu⟩ ⟨q.cons hw, hq.cons hqu⟩
  have heq' := congrArg (fun z : G.Path u r => z.val.getVert 1) heq
  simpa using heq'

theorem exists_unique_parent (hT : G.IsTree) (r : V) {u : V} (hu : u ≠ r) :
    ∃! v, G.Adj u v ∧ G.dist v r + 1 = G.dist u r := by
  obtain ⟨p, hp, hlen⟩ := hT.isConnected.exists_path_of_dist u r
  cases p with
  | nil => exact False.elim (hu rfl)
  | @cons u v r huv p =>
    have ht := tree_path_length_eq_dist hT p hp.of_cons
    simp only [SimpleGraph.Walk.length_cons] at hlen
    refine ⟨v, ⟨huv, by omega⟩, ?_⟩
    intro w hw
    exact unique_lower_neighbor hT r hw.1 huv hw.2 (by omega)

theorem radiusThree_reverse {r : V} (hr : RadiusThree G r) (v : V) : G.dist v r ≤ 3 := by
  rw [G.dist_comm]
  exact hr v

theorem depth_three_unique_neighbor (hT : G.IsTree) {r u v w : V}
    (hr : RadiusThree G r) (hu : G.dist u r = 3)
    (hv : G.Adj u v) (hw : G.Adj u w) : v = w := by
  have hdv := tree_adj_levels hT r hv
  have hdw := tree_adj_levels hT r hw
  have hbv := radiusThree_reverse hr v
  have hbw := radiusThree_reverse hr w
  exact unique_lower_neighbor hT r hv hw (by omega) (by omega)

theorem undominated_root_iff (hT : G.IsTree) [DecidableEq V] (r u : V) :
    (¬ ∃ v ∈ ({r} : Finset V), u = v ∨ G.Adj v u) ↔ 2 ≤ G.dist u r := by
  simp only [Finset.mem_singleton, exists_eq_left]
  have h0 := hT.isConnected.dist_eq_zero_iff (u := u) (v := r)
  have h1 := G.dist_eq_one_iff_adj (u := u) (v := r)
  have hs : G.Adj r u ↔ G.Adj u r := ⟨SimpleGraph.Adj.symm, SimpleGraph.Adj.symm⟩
  rw [hs, ← h0, ← h1]
  omega

end IsolationGame
