"""Check the 239-row supplement and the 2,745-row TSV, using only supplied files.
This checks finite data, not all-parameter proofs, authorship, or peer review.
Run with ordinary Python 3, not python -O (assertions are required).
"""
import ast
import csv
import json
from pathlib import Path
P = Path(__file__).resolve().parent
data = {}
name = None
for line in (P / 'finite_strategy_certificate_supplement.md').read_text(encoding='utf-8').splitlines():
    if line.startswith('## ') and line[3:] in {'00', '03', '07', '10', '15', 'O'}:
        name = line[3:]
        assert name not in data
        data[name] = {'rows': {}}
    elif line.startswith('Edges: '):
        data[name]['edges'] = ast.literal_eval(line[len('Edges: '):])
    elif line.startswith('|') and name and line.split('|')[1] not in ['M', '---']:
        _, mask, d, s, best, transitions, _ = line.split('|')
        successors = {}
        if transitions != 'terminal':
            for item in transitions.split('; '):
                a, b = item.split('→')
                assert int(a) not in successors
                successors[int(a)] = int(b, 16)
        m = int(mask, 16)
        assert m not in data[name]['rows']
        data[name]['rows'][m] = (int(d), int(s), None if best == '—' else int(best), successors)
counts = {}
for name, n in {'00': 1, '03': 10, '07': 8, '10': 3, '15': 8, 'O': 7}.items():
    entry = data[name]
    adj = {v: set() for v in range(n)}
    for a, b in entry['edges']:
        assert a in adj and b in adj and a != b
        adj[a].add(b)
        adj[b].add(a)
    rows = entry['rows']
    reached, todo = set(), [0, 1]
    while todo:
        m = todo.pop()
        if m in reached:
            continue
        reached.add(m)
        assert m in rows
        todo.extend(rows[m][3].values())
    assert reached == set(rows)
    for m, (d, s, best, successors) in rows.items():
        assert 0 <= m < 2**n
        marked = {v for v in adj if m & (1 << v)}
        white = {v for v in adj if v not in marked and adj[v] - marked}
        legal = {v for v in adj if (adj[v] | {v}) & white}
        assert set(successors) == legal
        for v, nxt in successors.items():
            assert nxt == sum(1 << u for u in marked | adj[v] | {v})
            assert nxt in rows and nxt != m
        if not legal:
            assert (d, s, best) == (0, 0, None)
        else:
            assert d == 1 + min(rows[z][1] for z in successors.values())
            assert s == 1 + max(rows[z][0] for z in successors.values())
            optimal = [v for v in sorted(legal) if d == 1 + rows[successors[v]][1]]
            assert best == optimal[0]
    counts[name] = len(rows)
assert sum(counts.values()) == 239
F = P / 'finite_certificates'
certs = json.loads((F / 'local_certificate.json').read_text(encoding='utf-8'))
expected = {(f"t{c['t']:02}", str(s['mask'])): s for c in certs for s in c['states']}
seen = set()
with (F / 'state_dag.tsv').open(encoding='utf-8', newline='') as f:
    for row in csv.DictReader(f, delimiter='\t'):
        key = (row['type'], row['mask'])
        assert key not in seen
        seen.add(key)
        st = expected[key]
        assert (int(row['D']), int(row['S'])) == (st['D'], st['S'])
        assert row['marked_vertices'] == ','.join(str(v) for v in range(st['mask'].bit_length()) if st['mask'] & (1 << v))
        assert row['original_vertex:next_mask'] == ';'.join(f'{v}:{z}' for v, z in st['moves'])
assert seen == set(expected) and len(seen) == 2745
print(json.dumps({'status': 'PASS', 'supplement_rows': counts, 'total_supplement_rows': 239, 'tsv_rows': len(seen), 'scope': 'Finite tables only; not an all-parameter proof or human review.'}))
