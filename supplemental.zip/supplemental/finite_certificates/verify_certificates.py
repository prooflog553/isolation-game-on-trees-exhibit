"""Verify supplied evidence independently: no call/import of generator or Lean."""
import json,csv,itertools,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent
G=json.loads((P/'graphs.json').read_text()); C=json.loads((P/'local_certificate.json').read_text())
assert [g['t'] for g in G]==list(range(20))==[c['t'] for c in C]
total=0
for g,c in zip(G,C):
 V=set(range(g['n']));N={v:{v} for v in V}
 assert len(g['edges'])==g['n']-1
 for a,b in g['edges']:
  assert a in V and b in V and a!=b
  N[a].add(b);N[b].add(a)
 def decode(m):
  assert 0<=m<2**g['n']
  return {v for v in V if m&(1<<v)}
 def encode(s):return sum(1<<v for v in s)
 def legal(m):
  M=decode(m);U=V-M
  W={v for v in U if (N[v]-{v})&U}
  return {v:encode(M|N[v]) for v in V if N[v]&W}
 S={s['mask']:s for s in c['states']};assert len(S)==len(c['states'])
 reached={0,1};todo=[0,1]
 while todo:
  m=todo.pop();assert m in S
  st=S[m];mov=legal(m);assert st['moves']==[[v,z] for v,z in sorted(mov.items())]
  for v,z in mov.items():
   assert decode(m)<decode(z) and z in S
   if z not in reached:reached.add(z);todo.append(z)
  if mov:
   assert st['D']==1+min(S[z]['S'] for z in mov.values())
   assert st['S']==1+max(S[z]['D'] for z in mov.values())
  else:assert st['D']==st['S']==0
 assert reached==set(S)
 def strict(m,B):return S[m]['D']+1<=B and all(S[z]['S']+1<=B for z in legal(m).values())
 assert len(c['starts'])==2
 for start,name,m,B,flag,kind in zip(c['starts'],['root','white'],[1,0],[g['c'],g['c']+g['e']],[g['a'],g['b']],['strict','reply']):
  assert (start['name'],start['mask'],start['capacity'],start['flag'],start['kind'])==(name,m,B,flag,kind)
  assert start['D']==S[m]['D'] and start['S']==S[m]['S']==B
  assert start['strict']==strict(m,B)
  assert [r['v'] for r in start['first']]==list(legal(m))
  for r in start['first']:
   z=legal(m)[r['v']];assert (r['next'],r['D'],r['S'])==(z,S[z]['D'],S[z]['S'])
   good=S[z]['S']+1<=B;assert r['good']==good
   if flag:
    assert S[m]['D']+1<=B
    if not good:
     assert kind=='reply' and r['reply'] in legal(z)
     assert strict(legal(z)[r['reply']],B-2)
  if flag and kind=='strict':assert strict(m,B)
 total+=len(S)
# Verify exhaustive classification coverage, every rejection, and exactly the stated 14.
ids=set(range(20))-{2}
def key(a,b):return (a,b) if (len(a),a)<=(len(b),b) else (b,a)
expected=set()
for n in range(4):
 for word in itertools.product(sorted(ids),repeat=n):
  for split in range(n+1):expected.add(key(tuple(sorted(word[:split])),tuple(sorted(word[split:]))))
def score(x,y):
 return 7*(sum(G[i]['c'] for i in x+y)+sum(G[i]['e'] for i in y)-(sum(G[i]['a'] for i in x)+sum(G[i]['b'] for i in y))//2)-3*sum(G[i]['n'] for i in x+y)
actual=set();kept=[]
for r in csv.DictReader((P/'classification_all.csv').open()):
 x=tuple(map(int,filter(None,r['left'].split(','))));y=tuple(map(int,filter(None,r['right'].split(','))))
 assert (x,y) not in actual;actual.add((x,y))
 L,R=score(x,y),score(y,x);assert (int(r['sL']),int(r['sR']))==(L,R)
 reason='all_t01_left' if all(i==1 for i in x) else 'all_t01_right' if all(i==1 for i in y) else 'left_score' if L<-1 else 'right_score' if R<-1 else 'KEEP'
 assert r['reason']==reason
 if reason=='KEEP':kept.append((x,y))
assert actual==expected
assert set(kept)=={((0,),(8,)),((3,),(8,)),((3,),(12,)),((7,),(8,)),((8,),(10,)),((8,),(15,)),((10,),(12,)),((15,),(15,)),((15,),(16,)),((15,),(19,)),((8,),(1,8)),((8,),(8,8)),((15,),(3,15)),((15,),(10,15))}
result={'status':'PASS','reachable_states':total,'classification_candidates':len(actual),'survivors':len(kept),'scope':'Finite local graphs and bounded profile-list classification only; not an all-parameter receiver proof.'}
print(json.dumps(result,ensure_ascii=False))
