# License scope of the finite reproduction package

The following notices apply only to the material listed.

## MIT: verifier programs

- [`supplemental/verify_supplement.py`](supplemental/verify_supplement.py)
- [`supplemental/finite_certificates/verify_certificates.py`](supplemental/finite_certificates/verify_certificates.py)

[MIT license text and copyright notice](LICENSES/MIT.txt).

## CC BY 4.0: finite data and explanatory supplement

- [`supplemental/finite_certificates/graphs.json`](supplemental/finite_certificates/graphs.json)
- [`supplemental/finite_certificates/local_certificate.json`](supplemental/finite_certificates/local_certificate.json)
- [`supplemental/finite_certificates/classification_all.csv`](supplemental/finite_certificates/classification_all.csv)
- [`supplemental/finite_certificates/state_dag.tsv`](supplemental/finite_certificates/state_dag.tsv)
- [`supplemental/finite_strategy_certificate_supplement.md`](supplemental/finite_strategy_certificate_supplement.md)

[CC BY 4.0 legal code](LICENSES/CC-BY-4.0.txt). Attribution: Isolation Game on Trees archive (prooflog553). Archive curation and maintenance: Cen Yi (岑弈). Neither line is a manuscript byline. The license covers only applicable rights; it does not extend to third-party materials or imply rights in facts.
